// AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
// Source: ha-latter/frontend_src/src/ (build via `node ha-latter/frontend_src/build.mjs`).
const __latterMods = new Map();
const __latterCache = new Map();
function __latterDef(id, factory) { __latterMods.set(id, factory); }
function __latterExp(target, getters) {
  for (const k of Object.keys(getters)) {
    Object.defineProperty(target, k, { enumerable: true, configurable: true, get: getters[k] });
  }
}
function __latterStar(target, src) {
  for (const k of Object.keys(src)) {
    if (k !== "default" && !(k in target)) {
      Object.defineProperty(target, k, { enumerable: true, configurable: true, get: () => src[k] });
    }
  }
}
function __latterReq(id) {
  let exp = __latterCache.get(id);
  if (exp !== undefined) return exp;
  const factory = __latterMods.get(id);
  if (!factory) throw new Error(`Missing Studio module: ${id}`);
  exp = Object.create(null);
  __latterCache.set(id, exp);
  factory(exp, __latterReq);
  return exp;
}
__latterDef("src/i18n/en-common.ts", (__exports, __req) => {
/**
 * Shared shell, navigation, action, status, combobox, sync, & Repairs strings (`D-061` — HA Sentence case).
 */
const EN_COMMON_STRINGS = {
  // Shell & navigation
  "shell.title": "Latter",
  "shell.toggle_ha_sidebar": "Toggle the Home Assistant sidebar",
  "shell.install_update": "Install update",
  "shell.rev_updated_banner": "Latter Studio was updated — reload page",
  "shell.reload_page": "Reload page",
  "shell.loading": "Loading Latter…",
  "shell.loading_device": "Loading Device…",
  "shell.retry": "Retry",
  "shell.saved_status": "Saved",
  "shell.dismiss_toast": "Dismiss notification",
  "nav.scope_label": "Scope",
  "nav.devices": "Devices",
  "nav.system": "System",
  "nav.managed": "Managed",
  "nav.discovered": "Discovered",
  "nav.back_managed": "← Managed",
  "nav.device_pages_label": "Device pages",
  "nav.system_pages_label": "System pages",
  "nav.devices_list_label": "Devices",
  // View titles (HA Sentence case; proper/IT nouns preserved)
  "view.system_overview": "Overview",
  "view.shared_entities": "Shared entities",
  "view.remotes": "Media & remotes",
  "view.system_sync": "Device groups",
  "view.area_tracking": "BLE & Area presence",
  "view.system_tools": "Tools",
  "view.select_device_prompt": "Managed devices",
  "view.discovered_devices": "Discovered devices",
  "view.dashboard": "Overview",
  "view.display": "Display",
  "view.interface": "Interface",
  "view.audio_voice": "Audio",
  "view.power": "Power",
  "view.presence": "Presence",
  "view.tools": "Tools",
  // Common actions & labels
  "action.cancel": "Cancel",
  "action.confirm": "Confirm",
  "action.done": "Done",
  "action.close": "Close",
  "action.save": "Save",
  "action.apply": "Apply",
  "action.reset": "Reset",
  "action.edit": "Edit",
  "action.delete": "Delete",
  "action.remove": "Remove",
  "action.add": "Add",
  "action.adopt": "Adopt",
  "action.ignore": "Ignore",
  "action.unignore": "Restore",
  "action.configure": "Configure",
  "action.run": "Run",
  "action.install": "Install",
  "action.use": "Use",
  "action.copy": "Copy",
  "action.clear": "Clear",
  "action.download": "Download",
  "action.refresh": "Refresh",
  "action.pause": "Pause",
  "action.resume": "Resume",
  "action.dismiss": "Dismiss",
  "action.open_in_ha": "Open in Home Assistant",
  "action.open_in_esphome": "Open in ESPHome",
  "action.open_integration": "Open integration",
  "action.open_repairs": "Open Repairs",
  "action.open_ha_logs": "Open Home Assistant logs",
  "action.open_shared_entities": "Open shared entities",
  "action.download_backup": "Download backup",
  "action.download_backup_first": "Download backup first",
  "action.restore_backup": "Restore backup",
  "action.download_diagnostics": "Download diagnostics",
  "action.add_custom_shortcut": "Add custom shortcut",
  "action.add_pinned_item": "Add pinned item",
  "action.reset_default_dock": "Reset default dock",
  "action.save_custom_group": "Save custom group",
  "action.save_group": "Save group",
  "action.save_shortcut": "Save shortcut",
  "action.save_color": "Save color",
  "action.add_custom_color": "Add custom color",
  "action.add_ble_tag": "Add BLE tag",
  "action.manage_groups": "Manage groups",
  "action.check_updates": "Check for updates",
  "action.default_icon": "Default icon",
  "action.move_up": "Move {item} up",
  "action.move_down": "Move {item} down",
  "action.move_earlier": "Move {item} earlier",
  "action.move_later": "Move {item} later",
  "action.drag_reorder": "Drag to reorder {item}",
  "action.remove_item": "Remove {item}",
  "action.edit_item": "Edit {item}",
  "action.configure_item": "Configure {item}",
  "common.none": "None",
  "common.none_option": "— None —",
  "common.none_configured": "None configured",
  "common.unassigned": "Unassigned",
  "common.no_person": "No person",
  "common.custom": "Custom",
  "common.auto": "Auto",
  "common.mixed": "Mixed",
  "common.active": "Active",
  "common.enabled": "Enabled",
  "common.disabled": "Disabled",
  "common.all_off": "All off",
  "common.loading": "Loading…",
  "common.unknown": "—",
  "common.missing_suffix": "{id} (missing)",
  "common.reordered_status": "Moved {item} to position {position} of {total}",
  "common.keep_one_enabled": "Keep at least one {noun} enabled",
  // Status & signal labels
  "status.online": "Online",
  "status.offline": "Offline",
  "status.update": "Update available",
  "status.up_to_date": "Up to date",
  "status.not_reported": "Not reported",
  "status.away": "Away",
  "status.scanning": "Scanning",
  "status.sleeping": "Sleeping",
  "status.hibernating": "Hibernating",
  "status.charging": "Charging",
  "status.plugged_in": "Plugged in",
  "status.on_battery": "On battery",
  "status.always_on": "Always on",
  "status.sleep_wake_active": "Sleep & wake active",
  "status.stationary": "Stationary",
  "status.roaming": "Roaming",
  "status.phone": "Phone",
  "status.ble_tag": "BLE tag",
  "status.needs_attention": "Needs attention",
  "status.pin_configured": "PIN configured",
  "status.pin_not_set": "Not set",
  "signal.no_reading": "No reading",
  "signal.excellent": "Excellent",
  "signal.good": "Good",
  "signal.fair": "Fair",
  "signal.weak": "Weak",
  // WAI-ARIA entity combobox (D-062 / Q11)
  "combobox.placeholder": "Search name, Area, or entity ID…",
  "combobox.no_matches": "No matching entities",
  "combobox.clear": "Clear selection",
  "combobox.showing_top": "Showing top {shown} of {total} matches",
  // Sync, timeouts & optimistic concurrency (D-064)
  "sync.conflict_reloaded": "Settings changed in another session; refreshed latest state.",
  "sync.restarting_device": "Restarting Device…",
  "sync.hibernating_device": "Hibernating Device…",
  "sync.triggered_action": "Triggered \"{label}\"",
  "sync.device_not_found": "Requested Device was not found; showing Managed devices.",
  "sync.save_device_failed": "Could not save Device settings",
  "sync.save_device_named_failed": "Could not save settings for \"{title}\": {error}",
  "sync.save_system_failed": "Could not save System settings",
  "sync.timeout_error": "Request timed out — check your Home Assistant connection and try again.",
  // Repairs fallback messages
  "issue.link_ma_player": "Not linked to its Music Assistant player.",
  "issue.missing_mapped_entity": "A chosen entity no longer exists.",
  "issue.missing_mapped_entity_detail": "A chosen entity no longer exists: {detail}.",
  "issue.ble_no_proxies":
    "BLE Area tracking is on, but no Bluetooth proxy is assigned to an Area.",
  "issue.slot_push_failing": "Latter cannot send Area and browse pages to this Device.",
  "issue.device_crashed": "Restarted after a crash.",
  "issue.device_crashed_detail": "Restarted after a crash ({detail}).",
  "issue.device_crashed_stall":
    "Restarted itself after its main loop stalled for 30 seconds.",
  "issue.device_brownout": "Restarted after a power dip (brownout).",
  "issue.firmware_rolled_back":
    "A firmware update failed to start; the previous firmware is running.",
  "issue.generic": "Repair: {label}.",
};
__latterExp(__exports, { EN_COMMON_STRINGS: () => EN_COMMON_STRINGS });
//# sourceURL=latter-studio/src/i18n/en-common.ts
});
__latterDef("src/i18n/en-devices.ts", (__exports, __req) => {
/**
 * Device-scope, Managed inventory, Wallpaper gallery, & Discovered onboarding UI strings
 * (`D-061` — Home Assistant Sentence case).
 */
const EN_DEVICES_STRINGS = {
  // Offline / sleeping & BLE transmitter banners (D-066)
  "offline.device_banner_title": "Device is offline or hibernating",
  "offline.device_sleeping_title": "Device is sleeping",
  "offline.device_banner_body":
    "Settings saved here are queued in Home Assistant and sync automatically when this Device wakes or reconnects. Live quick actions are unavailable while offline.",
  "offline.ble_tx_off_title": "BLE transmitter not active ({state})",
  "offline.ble_tx_off_body":
    "Enable the BLE Transmitter sensor in the Home Assistant Companion App on this phone so Bluetooth proxies can detect its Area.",
  // Device card titles & disambiguated display sections (D-066 / Q7 / Q8)
  "card.status": "Status",
  "card.quick_actions": "Quick actions",
  "card.assignments": "Assignments",
  "card.timers_alarms": "Timers & alarms",
  "card.sensors_controls": "Sensors & controls",
  "card.wallpapers": "Wallpapers",
  "card.brightness": "Brightness",
  "card.colors": "Colors",
  "card.screensaver": "Screensaver",
  "card.home_screen": "Home screen",
  "card.app_dock": "App Dock",
  "card.diagnostics": "Diagnostics",
  "card.developer_telemetry": "Developer & telemetry",
  "card.replace_hardware": "Replace hardware",
  "card.replace_hardware_body":
    "Replaced a physical board or reflashed under a new ESPHome node? Use Reconfigure on this Device entry in Home Assistant Integrations to rebind its hardware identity while keeping all shortcuts, Area rules, and settings.",
  "card.danger_zone": "Danger zone",
  // Device list & discovered devices (D-041 / D-066 / Q12)
  "devices.inventory_heading": "Inventory",
  "devices.col_device": "Device",
  "devices.col_model": "Model",
  "devices.col_area": "Area",
  "devices.col_group": "Group",
  "devices.col_status": "Status",
  "devices.filter_aria": "Filter managed Devices by category",
  "devices.open_row_aria": "Open {title}",
  "devices.all": "All Devices",
  "devices.online": "Online Devices",
  "devices.roaming": "Roaming Devices",
  "devices.stationary": "Stationary Devices",
  "devices.latter_displays": "Latter displays",
  "devices.ble_tracked": "BLE-tracked Devices",
  "devices.phones": "Phones",
  "devices.ble_tags": "BLE tags",
  "devices.assigned_person": "Assigned to a person",
  "devices.updates_available": "Updates available",
  "devices.group_prefix": "Group: {name}",
  "devices.empty_filtered": "No Devices match this category.",
  "devices.empty_zero_title": "No managed Devices yet",
  "devices.empty_zero_body":
    "Adopt discovered Latter displays, add Bluetooth tags for Area presence, or configure System Area sensor fusion.",
  "devices.open_discovered": "Open Discovered",
  "devices.open_area_presence": "Configure Area presence",
  "discovered.latter_devices": "Latter Devices",
  "discovered.bluetooth_devices": "Bluetooth devices",
  "discovered.empty_latter":
    "No unconfigured Latter Devices found in Home Assistant. Newly added ESPHome Devices running Latter firmware appear here automatically.",
  "discovered.web_installer": "Open Web Installer",
  "discovered.getting_started": "Getting started guide",
  "discovered.ignored_count": "Ignored ({count})",
  "discovered.default_latter_title": "Latter Device",
  "discovered.default_latter_model": "Latter ESPHome Device",
  "discovered.default_ble_kind": "BLE device",
  "discovered.meta_node": "Node: {node}",
  "discovered.meta_area": "Area: {area}",
  "discovered.meta_nearest_area": "Nearest Area: {area}",
  "discovered.group_select_aria": "Device group for {title}",
  "discovered.auto_group_option": "Auto ({group})",
  "discovered.person_select_aria": "Assigned person for {title}",
  "discovered.ignore_aria": "Ignore {title}",
  "discovered.restore_aria": "Restore {title}",
  "discovered.search_ble_aria": "Search discovered Bluetooth devices",
  "discovered.search_ble_placeholder": "Search name, address, or Area…",
  "discovered.filter_ble_aria": "Filter discovered Bluetooth devices",
  "discovered.all_ble": "All Bluetooth devices",
  "discovered.phones_trackers": "Phones & trackers",
  "discovered.named_ble": "Named BLE advertisements",
  "discovered.sort_ble_aria": "Sort discovered Bluetooth devices",
  "discovered.sort_name": "Sort: Name (A–Z)",
  "discovered.sort_rssi": "Sort: Signal strength",
  "discovered.sort_area": "Sort: Nearest Area",
  "discovered.pause_list": "Pause list",
  "discovered.resume_list": "Resume list",
  "discovered.paused_hint":
    "List updates paused ({count} shown). Select Resume list to refresh.",
  "discovered.empty_ble_filtered": "No Bluetooth devices match this filter.",
  "discovered.empty_ble_none": "No unadopted Bluetooth devices nearby.",
  "discovered.adopted_toast": "Adopted \"{title}\"",
  "discovered.ignored_toast": "Ignored \"{title}\"",
  "discovered.restored_toast": "Restored \"{title}\" to discovered list",
  // Wallpaper gallery & multipart upload (D-25 / Q5)
  "wp_gallery.empty": "No wallpapers available yet.",
  "wp_gallery.use_aria": "Use wallpaper {name}",
  "wp_gallery.star_add_aria": "Star {name} for rotation",
  "wp_gallery.star_remove_aria": "Remove {name} from favorites",
  "wp_gallery.star_active_title": "Starred for rotation",
  "wp_gallery.star_inactive_title": "Star for rotation",
  "wp_gallery.delete_aria": "Delete wallpaper {name}",
  "wp_gallery.uploaded": "Uploaded",
  "wp_gallery.builtin": "Built-in",
  "wp_gallery.file_aria": "Wallpaper image (up to 15 MB)",
  "wp_gallery.upload_photo": "Upload photo",
  "wp_gallery.uploading": "Uploading…",
  "wp_gallery.uploading_photo": "Uploading photo…",
  "wp_gallery.upload_progress_aria": "Wallpaper upload progress",
  // Device -> Overview (D-003 / D-066 / F-01)
  "dev_overview.waiting_for_reading": "Waiting for reading",
  "dev_overview.tile_area": "Area",
  "dev_overview.tile_current_area": "Current Area",
  "dev_overview.tile_closest_proxy": "Closest proxy",
  "dev_overview.ble_presence_meta": "BLE presence",
  "dev_overview.tile_battery": "Battery",
  "dev_overview.tile_power": "Power",
  "dev_overview.tile_ble_signal": "BLE signal",
  "dev_overview.tile_wifi_signal": "Wi-Fi signal",
  "dev_overview.tile_ble_target": "BLE target",
  "dev_overview.ble_address_meta": "Bluetooth address",
  "dev_overview.tile_firmware": "Firmware",
  "dev_overview.qa_find_my": "Find my Device",
  "dev_overview.qa_trigger_va": "Trigger voice assistant",
  "dev_overview.qa_activate_screensaver": "Activate screensaver",
  "dev_overview.qa_restart": "Restart Device",
  "dev_overview.restart_device": "Restart Device",
  "dev_overview.restart_device_desc":
    "Reboots this Device; Wi-Fi and active sessions reconnect automatically.",
  "dev_overview.restart_btn": "Restart",
  "dev_overview.empty_quick_actions": "No live actions reported by this Device.",
  "dev_overview.device_group_label": "Device group",
  "dev_overview.device_group_custom_desc":
    "Uses individual operational settings; save as a reusable group or pick an existing preset.",
  "dev_overview.device_group_preset_desc":
    "Applies shared operational settings (power, wake word, brightness, BLE).",
  "dev_overview.device_category_label": "Device category",
  "dev_overview.device_category_desc":
    "Classifies this Bluetooth Device under Phones or BLE tags across Managed devices.",
  "dev_overview.auto_category_option": "Auto ({category})",
  "dev_overview.assigned_person_label": "Assigned person",
  "dev_overview.assigned_person_desc":
    "Links this Device's Area presence to a Home Assistant person entity.",
  "dev_overview.unassigned_option": "— Unassigned —",
  "dev_overview.remote_group_label": "Remote control scope",
  "dev_overview.remote_group_desc":
    "Controls which TV and AV remotes appear in the Remote app.",
  "dev_overview.remote_follow_area": "Follow Area",
  "dev_overview.remote_all_system": "All System remotes",
  "dev_overview.ringing_alert_text": "An alarm or timer is ringing on this Device.",
  "dev_overview.dismissed_ringing_toast": "Dismissed ringing alert",
  "dev_overview.active_timer_label": "Active timer",
  "dev_overview.no_active_timer": "No active timer",
  "dev_overview.running": "Running",
  "dev_overview.paused": "Paused",
  "dev_overview.cancel_timer": "Cancel timer",
  "dev_overview.cancelled_timer_toast": "Cancelled timer",
  "dev_overview.stopwatch_label": "Stopwatch",
  "dev_overview.not_running": "Not running",
  "dev_overview.reset_stopwatch": "Reset stopwatch",
  "dev_overview.reset_stopwatch_toast": "Reset stopwatch",
  "dev_overview.alarms_label": "Alarms",
  "dev_overview.alarms_enabled_summary": "{count} enabled • {nextTime}",
  "dev_overview.alarms_desc":
    "Syncs 2-way with on-device alarm edits (1-minute precision).",
  "dev_overview.alarms_group_aria": "Device alarms",
  "dev_overview.alarm_time_label": "Alarm {index} time",
  "dev_overview.alarm_schedule_label": "Alarm {index} schedule",
  "dev_overview.alarm_rec_daily": "Daily",
  "dev_overview.alarm_rec_weekdays": "Weekdays",
  "dev_overview.alarm_rec_weekends": "Weekends",
  "dev_overview.alarm_rec_once": "Once",
  // Device -> Display (D-034 / D-069 / D-070)
  "dev_display.card_voice_assistant": "Voice assistant",
  "dev_display.bedtime_brightness_override_note":
    "Bedtime mode is currently active and overriding screen brightness.",
  "dev_display.screensaver_preview_desc":
    "Starts the screensaver on this Device immediately.",
  "dev_display.preview_btn": "Preview",
  "dev_display.custom_color_label": "Custom color",
  "dev_display.custom_color_desc": "Used when Color profile is set to Custom.",
  "dev_display.current_color_option": "Current ({hex})",
  "dev_display.add_color_btn": "Add color",
  "dev_display.wallpapers_subtitle":
    "Shared presets and uploaded photos cropped for this display.",
  "dev_display.active_wallpaper_label": "Active wallpaper",
  "dev_display.wp_weather_bg_note":
    "Weather background is enabled on Home — wallpapers appear across other screens.",
  "dev_display.wp_rotating_named_starred_one":
    "{name} • rotating 1 starred wallpaper.",
  "dev_display.wp_rotating_named_starred_many":
    "{name} • rotating {count} starred wallpapers.",
  "dev_display.wp_rotating_named_all": "{name} • rotating all {count} wallpapers.",
  "dev_display.wp_rotating_starred_one": "Rotating 1 starred wallpaper.",
  "dev_display.wp_rotating_starred_many": "Rotating {count} starred wallpapers.",
  "dev_display.wp_rotating_all": "Rotating all {count} wallpapers.",
  "dev_display.wp_static_named": "{name} (static — not rotating).",
  "dev_display.wp_off": "Off — select Use on a wallpaper below or enable rotation.",
  "dev_display.wp_hint_none":
    "No wallpapers starred — rotation cycles through all wallpapers.",
  "dev_display.wp_hint_one":
    "1 wallpaper starred — star at least 2 to cycle between favorites.",
  "dev_display.wp_hint_many":
    "{starred} of {total} wallpapers starred for rotation.",
  "dev_display.stop_rotation": "Stop rotation",
  "dev_display.enable_rotation": "Enable rotation",
  "dev_display.turn_off_wallpaper": "Turn off wallpaper",
  "dev_display.rotation_interval_label": "Rotation interval",
  "dev_display.rotation_interval_aria": "Wallpaper rotation interval",
  "dev_display.rot_0": "Do not rotate",
  "dev_display.rot_5": "Every 5 minutes",
  "dev_display.rot_15": "Every 15 minutes",
  "dev_display.rot_30": "Every 30 minutes",
  "dev_display.rot_60": "Every hour",
  "dev_display.rot_360": "Every 6 hours",
  "dev_display.rot_1440": "Once a day",
  "dev_display.star_all": "Star all",
  "dev_display.clear_stars": "Clear stars",
  // Device -> Interface (D-053 / D-064 / D-069 / U4)
  "dev_interface.enable_home_desc":
    "Provides the Home screen and App Dock. Turn off to lock this Device to a single start screen app.",
  "dev_interface.start_screen_multi_desc":
    "Choose the screen shown on startup. Swipe up from the bottom to return to Home.",
  "dev_interface.start_screen_single_desc":
    "Single-app screen shown at all times while the Home screen is disabled.",
  "dev_interface.time_format_desc":
    "Applies 12-hour or 24-hour time across Home, alarms, calendar, and schedules.",
  "dev_interface.home_clock_tap_desc":
    "Choose whether tapping the clock readout on Home opens the Time app or the standalone clock face.",
  "dev_interface.clock_face_desc":
    "Visual style for the standalone clock face screen.",
  "dev_interface.home_date_tap_desc":
    "Choose whether tapping the date readout on Home opens Day view or Overview in the Calendar app.",
  "dev_interface.return_timeout_desc":
    "Resets idle screens back to Home unless media is playing or a live activity is active.",
  "dev_interface.wake_greeting_desc":
    "Shows a brief morning, afternoon, or evening greeting after waking from standby.",
  "dev_interface.weather_bg_desc":
    "Replaces the Home screen backdrop with a live sky matching current conditions.",
  "dev_interface.sun_moon_label": "Sun & Moon",
  "dev_interface.sun_moon_desc":
    "Choose which sky bodies appear on the live weather background.",
  "dev_interface.activity_card_desc":
    "Shows live timers, alarms, media queue, stopwatch, and next calendar event on Home.",
  "dev_interface.activity_sources_desc":
    "Choose and reorder which live items appear in the Activity card.",
  "dev_interface.activity_src_calendar": "Calendar",
  "dev_interface.activity_src_music_queue": "Music queue",
  "dev_interface.activity_src_stopwatch": "Stopwatch",
  "dev_interface.activity_src_alarms": "Alarms",
  "dev_interface.activity_src_timers": "Timers",
  "dev_interface.app_dock_desc":
    "Toggle, drag to reorder, and configure apps on the App Dock, or add custom subpage and Home Assistant entity shortcuts. Pinned hides automatically when empty.",
  "dev_interface.active_dock_aria": "Active on App Dock",
  "dev_interface.show_on_dock_aria": "Show {title} on App Dock",
  "dev_interface.settings_title": "Settings",
  "dev_interface.settings_locked_meta": "Always shown last on the App Dock",
  "dev_interface.hidden_from_dock": "Hidden from dock",
  "dev_interface.pinned_empty_meta": "Empty — auto-hidden on dock",
  "dev_interface.pinned_count_meta": "{count} {shortcutWord} • {pages} {pageWord}",
  "dev_interface.word_shortcut_one": "shortcut",
  "dev_interface.word_shortcut_many": "shortcuts",
  "dev_interface.word_page_one": "page",
  "dev_interface.word_page_many": "pages",
  "dev_interface.music_meta": "Art: {art} • Albums: {albums}",
  "dev_interface.categories_enabled_one": "1 category enabled",
  "dev_interface.categories_enabled_many": "{count} categories enabled",
  "dev_interface.remote_follow_area": "Follow the active Area",
  "dev_interface.remote_all": "All System remotes",
  "dev_interface.weather_meta": "Current, forecast, Sun & Moon",
  "dev_interface.time_utc_world_one": "UTC + 1 world clock",
  "dev_interface.time_utc_world_many": "UTC + {count} world clocks",
  "dev_interface.time_world_one": "1 world clock",
  "dev_interface.time_world_many": "{count} world clocks",
  "dev_interface.time_local_utc": "Local time + UTC",
  "dev_interface.time_local": "Local time",
  "dev_interface.clock_24h": "24-hour",
  "dev_interface.clock_12h": "12-hour",
  "dev_interface.calendar_meta": "{days}-day lookahead • Starts {weekday}",
  "dev_interface.tools_enabled_one": "1 tool enabled",
  "dev_interface.tools_enabled_many": "{count} tools enabled",
  "dev_interface.games_enabled_one": "1 game enabled",
  "dev_interface.games_enabled_many": "{count} games enabled",
  "dev_interface.custom_route_meta": "Custom • {target}",
  "dev_interface.custom_entity_confirm_meta":
    "Custom • {action} • Confirm • {target}",
  "dev_interface.custom_entity_tap_meta": "Custom • {action} • 1-tap • {target}",
  // Device -> Audio (D-008 / D-031 / D-066 / Q8)
  "dev_audio.card_voice_wake": "Voice assistant & wake word",
  "dev_audio.card_sound_playback": "Sound & playback",
  "dev_audio.vfm_desc":
    "Updates this roaming Device's Home Assistant Area when BLE presence settles in a new Area, so Area-less voice commands target where you are.",
  "dev_audio.vfm_delay_label": "Voice Follows Me delay",
  "dev_audio.vfm_delay_desc":
    "How long a BLE-detected Area stays stable before moving the Device (3 to 60 seconds).",
  "dev_audio.ww_sensitivity_summary": "Wake word sensitivity (per model)",
  "dev_audio.default_speaker_label": "Default speaker",
  "dev_audio.default_speaker_desc":
    "Primary speaker controlled from Music and Home when this Device starts up.",
  "dev_audio.default_speaker_auto": "— Automatic (built-in or Area) —",
  "dev_audio.ma_player_label": "Music Assistant player",
  "dev_audio.ma_player_unmatched_desc":
    "Automatic match did not find {entity} in Music Assistant. Choose this Device's player for library playback, queues, and lyrics.",
  "dev_audio.ma_player_manual_desc":
    "Linked manually ({entity} was not used). Clear to return to automatic matching.",
  "dev_audio.ma_player_fallback_target": "this Device's player",
  "dev_audio.ma_player_auto": "— Automatic match —",
  "dev_audio.area_handoff_desc":
    "Transfers active Music Assistant playback when this Device moves to or selects another Area.",
  // Device -> Power (D-027 / D-068)
  "dev_power.card_sleep_wake": "Sleep & wake",
  "dev_power.card_bedtime": "Bedtime mode",
  "dev_power.card_bedtime_subtitle":
    "Turns off or dims the display overnight and silences non-critical notification chimes.",
  "dev_power.card_power_battery": "Power & battery",
  "dev_power.empty": "No sleep or battery entities reported by this Device.",
  // Device -> Presence (D-032 / D-066 / Q8)
  "dev_presence.card_area_tracking": "Area tracking",
  "dev_presence.card_ble_identity": "BLE identity",
  "dev_presence.track_ble_label": "Track Area with BLE proxies",
  "dev_presence.track_ble_desc":
    "Uses Home Assistant Area-assigned Bluetooth proxies to locate this Device automatically. Turn off to pin it to one assigned Area.",
  "dev_presence.auto_switch_desc":
    "Switches the Device's active Area controls automatically when BLE detects a move.",
  "dev_presence.fallback_area_label": "Fallback Area",
  "dev_presence.fallback_area_desc":
    "Default Home Assistant Area when no Bluetooth proxy is in range.",
  "dev_presence.fallback_area_auto": "— Automatic (ESPHome Area) —",
  "dev_presence.assigned_area_label": "Assigned Area",
  "dev_presence.assigned_area_desc":
    "Pins this Device's Area controls and Home Assistant Device Area to one location.",
  "dev_presence.target_addr_label": "BLE target address or entity",
  "dev_presence.target_addr_placeholder":
    "AA:BB:CC:DD:EE:FF or device_tracker.phone_ble",
  "dev_presence.target_addr_help":
    "Leave blank on Latter displays to track their built-in BLE beacon MAC automatically.",
  "dev_presence.ref_power_label": "Reference power (1 meter)",
  "dev_presence.ref_power_placeholder_detected": "Auto ({dbm} dBm)",
  "dev_presence.ref_power_help":
    "Leave blank to use auto-detected beacon power in dBm, or enter -90 to -30 dBm to calibrate this Device.",
  "dev_presence.companion_low_title": "Companion App low-power beacon detected",
  "dev_presence.companion_low_body":
    "This phone is advertising at {txPower} power{modeSuffix}.{refSuffix} Setting Transmit Power to Medium or High and Advertise Mode to Balanced in the Home Assistant Companion App improves multi-Area accuracy through walls.",
  "dev_presence.companion_mode_suffix": " ({mode} mode)",
  "dev_presence.companion_ref_suffix":
    " Latter automatically compensates its 1 m reference power ({dbm} dBm).",
  "dev_presence.companion_default_power": "default",
  "dev_presence.ibeacon_uuid_label": "iBeacon UUID",
  "dev_presence.ibeacon_uuid_placeholder": "Generated automatically per System",
  // Device -> Tools (D-027 / D-064 / D-066 / Q8 / Q12)
  "dev_tools.ble_signal": "BLE signal",
  "dev_tools.ble_target": "BLE target",
  "dev_tools.model": "Model",
  "dev_tools.esphome_node": "ESPHome node",
  "dev_tools.firmware_version": "Firmware version",
  "dev_tools.latter_sdk": "Latter SDK",
  "dev_tools.wifi_signal": "Wi-Fi signal",
  "dev_tools.ip_address": "IP address",
  "dev_tools.mac_address": "MAC address",
  "dev_tools.diagnostics_file_label": "Diagnostics file",
  "dev_tools.diagnostics_file_desc":
    "Downloads redacted Home Assistant diagnostics for troubleshooting.",
  "dev_tools.backup_row_label": "Device backup",
  "dev_tools.backup_row_desc":
    "Downloads this Device's Latter configuration and settings as JSON.",
  "dev_tools.perimeter_subtitle":
    "Governs unlocking doors, disarming alarms, and opening garage or gate covers from this Device.",
  "dev_tools.pin_policy_desc_prefix":
    "Auto requires a PIN on stationary wall panels when configured and allows roaming personal Devices. Effective policy:",
  "dev_tools.security_pin_label": "Security PIN",
  "dev_tools.security_pin_desc":
    "Write-only 4 to 12 digit numeric PIN verified by Home Assistant when the on-device keypad prompts. Never shown again after saving.",
  "dev_tools.pin_input_aria": "New security PIN (4 to 12 digits)",
  "dev_tools.pin_placeholder_replace": "Enter new PIN to replace…",
  "dev_tools.pin_placeholder_new": "4 to 12 digits",
  "dev_tools.save_pin": "Save PIN",
  "dev_tools.clear_pin": "Clear PIN",
  "dev_tools.reconfigure_in_ha": "Reconfigure in Home Assistant",
  "dev_tools.reset_defaults_label": "Reset to defaults",
  "dev_tools.reset_defaults_desc":
    "Resets on-device preferences and/or Latter settings while keeping Wi-Fi and Home Assistant pairing.",
  "dev_tools.remove_device_label": "Remove Device",
  "dev_tools.remove_device_desc":
    "Removes this Device from Latter. Your ESPHome device stays in Home Assistant.",
  "dev_tools.telem_uptime": "Session uptime",
  "dev_tools.telem_last_reset": "Last reset",
  "dev_tools.telem_wifi_disc": "Wi-Fi disconnects",
  "dev_tools.telem_beacon_timeouts": " ({count} beacon timeouts)",
  "dev_tools.telem_wifi_avg_min": "Wi-Fi avg / min",
  "dev_tools.telem_ha_sessions": "Home Assistant sessions",
  "dev_tools.telem_max_gap": " (max gap {duration})",
  "dev_tools.telem_light_sleep": "Light sleep duty",
  "dev_tools.telem_cycles": " ({count} cycles)",
  "dev_tools.telem_nvs_writes": "NVS flash writes",
  "dev_tools.telem_nvs_value":
    "{writes} writes ({erases} erases, {maxMs} ms max)",
  "dev_tools.telem_board": "Hardware board",
  "dev_tools.telem_processor": "Processor & PSRAM",
  "dev_tools.telem_psram_suffix": " • {mb} MB PSRAM",
  "dev_tools.telem_display_panel": "Display panel",
  "dev_tools.telem_headless": "Headless",
  "dev_tools.telem_traits": "Hardware traits",
  "dev_tools.trait_touch": "Touch",
  "dev_tools.trait_mic": "Mic",
  "dev_tools.trait_speaker": "Speaker",
  "dev_tools.trait_audio": "Audio",
  "dev_tools.trait_imu": "IMU",
  "dev_tools.trait_battery": "Battery",
  "dev_tools.trait_wearable": "Wearable",
  "dev_tools.trait_stationary": "Stationary",
};
__latterExp(__exports, { EN_DEVICES_STRINGS: () => EN_DEVICES_STRINGS });
//# sourceURL=latter-studio/src/i18n/en-devices.ts
});
__latterDef("src/i18n/en-system.ts", (__exports, __req) => {
/**
 * System-scope & modal dialog UI strings (`D-061` — Home Assistant Sentence case).
 */
const EN_SYSTEM_STRINGS = {
  // System card titles
  "card.perimeter_security": "Perimeter security",
  "card.perimeter_security_signing": "Perimeter security & signing",
  "card.notifications_announcements": "Notifications & announcements",
  "card.doorbell_intercom_audio": "Doorbell & intercom audio",
  "card.backup_restore": "Backup & restore",
  "card.system_device_logs": "System & Device logs",
  "card.support_diagnostics": "Support & diagnostics",
  "card.support_subtitle":
    "Version lockstep, redacted System diagnostics bundle, and issue reporting.",
  "card.area_deployment": "Area deployment",
  "card.system_capabilities": "System capabilities",
  "card.home_hub_weather": "Home hub & weather",
  "card.calendars": "Calendars",
  "card.cameras_doorbell": "Cameras & doorbell audio",
  "card.custom_colors": "Custom colors",
  "card.remote_controls": "Remote controls",
  "card.volume_overrides": "Speaker volume overrides",
  "card.remote_groups": "Remote control groups",
  "card.area_presence_sensors": "Area presence & sensors",
  "card.ble_calibration": "Walk-around BLE calibration",
  "card.advanced_ble": "Advanced BLE settings",
  // Support & diagnostics card (D-066)
  "support.ha_version": "Home Assistant",
  "support.integration_version": "Latter integration",
  "support.sdk_rev": "Minimum firmware SDK",
  "support.studio_rev": "Studio contract",
  "support.managed_devices": "Managed Devices",
  "support.managed_devices_value":
    "{total} ({displays} displays, {trackers} BLE trackers)",
  "support.copy_summary": "Copy version summary",
  "support.copied_summary": "Copied version summary to clipboard",
  "support.download_system_diagnostics": "Download System diagnostics",
  "support.documentation": "Documentation",
  "support.report_issue": "Report an issue",
  // System -> Overview (D-051 / D-003 / D-004 / D-061)
  "sys_overview.no_devices": "No Devices",
  "sys_overview.issues_one": "1 issue",
  "sys_overview.issues_many": "{count} issues",
  "sys_overview.updates_one": "1 update",
  "sys_overview.updates_many": "{count} updates",
  "sys_overview.all_online": "All online",
  "sys_overview.online_ratio": "{online} / {total} online",
  "sys_overview.zero_devices": "0 Devices",
  "sys_overview.ready_to_onboard": "Ready to onboard",
  "sys_overview.displays_one": "1 display",
  "sys_overview.displays_many": "{count} displays",
  "sys_overview.phones_one": "1 phone",
  "sys_overview.phones_many": "{count} phones",
  "sys_overview.ble_tags_one": "1 BLE tag",
  "sys_overview.ble_tags_many": "{count} BLE tags",
  "sys_overview.audio_count": "{count} audio",
  "sys_overview.open_device": "Open Device",
  "sys_overview.discovered_banner_title": "Hardware ready to adopt",
  "sys_overview.discovered_banner_one":
    "1 unbound Latter Device detected on your network ({names}).",
  "sys_overview.discovered_banner_many":
    "{count} unbound Latter Devices detected on your network ({names}).",
  "sys_overview.open_discovered": "Open discovered",
  "sys_overview.tile_devices": "Managed Devices",
  "sys_overview.tile_areas": "Area presence",
  "sys_overview.occupied_count": "{count} occupied",
  "sys_overview.areas_proxies_meta": "{areas} • {proxies}",
  "sys_overview.areas_one": "1 Area",
  "sys_overview.areas_many": "{count} Areas",
  "sys_overview.proxies_one": "1 BLE proxy",
  "sys_overview.proxies_many": "{count} BLE proxies",
  "sys_overview.no_areas": "No Areas configured",
  "sys_overview.tile_people_roaming": "People & roaming",
  "sys_overview.people_assigned_one": "1 person assigned",
  "sys_overview.people_assigned_many": "{count} people assigned",
  "sys_overview.ble_tracked_meta": "{count} BLE-tracked",
  "sys_overview.tile_release": "System release",
  "sys_overview.fw_updates_one": "1 firmware update available",
  "sys_overview.fw_updates_many": "{count} firmware updates available",
  "sys_overview.check_fw_updates": "Check firmware updates",
  "sys_overview.area_deployment_subtitle":
    "Live occupancy, assigned Devices, and Bluetooth coverage across your Areas.",
  "sys_overview.manage_presence": "Manage presence",
  "sys_overview.roaming_devices": "Roaming Devices",
  "sys_overview.roaming_active_ratio": "{online} / {total} active",
  "sys_overview.plus_more": "+{count} more",
  "sys_overview.here_prefix": "Here: {names}",
  "sys_overview.remotes_one": "1 remote",
  "sys_overview.remotes_many": "{count} remotes",
  "sys_overview.active_sensors_one": "1 active sensor",
  "sys_overview.active_sensors_many": "{count} active sensors",
  "sys_overview.sensors_one": "1 sensor",
  "sys_overview.sensors_many": "{count} sensors",
  "sys_overview.occupied": "Occupied",
  "sys_overview.no_devices_stationed": "No Devices stationed",
  "sys_overview.signature_count": "Signature ({count})",
  "sys_overview.ble_proxy": "BLE proxy",
  "sys_overview.no_ble_proxy": "No BLE proxy",
  "sys_overview.empty_deployment":
    "No Home Assistant Areas or managed Devices configured yet.",
  "sys_overview.unconfigured_areas_one":
    "+1 additional Home Assistant Area without Latter Devices or BLE coverage.",
  "sys_overview.unconfigured_areas_many":
    "+{count} additional Home Assistant Areas without Latter Devices or BLE coverage.",
  "sys_overview.capabilities_subtitle":
    "Shared entities, media routing, Device groups, colors & wallpapers, and security policies.",
  "sys_overview.active_of_six": "{count} / 6 active",
  "sys_overview.hub_weather": "Weather",
  "sys_overview.hub_alarm": "Alarm",
  "sys_overview.hub_thermostat": "Thermostat",
  "sys_overview.hub_zones": "{count} zones",
  "sys_overview.hub_lock": "Door lock",
  "sys_overview.hub_locks": "{count} locks",
  "sys_overview.hub_garage": "Garage door",
  "sys_overview.hub_garages": "{count} garage doors",
  "sys_overview.hub_vacuum": "Vacuum",
  "sys_overview.hub_vacuums": "{count} vacuums",
  "sys_overview.cap_cameras_calendars": "Cameras, doorbells & calendars",
  "sys_overview.not_set": "Not set",
  "sys_overview.cameras_one": "1 camera",
  "sys_overview.cameras_many": "{count} cameras",
  "sys_overview.doorbells_one": "1 doorbell",
  "sys_overview.doorbells_many": "{count} doorbells",
  "sys_overview.calendars_one": "1 calendar",
  "sys_overview.calendars_many": "{count} calendars",
  "sys_overview.cameras_calendars_empty":
    "Connect cameras for doorbell popups and calendars for the Home agenda.",
  "sys_overview.cap_media_remotes": "Media & remotes",
  "sys_overview.remotes_meta": "{groups} • {overrides}",
  "sys_overview.area_groups_one": "1 Area group",
  "sys_overview.area_groups_many": "{count} Area groups",
  "sys_overview.vol_overrides_one": "1 volume override",
  "sys_overview.vol_overrides_many": "{count} volume overrides",
  "sys_overview.remotes_empty":
    "Add TV, streaming, or AV receiver remotes and volume overrides.",
  "sys_overview.cap_device_groups": "Device groups",
  "sys_overview.groups_one": "1 group",
  "sys_overview.groups_many": "{count} groups",
  "sys_overview.groups_meta_dynamic": "Shared baselines across {names}.",
  "sys_overview.groups_meta_empty":
    "Shared baselines that keep assigned Devices aligned.",
  "sys_overview.custom_group_chip": "Custom: {count}",
  "sys_overview.cap_colors_wallpapers": "Colors & wallpapers",
  "sys_overview.wallpapers_one": "1 wallpaper",
  "sys_overview.wallpapers_many": "{count} wallpapers",
  "sys_overview.colors_wallpapers_meta": "{colors} • {presets}{uploaded}",
  "sys_overview.custom_colors_one": "1 custom color",
  "sys_overview.custom_colors_many": "{count} custom colors",
  "sys_overview.presets_one": "1 preset",
  "sys_overview.presets_many": "{count} presets",
  "sys_overview.uploaded_suffix": ", {count} uploaded",
  "sys_overview.system_pin_set": "System PIN set",
  "sys_overview.no_system_pin": "No System PIN",
  "sys_overview.pin_active_meta":
    "Default PIN active for opening locks, garage covers, and code-less alarms.",
  "sys_overview.pin_unset_meta":
    "Set a fallback System security PIN for perimeter locks, covers, and alarms.",
  // System -> Shared entities (D-022 / D-059 / D-065)
  "shared.home_hub_subtitle":
    "Shared climate zones, entry controls, vacuums, security, and weather across every Device.",
  "shared.weather_label": "Weather",
  "shared.security_alarm_label": "Security alarm",
  "shared.thermostat_zones": "Thermostat zones",
  "shared.add_zone": "Add zone",
  "shared.choose_thermostat": "— Choose a thermostat —",
  "shared.thermostat_aria": "Thermostat zone",
  "shared.remove_thermostat": "Remove thermostat zone",
  "shared.door_locks": "Door locks",
  "shared.add_lock": "Add lock",
  "shared.choose_lock": "— Choose a door lock —",
  "shared.lock_aria": "Door lock",
  "shared.remove_lock": "Remove door lock",
  "shared.garage_doors": "Garage doors",
  "shared.add_garage": "Add garage door",
  "shared.choose_garage": "— Choose a garage door —",
  "shared.garage_aria": "Garage door",
  "shared.remove_garage": "Remove garage door",
  "shared.robot_vacuums": "Robot vacuums",
  "shared.add_vacuum": "Add vacuum",
  "shared.choose_vacuum": "— Choose a robot vacuum —",
  "shared.vacuum_aria": "Robot vacuum",
  "shared.remove_vacuum": "Remove robot vacuum",
  "shared.calendars_subtitle":
    "Upcoming events merged into the Activity card and agenda feed.",
  "shared.add_calendar": "Add calendar",
  "shared.choose_calendar": "— Choose a calendar —",
  "shared.empty_calendars": "No calendars configured yet.",
  "shared.calendar_aria": "Calendar",
  "shared.remove_calendar": "Remove calendar",
  "shared.wallpapers_subtitle":
    "Shared System wallpapers and presets available to every Latter display.",
  "shared.cameras_subtitle":
    "Up to 10 cameras. Doorbell ring sensors wake displays automatically with listen audio and push-to-talk TTS replies.",
  "shared.add_camera": "Add camera",
  "shared.doorbell_filter_label": "Doorbell audio filter",
  "shared.doorbell_filter_desc":
    "Noise-reduction preset applied when listening to camera audio.",
  "shared.filter_strong": "Strong",
  "shared.filter_light": "Light",
  "shared.filter_off": "Off",
  "shared.choose_camera": "— Choose a camera —",
  "shared.empty_cameras": "No cameras configured yet.",
  "shared.camera_aria": "Camera",
  "shared.remove_camera": "Remove camera",
  "shared.camera_slot_primary": "Camera 1 (primary)",
  "shared.camera_slot_n": "Camera {index}",
  "shared.preview": "Preview",
  "shared.preview_heading": "Preview: {entity}",
  "shared.camera_preview_alt": "Camera preview",
  "shared.doorbells_heading": "Doorbells",
  "shared.no_ring_sensor": "No ring sensor found",
  "shared.last_ring": "last ring {when}",
  "shared.no_ring_yet": "no ring yet",
  "shared.ringing": "ringing",
  "shared.idle": "idle",
  "shared.idle_changed": "idle, changed {when}",
  "shared.unavailable": "unavailable",
  "shared.talk_listening": "listening",
  "shared.talk_talking": "replying",
  "shared.colors_subtitle":
    "Shared 24-swatch accent library available across all Devices.",
  "shared.add_color": "Add color",
  "shared.delete_color_aria": "Delete color {name}",
  "shared.empty_colors": "No custom colors saved yet.",
  // System -> Media & remotes
  "remotes.controls_subtitle":
    "Up to 10 TV, streamer, or receiver entities controlled from the Remote screen.",
  "remotes.add_remote": "Add remote",
  "remotes.choose_remote": "— Choose a remote or media player —",
  "remotes.empty_remotes": "No remote controls configured yet.",
  "remotes.remote_aria": "Remote or media player",
  "remotes.remove_remote": "Remove remote",
  "remotes.slot_primary": "Slot 1 (primary power target)",
  "remotes.slot_n": "Slot {index}",
  "remotes.overrides_subtitle":
    "Redirects volume buttons when audio plays through an external AVR or soundbar.",
  "remotes.add_override": "Add override",
  "remotes.when_playing_on": "When audio plays on",
  "remotes.speaker_aria": "Speaker",
  "remotes.choose_speaker": "— Choose a speaker —",
  "remotes.change_volume_on": "Change the volume on",
  "remotes.volume_target_aria": "Volume target",
  "remotes.choose_volume_target": "— Choose a volume target —",
  "remotes.remove_override_aria": "Remove volume override",
  "remotes.empty_overrides": "No volume overrides configured.",
  "remotes.groups_subtitle":
    "Bind sets of remotes to Home Assistant Areas or specific Devices.",
  "remotes.add_group": "Add group",
  "remotes.group_name": "Group name",
  "remotes.group_name_placeholder": "e.g. Living Area TV",
  "remotes.loads_in_area": "Loads in Area",
  "remotes.area_aria": "Area",
  "remotes.no_area_option": "No Area (assign to Devices only)",
  "remotes.delete_group_aria": "Delete remote group {name}",
  "remotes.group_remotes_label": "Remote controls",
  "remotes.primary_badge": "★ Primary: {name}",
  "remotes.numbered_badge": "#{index}: {name}",
  "remotes.add_badge": "+ {name}",
  "remotes.add_remotes_first": "Add remote controls first.",
  "remotes.empty_groups": "No remote groups yet.",
  // Device groups & staged Batch controls (D-050 / D-064 / Q6 / R-8)
  "groups.title": "Device groups",
  "groups.card_title": "Group presets & custom groups",
  "groups.card_subtitle":
    "Built-in hardware presets and custom Device groups that keep assigned Devices aligned.",
  "groups.create_group": "Create group",
  "groups.group_name": "Group name",
  "groups.group_name_placeholder": "e.g. Guest suites",
  "groups.description_optional": "Description (optional)",
  "groups.description_placeholder": "Optional description",
  "groups.copy_from_aria": "Copy settings from Device",
  "groups.start_from_defaults": "Start from default settings",
  "groups.copy_from_prefix": "Copy from: {title}",
  "groups.members_one": "1 Device",
  "groups.members_many": "{count} Devices",
  "groups.scope_display_chip": "Display",
  "groups.scope_interface_chip": "Interface",
  "groups.view_devices": "View Devices",
  "groups.reset_preset": "Reset preset",
  "groups.reset_preset_toast": "Reset \"{name}\" to preset defaults",
  "groups.delete_group_aria": "Delete group {name}",
  "groups.devices_list_meta": "Devices: {names}",
  "groups.no_devices_assigned": "No Devices assigned",
  "groups.empty_groups": "No Device groups configured.",
  "groups.custom_summary_title": "Custom (individual settings)",
  "groups.custom_summary_desc":
    "Devices move to Custom automatically when individual settings diverge from a group baseline.",
  "groups.detached_toast": "Detached \"{title}\" to Custom (individual settings)",
  "groups.detached_many_toast": "Applied changes ({count} Devices switched to Custom)",
  "groups.baseline_settings": "Baseline settings",
  "groups.section_power_brightness": "Power & brightness",
  "groups.section_audio_voice": "Audio & voice",
  "groups.section_presence_security": "Presence & security",
  "groups.section_display": "Display",
  "groups.section_interface": "Interface & shortcuts",
  "groups.for_group_aria": "{label} for {group}",
  "groups.wallpaper_none": "None (weather / solid)",
  "groups.remote_match_area": "Follow the active Area",
  "groups.remote_group_prefix": "Group: {name}",
  "groups.remote_all_system": "All System remotes",
  "groups.dock_baseline_desc_one":
    "Baseline holds 1 shortcut (captures from source Device below).",
  "groups.dock_baseline_desc_many":
    "Baseline holds {count} shortcuts (captures from source Device below).",
  "groups.copy_dock": "Copy dock",
  "groups.pinned_baseline_desc_one":
    "Baseline holds 1 shortcut (captures from source Device below).",
  "groups.pinned_baseline_desc_many":
    "Baseline holds {count} shortcuts (captures from source Device below).",
  "groups.copy_pinned": "Copy pinned",
  "groups.clocks_baseline_desc_one":
    "Baseline holds 1 zone (captures from source Device below).",
  "groups.clocks_baseline_desc_many":
    "Baseline holds {count} zones (captures from source Device below).",
  "groups.copy_clocks": "Copy clocks",
  "groups.copy_from_device": "Copy from Device",
  "groups.source_device": "Source Device",
  "groups.source_device_desc":
    "Replaces this group's active baseline scope with an existing Device's settings.",
  "groups.copy_into_aria": "Copy settings into {name}",
  "groups.copy_settings": "Copy settings",
  "groups.confirm_copy_title": "Copy settings into \"{group}\"?",
  "groups.confirm_copy_body":
    "Updates the \"{group}\" baseline from \"{device}\" and syncs all assigned Devices.",
  "groups.confirm_copy_list_body":
    "Copies {listLabel} from \"{device}\" into the \"{group}\" baseline and syncs assigned Devices.",
  "groups.confirm_copy_confirm": "Copy into baseline",
  "groups.include_display": "Include display settings",
  "groups.include_display_desc":
    "Sync wallpapers, clock face, color profile, and media appearance.",
  "groups.include_interface": "Include interface & shortcuts",
  "groups.include_interface_desc":
    "Sync start screen, App Dock, pinned shortcuts, and hub categories.",
  "batch.title": "Batch controls",
  "batch.subtitle":
    "Stage changes across a filtered set of Devices, then apply them together without altering saved group baselines.",
  "batch.target_filter": "Target Devices",
  "batch.target_filter_aria": "Target Devices for batch controls",
  "batch.category_filter_aria": "Filter batch controls by category",
  "batch.all_latter_devices": "All Latter Devices",
  "batch.online_devices": "Online Devices",
  "batch.roaming_devices": "Roaming Devices",
  "batch.stationary_devices": "Stationary Devices",
  "batch.all_categories": "All categories",
  "batch.cat_display": "Display",
  "batch.cat_interface": "Interface",
  "batch.cat_audio": "Audio",
  "batch.cat_power": "Power",
  "batch.cat_presence": "Presence",
  "batch.cat_security": "Security",
  "batch.staged_count": "{count} staged",
  "batch.staged_badge": "Staged",
  "batch.mixed_badge": "Mixed",
  "batch.mixed_pill_suffix": "{label} (mixed)",
  "batch.mixed_hint":
    "Target Devices currently have different values — choose a value to stage across all targets.",
  "batch.row_meta_one": "{section} • 1 Device",
  "batch.row_meta_many": "{section} • {count} Devices",
  "batch.detachment_note_one":
    "1 grouped Device will switch to Custom if staged settings diverge from its group baseline.",
  "batch.detachment_note_many":
    "{count} grouped Devices will switch to Custom if staged settings diverge from their group baselines.",
  "batch.apply_to_n": "Apply to {count} Devices",
  "batch.apply_to_one": "Apply to 1 Device",
  "batch.applied_to_n": "Applied staged changes to {count} Devices",
  "batch.applied_to_one": "Applied staged changes to 1 Device",
  "batch.reset_staged": "Reset",
  "batch.no_targets": "No Devices match the selected filter.",
  "batch.empty_all": "No Latter Devices onboarded yet.",
  "batch.empty_target": "No Latter Devices currently match {target}.",
  "batch.empty_category": "No batch controls match this category.",
  "batch.target_summary": "Target ({count}): {names}",
  "batch.copy_lists_title": "Copy multi-item lists",
  "batch.template_device": "Template Device",
  "batch.template_device_aria": "Template Device for batch list copy",
  "batch.template_device_desc":
    "Copies App Dock, pinned shortcuts, or world clocks to {target}.",
  "batch.push_dock": "Push App Dock",
  "batch.push_pinned": "Push pinned shortcuts",
  "batch.push_clocks": "Push world clocks",
  "batch.confirm_push_list_title": "Push {listLabel} to {target}?",
  "batch.confirm_push_list_body":
    "Replaces {listLabel} on matching Devices using \"{device}\" as the template.",
  "batch.confirm_push_list_confirm": "Push list",
  // System -> BLE & Area presence (D-044 / D-045 / D-046 / D-058)
  "presence_sys.area_card_subtitle":
    "Configures how each Area combines Bluetooth tracking and occupancy sensors.",
  "presence_sys.mode_weighted": "Weighted (BLE and sensors)",
  "presence_sys.mode_any_or": "Either (BLE or a sensor)",
  "presence_sys.mode_ble_only": "BLE only",
  "presence_sys.mode_both": "Both (BLE and a sensor)",
  "presence_sys.occupied_sensor": "Occupied (sensor)",
  "presence_sys.empty": "Empty",
  "presence_sys.ble_dbm": "BLE {rssi} dBm{distance}",
  "presence_sys.signature_match": "signature match",
  "presence_sys.active_sensors_one": "1 active sensor",
  "presence_sys.active_sensors_many": "{count} active sensors",
  "presence_sys.clear_sensors_one": "1 sensor clear",
  "presence_sys.clear_sensors_many": "{count} sensors clear",
  "presence_sys.calibrated_meta": "calibrated {when} ({samples} samples)",
  "presence_sys.calibrate_hint":
    "calibrate with a carried Device to detect BLE presence here",
  "presence_sys.clear_signature": "Clear signature",
  "presence_sys.calibrate": "Calibrate",
  "presence_sys.occupied_chip": "Occupied • {confidence}",
  "presence_sys.clear_chip": "Clear",
  "presence_sys.signature_proxies_one": "Signature (1 proxy)",
  "presence_sys.signature_proxies_many": "Signature ({count} proxies)",
  "presence_sys.presence_mode": "Presence mode",
  "presence_sys.presence_mode_aria": "Presence mode for {area}",
  "presence_sys.sensor_threshold_drawer": "Sensor & threshold settings",
  "presence_sys.occupied_at": "Occupied at",
  "presence_sys.occupied_at_weighted_desc":
    "The Area counts as occupied when the combined BLE and sensor score reaches this level.",
  "presence_sys.occupied_at_other_desc": "Used only in Weighted mode.",
  "presence_sys.sensors_that_count": "Sensors that count",
  "presence_sys.sensors_selected_desc": "{selected} of {total} selected.",
  "presence_sys.sensors_all_desc": "None selected: every sensor in this Area counts.",
  "presence_sys.sensors_group_aria": "Sensors that count in {area}",
  "presence_sys.no_area_sensors":
    "This Area has no occupancy, motion, or door sensors.",
  "presence_sys.empty_areas":
    "No Home Assistant Areas, Bluetooth proxies, or occupancy sensors found yet.",
  "presence_sys.calibration_subtitle":
    "Carry a tracked Device into an Area to check Bluetooth proxy signal levels or save an Area signature.",
  "presence_sys.pause_stream": "Pause stream",
  "presence_sys.resume_stream": "Resume stream",
  "presence_sys.open_discovered": "Open discovered Devices",
  "presence_sys.empty_ble_devices":
    "No Devices currently have Bluetooth Area tracking enabled. Turn on BLE Area tracking on a portable Device, or adopt a phone or tag under Discovered devices.",
  "presence_sys.handoff_ready":
    "Ready to calibrate {area} — carry {device} into {area} and select Calibrate Area.",
  "presence_sys.your_device": "your Device",
  "presence_sys.this_device": "this Device",
  "presence_sys.this_area": "this Area",
  "presence_sys.carried_device": "Carried Device",
  "presence_sys.carried_device_desc":
    "Choose the actively tracked Device or BLE tag you are holding.",
  "presence_sys.live_signal_active": "Live BLE signal active — currently detected in ",
  "presence_sys.packets_observed": " ({count} packets observed).",
  "presence_sys.no_recent_packets_prefix":
    "No live BLE packets in the last 12 seconds — wake ",
  "presence_sys.no_recent_packets_suffix":
    " or hold it in hand so its Bluetooth beacon broadcasts before calibrating.",
  "presence_sys.standing_in_area": "Standing in Area",
  "presence_sys.cal_desc_no_areas":
    "Create at least one Home Assistant Area before saving a Bluetooth signature.",
  "presence_sys.cal_desc_replace":
    "Updates the saved {count}-proxy Bluetooth signature for {area} using live signal readings.",
  "presence_sys.cal_desc_proxyless":
    "Saves readings from nearby Bluetooth proxies so {area} can detect presence even without its own proxy.",
  "presence_sys.cal_desc_new":
    "Saves Bluetooth signal strengths from nearby proxies while you stand in {area} for more accurate Area boundaries.",
  "presence_sys.suffix_saved": " (signature saved)",
  "presence_sys.suffix_no_proxy": " (no BLE proxy)",
  "presence_sys.no_ha_areas_option": "No Home Assistant Areas configured",
  "presence_sys.calibrate_area_btn": "Calibrate Area",
  "presence_sys.nearby_proxies": "Nearby Bluetooth proxies",
  "presence_sys.unassigned_proxy": "Unassigned proxy",
  "presence_sys.assign_area_in_ha": "Assign Area in Home Assistant",
  "presence_sys.active_winner": "Active winner",
  "presence_sys.stale_suffix": " (stale)",
  "presence_sys.trim_suffix": " • trim {offset}",
  "presence_sys.antenna_trim": "Antenna trim",
  "presence_sys.antenna_trim_help":
    "Raw {raw} • Offset {offset} — adjust only if this proxy consistently reads stronger or weaker across every Area.",
  "presence_sys.minus_one_db": "-1 dB",
  "presence_sys.plus_one_db": "+1 dB",
  "presence_sys.empty_survey": "No Bluetooth proxy readings yet for this Device.",
  "presence_sys.advanced_subtitle":
    "System-wide away timeout, maximum detection distance, movement smoothing, and wall signal drop-off.",
  "presence_sys.away_timeout": "Away timeout",
  "presence_sys.away_timeout_desc":
    "Seconds without any Bluetooth packet before a tracked tag or offline Device is marked Away.",
  "presence_sys.max_radius": "Maximum Area radius",
  "presence_sys.max_radius_desc":
    "Ignores Bluetooth proxies farther than this distance in meters so outdoor signals do not claim indoor Areas.",
  "presence_sys.max_speed": "Maximum movement speed",
  "presence_sys.max_speed_desc":
    "Smooths sudden signal drops that would imply movement faster than this speed in meters per second.",
  "presence_sys.attenuation": "Wall signal drop-off",
  "presence_sys.attenuation_desc":
    "Controls how quickly Bluetooth signal strength fades with distance through walls (default 2.2).",
  // System -> Tools (D-020 / D-040 / D-064 / D-066)
  "tools_sys.announce_subtitle":
    "Send screen popups or spoken intercom broadcasts to all Devices, occupied Areas, or one display.",
  "tools_sys.announce_mode_aria": "Announcement mode",
  "tools_sys.screen_notification": "Screen notification",
  "tools_sys.voice_broadcast": "Voice broadcast",
  "tools_sys.target_label": "Target",
  "tools_sys.all_displays": "All Latter displays",
  "tools_sys.occupied_areas_only": "Occupied Areas only",
  "tools_sys.device_prefix": "Device: {title}",
  "tools_sys.notification_title": "Notification title",
  "tools_sys.notification_title_placeholder": "e.g. Front gate",
  "tools_sys.priority": "Priority",
  "tools_sys.priority_normal": "Normal",
  "tools_sys.priority_warning": "Warning",
  "tools_sys.priority_critical": "Critical",
  "tools_sys.include_camera": "Include primary camera",
  "tools_sys.message": "Message",
  "tools_sys.message_placeholder": "Message to display or speak…",
  "tools_sys.send_now": "Send now",
  "tools_sys.doorbell_subtitle":
    "Verify push-to-talk TTS reply playback through Camera 1's bound door speaker.",
  "tools_sys.source_device": "Source Device",
  "tools_sys.source_device_desc":
    "Latter Device context used when routing the door speaker reply.",
  "tools_sys.no_latter_devices": "— No Latter Devices —",
  "tools_sys.test_door_reply": "Test door speaker reply",
  "tools_sys.doorbell_desc_no_cam":
    "Add a camera with a bound door speaker in Shared entities first to test TTS reply playback.",
  "tools_sys.doorbell_desc_no_dev":
    "Onboard at least one Latter Device first to route push-to-talk test replies.",
  "tools_sys.doorbell_desc_ready":
    "Plays a short TTS phrase on Camera 1's bound media player ({camera}).",
  "tools_sys.doorbell_reply_placeholder": "Testing Latter doorbell audio.",
  "tools_sys.play_door_speaker": "Play on door speaker",
  "tools_sys.logs_filter_aria": "Filter diagnostic logs",
  "tools_sys.logs_all": "All events",
  "tools_sys.logs_studio": "Latter Studio",
  "tools_sys.logs_errors": "Warnings & errors",
  "tools_sys.refresh_logs": "Refresh logs",
  "tools_sys.copy_logs": "Copy logs",
  "tools_sys.clear_logs": "Clear logs",
  "tools_sys.backup_subtitle":
    "Export or restore non-secret System and Device settings as portable JSON bundles.",
  "tools_sys.export_scope": "Export scope",
  "tools_sys.entire_system": "Entire System + all Devices",
  "tools_sys.restore_from_backup": "Restore from backup",
  "tools_sys.target_device_restore": "Target Device (for single-Device backups)",
  "tools_sys.auto_system_backup": "— Automatic (System backup) —",
  "tools_sys.system_pin_label": "System security PIN",
  "tools_sys.system_pin_desc":
    "Default 4-to-12-digit PIN required before unlocking doors, opening garage covers, or disarming alarms when a Device requires a PIN.",
  "tools_sys.system_pin_aria": "System security PIN (4 to 12 digits)",
  "tools_sys.pin_replace_placeholder": "Enter new PIN to replace…",
  "tools_sys.pin_digits_placeholder": "4 to 12 digits",
  "tools_sys.save_pin": "Save PIN",
  "tools_sys.clear_pin": "Clear PIN",
  "tools_sys.signing_key_label": "Resource URL signing key",
  "tools_sys.signing_key_desc":
    "Refreshes the signing key for camera, wallpaper, and doorbell audio links and updates connected Devices.",
  "tools_sys.rotate_signing_key": "Rotate signing key",
  // Dialogs (`src/components/dialogs/*`, D-047 / D-053 / D-062 / D-064)
  "dialogs.app_pinned": "Pinned app",
  "dialogs.app_home_hub": "Home hub",
  "dialogs.app_area": "Area control",
  "dialogs.app_music": "Music",
  "dialogs.app_remote": "Remote control",
  "dialogs.app_time": "Time",
  "dialogs.app_calendar": "Calendar",
  "dialogs.app_clock": "Clock face",
  "dialogs.app_tools": "Tools",
  "dialogs.app_games": "Games",
  "dialogs.app_fallback": "Configure app",
  "dialogs.pinned_label": "Pinned shortcuts",
  "dialogs.pinned_desc":
    "Assign Home Assistant entity quick actions or deep-link any Latter app or subpage (6 buttons per page, swipable vertically).",
  "dialogs.pinned_aria": "Pinned app shortcuts",
  "dialogs.pinned_page_slot": "Page {page}",
  "dialogs.pinned_confirm_mode": "Confirm",
  "dialogs.pinned_one_tap_mode": "1-tap",
  "dialogs.pinned_empty":
    "No pinned items configured yet. The Pinned icon stays hidden on the App Dock until you add at least one item.",
  "dialogs.home_cats_label": "Home categories",
  "dialogs.home_cats_desc":
    "Toggle and reorder categories shown in the Home hub. The first available category opens by default; categories with no configured entity are not displayed.",
  "dialogs.area_cats_label": "Area categories",
  "dialogs.area_cats_desc":
    "Toggle and reorder categories shown on the Area screen. The first available category opens by default; categories with no entities in the active Area are not displayed.",
  "dialogs.remote_group_label": "Remote control scope",
  "dialogs.remote_group_desc":
    "Choose which remotes appear on this Device's Remote screen.",
  "dialogs.remote_follow_area": "Follow the active Area",
  "dialogs.remote_group_option": "Group: {name}",
  "dialogs.remote_all_system": "All System remotes",
  "dialogs.remote_missing_group": "Missing group ({id})",
  "dialogs.manage_remote_groups": "Manage remote groups",
  "dialogs.local_clock_label": "Local clock label",
  "dialogs.local_clock_desc":
    "Optional custom label shown above local time on the Clock tab.",
  "dialogs.optional_label_placeholder": "Optional label…",
  "dialogs.show_utc_label": "Show UTC clock",
  "dialogs.show_utc_desc":
    "Pin a live 24-hour UTC reference row to this Device's Clock tab.",
  "dialogs.world_clocks_label": "World clocks",
  "dialogs.world_clocks_desc":
    "Configure up to 4 custom-labeled time zones (UTC-12:00 to UTC+14:00) shown on this Device's Clock tab.",
  "dialogs.world_clocks_aria": "Configured world clocks",
  "dialogs.world_clock_city_label": "World clock {index} city label",
  "dialogs.world_clock_zone_label": "World clock {index} time zone",
  "dialogs.city_label_placeholder": "Enter city or label…",
  "dialogs.new_city_label": "New city label",
  "dialogs.add_time_zone": "Add time zone",
  "dialogs.max_world_clocks": "Maximum 4 world clocks added",
  "dialogs.select_tz_placeholder": "Select a time zone (UTC-12 to UTC+14)…",
  "dialogs.toast_enter_city": "Enter a city or label for this world clock",
  "dialogs.toast_select_tz": "Select a time zone for this world clock",
  "dialogs.toast_dup_world_clock": "That world clock is already added",
  "dialogs.toast_city_empty": "City label cannot be empty",
  "dialogs.calendar_lookahead_label": "Overview lookahead",
  "dialogs.calendar_lookahead_desc":
    "Number of upcoming days shown on the Overview tab (days with no events are omitted).",
  "dialogs.calendar_week_start_label": "Start week on",
  "dialogs.calendar_week_start_desc":
    "First column shown in Week and Month views.",
  "dialogs.tools_label": "Tools",
  "dialogs.tools_desc": "Toggle and reorder utilities shown in the Tools launcher.",
  "dialogs.games_label": "Games",
  "dialogs.games_desc": "Toggle and reorder games shown in the Games launcher.",
  "dialogs.sc_edit_dock": "Edit custom dock shortcut",
  "dialogs.sc_edit_pinned": "Edit pinned shortcut",
  "dialogs.sc_add_dock": "Add custom dock shortcut",
  "dialogs.sc_add_pinned": "Add pinned shortcut",
  "dialogs.sc_type_aria": "Shortcut type",
  "dialogs.sc_tab_subpage": "Subpage",
  "dialogs.sc_tab_app_page": "App or page",
  "dialogs.sc_tab_entity": "Home Assistant entity",
  "dialogs.sc_target_subpage": "Target subpage",
  "dialogs.sc_target_app_page": "Target app or subpage",
  "dialogs.sc_domain_filter": "Domain filter",
  "dialogs.sc_all_domains": "All domains",
  "dialogs.shortcut_entity_label": "Entity",
  "dialogs.sc_action_label": "Action",
  "dialogs.sc_confirm_label": "Confirm before running",
  "dialogs.sc_confirm_dock_desc":
    "Shows a confirmation prompt before running this action from the App Dock.",
  "dialogs.sc_confirm_pinned_desc":
    "Require a confirmation tap instead of running immediately on a single tap.",
  "dialogs.sc_custom_label": "Custom label (optional)",
  "dialogs.sc_default_shortcut": "Shortcut",
  "dialogs.sc_default_entity_action": "Entity action",
  "dialogs.sc_icon_label": "Icon (optional MDI override)",
  "dialogs.sc_icon_search_placeholder":
    "Search all {total} icons (e.g. teddy-bear, baby, lamp)…",
  "dialogs.sc_icon_selected": "Selected: {icon}",
  "dialogs.sc_icon_default": "Default: {icon}",
  "dialogs.sc_icon_no_matches": "No matching icons — try another keyword",
  "dialogs.sc_icon_showing_subset": "Showing {shown} of {total} matches",
  "dialogs.sc_icon_matches_one": "1 matching icon",
  "dialogs.sc_icon_matches_many": "{count} matching icons",
  "dialogs.sc_icon_popular": "Showing popular icons ({total} searchable)",
  "dialogs.sc_mdi_group_aria": "Material Design Icons",
  "dialogs.cw_title": "Add a custom color",
  "dialogs.cw_color_aria": "Color",
  "dialogs.cw_hex_aria": "Hex color",
  "dialogs.cw_name_label": "Name",
  "dialogs.cw_name_placeholder": "e.g. Sunset coral",
  "dialogs.ble_title": "Add a BLE tag",
  "dialogs.ble_body":
    "A phone, watch, or Bluetooth tag that Latter tracks by Area. Latter displays are adopted under Discovered devices.",
  "dialogs.ble_discovered_label": "Discovered Bluetooth devices",
  "dialogs.ble_enter_manually": "Enter manually…",
  "dialogs.ble_name_label": "Name",
  "dialogs.ble_name_placeholder": "e.g. phone, watch, keys",
  "dialogs.ble_addr_label": "Target address or entity",
  "dialogs.ble_addr_placeholder":
    "AA:BB:CC:DD:EE:FF, iBeacon UUID, or tracker entity",
  "dialogs.ble_addr_help":
    "Enter a static BLE MAC address, iBeacon UUID (with optional major:minor), or Home Assistant Companion App or tracker entity.",
  "dialogs.ble_person_label": "Assigned person (optional)",
  "dialogs.save_group_title": "Save custom group",
  "dialogs.save_group_body":
    "Saves this Device's settings as a reusable Device group and assigns this Device to it.",
  "dialogs.save_group_name_placeholder": "e.g. Nightstands, Guest suites",
  "dialogs.save_group_desc_placeholder": "Optional summary of these settings",
  // Confirmation dialogs (D-064 / Q5 — all destructive / System-wide actions)
  "confirm.blast_radius_one": "Affects 1 Device",
  "confirm.blast_radius_many": "Affects {count} Devices",
  "confirm.remove_device.title": "Remove {title}?",
  "confirm.remove_device.body":
    "Removes \"{title}\" from Latter and deletes its stored Latter preferences and shortcuts. Your ESPHome device stays in Home Assistant.",
  "confirm.remove_device.confirm": "Remove Device",
  "confirm.reset_device.title": "Reset to defaults?",
  "confirm.reset_device.body":
    "Wi-Fi and pairing are kept, so the Device rejoins Home Assistant automatically. Its ESPHome binding and Music Assistant player link are kept too.",
  "confirm.reset_device.device_settings": "Settings saved on the Device",
  "confirm.reset_device.device_settings_desc":
    "Erases everything saved on the Device and restarts it.",
  "confirm.reset_device.latter_options": "Latter settings for this Device",
  "confirm.reset_device.latter_options_desc":
    "Resets shortcuts, group assignment, and Latter preferences for this Device to factory defaults.",
  "confirm.reset_device.confirm": "Reset",
  "confirm.restore_backup.title": "Restore from backup?",
  "confirm.restore_backup.body":
    "Overwrites current Latter settings with the selected JSON backup bundle.",
  "confirm.restore_backup.confirm": "Restore backup",
  "confirm.delete_group.title": "Delete group \"{name}\"?",
  "confirm.delete_group.body":
    "Devices currently assigned to this group keep their settings and switch to Custom.",
  "confirm.delete_group.confirm": "Delete group",
  "confirm.reset_group.title": "Reset \"{name}\" to preset defaults?",
  "confirm.reset_group.body":
    "Restores the built-in power, wake, and scope defaults for this group and applies them to assigned Devices.",
  "confirm.reset_group.confirm": "Reset preset",
  "confirm.rotate_signing_key.title": "Rotate URL signing key?",
  "confirm.rotate_signing_key.body":
    "Invalidates active signed wallpaper, camera snapshot, and doorbell audio URLs until Devices receive the next state push.",
  "confirm.rotate_signing_key.confirm": "Rotate signing key",
  "confirm.delete_wallpaper.title": "Delete wallpaper \"{name}\"?",
  "confirm.delete_wallpaper.body":
    "Permanently deletes this uploaded wallpaper. Devices using it revert to their fallback background.",
  "confirm.delete_wallpaper.confirm": "Delete wallpaper",
  "confirm.reset_dock.title": "Reset App Dock to default?",
  "confirm.reset_dock.body":
    "Restores the default native apps on the App Dock and removes custom dock shortcuts on this Device.",
  "confirm.reset_dock.confirm": "Reset dock",
  "confirm.clear_ble_signature.title": "Clear BLE signature for {area}?",
  "confirm.clear_ble_signature.body":
    "Removes captured RSSI calibration samples for {area} and reverts to path-loss estimation.",
  "confirm.clear_ble_signature.confirm": "Clear signature",
  "confirm.clear_pin.title": "Clear security PIN?",
  "confirm.clear_pin.body":
    "Removes the configured security PIN. Perimeter actions governed by Require PIN stay blocked until a new PIN is set.",
  "confirm.clear_pin.confirm": "Clear PIN",
  "confirm.apply_batch.title": "Apply staged changes to {count} Devices?",
  "confirm.apply_batch.body":
    "Pushes {settingCount} staged setting changes to {count} target Devices.",
  "confirm.apply_batch.confirm": "Apply changes",
};
__latterExp(__exports, { EN_SYSTEM_STRINGS: () => EN_SYSTEM_STRINGS });
//# sourceURL=latter-studio/src/i18n/en-system.ts
});
__latterDef("src/i18n/en.ts", (__exports, __req) => {
const { EN_COMMON_STRINGS } = __req("src/i18n/en-common.ts");
const { EN_DEVICES_STRINGS } = __req("src/i18n/en-devices.ts");
const { EN_SYSTEM_STRINGS } = __req("src/i18n/en-system.ts");
/**
 * Canonical English Studio UI string catalog (`D-061` — Home Assistant Sentence case).
 * Composed from disjoint slices (`en-common.ts`, `en-system.ts`, `en-devices.ts`) and mirrored
 * deterministically to `custom_components/latter/studio/locales/en.json` by `build.mjs`.
 */
const EN_STRINGS = {
  ...EN_COMMON_STRINGS,
  ...EN_SYSTEM_STRINGS,
  ...EN_DEVICES_STRINGS,
};
/**
 * Sentence-case labels for all 56 `DevicePrefSpec` keys + group/device setting keys.
 */
const PREF_LABELS = {
  wake_word_mode: "Wake word mode",
  tap_to_wake: "Tap to wake",
  pickup_to_wake: "Pickup to wake",
  battery_screen_timeout: "Battery screen timeout",
  docked_idle_timeout: "Docked idle timeout",
  battery_hibernate_timeout: "Battery hibernate timeout",
  docked_screensaver: "Docked screensaver",
  screensaver_style: "Screensaver style",
  hold_crown_power_off: "Hold crown to power off",
  bedtime_active: "Bedtime mode",
  bedtime_display: "Idle display in bedtime",
  bedtime_brightness: "Bedtime brightness",
  bedtime_schedule: "Bedtime schedule",
  bedtime_start_hour: "Bedtime starts",
  bedtime_end_hour: "Bedtime ends",
  auto_brightness_mode: "Auto brightness mode",
  manual_brightness: "Manual brightness",
  day_brightness: "Day brightness",
  night_brightness: "Night brightness",
  day_start_hour: "Day start hour",
  night_start_hour: "Night start hour",
  color_profile: "Color profile",
  va_visual_profile: "Visual profile",
  home_screen_enabled: "Enable Home screen",
  start_screen: "Start screen",
  return_to_home_timeout: "Return to Home timeout",
  clock_face: "Clock face",
  time_format: "Time format",
  weather_background: "Weather background",
  home_sun: "Sun",
  home_moon: "Moon",
  wake_greeting: "Wake greeting",
  album_art_style: "Album art style",
  music_overlay_style: "Overlay style",
  album_sort_order: "Album sort order",
  artist_album_sort_order: "Artist album sort order",
  podcast_sort_order: "Podcast sort order",
  ww_sens_okay_nabu: "Okay Nabu sensitivity",
  ww_sens_hey_luna: "Hey Luna sensitivity",
  ww_sens_hey_jarvis: "Hey Jarvis sensitivity",
  ww_sens_hey_mycroft: "Hey Mycroft sensitivity",
  ww_sens_alexa: "Alexa sensitivity",
  wake_screen_on_assist: "Wake screen on Assist",
  alert_volume: "Alert volume",
  volume_step_size: "Volume step size",
  game_sound_effects: "Game sound effects",
  ble_beacon_mode: "BLE beacon mode",
  weather_sim_condition: "Weather simulation",
  home_clock_tap_action: "Home time tap",
  home_date_tap_action: "Home date tap",
  local_clock_label: "Local clock label",
  show_utc_clock: "Show UTC clock",
  world_clocks: "World clocks",
  alarms_summary: "Alarms",
  calendar_lookahead_days: "Overview lookahead",
  calendar_week_start: "Start week on",
  // Non-pref group & Device config keys
  native_ble_tracking: "BLE Area tracking",
  ble_auto_switch: "Auto-switch active Area",
  sync_device_area: "Voice Follows Me",
  area_follow_dwell_s: "Area follow dwell",
  area_handoff: "Media Area handoff",
  security_pin_policy: "Perimeter security policy",
  wallpaper_source: "Wallpaper",
  wallpaper_cycle_minutes: "Wallpaper rotation",
  device_custom_color: "Custom color",
  device_remote_group: "Remote control scope",
  activity_card: "Show Activity card",
  activity_sources: "Activity card sources",
  area_categories: "Area categories",
  home_categories: "Home categories",
  tools_items: "Enabled tools",
  games_items: "Enabled games",
};
/**
 * Maps canonical wire option strings (`protocol_v3.json` / ESPHome select options) to
 * localized Sentence-case display labels without changing wire values.
 */
const PREF_OPTION_LABELS = {
  // Wake & power options
  "Docked Only": "Docked only",
  "Always On": "Always on",
  Disabled: "Disabled",
  "Single Tap": "Single tap",
  "Double Tap": "Double tap",
  Never: "Never",
  "10s": "10 seconds",
  "15s": "15 seconds",
  "30s": "30 seconds",
  "1 min": "1 minute",
  "2 min": "2 minutes",
  "5 min": "5 minutes",
  "10 min": "10 minutes",
  "15 min": "15 minutes",
  "30 min": "30 minutes",
  // Screensaver, brightness & colors
  "Screen Off": "Screen off",
  "Ambient Clock": "Ambient clock",
  Aurora: "Aurora",
  Starfield: "Starfield",
  "Digital Rain": "Digital rain",
  Fireworks: "Fireworks",
  "Sun Synchronized": "Sun synchronized",
  "Time Schedule": "Time schedule",
  "Steel Blue": "Steel blue",
  Pink: "Pink",
  Blue: "Blue",
  Green: "Green",
  Custom: "Custom",
  Nebula: "Nebula",
  Solaris: "Solaris",
  Rings: "Rings",
  "Light Bar": "Light bar",
  "Dot Wave": "Dot wave",
  // Home, start screen, clock & calendar
  Home: "Home",
  Pinned: "Pinned",
  "Time App": "Time app",
  Calendar: "Calendar",
  "Clock Face": "Clock face",
  Media: "Media",
  "Home Hub": "Home hub",
  "Area Controls": "Area controls",
  Remote: "Remote",
  Weather: "Weather",
  Cameras: "Cameras",
  Games: "Games",
  Tools: "Tools",
  "Minimal Digital": "Minimal digital",
  "Modern Analog": "Modern analog",
  "Hybrid Digital": "Hybrid digital",
  "12-Hour (AM/PM)": "12-hour (AM/PM)",
  "24-Hour": "24-hour",
  "Day View": "Day view",
  Overview: "Overview",
  Sunday: "Sunday",
  Monday: "Monday",
  // Music & media
  "Full Screen": "Full screen",
  Letterbox: "Letterbox",
  Standard: "Standard",
  None: "None",
  "Art Only": "Art only",
  "Art + Metadata": "Art + metadata",
  "Always Visible": "Always visible",
  Alphabetical: "Alphabetical",
  "Newest on Top": "Newest on top",
  "Oldest on Top": "Oldest on top",
  // Wake word sensitivity & BLE beacon
  "Slightly sensitive": "Slightly sensitive",
  "Moderately sensitive": "Moderately sensitive",
  "Very sensitive": "Very sensitive",
  "Handheld Only": "Handheld only",
  "Handheld + Screen Off": "Handheld + screen off",
  Always: "Always",
  // Weather simulation
  "Live (Home Assistant)": "Live (Home Assistant)",
  "Clear Night": "Clear night",
  "Sunny / Clear Day": "Sunny / clear day",
  "Partly Cloudy (Day)": "Partly cloudy (day)",
  "Partly Cloudy (Night)": "Partly cloudy (night)",
  "Cloudy / Overcast (Day)": "Cloudy / overcast (day)",
  "Cloudy / Overcast (Night)": "Cloudy / overcast (night)",
  "Fog / Mist (Day)": "Fog / mist (day)",
  "Fog / Mist (Night)": "Fog / mist (night)",
  "Rainy (Day)": "Rainy (day)",
  "Rainy (Night)": "Rainy (night)",
  "Pouring / Heavy Rain": "Pouring / heavy rain",
  "Snow (Day)": "Snow (day)",
  "Snow (Night)": "Snow (night)",
  "Thunderstorm (Day)": "Thunderstorm (day)",
  "Thunderstorm (Night)": "Thunderstorm (night)",
  Windy: "Windy",
  // Security PIN policy wire tokens
  auto: "Auto (recommended)",
  allow: "Allow without PIN",
  require_pin: "Require PIN",
  block: "Block unlock & disarm",
};
/**
 * Builds the complete deterministic flat JSON catalog written to
 * `custom_components/latter/studio/locales/en.json`.
 */
function buildStudioEnLocaleCatalog() {
  const out = {};
  for (const [k, v] of Object.entries(EN_STRINGS)) {
    out[k] = v;
  }
  for (const [k, v] of Object.entries(PREF_LABELS)) {
    out[`pref.${k}`] = v;
  }
  for (const [k, v] of Object.entries(PREF_OPTION_LABELS)) {
    out[`pref_option.${k}`] = v;
  }
  return out;
}
__latterExp(__exports, { EN_COMMON_STRINGS: () => EN_COMMON_STRINGS, EN_DEVICES_STRINGS: () => EN_DEVICES_STRINGS, EN_SYSTEM_STRINGS: () => EN_SYSTEM_STRINGS, EN_STRINGS: () => EN_STRINGS, PREF_LABELS: () => PREF_LABELS, PREF_OPTION_LABELS: () => PREF_OPTION_LABELS, buildStudioEnLocaleCatalog: () => buildStudioEnLocaleCatalog });
//# sourceURL=latter-studio/src/i18n/en.ts
});
__latterDef("src/i18n/index.ts", (__exports, __req) => {
const { buildStudioEnLocaleCatalog, EN_STRINGS, PREF_LABELS, PREF_OPTION_LABELS } = __req("src/i18n/en.ts");
/**
 * Hybrid typed Studio i18n runtime (`D-061`):
 * - Compile-time typed `t()` lookup against `EN_STRINGS` with runtime `<lang>.json` overlay support
 * - Preference label & canonical wire option localization (`tPrefLabel`, `tPrefOption`)
 * - Home Assistant Repairs `hass.localize` bridge (`localizeRepairIssue`)
 * - Home Assistant entity state formatter bridge (`formatHaEntityState`)
 */
const PLACEHOLDER_RE = /\{([A-Za-z0-9_]+)\}/g;
function interpolate(
  template,
  vars,
) {
  if (!vars) return template;
  return template.replace(PLACEHOLDER_RE, (match, name) => {
    const val = vars[name];
    return val === undefined || val === null ? match : String(val);
  });
}
function t(
  key,
  vars,
  overlay,
) {
  const raw = (overlay && overlay[key]) || EN_STRINGS[key] || key;
  return interpolate(raw, vars);
}
function tPrefLabel(
  key,
  fallback,
  overlay,
) {
  const cleanKey = String(key || "").trim();
  if (!cleanKey) return fallback || "—";
  const overlayVal = overlay?.[`pref.${cleanKey}`];
  if (overlayVal) return overlayVal;
  const known = PREF_LABELS[cleanKey];
  if (known) return known;
  if (fallback && fallback.trim()) return fallback.trim();
  const humanized = cleanKey.replace(/_/g, " ").trim();
  return humanized ? humanized.charAt(0).toUpperCase() + humanized.slice(1) : "—";
}
function tPrefOption(
  prefKey,
  rawOption,
  overlay,
) {
  const opt = String(rawOption ?? "");
  if (!opt) return "";
  if (overlay) {
    const scoped = prefKey ? overlay[`pref_option.${prefKey}.${opt}`] : undefined;
    if (scoped) return scoped;
    const generic = overlay[`pref_option.${opt}`];
    if (generic) return generic;
  }
  return PREF_OPTION_LABELS[opt] ?? opt;
}
function localizeRepairIssue(
  hass,
  issueKey,
  placeholders,
  fallback,
) {
  const cleanKey = String(issueKey || "").trim();
  const h = hass;
  if (cleanKey && typeof h?.localize === "function") {
    const params = placeholders ? { ...placeholders } : undefined;
    for (const suffix of [".description", ".title", ""]) {
      const haKey = `component.latter.issues.${cleanKey}${suffix}`;
      try {
        const localized = h.localize(haKey, params);
        if (localized && localized !== haKey && !localized.startsWith("component.latter.")) {
          return localized;
        }
      } catch {
        // Fall through to Studio catalog / fallback string.
      }
    }
  }
  if (fallback) return fallback;
  if (!cleanKey) return t("issue.generic", { label: "issue" });
  const detail = placeholders?.detail !== undefined ? String(placeholders.detail) : "";
  if (cleanKey === "missing_mapped_entity") {
    return detail
      ? t("issue.missing_mapped_entity_detail", { detail })
      : t("issue.missing_mapped_entity");
  }
  if (cleanKey === "device_crashed") {
    if (detail === "stall") return t("issue.device_crashed_stall");
    return detail
      ? t("issue.device_crashed_detail", { detail })
      : t("issue.device_crashed");
  }
  const catalogKey = `issue.${cleanKey}`;
  if (catalogKey in EN_STRINGS) {
    return t(catalogKey, placeholders);
  }
  return t("issue.generic", { label: cleanKey.replace(/_/g, " ") });
}
function formatHaEntityState(
  hass,
  entityId,
  option,
) {
  const cleanId = String(entityId || "").trim();
  const stateObj = cleanId ? hass?.states?.[cleanId] : undefined;
  const h = hass;
  if (stateObj && typeof h?.formatEntityState === "function") {
    try {
      const formatted = h.formatEntityState(stateObj, option);
      if (formatted) return formatted;
    } catch {
      // Fall back to raw state string below.
    }
  }
  const raw = option ?? stateObj?.state ?? "";
  return raw || "—";
}
__latterExp(__exports, { buildStudioEnLocaleCatalog: () => buildStudioEnLocaleCatalog, EN_STRINGS: () => EN_STRINGS, PREF_LABELS: () => PREF_LABELS, PREF_OPTION_LABELS: () => PREF_OPTION_LABELS, t: () => t, tPrefLabel: () => tPrefLabel, tPrefOption: () => tPrefOption, localizeRepairIssue: () => localizeRepairIssue, formatHaEntityState: () => formatHaEntityState });
//# sourceURL=latter-studio/src/i18n/index.ts
});
__latterDef("src/lib/vendor/directive.js", (__exports, __req) => {
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const t={ATTRIBUTE:1,CHILD:2,PROPERTY:3,BOOLEAN_ATTRIBUTE:4,EVENT:5,ELEMENT:6},e=t=>(...e)=>({_$litDirective$:t,values:e});class i{constructor(t){}get _$AU(){return this._$AM._$AU}_$AT(t,e,i){this._$Ct=t,this._$AM=e,this._$Ci=i}_$AS(t,e){return this.update(t,e)}update(t,e){return this.render(...e)}}
__latterExp(__exports, { Directive: () => i, PartType: () => t, directive: () => e });
//# sourceURL=latter-studio/src/lib/vendor/directive.js
});
__latterDef("src/lib/vendor/lit-html.js", (__exports, __req) => {
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 * Latter Studio adaptation: live DOM comparison on PropertyPart (`class I`) and post-children `<select .value>` sync (`class R.p`).
 */
const t=globalThis,i=t=>t,s=t.trustedTypes,e=s?s.createPolicy("lit-html",{createHTML:t=>t}):void 0,h="$lit$",o=`lit$${Math.random().toFixed(9).slice(2)}$`,n="?"+o,r=`<${n}>`,l=document,c=()=>l.createComment(""),a=t=>null===t||"object"!=typeof t&&"function"!=typeof t,u=Array.isArray,d=t=>u(t)||"function"==typeof t?.[Symbol.iterator],f="[ \t\n\f\r]",v=/<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g,_=/-->/g,m=/>/g,p=RegExp(`>|${f}(?:([^\\s"'>=/]+)(${f}*=${f}*(?:[^ \t\n\f\r"'\`<>=]|("|')|))|$)`,"g"),g=/'/g,$=/"/g,y=/^(?:script|style|textarea|title)$/i,x=t=>(i,...s)=>({_$litType$:t,strings:i,values:s}),b=x(1),w=x(2),T=x(3),E=Symbol.for("lit-noChange"),A=Symbol.for("lit-nothing"),C=new WeakMap,P=l.createTreeWalker(l,129);function V(t,i){if(!u(t)||!t.hasOwnProperty("raw"))throw Error("invalid template strings array");return void 0!==e?e.createHTML(i):i}const N=(t,i)=>{const s=t.length-1,e=[];let n,l=2===i?"<svg>":3===i?"<math>":"",c=v;for(let i=0;i<s;i++){const s=t[i];let a,u,d=-1,f=0;for(;f<s.length&&(c.lastIndex=f,u=c.exec(s),null!==u);)f=c.lastIndex,c===v?"!--"===u[1]?c=_:void 0!==u[1]?c=m:void 0!==u[2]?(y.test(u[2])&&(n=RegExp("</"+u[2],"g")),c=p):void 0!==u[3]&&(c=p):c===p?">"===u[0]?(c=n??v,d=-1):void 0===u[1]?d=-2:(d=c.lastIndex-u[2].length,a=u[1],c=void 0===u[3]?p:'"'===u[3]?$:g):c===$||c===g?c=p:c===_||c===m?c=v:(c=p,n=void 0);const x=c===p&&t[i+1].startsWith("/>")?" ":"";l+=c===v?s+r:d>=0?(e.push(a),s.slice(0,d)+h+s.slice(d)+o+x):s+o+(-2===d?i:x)}return[V(t,l+(t[s]||"<?>")+(2===i?"</svg>":3===i?"</math>":"")),e]};class S{constructor({strings:t,_$litType$:i},e){let r;this.parts=[];let l=0,a=0;const u=t.length-1,d=this.parts,[f,v]=N(t,i);if(this.el=S.createElement(f,e),P.currentNode=this.el.content,2===i||3===i){const t=this.el.content.firstChild;t.replaceWith(...t.childNodes)}for(;null!==(r=P.nextNode())&&d.length<u;){if(1===r.nodeType){if(r.hasAttributes())for(const t of r.getAttributeNames())if(t.endsWith(h)){const i=v[a++],s=r.getAttribute(t).split(o),e=/([.?@])?(.*)/.exec(i);d.push({type:1,index:l,name:e[2],strings:s,ctor:"."===e[1]?I:"?"===e[1]?L:"@"===e[1]?z:H}),r.removeAttribute(t)}else t.startsWith(o)&&(d.push({type:6,index:l}),r.removeAttribute(t));if(y.test(r.tagName)){const t=r.textContent.split(o),i=t.length-1;if(i>0){r.textContent=s?s.emptyScript:"";for(let s=0;s<i;s++)r.append(t[s],c()),P.nextNode(),d.push({type:2,index:++l});r.append(t[i],c())}}}else if(8===r.nodeType)if(r.data===n)d.push({type:2,index:l});else{let t=-1;for(;-1!==(t=r.data.indexOf(o,t+1));)d.push({type:7,index:l}),t+=o.length-1}l++}}static createElement(t,i){const s=l.createElement("template");return s.innerHTML=t,s}}function M(t,i,s=t,e){if(i===E)return i;let h=void 0!==e?s._$Co?.[e]:s._$Cl;const o=a(i)?void 0:i._$litDirective$;return h?.constructor!==o&&(h?._$AO?.(!1),void 0===o?h=void 0:(h=new o(t),h._$AT(t,s,e)),void 0!==e?(s._$Co??=[])[e]=h:s._$Cl=h),void 0!==h&&(i=M(t,h._$AS(t,i.values),h,e)),i}class R{constructor(t,i){this._$AV=[],this._$AN=void 0,this._$AD=t,this._$AM=i}get parentNode(){return this._$AM.parentNode}get _$AU(){return this._$AM._$AU}u(t){const{el:{content:i},parts:s}=this._$AD,e=(t?.creationScope??l).importNode(i,!0);P.currentNode=e;let h=P.nextNode(),o=0,n=0,r=s[0];for(;void 0!==r;){if(o===r.index){let i;2===r.type?i=new k(h,h.nextSibling,this,t):1===r.type?i=new r.ctor(h,r.name,r.strings,this,t):6===r.type&&(i=new Z(h,this,t)),this._$AV.push(i),r=s[++n]}o!==r?.index&&(h=P.nextNode(),o++)}return P.currentNode=l,e}p(t){let i=0;for(const s of this._$AV)void 0!==s&&(void 0!==s.strings?(s._$AI(t,s,i),i+=s.strings.length-2):s._$AI(t[i])),i++;for(const s of this._$AV)3===s?.type&&"value"===s.name&&"SELECT"===s.element.tagName&&s._$AH!==E&&s._$AH!==A&&void 0!==s._$AH&&s.element.value!==s._$AH&&(s.element.value=s._$AH)}}class k{get _$AU(){return this._$AM?._$AU??this._$Cv}constructor(t,i,s,e){this.type=2,this._$AH=A,this._$AN=void 0,this._$AA=t,this._$AB=i,this._$AM=s,this.options=e,this._$Cv=e?.isConnected??!0}get parentNode(){let t=this._$AA.parentNode;const i=this._$AM;return void 0!==i&&11===t?.nodeType&&(t=i.parentNode),t}get startNode(){return this._$AA}get endNode(){return this._$AB}_$AI(t,i=this){t=M(this,t,i),a(t)?t===A||null==t||""===t?(this._$AH!==A&&this._$AR(),this._$AH=A):t!==this._$AH&&t!==E&&this._(t):void 0!==t._$litType$?this.$(t):void 0!==t.nodeType?this.T(t):d(t)?this.k(t):this._(t)}O(t){return this._$AA.parentNode.insertBefore(t,this._$AB)}T(t){this._$AH!==t&&(this._$AR(),this._$AH=this.O(t))}_(t){this._$AH!==A&&a(this._$AH)?this._$AA.nextSibling.data=t:this.T(l.createTextNode(t)),this._$AH=t}$(t){const{values:i,_$litType$:s}=t,e="number"==typeof s?this._$AC(t):(void 0===s.el&&(s.el=S.createElement(V(s.h,s.h[0]),this.options)),s);if(this._$AH?._$AD===e)this._$AH.p(i);else{const t=new R(e,this),s=t.u(this.options);t.p(i),this.T(s),this._$AH=t}}_$AC(t){let i=C.get(t.strings);return void 0===i&&C.set(t.strings,i=new S(t)),i}k(t){u(this._$AH)||(this._$AH=[],this._$AR());const i=this._$AH;let s,e=0;for(const h of t)e===i.length?i.push(s=new k(this.O(c()),this.O(c()),this,this.options)):s=i[e],s._$AI(h),e++;e<i.length&&(this._$AR(s&&s._$AB.nextSibling,e),i.length=e)}_$AR(t=this._$AA.nextSibling,s){for(this._$AP?.(!1,!0,s);t!==this._$AB;){const s=i(t).nextSibling;i(t).remove(),t=s}}setConnected(t){void 0===this._$AM&&(this._$Cv=t,this._$AP?.(t))}}class H{get tagName(){return this.element.tagName}get _$AU(){return this._$AM._$AU}constructor(t,i,s,e,h){this.type=1,this._$AH=A,this._$AN=void 0,this.element=t,this.name=i,this._$AM=e,this.options=h,s.length>2||""!==s[0]||""!==s[1]?(this._$AH=Array(s.length-1).fill(new String),this.strings=s):this._$AH=A}_$AI(t,i=this,s,e){const h=this.strings;let o=!1;if(void 0===h)t=M(this,t,i,0),o=!a(t)||t!==this._$AH&&t!==E,o&&(this._$AH=t);else{const e=t;let n,r;for(t=h[0],n=0;n<h.length-1;n++)r=M(this,e[s+n],i,n),r===E&&(r=this._$AH[n]),o||=!a(r)||r!==this._$AH[n],r===A?t=A:t!==A&&(t+=(r??"")+h[n+1]),this._$AH[n]=r}o&&!e&&this.j(t)}j(t){t===A?this.element.removeAttribute(this.name):this.element.setAttribute(this.name,t??"")}}class I extends H{constructor(){super(...arguments),this.type=3}_$AI(t,i=this,s,e){if(void 0!==this.strings){super._$AI(t,i,s,e);return}if((t=M(this,t,i,0))===E)return;const r=t===A?void 0:t;this._$AH=t,e||this.element[this.name]===r||(this.element[this.name]=r)}j(t){this.element[this.name]=t===A?void 0:t}}class L extends H{constructor(){super(...arguments),this.type=4}j(t){this.element.toggleAttribute(this.name,!!t&&t!==A)}}class z extends H{constructor(t,i,s,e,h){super(t,i,s,e,h),this.type=5}_$AI(t,i=this){if((t=M(this,t,i,0)??A)===E)return;const s=this._$AH,e=t===A&&s!==A||t.capture!==s.capture||t.once!==s.once||t.passive!==s.passive,h=t!==A&&(s===A||e);e&&this.element.removeEventListener(this.name,this,s),h&&this.element.addEventListener(this.name,this,t),this._$AH=t}handleEvent(t){"function"==typeof this._$AH?this._$AH.call(this.options?.host??this.element,t):this._$AH.handleEvent(t)}}class Z{constructor(t,i,s){this.element=t,this.type=6,this._$AN=void 0,this._$AM=i,this.options=s}get _$AU(){return this._$AM._$AU}_$AI(t){M(this,t)}}const j={M:h,P:o,A:n,C:1,L:N,R,D:d,V:M,I:k,H,N:L,U:z,B:I,F:Z},B=t.litHtmlPolyfillSupport;B?.(S,k),(t.litHtmlVersions??=[]).push("3.3.3");const D=(t,i,s)=>{const e=s?.renderBefore??i;let h=e._$litPart$;if(void 0===h){const t=s?.renderBefore??null;e._$litPart$=h=new k(i.insertBefore(c(),t),t,void 0,s??{})}return h._$AI(t),h};
__latterExp(__exports, { _$LH: () => j, html: () => b, mathml: () => T, noChange: () => E, nothing: () => A, render: () => D, svg: () => w });
//# sourceURL=latter-studio/src/lib/vendor/lit-html.js
});
__latterDef("src/lib/vendor/directive-helpers.js", (__exports, __req) => {
const { _$LH: o } = __req("src/lib/vendor/lit-html.js");
/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const{I:t}=o,i=o=>o,n=o=>null===o||"object"!=typeof o&&"function"!=typeof o,e={HTML:1,SVG:2,MATHML:3},l=(o,t)=>void 0===t?void 0!==o?._$litType$:o?._$litType$===t,d=o=>null!=o?._$litType$?.h,c=o=>void 0!==o?._$litDirective$,f=o=>o?._$litDirective$,r=o=>void 0===o.strings,s=()=>document.createComment(""),v=(o,n,e)=>{const l=o._$AA.parentNode,d=void 0===n?o._$AB:n._$AA;if(void 0===e){const i=l.insertBefore(s(),d),n=l.insertBefore(s(),d);e=new t(i,n,o,o.options)}else{const t=e._$AB.nextSibling,n=e._$AM,c=n!==o;if(c){let t;e._$AQ?.(o),e._$AM=o,void 0!==e._$AP&&(t=o._$AU)!==n._$AU&&e._$AP(t)}if(t!==d||c){let o=e._$AA;for(;o!==t;){const t=i(o).nextSibling;i(l).insertBefore(o,d),o=t}}}return e},u=(o,t,i=o)=>(o._$AI(t,i),o),m={},p=(o,t=m)=>o._$AH=t,M=o=>o._$AH,h=o=>{o._$AR(),o._$AA.remove()},j=o=>{o._$AR()};
__latterExp(__exports, { TemplateResultType: () => e, clearPart: () => j, getCommittedValue: () => M, getDirectiveClass: () => f, insertPart: () => v, isCompiledTemplateResult: () => d, isDirectiveResult: () => c, isPrimitive: () => n, isSingleExpression: () => r, isTemplateResult: () => l, removePart: () => h, setChildPartValue: () => u, setCommittedValue: () => p });
//# sourceURL=latter-studio/src/lib/vendor/directive-helpers.js
});
__latterDef("src/lib/vendor/directives/repeat.js", (__exports, __req) => {
const { noChange: e } = __req("src/lib/vendor/lit-html.js");
const { directive: s, Directive: t, PartType: r } = __req("src/lib/vendor/directive.js");
const { getCommittedValue: l, setChildPartValue: o, insertPart: i, removePart: n, setCommittedValue: f } = __req("src/lib/vendor/directive-helpers.js");
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const u=(e,s,t)=>{const r=new Map;for(let l=s;l<=t;l++)r.set(e[l],l);return r},c=s(class extends t{constructor(e){if(super(e),e.type!==r.CHILD)throw Error("repeat() can only be used in text expressions")}dt(e,s,t){let r;void 0===t?t=s:void 0!==s&&(r=s);const l=[],o=[];let i=0;for(const s of e)l[i]=r?r(s,i):i,o[i]=t(s,i),i++;return{values:o,keys:l}}render(e,s,t){return this.dt(e,s,t).values}update(s,[t,r,c]){const d=l(s),{values:p,keys:a}=this.dt(t,r,c);if(!Array.isArray(d))return this.ut=a,p;const h=this.ut??=[],v=[];let m,y,x=0,j=d.length-1,k=0,w=p.length-1;for(;x<=j&&k<=w;)if(null===d[x])x++;else if(null===d[j])j--;else if(h[x]===a[k])v[k]=o(d[x],p[k]),x++,k++;else if(h[j]===a[w])v[w]=o(d[j],p[w]),j--,w--;else if(h[x]===a[w])v[w]=o(d[x],p[w]),i(s,v[w+1],d[x]),x++,w--;else if(h[j]===a[k])v[k]=o(d[j],p[k]),i(s,d[x],d[j]),j--,k++;else if(void 0===m&&(m=u(a,k,w),y=u(h,x,j)),m.has(h[x]))if(m.has(h[j])){const e=y.get(a[k]),t=void 0!==e?d[e]:null;if(null===t){const e=i(s,d[x]);o(e,p[k]),v[k]=e}else v[k]=o(t,p[k]),i(s,d[x],t),d[e]=null;k++}else n(d[j]),j--;else n(d[x]),x++;for(;k<=w;){const e=i(s,v[w+1]);o(e,p[k]),v[k++]=e}for(;x<=j;){const e=d[x++];null!==e&&n(e)}return this.ut=a,f(s,v),e}});
__latterExp(__exports, { repeat: () => c });
//# sourceURL=latter-studio/src/lib/vendor/directives/repeat.js
});
__latterDef("src/lib/lit.ts", (__exports, __req) => {
const { Directive, directive, PartType } = __req("src/lib/vendor/directive.js");
const { repeat: litRepeat } = __req("src/lib/vendor/directives/repeat.js");
const { html, noChange, nothing, render, svg } = __req("src/lib/vendor/lit-html.js");
/**
 * Vendored `lit-html` (v3.3.3, BSD-3-Clause) wrapper, thin `LitElement` reactive host,
 * `focusSafe` property directive (`D-039`), and duplicate-key-safe `repeat` directive (`D-062`).
 */
const STYLE_SHEET_CACHE = new WeakMap();
function css(strings, ...values) {
  let out = "";
  for (let i = 0; i < strings.length; i += 1) {
    out += strings[i];
    if (i < values.length) {
      const v = values[i];
      if (v && typeof v === "object" && "styleSheetText" in (v)) {
        out += (v).styleSheetText;
      } else if (v !== undefined && v !== null) {
        out += String(v);
      }
    }
  }
  return { styleSheetText: out };
}
function getCachedStyleSheet(res) {
  let sheet = STYLE_SHEET_CACHE.get(res);
  if (!sheet) {
    sheet = new CSSStyleSheet();
    sheet.replaceSync(res.styleSheetText);
    STYLE_SHEET_CACHE.set(res, sheet);
  }
  return sheet;
}
const NON_TEXT_INPUT_TYPES = new Set([
  "button",
  "checkbox",
  "color",
  "file",
  "hidden",
  "image",
  "radio",
  "range",
  "reset",
  "submit",
]);
function isActivelyFocusedTextControl(el) {
  if (!el) return false;
  const tag = el.tagName;
  if (tag !== "INPUT" && tag !== "TEXTAREA") return false;
  if (tag === "INPUT") {
    const inpType = ((el).type || "text").toLowerCase();
    if (NON_TEXT_INPUT_TYPES.has(inpType)) return false;
  }
  const root = typeof el.getRootNode === "function" ? el.getRootNode() : null;
  if (root && typeof root === "object" && "activeElement" in root) {
    return (root).activeElement === el;
  }
  return typeof document !== "undefined" && document.activeElement === el;
}
class FocusSafeDirective extends Directive {
          _initialized = false;
  constructor(partInfo) {
    super(partInfo);
    if (partInfo.type !== PartType.PROPERTY && partInfo.type !== PartType.ATTRIBUTE) {
      throw new Error("focusSafe() can only be used in property or attribute bindings");
    }
  }
  render(value) {
    return value === nothing || value === null || value === undefined ? "" : value;
  }
           update(part, [value]) {
    const normalized = value === nothing || value === null || value === undefined ? "" : value;
    if (this._initialized && "element" in part && isActivelyFocusedTextControl(part.element)) {
      return noChange;
    }
    this._initialized = true;
    if ("element" in part && part.type === PartType.PROPERTY) {
      const target = part.element;
      if (target[part.name] !== normalized) {
        target[part.name] = normalized;
      }
      return noChange;
    }
    return normalized;
  }
}
/**
 * Property directive (`D-039`) that prevents background reactive updates from clobbering `.value`
 * on an actively focused `<input>` or `<textarea>`, while syncing live DOM value once blurred.
 */
const focusSafe = directive(FocusSafeDirective);
/**
 * Keyed `repeat()` directive with an automatic duplicate-key guard so accidental colliding keys
 * never crash or orphan DOM nodes.
 */
function repeat (
  items,
  keyFnOrTemplate,
  template,
) {
  if (template === undefined) {
    return litRepeat(items, keyFnOrTemplate);
  }
  const keyFn = keyFnOrTemplate;
  const seenKeys = new Map();
  const safeKeyFn = (item, index) => {
    if (index === 0) {
      seenKeys.clear();
    }
    const rawKey = keyFn(item, index);
    const prevCount = seenKeys.get(rawKey) ?? 0;
    seenKeys.set(rawKey, prevCount + 1);
    if (prevCount === 0) {
      return rawKey;
    }
    return `${String(rawKey)}__dup_${prevCount}`;
  };
  return litRepeat(items, safeKeyFn, template);
}
const BaseHTMLElement =
  typeof HTMLElement !== "undefined"
    ? HTMLElement
    : (class {});
class LitElement extends BaseHTMLElement {
  static styles;
           renderRoot;
                   _controllers = new Set();
          _updatePending = false;
          _hasUpdated = false;
          _updatePromise = Promise.resolve(true);
          _rootPart = null;
          _stylesAdopted = false;
  constructor() {
    super();
    this.renderRoot = this.attachShadow({ mode: "open" });
  }
  addController(controller) {
    this._controllers.add(controller);
    if (this.isConnected && controller.hostConnected) {
      controller.hostConnected();
    }
  }
  removeController(controller) {
    this._controllers.delete(controller);
  }
  connectedCallback() {
    this._adoptStylesOnce();
    this._rootPart?.setConnected(true);
    for (const c of this._controllers) {
      c.hostConnected?.();
    }
    this.requestUpdate();
  }
  disconnectedCallback() {
    for (const c of this._controllers) {
      c.hostDisconnected?.();
    }
    this._rootPart?.setConnected(false);
  }
  get updateComplete() {
    return this._updatePromise;
  }
  requestUpdate() {
    if (this._updatePending) return;
    this._updatePending = true;
    let resolveCycle;
    this._updatePromise = new Promise ((resolve) => {
      resolveCycle = resolve;
    });
    queueMicrotask(() => this._performUpdate(resolveCycle));
  }
          _adoptStylesOnce() {
    if (this._stylesAdopted) return;
    this._stylesAdopted = true;
    const ctor = this.constructor;
    if (!ctor.styles) return;
    const list = Array.isArray(ctor.styles) ? ctor.styles : [ctor.styles];
    if (typeof CSSStyleSheet !== "undefined" && "adoptedStyleSheets" in this.renderRoot) {
      this.renderRoot.adoptedStyleSheets = list.map((s) => getCachedStyleSheet(s));
    }
  }
          _performUpdate(resolveCycle) {
    this._updatePending = false;
    if (!this.isConnected) {
      resolveCycle(false);
      return;
    }
    let completed = false;
    try {
      this._adoptStylesOnce();
      for (const c of this._controllers) {
        c.hostUpdate?.();
      }
      const rendered = this.render();
      this._rootPart = render(rendered, this.renderRoot, { host: this });
      if (!this._hasUpdated) {
        this._hasUpdated = true;
        this.firstUpdated();
      }
      this.updated();
      for (const c of this._controllers) {
        c.hostUpdated?.();
      }
      completed = true;
    } catch (err) {
      console.error("[latter-studio] Render update failed:", err);
    } finally {
      resolveCycle(completed);
    }
  }
            render() {
    return nothing;
  }
            firstUpdated() {}
            updated() {}
}
__latterExp(__exports, { Directive: () => Directive, directive: () => directive, html: () => html, noChange: () => noChange, nothing: () => nothing, PartType: () => PartType, render: () => render, svg: () => svg, css: () => css, isActivelyFocusedTextControl: () => isActivelyFocusedTextControl, focusSafe: () => focusSafe, repeat: () => repeat, LitElement: () => LitElement });
//# sourceURL=latter-studio/src/lib/lit.ts
});
__latterDef("src/protocol-schema.ts", (__exports, __req) => {
// AUTO-GENERATED FROM protocol/latter_v3.json BY tools/gen_protocol.py — DO NOT EDIT MANUALLY.
const PROTOCOL_CONTRACT_VERSION = 3;
const STUDIO_REV = 37;
const ALLOWED_DEVICE_ACTIONS = [
  "restart",
  "find_my",
  "activate_screensaver",
  "trigger_va",
  "log_memory_report",
  "dismiss_ringing",
  "cancel_timer",
  "reset_stopwatch",
];
const SYSTEM_WS_COMMANDS = new Set([
  "set_ble_scanner_offset",
  "set_area_fusion",
  "capture_ble_area_signature",
  "clear_ble_area_signature",
  "system_entity_action",
  "send_announcement",
  "check_system_updates",
  "clear_internal_logs",
  "remove_device",
  "add_latter_device",
  "ignore_discovered_device",
  "unignore_discovered_device",
  "add_ble_device",
  "create_device_group",
  "delete_device_group",
  "update_group_baseline",
  "apply_batch_device_setting",
  "test_doorbell_speaker",
  "mint_camera_preview_url",
  "delete_wallpaper",
  "save_system_config",
  "rotate_signing_key",
  "set_security_pin",
]);
const DEVICE_WS_COMMANDS = new Set([
  "esphome_entity_action",
  "device_action",
  "select_wallpaper",
  "toggle_wallpaper_favorite",
  "save_device_config",
]);
const SHORTCUT_ROUTES_CATALOG = [
  {token: "app:pinned", label: "Pinned", group: "Apps", dockOnly: true},
  {token: "app:music", label: "Music", group: "Apps"},
  {token: "app:home_hub", label: "Home Hub", group: "Apps"},
  {token: "app:area", label: "Area Control", group: "Apps"},
  {token: "app:remote", label: "Remote", group: "Apps"},
  {token: "app:weather", label: "Sky & Weather", group: "Apps"},
  {token: "app:time", label: "Time", group: "Apps"},
  {token: "app:calendar", label: "Calendar", group: "Apps"},
  {token: "app:tools", label: "Tools", group: "Apps"},
  {token: "app:games", label: "Games", group: "Apps"},
  {token: "app:clock", label: "Clock Face", group: "Apps"},
  {token: "home_hub:alarm", label: "Security Alarm", group: "Home Hub"},
  {token: "home_hub:cameras", label: "Cameras", group: "Home Hub"},
  {token: "home_hub:intercom", label: "Intercom", group: "Home Hub"},
  {token: "home_hub:thermostat", label: "Thermostat", group: "Home Hub"},
  {token: "home_hub:entry", label: "Entry & Garage", group: "Home Hub"},
  {token: "home_hub:vacuum", label: "Robot Vacuum", group: "Home Hub"},
  {token: "area:picker", label: "Switch Area", group: "Area Control"},
  {token: "area:scene", label: "Area: Scenes", group: "Area Control"},
  {token: "area:light", label: "Area: Lights", group: "Area Control"},
  {token: "area:cover", label: "Area: Blinds & Curtains", group: "Area Control"},
  {token: "area:fan", label: "Area: Fans", group: "Area Control"},
  {token: "area:switch", label: "Area: Switches", group: "Area Control"},
  {token: "area:climate", label: "Area: Climate", group: "Area Control"},
  {token: "area:media", label: "Area: Media", group: "Area Control"},
  {token: "area:all", label: "Area: All Devices", group: "Area Control"},
  {token: "weather:current", label: "Current Weather", group: "Sky & Weather"},
  {token: "weather:forecast", label: "5-Day Forecast", group: "Sky & Weather"},
  {token: "weather:sun", label: "Sun Path", group: "Sky & Weather"},
  {token: "weather:moon", label: "Moon Phase", group: "Sky & Weather"},
  {token: "time:clock", label: "World Clocks", group: "Time"},
  {token: "time:timers", label: "Timers", group: "Time"},
  {token: "time:alarms", label: "Alarms", group: "Time"},
  {token: "time:stopwatch", label: "Stopwatch", group: "Time"},
  {token: "calendar:overview", label: "Upcoming Events", group: "Calendar"},
  {token: "calendar:day", label: "Day View", group: "Calendar"},
  {token: "calendar:week", label: "Week View", group: "Calendar"},
  {token: "calendar:month", label: "Month View", group: "Calendar"},
  {token: "music:speakers", label: "Speakers", group: "Music"},
  {token: "music:library", label: "Music Library", group: "Music"},
  {token: "music:favorites", label: "Favorites", group: "Music"},
  {token: "music:playlists", label: "Playlists", group: "Music"},
  {token: "music:queue", label: "Playback Queue", group: "Music"},
  {token: "music:album_tracks", label: "Album Tracks", group: "Music"},
  {token: "music:lyrics", label: "Music Lyrics", group: "Music"},
  {token: "music:info", label: "Track Info", group: "Music"},
  {token: "remote:devices", label: "Remote Devices", group: "Remote"},
  {token: "tools:stopwatch", label: "Analog Chronograph", group: "Tools", capability: "round"},
  {token: "tools:level", label: "Bubble Level", group: "Tools", capability: "imu"},
  {token: "tools:flashlight", label: "Flashlight", group: "Tools"},
  {token: "tools:calculator", label: "Calculator", group: "Tools"},
  {token: "tools:dice", label: "Dice Roll", group: "Tools"},
  {token: "tools:coin_flip", label: "Coin Flip", group: "Tools"},
  {token: "games:marbles", label: "Marbles", group: "Games"},
  {token: "games:archery", label: "Archery", group: "Games"},
  {token: "games:bricks", label: "Bricks", group: "Games"},
  {token: "games:chomp", label: "Chomp", group: "Games"},
  {token: "games:2048", label: "2048", group: "Games"},
  {token: "games:memory", label: "Memory Match", group: "Games"},
  {token: "settings:display", label: "Display Settings", group: "Settings"},
  {token: "settings:sleep", label: "Sleep & Wake", group: "Settings"},
  {token: "settings:sound", label: "Sound Settings", group: "Settings"},
  {token: "settings:voice", label: "Voice Settings", group: "Settings"},
  {token: "settings:music", label: "Music Settings", group: "Settings"},
  {token: "settings:home", label: "Home Settings", group: "Settings"},
  {token: "settings:actions", label: "Device Actions", group: "Settings"},
  {token: "settings:update", label: "Software Update", group: "Settings"},
  {token: "settings:info", label: "System Info", group: "Settings"},
];
const ACTIVITY_SOURCES_CATALOG = [
  {token: "calendar", label: "Calendar"},
  {token: "music_queue", label: "Music Queue"},
  {token: "stopwatch", label: "Stopwatch"},
  {token: "alarms", label: "Alarms"},
  {token: "timers", label: "Timers"},
];
const AREA_CATEGORIES_CATALOG = [
  {token: "scene", label: "Scenes"},
  {token: "light", label: "Lights"},
  {token: "cover", label: "Blinds & Curtains"},
  {token: "fan", label: "Fans"},
  {token: "switch", label: "Switches"},
  {token: "climate", label: "Climate"},
  {token: "media", label: "Media"},
  {token: "all", label: "All Devices"},
];
const HOME_CATEGORIES_CATALOG = [
  {token: "alarm", label: "Security Alarm"},
  {token: "cameras", label: "Cameras"},
  {token: "intercom", label: "Intercom"},
  {token: "thermostat", label: "Thermostat"},
  {token: "entry", label: "Entry & Garage"},
  {token: "vacuum", label: "Robot Vacuum"},
];
const TOOLS_ITEMS_CATALOG = [
  {token: "stopwatch", label: "Analog Chronograph", capability: "round"},
  {token: "level", label: "Bubble Level", capability: "imu"},
  {token: "flashlight", label: "Flashlight"},
  {token: "calculator", label: "Calculator"},
  {token: "dice", label: "Dice Roll"},
  {token: "coin_flip", label: "Coin Flip"},
];
const GAMES_ITEMS_CATALOG = [
  {token: "marbles", label: "Marbles"},
  {token: "archery", label: "Archery"},
  {token: "bricks", label: "Bricks"},
  {token: "chomp", label: "Chomp"},
  {token: "2048", label: "2048"},
  {token: "memory", label: "Memory Match"},
];
const WORLD_CLOCK_ZONES_CATALOG = [
  {iana: "Etc/GMT+12", city: "UTC-12", label: "UTC-12:00 — International Date Line West", std_off: -720, dst_off: -720, std_abbr: "UTC-12", dst_abbr: "UTC-12", rule: "none" },
  {iana: "Pacific/Pago_Pago", city: "Pago Pago", label: "UTC-11:00 — Samoa Standard Time (SST)", std_off: -660, dst_off: -660, std_abbr: "SST", dst_abbr: "SST", rule: "none" },
  {iana: "Pacific/Honolulu", city: "Honolulu", label: "UTC-10:00 — Hawaii-Aleutian Standard Time (HST)", std_off: -600, dst_off: -600, std_abbr: "HST", dst_abbr: "HST", rule: "none" },
  {iana: "Pacific/Marquesas", city: "Marquesas", label: "UTC-09:30 — Marquesas Time (MART)", std_off: -570, dst_off: -570, std_abbr: "MART", dst_abbr: "MART", rule: "none" },
  {iana: "America/Anchorage", city: "Anchorage", label: "UTC-09:00 — Alaska Time (AKST/AKDT)", std_off: -540, dst_off: -480, std_abbr: "AKST", dst_abbr: "AKDT", rule: "us" },
  {iana: "America/Los_Angeles", city: "Los Angeles", label: "UTC-08:00 — Pacific Time (PST/PDT)", std_off: -480, dst_off: -420, std_abbr: "PST", dst_abbr: "PDT", rule: "us" },
  {iana: "Etc/GMT+8", city: "UTC-8", label: "UTC-08:00 — Coordinated Universal Time-08 (No DST)", std_off: -480, dst_off: -480, std_abbr: "UTC-8", dst_abbr: "UTC-8", rule: "none" },
  {iana: "America/Denver", city: "Denver", label: "UTC-07:00 — Mountain Time (MST/MDT)", std_off: -420, dst_off: -360, std_abbr: "MST", dst_abbr: "MDT", rule: "us" },
  {iana: "America/Phoenix", city: "Phoenix", label: "UTC-07:00 — Mountain Standard Time (MST, No DST)", std_off: -420, dst_off: -420, std_abbr: "MST", dst_abbr: "MST", rule: "none" },
  {iana: "America/Chicago", city: "Chicago", label: "UTC-06:00 — Central Time (CST/CDT)", std_off: -360, dst_off: -300, std_abbr: "CST", dst_abbr: "CDT", rule: "us" },
  {iana: "America/Regina", city: "Regina", label: "UTC-06:00 — Central Standard Time (CST, No DST)", std_off: -360, dst_off: -360, std_abbr: "CST", dst_abbr: "CST", rule: "none" },
  {iana: "America/New_York", city: "New York", label: "UTC-05:00 — Eastern Time (EST/EDT)", std_off: -300, dst_off: -240, std_abbr: "EST", dst_abbr: "EDT", rule: "us" },
  {iana: "America/Lima", city: "Lima", label: "UTC-05:00 — Eastern Standard Time (EST, No DST)", std_off: -300, dst_off: -300, std_abbr: "EST", dst_abbr: "EST", rule: "none" },
  {iana: "America/Halifax", city: "Halifax", label: "UTC-04:00 — Atlantic Time (AST/ADT)", std_off: -240, dst_off: -180, std_abbr: "AST", dst_abbr: "ADT", rule: "us" },
  {iana: "America/Puerto_Rico", city: "Puerto Rico", label: "UTC-04:00 — Atlantic Standard Time (AST, No DST)", std_off: -240, dst_off: -240, std_abbr: "AST", dst_abbr: "AST", rule: "none" },
  {iana: "America/St_Johns", city: "St. John's", label: "UTC-03:30 — Newfoundland Time (NST/NDT)", std_off: -210, dst_off: -150, std_abbr: "NST", dst_abbr: "NDT", rule: "us" },
  {iana: "America/Sao_Paulo", city: "Sao Paulo", label: "UTC-03:00 — South America Eastern Time (BRT/ART)", std_off: -180, dst_off: -180, std_abbr: "BRT", dst_abbr: "BRT", rule: "none" },
  {iana: "Etc/GMT+2", city: "UTC-2", label: "UTC-02:00 — Coordinated Universal Time-02", std_off: -120, dst_off: -120, std_abbr: "UTC-2", dst_abbr: "UTC-2", rule: "none" },
  {iana: "Atlantic/Azores", city: "Azores", label: "UTC-01:00 — Azores Time (AZOT/AZOST)", std_off: -60, dst_off: 0, std_abbr: "AZOT", dst_abbr: "AZOST", rule: "eu" },
  {iana: "Atlantic/Cape_Verde", city: "Cape Verde", label: "UTC-01:00 — Cape Verde Time (CVT, No DST)", std_off: -60, dst_off: -60, std_abbr: "CVT", dst_abbr: "CVT", rule: "none" },
  {iana: "Atlantic/Reykjavik", city: "Reykjavik", label: "UTC+00:00 — Greenwich Mean Time (GMT, No DST)", std_off: 0, dst_off: 0, std_abbr: "GMT", dst_abbr: "GMT", rule: "none" },
  {iana: "Europe/London", city: "London", label: "UTC+00:00 — Western European Time (GMT/BST)", std_off: 0, dst_off: 60, std_abbr: "GMT", dst_abbr: "BST", rule: "eu" },
  {iana: "Europe/Berlin", city: "Berlin", label: "UTC+01:00 — Central European Time (CET/CEST)", std_off: 60, dst_off: 120, std_abbr: "CET", dst_abbr: "CEST", rule: "eu" },
  {iana: "Africa/Lagos", city: "Lagos", label: "UTC+01:00 — West Africa Time (WAT, No DST)", std_off: 60, dst_off: 60, std_abbr: "WAT", dst_abbr: "WAT", rule: "none" },
  {iana: "Europe/Athens", city: "Athens", label: "UTC+02:00 — Eastern European Time (EET/EEST)", std_off: 120, dst_off: 180, std_abbr: "EET", dst_abbr: "EEST", rule: "eu" },
  {iana: "Africa/Johannesburg", city: "Johannesburg", label: "UTC+02:00 — Central / South Africa Time (CAT/SAST)", std_off: 120, dst_off: 120, std_abbr: "SAST", dst_abbr: "SAST", rule: "none" },
  {iana: "Asia/Riyadh", city: "Riyadh", label: "UTC+03:00 — Arabia / East Africa Time (AST/EAT)", std_off: 180, dst_off: 180, std_abbr: "AST", dst_abbr: "AST", rule: "none" },
  {iana: "Asia/Tehran", city: "Tehran", label: "UTC+03:30 — Iran Standard Time (IRST)", std_off: 210, dst_off: 210, std_abbr: "IRST", dst_abbr: "IRST", rule: "none" },
  {iana: "Asia/Dubai", city: "Dubai", label: "UTC+04:00 — Gulf Standard Time (GST)", std_off: 240, dst_off: 240, std_abbr: "GST", dst_abbr: "GST", rule: "none" },
  {iana: "Asia/Kabul", city: "Kabul", label: "UTC+04:30 — Afghanistan Time (AFT)", std_off: 270, dst_off: 270, std_abbr: "AFT", dst_abbr: "AFT", rule: "none" },
  {iana: "Asia/Karachi", city: "Karachi", label: "UTC+05:00 — Pakistan / West Asia Time (PKT)", std_off: 300, dst_off: 300, std_abbr: "PKT", dst_abbr: "PKT", rule: "none" },
  {iana: "Asia/Kolkata", city: "Kolkata", label: "UTC+05:30 — India / Sri Lanka Standard Time (IST)", std_off: 330, dst_off: 330, std_abbr: "IST", dst_abbr: "IST", rule: "none" },
  {iana: "Asia/Kathmandu", city: "Kathmandu", label: "UTC+05:45 — Nepal Time (NPT)", std_off: 345, dst_off: 345, std_abbr: "NPT", dst_abbr: "NPT", rule: "none" },
  {iana: "Asia/Dhaka", city: "Dhaka", label: "UTC+06:00 — Bangladesh / Central Asia Time (BST)", std_off: 360, dst_off: 360, std_abbr: "BST", dst_abbr: "BST", rule: "none" },
  {iana: "Asia/Yangon", city: "Yangon", label: "UTC+06:30 — Myanmar Time (MMT)", std_off: 390, dst_off: 390, std_abbr: "MMT", dst_abbr: "MMT", rule: "none" },
  {iana: "Asia/Bangkok", city: "Bangkok", label: "UTC+07:00 — Indochina Time (ICT)", std_off: 420, dst_off: 420, std_abbr: "ICT", dst_abbr: "ICT", rule: "none" },
  {iana: "Asia/Singapore", city: "Singapore", label: "UTC+08:00 — China / Singapore / AWST (CST/SGT/AWST)", std_off: 480, dst_off: 480, std_abbr: "SGT", dst_abbr: "SGT", rule: "none" },
  {iana: "Australia/Eucla", city: "Eucla", label: "UTC+08:45 — Australian Central Western Time (ACWST)", std_off: 525, dst_off: 525, std_abbr: "ACWST", dst_abbr: "ACWST", rule: "none" },
  {iana: "Asia/Tokyo", city: "Tokyo", label: "UTC+09:00 — Japan / Korea Standard Time (JST/KST)", std_off: 540, dst_off: 540, std_abbr: "JST", dst_abbr: "JST", rule: "none" },
  {iana: "Australia/Adelaide", city: "Adelaide", label: "UTC+09:30 — Australian Central Time (ACST/ACDT)", std_off: 570, dst_off: 630, std_abbr: "ACST", dst_abbr: "ACDT", rule: "au" },
  {iana: "Australia/Darwin", city: "Darwin", label: "UTC+09:30 — Australian Central Standard Time (ACST, No DST)", std_off: 570, dst_off: 570, std_abbr: "ACST", dst_abbr: "ACST", rule: "none" },
  {iana: "Australia/Sydney", city: "Sydney", label: "UTC+10:00 — Australian Eastern Time (AEST/AEDT)", std_off: 600, dst_off: 660, std_abbr: "AEST", dst_abbr: "AEDT", rule: "au" },
  {iana: "Australia/Brisbane", city: "Brisbane", label: "UTC+10:00 — Australian Eastern Standard Time (AEST, No DST)", std_off: 600, dst_off: 600, std_abbr: "AEST", dst_abbr: "AEST", rule: "none" },
  {iana: "Australia/Lord_Howe", city: "Lord Howe", label: "UTC+10:30 — Lord Howe Time (LHST/LHDT)", std_off: 630, dst_off: 660, std_abbr: "LHST", dst_abbr: "LHDT", rule: "au30" },
  {iana: "Pacific/Guadalcanal", city: "Guadalcanal", label: "UTC+11:00 — Solomon Islands / New Caledonia Time (SBT)", std_off: 660, dst_off: 660, std_abbr: "SBT", dst_abbr: "SBT", rule: "none" },
  {iana: "Pacific/Auckland", city: "Auckland", label: "UTC+12:00 — New Zealand Time (NZST/NZDT)", std_off: 720, dst_off: 780, std_abbr: "NZST", dst_abbr: "NZDT", rule: "nz" },
  {iana: "Etc/GMT-12", city: "UTC+12", label: "UTC+12:00 — Coordinated Universal Time+12 (No DST)", std_off: 720, dst_off: 720, std_abbr: "UTC+12", dst_abbr: "UTC+12", rule: "none" },
  {iana: "Pacific/Chatham", city: "Chatham", label: "UTC+12:45 — Chatham Islands Time (CHAST/CHADT)", std_off: 765, dst_off: 825, std_abbr: "CHAST", dst_abbr: "CHADT", rule: "nz" },
  {iana: "Pacific/Tongatapu", city: "Tongatapu", label: "UTC+13:00 — Tonga / Phoenix Islands Time (TOT)", std_off: 780, dst_off: 780, std_abbr: "TOT", dst_abbr: "TOT", rule: "none" },
  {iana: "Pacific/Kiritimati", city: "Kiritimati", label: "UTC+14:00 — Line Islands Time (LINT)", std_off: 840, dst_off: 840, std_abbr: "LINT", dst_abbr: "LINT", rule: "none" },
];
const DEVICE_PREF_SPECS_CATALOG = [
  {key: "wake_word_mode", label: "Wake Word Mode", domain: "select", default: "Docked Only", section: "audio", esphome_section: "voice", group_tier: "behavior", options: ["Docked Only", "Always On", "Disabled"], min: null, max: null, step: null, unit: "", capability: "mic" },
  {key: "tap_to_wake", label: "Tap to Wake", domain: "select", default: "Docked Only", section: "power", esphome_section: "sleep", group_tier: "behavior", options: ["Single Tap", "Double Tap", "Docked Only", "Disabled"], min: null, max: null, step: null, unit: "", capability: "display" },
  {key: "pickup_to_wake", label: "Pickup to Wake", domain: "select", default: "Docked Only", section: "power", esphome_section: "sleep", group_tier: "behavior", options: ["Always On", "Docked Only", "Disabled"], min: null, max: null, step: null, unit: "", capability: "display_imu" },
  {key: "battery_screen_timeout", label: "Battery Screen Timeout", domain: "select", default: "30s", section: "power", esphome_section: "sleep", group_tier: "behavior", options: ["10s", "15s", "30s", "1 min", "2 min", "Never"], min: null, max: null, step: null, unit: "", capability: "display_battery" },
  {key: "docked_idle_timeout", label: "Docked Idle Timeout", domain: "select", default: "1 min", section: "display", esphome_section: "display", group_tier: "behavior", options: ["10s", "15s", "30s", "1 min", "2 min", "5 min", "Never"], min: null, max: null, step: null, unit: "", capability: "display" },
  {key: "battery_hibernate_timeout", label: "Battery Hibernate Timeout", domain: "select", default: "15 min", section: "power", esphome_section: "sleep", group_tier: "behavior", options: ["5 min", "10 min", "15 min", "30 min", "Disabled"], min: null, max: null, step: null, unit: "", capability: "display_battery" },
  {key: "docked_screensaver", label: "Docked Screensaver", domain: "switch", default: true, section: "display", esphome_section: "display", group_tier: "behavior", options: [], min: null, max: null, step: null, unit: "", capability: "display" },
  {key: "screensaver_style", label: "Screensaver Style", domain: "select", default: "Ambient Clock", section: "display", esphome_section: "display", group_tier: "display", options: ["Ambient Clock", "Aurora", "Starfield", "Digital Rain", "Fireworks"], min: null, max: null, step: null, unit: "", capability: "display" },
  {key: "hold_crown_power_off", label: "Hold Crown to Power Off", domain: "switch", default: false, section: "power", esphome_section: "sleep", group_tier: "behavior", options: [], min: null, max: null, step: null, unit: "", capability: "display_battery" },
  {key: "auto_brightness_mode", label: "Auto Brightness Mode", domain: "select", default: "Sun Synchronized", section: "display", esphome_section: "display", group_tier: "behavior", options: ["Disabled", "Sun Synchronized", "Time Schedule"], min: null, max: null, step: null, unit: "", capability: "display" },
  {key: "manual_brightness", label: "Manual Brightness", domain: "number", default: 80, section: "display", esphome_section: "display", group_tier: "behavior", options: [], min: 1, max: 100, step: 1, unit: "%", capability: "display" },
  {key: "day_brightness", label: "Day Brightness", domain: "number", default: 90, section: "display", esphome_section: "display", group_tier: "behavior", options: [], min: 1, max: 100, step: 1, unit: "%", capability: "display" },
  {key: "night_brightness", label: "Night Brightness", domain: "number", default: 35, section: "display", esphome_section: "display", group_tier: "behavior", options: [], min: 1, max: 100, step: 1, unit: "%", capability: "display" },
  {key: "day_start_hour", label: "Day Start Hour", domain: "number", default: 7, section: "display", esphome_section: "display", group_tier: "behavior", options: [], min: 0, max: 23, step: 1, unit: ":00", capability: "display" },
  {key: "night_start_hour", label: "Night Start Hour", domain: "number", default: 20, section: "display", esphome_section: "display", group_tier: "behavior", options: [], min: 0, max: 23, step: 1, unit: ":00", capability: "display" },
  {key: "color_profile", label: "Color Profile", domain: "select", default: "Steel Blue", section: "display", esphome_section: "display", group_tier: "display", options: ["Steel Blue", "Pink", "Blue", "Green", "Custom"], min: null, max: null, step: null, unit: "", capability: "display" },
  {key: "va_visual_profile", label: "Visual Profile", domain: "select", default: "Nebula", section: "display", esphome_section: "display", group_tier: "display", options: ["Nebula", "Solaris", "Rings", "Light Bar", "Dot Wave"], min: null, max: null, step: null, unit: "", capability: "display" },
  {key: "home_screen_enabled", label: "Enable Home Screen", domain: "switch", default: true, section: "interface", esphome_section: "home", group_tier: "interface", options: [], min: null, max: null, step: null, unit: "", capability: "display" },
  {key: "start_screen", label: "Start Screen", domain: "select", default: "Home", section: "interface", esphome_section: "home", group_tier: "interface", options: ["Home", "Pinned", "Time App", "Calendar", "Clock Face", "Media", "Home Hub", "Area Controls", "Remote", "Weather", "Cameras", "Games", "Tools"], min: null, max: null, step: null, unit: "", capability: "display" },
  {key: "return_to_home_timeout", label: "Return to Home Timeout", domain: "select", default: "2 min", section: "interface", esphome_section: "home", group_tier: "interface", options: ["15s", "30s", "1 min", "2 min", "5 min", "10 min", "Never"], min: null, max: null, step: null, unit: "", capability: "display" },
  {key: "clock_face", label: "Clock Face", domain: "select", default: "Minimal Digital", section: "interface", esphome_section: "display", group_tier: "interface", options: ["Minimal Digital", "Modern Analog", "Hybrid Digital"], min: null, max: null, step: null, unit: "", capability: "display" },
  {key: "time_format", label: "Time Format", domain: "select", default: "12-Hour (AM/PM)", section: "interface", esphome_section: "display", group_tier: "interface", options: ["12-Hour (AM/PM)", "24-Hour"], min: null, max: null, step: null, unit: "", capability: "display" },
  {key: "weather_background", label: "Weather Background", domain: "switch", default: true, section: "interface", esphome_section: "display", group_tier: "interface", options: [], min: null, max: null, step: null, unit: "", capability: "display" },
  {key: "home_sun", label: "Sun", domain: "switch", default: true, section: "interface", esphome_section: "display", group_tier: "interface", options: [], min: null, max: null, step: null, unit: "", capability: "display" },
  {key: "home_moon", label: "Moon", domain: "switch", default: true, section: "interface", esphome_section: "display", group_tier: "interface", options: [], min: null, max: null, step: null, unit: "", capability: "display" },
  {key: "wake_greeting", label: "Wake Greeting", domain: "switch", default: true, section: "interface", esphome_section: "display", group_tier: "interface", options: [], min: null, max: null, step: null, unit: "", capability: "display" },
  {key: "album_art_style", label: "Album Art Style", domain: "select", default: "Full Screen", section: "interface", esphome_section: "music", group_tier: "interface", options: ["Full Screen", "Letterbox", "Standard", "None"], min: null, max: null, step: null, unit: "", capability: "display" },
  {key: "music_overlay_style", label: "Overlay Style", domain: "select", default: "Art + Metadata", section: "interface", esphome_section: "music", group_tier: "interface", options: ["Art Only", "Art + Metadata", "Always Visible"], min: null, max: null, step: null, unit: "", capability: "display" },
  {key: "album_sort_order", label: "Album Sort Order", domain: "select", default: "Alphabetical", section: "interface", esphome_section: "music", group_tier: "interface", options: ["Alphabetical", "Newest on Top", "Oldest on Top"], min: null, max: null, step: null, unit: "", capability: "display" },
  {key: "artist_album_sort_order", label: "Artist Album Sort Order", domain: "select", default: "Oldest on Top", section: "interface", esphome_section: "music", group_tier: "interface", options: ["Oldest on Top", "Newest on Top", "Alphabetical"], min: null, max: null, step: null, unit: "", capability: "display" },
  {key: "podcast_sort_order", label: "Podcast Sort Order", domain: "select", default: "Newest on Top", section: "interface", esphome_section: "music", group_tier: "interface", options: ["Newest on Top", "Oldest on Top"], min: null, max: null, step: null, unit: "", capability: "display" },
  {key: "ww_sens_okay_nabu", label: "Okay Nabu Sensitivity", domain: "select", default: "Moderately sensitive", section: "audio", esphome_section: "voice", group_tier: "behavior", options: ["Slightly sensitive", "Moderately sensitive", "Very sensitive"], min: null, max: null, step: null, unit: "", capability: "mic" },
  {key: "ww_sens_hey_luna", label: "Hey Luna Sensitivity", domain: "select", default: "Moderately sensitive", section: "audio", esphome_section: "voice", group_tier: "behavior", options: ["Slightly sensitive", "Moderately sensitive", "Very sensitive"], min: null, max: null, step: null, unit: "", capability: "mic" },
  {key: "ww_sens_hey_jarvis", label: "Hey Jarvis Sensitivity", domain: "select", default: "Moderately sensitive", section: "audio", esphome_section: "voice", group_tier: "behavior", options: ["Slightly sensitive", "Moderately sensitive", "Very sensitive"], min: null, max: null, step: null, unit: "", capability: "mic" },
  {key: "ww_sens_hey_mycroft", label: "Hey Mycroft Sensitivity", domain: "select", default: "Moderately sensitive", section: "audio", esphome_section: "voice", group_tier: "behavior", options: ["Slightly sensitive", "Moderately sensitive", "Very sensitive"], min: null, max: null, step: null, unit: "", capability: "mic" },
  {key: "ww_sens_alexa", label: "Alexa Sensitivity", domain: "select", default: "Moderately sensitive", section: "audio", esphome_section: "voice", group_tier: "behavior", options: ["Slightly sensitive", "Moderately sensitive", "Very sensitive"], min: null, max: null, step: null, unit: "", capability: "mic" },
  {key: "wake_screen_on_assist", label: "Wake Screen on Assist", domain: "switch", default: true, section: "audio", esphome_section: "voice", group_tier: "behavior", options: [], min: null, max: null, step: null, unit: "", capability: "display" },
  {key: "alert_volume", label: "Alert Volume", domain: "number", default: 80, section: "audio", esphome_section: "sound", group_tier: "behavior", options: [], min: 20, max: 100, step: 5, unit: "%", capability: "speaker" },
  {key: "volume_step_size", label: "Volume Step Size", domain: "number", default: 5, section: "audio", esphome_section: "sound", group_tier: "behavior", options: [], min: 1, max: 10, step: 1, unit: "%", capability: "speaker" },
  {key: "game_sound_effects", label: "Game Sound Effects", domain: "switch", default: true, section: "audio", esphome_section: "sound", group_tier: "behavior", options: [], min: null, max: null, step: null, unit: "", capability: "display" },
  {key: "ble_beacon_mode", label: "BLE Beacon Mode", domain: "select", default: "Handheld Only", section: "presence", esphome_section: "presence", group_tier: "behavior", options: ["Handheld Only", "Handheld + Screen Off", "Always"], min: null, max: null, step: null, unit: "", capability: "beacon_battery" },
  {key: "weather_sim_condition", label: "Weather Simulation", domain: "select", default: "Live (Home Assistant)", section: "developer", esphome_section: "developer", group_tier: null, options: ["Live (Home Assistant)", "Clear Night", "Sunny / Clear Day", "Partly Cloudy (Day)", "Partly Cloudy (Night)", "Cloudy / Overcast (Day)", "Cloudy / Overcast (Night)", "Fog / Mist (Day)", "Fog / Mist (Night)", "Rainy (Day)", "Rainy (Night)", "Pouring / Heavy Rain", "Snow (Day)", "Snow (Night)", "Thunderstorm (Day)", "Thunderstorm (Night)", "Windy"], min: null, max: null, step: null, unit: "", capability: "display" },
  {key: "home_clock_tap_action", label: "Home Time Tap", domain: "select", default: "Time App", section: "interface", esphome_section: "home", group_tier: "interface", options: ["Time App", "Clock Face"], min: null, max: null, step: null, unit: "", capability: "display" },
  {key: "home_date_tap_action", label: "Home Date Tap", domain: "select", default: "Overview", section: "interface", esphome_section: "home", group_tier: "interface", options: ["Day View", "Overview"], min: null, max: null, step: null, unit: "", capability: "display" },
  {key: "local_clock_label", label: "Local Clock Label", domain: "text", default: "", section: "time", esphome_section: "time", group_tier: null, options: [], min: null, max: null, step: null, unit: "", capability: "display" },
  {key: "show_utc_clock", label: "Show UTC Clock", domain: "switch", default: false, section: "interface", esphome_section: "home", group_tier: "interface", options: [], min: null, max: null, step: null, unit: "", capability: "display" },
  {key: "world_clocks", label: "World Clocks", domain: "text", default: "", section: "interface", esphome_section: "home", group_tier: "interface", options: [], min: null, max: null, step: null, unit: "", capability: "display" },
  {key: "alarms_summary", label: "Alarms", domain: "text", default: "07:00|0|1;08:30|0|2;09:00|0|2", section: "time", esphome_section: "time", group_tier: null, options: [], min: null, max: null, step: null, unit: "", capability: "display" },
  {key: "calendar_lookahead_days", label: "Overview Lookahead", domain: "number", default: 30, section: "interface", esphome_section: "home", group_tier: "interface", options: [], min: 7, max: 60, step: 1, unit: "d", capability: "display" },
  {key: "calendar_week_start", label: "Start Week On", domain: "select", default: "Sunday", section: "interface", esphome_section: "home", group_tier: "interface", options: ["Sunday", "Monday"], min: null, max: null, step: null, unit: "", capability: "display" },
  {key: "bedtime_active", label: "Bedtime Mode", domain: "switch", default: false, section: "power", esphome_section: "sleep", group_tier: null, options: [], min: null, max: null, step: null, unit: "", capability: "display" },
  {key: "bedtime_display", label: "Idle Display in Bedtime", domain: "select", default: "Screen Off", section: "power", esphome_section: "sleep", group_tier: "behavior", options: ["Screen Off", "Ambient Clock"], min: null, max: null, step: null, unit: "", capability: "display" },
  {key: "bedtime_schedule", label: "Bedtime Schedule", domain: "switch", default: false, section: "power", esphome_section: "sleep", group_tier: "behavior", options: [], min: null, max: null, step: null, unit: "", capability: "display" },
  {key: "bedtime_start_hour", label: "Bedtime Starts", domain: "number", default: 22, section: "power", esphome_section: "sleep", group_tier: "behavior", options: [], min: 0, max: 23, step: 1, unit: ":00", capability: "display" },
  {key: "bedtime_end_hour", label: "Bedtime Ends", domain: "number", default: 7, section: "power", esphome_section: "sleep", group_tier: "behavior", options: [], min: 0, max: 23, step: 1, unit: ":00", capability: "display" },
  {key: "bedtime_brightness", label: "Bedtime Brightness", domain: "number", default: 15, section: "power", esphome_section: "sleep", group_tier: "behavior", options: [], min: 1, max: 100, step: 1, unit: "%", capability: "display" },
];
const DEVICE_PREF_SPECS_MAP = Object.fromEntries(DEVICE_PREF_SPECS_CATALOG.map((s) => [s.key, s]));
const DEFAULT_DOCK_ROUTES = "app:pinned,app:music,app:home_hub,app:area,app:remote,app:games,app:tools";
const DEFAULT_DOCK_ROUTES_TOKENS = [
  "app:pinned",
  "app:music",
  "app:home_hub",
  "app:area",
  "app:remote",
  "app:games",
  "app:tools",
];
const DEFAULT_ACTIVITY_CARD = "1";
const DEFAULT_ACTIVITY_CARD_TOKENS = [
  "1",
];
const DEFAULT_ACTIVITY_SOURCES = "calendar,music_queue,stopwatch,alarms,timers";
const DEFAULT_ACTIVITY_SOURCES_TOKENS = [
  "calendar",
  "music_queue",
  "stopwatch",
  "alarms",
  "timers",
];
const DEFAULT_AREA_CATEGORIES = "scene,light,cover,fan,switch,climate,media";
const DEFAULT_AREA_CATEGORIES_TOKENS = [
  "scene",
  "light",
  "cover",
  "fan",
  "switch",
  "climate",
  "media",
];
const DEFAULT_HOME_CATEGORIES = "alarm,cameras,intercom,thermostat,entry,vacuum";
const DEFAULT_HOME_CATEGORIES_TOKENS = [
  "alarm",
  "cameras",
  "intercom",
  "thermostat",
  "entry",
  "vacuum",
];
const DEFAULT_TOOLS_ITEMS = "stopwatch,level,flashlight,calculator,dice,coin_flip";
const DEFAULT_TOOLS_ITEMS_TOKENS = [
  "stopwatch",
  "level",
  "flashlight",
  "calculator",
  "dice",
  "coin_flip",
];
const DEFAULT_GAMES_ITEMS = "marbles,archery,bricks,chomp,2048,memory";
const DEFAULT_GAMES_ITEMS_TOKENS = [
  "marbles",
  "archery",
  "bricks",
  "chomp",
  "2048",
  "memory",
];
__latterExp(__exports, { PROTOCOL_CONTRACT_VERSION: () => PROTOCOL_CONTRACT_VERSION, STUDIO_REV: () => STUDIO_REV, ALLOWED_DEVICE_ACTIONS: () => ALLOWED_DEVICE_ACTIONS, SYSTEM_WS_COMMANDS: () => SYSTEM_WS_COMMANDS, DEVICE_WS_COMMANDS: () => DEVICE_WS_COMMANDS, SHORTCUT_ROUTES_CATALOG: () => SHORTCUT_ROUTES_CATALOG, ACTIVITY_SOURCES_CATALOG: () => ACTIVITY_SOURCES_CATALOG, AREA_CATEGORIES_CATALOG: () => AREA_CATEGORIES_CATALOG, HOME_CATEGORIES_CATALOG: () => HOME_CATEGORIES_CATALOG, TOOLS_ITEMS_CATALOG: () => TOOLS_ITEMS_CATALOG, GAMES_ITEMS_CATALOG: () => GAMES_ITEMS_CATALOG, WORLD_CLOCK_ZONES_CATALOG: () => WORLD_CLOCK_ZONES_CATALOG, DEVICE_PREF_SPECS_CATALOG: () => DEVICE_PREF_SPECS_CATALOG, DEVICE_PREF_SPECS_MAP: () => DEVICE_PREF_SPECS_MAP, DEFAULT_DOCK_ROUTES: () => DEFAULT_DOCK_ROUTES, DEFAULT_DOCK_ROUTES_TOKENS: () => DEFAULT_DOCK_ROUTES_TOKENS, DEFAULT_ACTIVITY_CARD: () => DEFAULT_ACTIVITY_CARD, DEFAULT_ACTIVITY_CARD_TOKENS: () => DEFAULT_ACTIVITY_CARD_TOKENS, DEFAULT_ACTIVITY_SOURCES: () => DEFAULT_ACTIVITY_SOURCES, DEFAULT_ACTIVITY_SOURCES_TOKENS: () => DEFAULT_ACTIVITY_SOURCES_TOKENS, DEFAULT_AREA_CATEGORIES: () => DEFAULT_AREA_CATEGORIES, DEFAULT_AREA_CATEGORIES_TOKENS: () => DEFAULT_AREA_CATEGORIES_TOKENS, DEFAULT_HOME_CATEGORIES: () => DEFAULT_HOME_CATEGORIES, DEFAULT_HOME_CATEGORIES_TOKENS: () => DEFAULT_HOME_CATEGORIES_TOKENS, DEFAULT_TOOLS_ITEMS: () => DEFAULT_TOOLS_ITEMS, DEFAULT_TOOLS_ITEMS_TOKENS: () => DEFAULT_TOOLS_ITEMS_TOKENS, DEFAULT_GAMES_ITEMS: () => DEFAULT_GAMES_ITEMS, DEFAULT_GAMES_ITEMS_TOKENS: () => DEFAULT_GAMES_ITEMS_TOKENS });
//# sourceURL=latter-studio/src/protocol-schema.ts
});
__latterDef("src/constants.ts", (__exports, __req) => {
const { ACTIVITY_SOURCES_CATALOG, ALLOWED_DEVICE_ACTIONS, AREA_CATEGORIES_CATALOG, DEFAULT_ACTIVITY_SOURCES, DEFAULT_ACTIVITY_SOURCES_TOKENS, DEFAULT_AREA_CATEGORIES, DEFAULT_AREA_CATEGORIES_TOKENS, DEFAULT_DOCK_ROUTES, DEFAULT_DOCK_ROUTES_TOKENS, DEFAULT_GAMES_ITEMS, DEFAULT_GAMES_ITEMS_TOKENS, DEFAULT_HOME_CATEGORIES, DEFAULT_HOME_CATEGORIES_TOKENS, DEFAULT_TOOLS_ITEMS, DEFAULT_TOOLS_ITEMS_TOKENS, DEVICE_PREF_SPECS_CATALOG, DEVICE_PREF_SPECS_MAP, DEVICE_WS_COMMANDS, GAMES_ITEMS_CATALOG, HOME_CATEGORIES_CATALOG, SHORTCUT_ROUTES_CATALOG, STUDIO_REV, SYSTEM_WS_COMMANDS, TOOLS_ITEMS_CATALOG, WORLD_CLOCK_ZONES_CATALOG } = __req("src/protocol-schema.ts");
/**
 * Canonical constants, route maps, and acronym dictionaries for Latter Studio (`D-061`, `D-063`).
 * Re-exports single-source-of-truth catalogs & contract constants from `protocol-schema.ts`.
 */
const MAX_DOCK_ITEMS = 24;
const MAX_PINNED_ITEMS = 96;
const SHORTCUT_LABEL_MAX = 24;
const NATIVE_DOCK_APP_TOKENS = [
  "app:pinned",
  "app:music",
  "app:home_hub",
  "app:area",
  "app:remote",
  "app:weather",
  "app:time",
  "app:calendar",
  "app:clock",
  "app:tools",
  "app:games",
];
const NATIVE_DOCK_CONFIG_APP_MAP = {
  "app:pinned": "pinned",
  "app:music": "music",
  "app:home_hub": "home_hub",
  "app:area": "area",
  "app:remote": "remote",
  "app:time": "time",
  "app:calendar": "calendar",
  "app:clock": "clock",
  "app:tools": "tools",
  "app:games": "games",
};
const START_SCREEN_CONFIG_APP_MAP = {
  Pinned: "pinned",
  Media: "music",
  "Home Hub": "home_hub",
  Cameras: "home_hub",
  "Area Controls": "area",
  Remote: "remote",
  "Time App": "time",
  Calendar: "calendar",
  "Clock Face": "clock",
  Tools: "tools",
  Games: "games",
};
const MAX_WALLPAPER_UPLOAD_BYTES = 15 * 1024 * 1024;
const DEVICE_VIEW_SLUGS
  = {
  dashboard: "overview",
  display: "display",
  interface: "interface",
  audio_voice: "audio",
  power: "power",
  presence: "presence",
  tools: "tools",
};
const SYSTEM_VIEW_SLUGS = {
  system_overview: "overview",
  shared_entities: "shared",
  remotes: "remotes",
  system_sync: "groups",
  area_tracking: "presence",
  system_tools: "tools",
};
const VIEW_TITLE_KEYS = {
  system_overview: "view.system_overview",
  shared_entities: "view.shared_entities",
  remotes: "view.remotes",
  system_sync: "view.system_sync",
  area_tracking: "view.area_tracking",
  system_tools: "view.system_tools",
  select_device_prompt: "view.select_device_prompt",
  discovered_devices: "view.discovered_devices",
  dashboard: "view.dashboard",
  display: "view.display",
  interface: "view.interface",
  audio_voice: "view.audio_voice",
  power: "view.power",
  presence: "view.presence",
  tools: "view.tools",
};
const START_SCREEN_OPTIONS =
  DEVICE_PREF_SPECS_MAP.start_screen?.options ?? [];
const HOME_CLOCK_TAP_OPTIONS =
  DEVICE_PREF_SPECS_MAP.home_clock_tap_action?.options ?? [];
const HOME_DATE_TAP_OPTIONS =
  DEVICE_PREF_SPECS_MAP.home_date_tap_action?.options ?? [];
const CALENDAR_LOOKAHEAD_OPTIONS = [
  { value: 7, label: "7 days" },
  { value: 14, label: "14 days" },
  { value: 30, label: "30 days" },
  { value: 60, label: "60 days" },
];
const CALENDAR_WEEK_START_OPTIONS =
  DEVICE_PREF_SPECS_MAP.calendar_week_start?.options ?? [];
const MAX_WORLD_CLOCKS = 4;
const DEFAULT_ALARMS_SUMMARY = "07:00|0|1;08:30|0|2;09:00|0|2";
const RETURN_TO_HOME_TIMEOUT_OPTIONS =
  DEVICE_PREF_SPECS_MAP.return_to_home_timeout?.options ?? [];
const SECURITY_PIN_POLICY_OPTIONS = [
  { value: "auto", label: "Auto (recommended)" },
  { value: "allow", label: "Allow without PIN" },
  { value: "require_pin", label: "Require PIN" },
  { value: "block", label: "Block unlock & disarm" },
];
const WALLPAPER_ROTATION_OPTIONS = [
  { value: 0, label: "Do not rotate" },
  { value: 5, label: "Every 5 minutes" },
  { value: 15, label: "Every 15 minutes" },
  { value: 30, label: "Every 30 minutes" },
  { value: 60, label: "Every hour" },
  { value: 360, label: "Every 6 hours" },
  { value: 1440, label: "Once a day" },
];
const DEFAULT_DEVICE_GROUP_IDS = new Set([
  "pocket_carry",
  "handhelds",
  "wearables",
  "wall_panels",
]);
const GROUP_BEHAVIOR_NON_PREF_KEYS = [
  "native_ble_tracking",
  "ble_auto_switch",
  "sync_device_area",
  "area_follow_dwell_s",
  "area_handoff",
  "security_pin_policy",
];
const GROUP_DISPLAY_NON_PREF_KEYS = [
  "wallpaper_source",
  "wallpaper_cycle_minutes",
  "device_custom_color",
];
const GROUP_INTERFACE_NON_PREF_KEYS = [
  "dock_items",
  "pinned_items",
  "area_categories",
  "home_categories",
  "tools_items",
  "games_items",
  "activity_card",
  "activity_sources",
  "device_remote_group",
];
const LABEL_ACRONYMS = {
  ble: "BLE",
  cpu: "CPU",
  db: "dB",
  dbm: "dBm",
  dns: "DNS",
  esp: "ESP",
  esphome: "ESPHome",
  ha: "HA",
  http: "HTTP",
  id: "ID",
  imu: "IMU",
  ip: "IP",
  ips: "IPS",
  led: "LED",
  ma: "MA",
  mac: "MAC",
  mic: "Mic",
  ota: "OTA",
  pin: "PIN",
  pmu: "PMU",
  psram: "PSRAM",
  ram: "RAM",
  rgb: "RGB",
  rssi: "RSSI",
  sdk: "SDK",
  sram: "SRAM",
  ssid: "SSID",
  tts: "TTS",
  ui: "UI",
  url: "URL",
  usb: "USB",
  uuid: "UUID",
  va: "VA",
  wifi: "Wi-Fi",
  "wi-fi": "Wi-Fi",
};
__latterExp(__exports, { ACTIVITY_SOURCES_CATALOG: () => ACTIVITY_SOURCES_CATALOG, ALLOWED_DEVICE_ACTIONS: () => ALLOWED_DEVICE_ACTIONS, AREA_CATEGORIES_CATALOG: () => AREA_CATEGORIES_CATALOG, DEFAULT_ACTIVITY_SOURCES: () => DEFAULT_ACTIVITY_SOURCES, DEFAULT_ACTIVITY_SOURCES_TOKENS: () => DEFAULT_ACTIVITY_SOURCES_TOKENS, DEFAULT_AREA_CATEGORIES: () => DEFAULT_AREA_CATEGORIES, DEFAULT_AREA_CATEGORIES_TOKENS: () => DEFAULT_AREA_CATEGORIES_TOKENS, DEFAULT_DOCK_ROUTES: () => DEFAULT_DOCK_ROUTES, DEFAULT_DOCK_ROUTES_TOKENS: () => DEFAULT_DOCK_ROUTES_TOKENS, DEFAULT_GAMES_ITEMS: () => DEFAULT_GAMES_ITEMS, DEFAULT_GAMES_ITEMS_TOKENS: () => DEFAULT_GAMES_ITEMS_TOKENS, DEFAULT_HOME_CATEGORIES: () => DEFAULT_HOME_CATEGORIES, DEFAULT_HOME_CATEGORIES_TOKENS: () => DEFAULT_HOME_CATEGORIES_TOKENS, DEFAULT_TOOLS_ITEMS: () => DEFAULT_TOOLS_ITEMS, DEFAULT_TOOLS_ITEMS_TOKENS: () => DEFAULT_TOOLS_ITEMS_TOKENS, DEVICE_PREF_SPECS_CATALOG: () => DEVICE_PREF_SPECS_CATALOG, DEVICE_PREF_SPECS_MAP: () => DEVICE_PREF_SPECS_MAP, DEVICE_WS_COMMANDS: () => DEVICE_WS_COMMANDS, GAMES_ITEMS_CATALOG: () => GAMES_ITEMS_CATALOG, HOME_CATEGORIES_CATALOG: () => HOME_CATEGORIES_CATALOG, SHORTCUT_ROUTES_CATALOG: () => SHORTCUT_ROUTES_CATALOG, STUDIO_REV: () => STUDIO_REV, SYSTEM_WS_COMMANDS: () => SYSTEM_WS_COMMANDS, TOOLS_ITEMS_CATALOG: () => TOOLS_ITEMS_CATALOG, WORLD_CLOCK_ZONES_CATALOG: () => WORLD_CLOCK_ZONES_CATALOG, MAX_DOCK_ITEMS: () => MAX_DOCK_ITEMS, MAX_PINNED_ITEMS: () => MAX_PINNED_ITEMS, SHORTCUT_LABEL_MAX: () => SHORTCUT_LABEL_MAX, NATIVE_DOCK_APP_TOKENS: () => NATIVE_DOCK_APP_TOKENS, NATIVE_DOCK_CONFIG_APP_MAP: () => NATIVE_DOCK_CONFIG_APP_MAP, START_SCREEN_CONFIG_APP_MAP: () => START_SCREEN_CONFIG_APP_MAP, MAX_WALLPAPER_UPLOAD_BYTES: () => MAX_WALLPAPER_UPLOAD_BYTES, DEVICE_VIEW_SLUGS: () => DEVICE_VIEW_SLUGS, SYSTEM_VIEW_SLUGS: () => SYSTEM_VIEW_SLUGS, VIEW_TITLE_KEYS: () => VIEW_TITLE_KEYS, START_SCREEN_OPTIONS: () => START_SCREEN_OPTIONS, HOME_CLOCK_TAP_OPTIONS: () => HOME_CLOCK_TAP_OPTIONS, HOME_DATE_TAP_OPTIONS: () => HOME_DATE_TAP_OPTIONS, CALENDAR_LOOKAHEAD_OPTIONS: () => CALENDAR_LOOKAHEAD_OPTIONS, CALENDAR_WEEK_START_OPTIONS: () => CALENDAR_WEEK_START_OPTIONS, MAX_WORLD_CLOCKS: () => MAX_WORLD_CLOCKS, DEFAULT_ALARMS_SUMMARY: () => DEFAULT_ALARMS_SUMMARY, RETURN_TO_HOME_TIMEOUT_OPTIONS: () => RETURN_TO_HOME_TIMEOUT_OPTIONS, SECURITY_PIN_POLICY_OPTIONS: () => SECURITY_PIN_POLICY_OPTIONS, WALLPAPER_ROTATION_OPTIONS: () => WALLPAPER_ROTATION_OPTIONS, DEFAULT_DEVICE_GROUP_IDS: () => DEFAULT_DEVICE_GROUP_IDS, GROUP_BEHAVIOR_NON_PREF_KEYS: () => GROUP_BEHAVIOR_NON_PREF_KEYS, GROUP_DISPLAY_NON_PREF_KEYS: () => GROUP_DISPLAY_NON_PREF_KEYS, GROUP_INTERFACE_NON_PREF_KEYS: () => GROUP_INTERFACE_NON_PREF_KEYS, LABEL_ACRONYMS: () => LABEL_ACRONYMS });
//# sourceURL=latter-studio/src/constants.ts
});
__latterDef("src/utils/format.ts", (__exports, __req) => {
const { LABEL_ACRONYMS } = __req("src/constants.ts");
const { localizeRepairIssue } = __req("src/i18n/index.ts");
/**
 * Locale-aware formatters (`hass.locale` number/time/date/weekday), cached `Intl` instances,
 * entity label humanizer, color helpers, and shadow-safe clipboard / download helpers.
 * Note: Avoid literal `#RRGGBB` color constants here so `[STUDIO TOKENS]` stays 100% pure.
 */
const MAX_FORMATTER_CACHE = 64;
const NUMBER_FMT_CACHE = new Map();
const REL_TIME_FMT_CACHE = new Map();
const DATE_TIME_FMT_CACHE = new Map();
function setBoundedCache (cache, key, val) {
  if (cache.size >= MAX_FORMATTER_CACHE) {
    const oldest = cache.keys().next().value;
    if (oldest !== undefined) {
      cache.delete(oldest);
    }
  }
  cache.set(key, val);
  return val;
}
function getLocaleObj(hass) {
  return (hass)?.locale;
}
function hassLanguage(hass) {
  const navLang = typeof navigator !== "undefined" ? navigator.language : "";
  return String(getLocaleObj(hass)?.language || hass?.language || navLang || "en");
}
function resolveNumberLocaleAndGrouping(
  hass,
) {
  const nf = getLocaleObj(hass)?.number_format;
  switch (nf) {
    case "comma_decimal":
      return { locale: "en-US", useGrouping: true };
    case "decimal_comma":
      return { locale: "de-DE", useGrouping: true };
    case "space_comma":
      return { locale: "fr-FR", useGrouping: true };
    case "none":
      return { locale: hassLanguage(hass), useGrouping: false };
    case "system":
      return { locale: undefined, useGrouping: undefined };
    default:
      return { locale: hassLanguage(hass), useGrouping: undefined };
  }
}
function getNumberFormatter(
  locale,
  opts,
) {
  const key = `${locale || "sys"}|${opts.style || "decimal"}|${opts.unit || ""}|${opts.maximumFractionDigits ?? ""}|${String(opts.useGrouping ?? "")}`;
  const cached = NUMBER_FMT_CACHE.get(key);
  if (cached) return cached;
  return setBoundedCache(NUMBER_FMT_CACHE, key, new Intl.NumberFormat(locale, opts));
}
function getRelativeTimeFormatter(locale) {
  const cached = REL_TIME_FMT_CACHE.get(locale);
  if (cached) return cached;
  return setBoundedCache(
    REL_TIME_FMT_CACHE,
    locale,
    new Intl.RelativeTimeFormat(locale, { numeric: "auto" }),
  );
}
function resolveDateTimeLocale(hass) {
  const df = getLocaleObj(hass)?.date_format;
  switch (df) {
    case "DMY":
      return "en-GB";
    case "MDY":
      return "en-US";
    case "YMD":
      return "sv-SE";
    case "system":
      return undefined;
    default:
      return hassLanguage(hass);
  }
}
function resolveHour12(hass) {
  const tf = getLocaleObj(hass)?.time_format;
  if (tf === "am_pm") return true;
  if (tf === "24") return false;
  return undefined;
}
function defaultLocaleTimeFormat(
  hass,
) {
  const tf = getLocaleObj(hass)?.time_format;
  if (tf === "24") return "24-Hour";
  if (tf === "am_pm") return "12-Hour (AM/PM)";
  try {
    const lang = getLocaleObj(hass)?.language || hass?.language || undefined;
    const hour12 = new Intl.DateTimeFormat(lang, { hour: "numeric" }).resolvedOptions().hour12;
    if (hour12 === false) return "24-Hour";
  } catch {
    // Fall back to 12-hour wire token when Intl options are unavailable.
  }
  return "12-Hour (AM/PM)";
}
function formatClockHhMm(
  hhmm,
  is24h,
) {
  const raw = String(hhmm ?? "").trim();
  const m = /^(\d{1,2}):(\d{2})$/.exec(raw);
  if (!m) return raw || "—";
  const hh = Number(m[1]);
  const mm = Number(m[2]);
  if (!Number.isFinite(hh) || !Number.isFinite(mm) || hh < 0 || hh > 23 || mm < 0 || mm > 59) {
    return raw;
  }
  const mmStr = String(mm).padStart(2, "0");
  if (is24h) {
    return `${String(hh).padStart(2, "0")}:${mmStr}`;
  }
  const h12 = hh % 12 === 0 ? 12 : hh % 12;
  return `${h12}:${mmStr} ${hh >= 12 ? "PM" : "AM"}`;
}
function formatHourSlot(
  hour,
  is24h,
) {
  const n = Number(hour);
  if (!Number.isFinite(n)) return "—";
  const hh = ((Math.round(n) % 24) + 24) % 24;
  if (is24h) {
    return `${String(hh).padStart(2, "0")}:00`;
  }
  const h12 = hh % 12 === 0 ? 12 : hh % 12;
  return `${h12}:00 ${hh >= 12 ? "PM" : "AM"}`;
}
function getDateTimeFormatter(
  locale,
  opts,
) {
  const key = `${locale || "sys"}|${opts.timeZone || "local"}|${String(opts.hour12 ?? "auto")}`;
  const cached = DATE_TIME_FMT_CACHE.get(key);
  if (cached) return cached;
  return setBoundedCache(DATE_TIME_FMT_CACHE, key, new Intl.DateTimeFormat(locale, opts));
}
function hassFirstWeekday(hass) {
  const fw = String(getLocaleObj(hass)?.first_weekday || "language").toLowerCase();
  if (fw === "monday") return "Monday";
  if (fw === "sunday") return "Sunday";
  try {
    const loc = new Intl.Locale(hassLanguage(hass))
     ;
    const firstDay = loc.getWeekInfo?.()?.firstDay ?? loc.weekInfo?.firstDay;
    if (firstDay === 1) return "Monday";
  } catch {
    // Default to Sunday when Intl.Locale weekInfo is unavailable.
  }
  return "Sunday";
}
function fmtNumber(
  value,
  hass,
  maximumFractionDigits = 1,
) {
  if (value === null || value === undefined || value === "") return "—";
  const num = Number(value);
  if (!Number.isFinite(num)) return String(value);
  try {
    const { locale, useGrouping } = resolveNumberLocaleAndGrouping(hass);
    return getNumberFormatter(locale, { maximumFractionDigits, useGrouping }).format(num);
  } catch {
    return String(num);
  }
}
function fmtPercent(
  value,
  hass,
) {
  if (value === null || value === undefined || value === "") return "—";
  const num = Number(value);
  if (!Number.isFinite(num)) return String(value);
  try {
    const { locale, useGrouping } = resolveNumberLocaleAndGrouping(hass);
    return getNumberFormatter(locale, {
      style: "percent",
      maximumFractionDigits: 0,
      useGrouping,
    }).format(num / 100);
  } catch {
    return `${Math.round(num)}%`;
  }
}
function fmtDistance(
  meters,
  hass,
  feet,
) {
  const isImperial = hass?.config?.unit_system?.length === "mi";
  const { locale, useGrouping } = resolveNumberLocaleAndGrouping(hass);
  if (isImperial) {
    const hasFeet = feet !== null && feet !== undefined && Number.isFinite(Number(feet));
    const hasMeters = meters !== null && meters !== undefined && Number.isFinite(Number(meters));
    if (!hasFeet && !hasMeters) return "—";
    const ft = hasFeet ? Number(feet) : Number(meters) * 3.28084;
    try {
      return getNumberFormatter(locale, {
        style: "unit",
        unit: "foot",
        maximumFractionDigits: 1,
        useGrouping,
      }).format(ft);
    } catch {
      return `${ft.toFixed(1)} ft`;
    }
  }
  if (meters === null || meters === undefined || !Number.isFinite(Number(meters))) return "—";
  const m = Number(meters);
  try {
    return getNumberFormatter(locale, {
      style: "unit",
      unit: "meter",
      maximumFractionDigits: 1,
      useGrouping,
    }).format(m);
  } catch {
    return `${m.toFixed(1)} m`;
  }
}
function fmtAgo(
  secondsAgo,
  hass,
) {
  if (secondsAgo === null || secondsAgo === undefined || !Number.isFinite(Number(secondsAgo))) {
    return "—";
  }
  const secs = Math.max(0, Math.round(Number(secondsAgo)));
  try {
    const rtf = getRelativeTimeFormatter(hassLanguage(hass));
    if (secs < 60) return rtf.format(-secs, "second");
    if (secs < 3600) return rtf.format(-Math.round(secs / 60), "minute");
    if (secs < 86400) return rtf.format(-Math.round(secs / 3600), "hour");
    return rtf.format(-Math.round(secs / 86400), "day");
  } catch {
    return `${secs}s ago`;
  }
}
function fmtDateTime(
  ts,
  hass,
) {
  if (ts === null || ts === undefined || ts === "") return "";
  const date = typeof ts === "number" ? new Date(ts < 1e12 ? ts * 1000 : ts) : new Date(ts);
  if (Number.isNaN(date.getTime())) return String(ts);
  const localeObj = getLocaleObj(hass);
  const useServerTz = localeObj?.time_zone === "server" && Boolean(hass?.config?.time_zone);
  const opts = {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  };
  const hour12 = resolveHour12(hass);
  if (hour12 !== undefined) {
    opts.hour12 = hour12;
  }
  if (useServerTz && hass?.config?.time_zone) {
    opts.timeZone = hass.config.time_zone;
  }
  try {
    return getDateTimeFormatter(resolveDateTimeLocale(hass), opts).format(date);
  } catch {
    return date.toISOString();
  }
}
function formatSentenceSegment(seg, isFirstWord) {
  if (!seg) return seg;
  const low = seg.toLowerCase();
  if (LABEL_ACRONYMS[low]) return LABEL_ACRONYMS[low];
  if (/^[a-z]+[A-Z]/.test(seg) || /^[A-Z0-9]{2,}$/.test(seg)) return seg;
  if (isFirstWord) {
    return seg.charAt(0).toUpperCase() + seg.slice(1);
  }
  return seg;
}
/**
 * Formats an entity or setting label in Home Assistant Sentence case (`D-061`),
 * capitalizing the leading word while preserving acronyms (`BLE`, `Wi-Fi`, `ESPHome`, `PIN`)
 * and parenthesized units (`(ms)`, `(dBm)`, `(%)`).
 */
function entityLabel(rawName) {
  const cleaned = String(rawName || "").trim();
  if (!cleaned) return "—";
  const words = cleaned.split(/\s+/).filter(Boolean);
  return words
    .map((word, idx) => {
      const m = /^([([{"']*)(.*?)([)\]}"':,.?]*)$/.exec(word);
      const lead = m ? m[1] : "";
      const core = m ? m[2] : word;
      const trail = m ? m[3] : "";
      if (!core) return word;
      if (
        lead === "(" &&
        trail === ")" &&
        /^(ms|s|m|h|d|dB|dBm|Hz|kHz|MHz|V|mV|A|mA|W|%|°C|°F)$/.test(core)
      ) {
        return word;
      }
      const low = core.toLowerCase();
      if (LABEL_ACRONYMS[low]) {
        return `${lead}${LABEL_ACRONYMS[low]}${trail}`;
      }
      const hyph = core
        .split("-")
        .map((seg, segIdx) => formatSentenceSegment(seg, idx === 0 && segIdx === 0))
        .join("-");
      return `${lead}${hyph}${trail}`;
    })
    .join(" ");
}
function issueMessage(issue, hass) {
  const kind = String(issue.kind || issue.key || "");
  return localizeRepairIssue(
    hass,
    kind,
    issue.detail ? { detail: issue.detail } : undefined,
  );
}
function rssiToPercent(rssi) {
  if (rssi === null || rssi === undefined || !Number.isFinite(Number(rssi))) return 0;
  const clamped = Math.max(-95, Math.min(-35, Number(rssi)));
  return Math.round(((clamped + 95) / 60) * 100);
}
function isValidHexColor(val) {
  const s = String(val || "").trim();
  if (s.length !== 7 || s.charCodeAt(0) !== 35) return false;
  for (let i = 1; i < 7; i += 1) {
    const code = s.charCodeAt(i);
    const isDigit = code >= 48 && code <= 57;
    const isUpper = code >= 65 && code <= 70;
    const isLower = code >= 97 && code <= 102;
    if (!isDigit && !isUpper && !isLower) return false;
  }
  return true;
}
function byteToHex(b) {
  const clamped = Math.max(0, Math.min(255, Math.round(b)));
  return clamped.toString(16).padStart(2, "0").toUpperCase();
}
function packRgbHex(r, g, b) {
  return String.fromCharCode(35) + byteToHex(r) + byteToHex(g) + byteToHex(b);
}
function hsvToRgbJS(h, s, v) {
  const c = v * s;
  const x = c * (1 - Math.abs(((h / 60) % 2) - 1));
  const m = v - c;
  let r1 = 0;
  let g1 = 0;
  let b1 = 0;
  if (h < 60) [r1, g1, b1] = [c, x, 0];
  else if (h < 120) [r1, g1, b1] = [x, c, 0];
  else if (h < 180) [r1, g1, b1] = [0, c, x];
  else if (h < 240) [r1, g1, b1] = [0, x, c];
  else if (h < 300) [r1, g1, b1] = [x, 0, c];
  else [r1, g1, b1] = [c, 0, x];
  return [
    Math.round((r1 + m) * 255),
    Math.round((g1 + m) * 255),
    Math.round((b1 + m) * 255),
  ];
}
function hsvToHex(h, s, v) {
  const [r, g, b] = hsvToRgbJS(h, s, v);
  return packRgbHex(r, g, b);
}
function defaultThemeHex(hostEl) {
  if (hostEl && typeof getComputedStyle === "function") {
    const raw = getComputedStyle(hostEl).getPropertyValue("--primary-color").trim();
    if (isValidHexColor(raw)) return raw.toUpperCase();
  }
  return packRgbHex(0, 154, 199);
}
async function copyTextToClipboard(
  text,
  root,
) {
  if (!text) return false;
  try {
    if (typeof navigator !== "undefined" && typeof navigator.clipboard?.writeText === "function") {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch {
    // Fall back to shadow-safe offscreen textarea selection below.
  }
  if (typeof document === "undefined") return false;
  try {
    const shadow =
      (root && "querySelector" in root ? root : null) ??
      document.activeElement?.shadowRoot ??
      document.querySelector("latter-studio")?.shadowRoot ??
      null;
    const prevActive =
      (shadow && "activeElement" in shadow
        ? (shadow).activeElement
        : document.activeElement);
    const mountTarget =
      shadow?.querySelector("dialog[open]") ?? shadow ?? document.body;
    const ta = document.createElement("textarea");
    ta.className = "offscreen";
    ta.setAttribute("aria-hidden", "true");
    ta.tabIndex = -1;
    ta.readOnly = true;
    ta.value = text;
    mountTarget.appendChild(ta);
    ta.focus({ preventScroll: true });
    ta.select();
    const ok = typeof document.execCommand === "function" && document.execCommand("copy");
    mountTarget.removeChild(ta);
    prevActive?.focus?.({ preventScroll: true });
    return Boolean(ok);
  } catch {
    return false;
  }
}
function triggerJsonDownload(filename, data) {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
function navigateHaPath(path, replace = false) {
  if (!path) return;
  if (replace) {
    globalThis.history.replaceState(null, "", path);
  } else {
    globalThis.history.pushState(null, "", path);
  }
  globalThis.dispatchEvent(new Event("location-changed", { bubbles: true, composed: true }));
}
__latterExp(__exports, { hassLanguage: () => hassLanguage, defaultLocaleTimeFormat: () => defaultLocaleTimeFormat, formatClockHhMm: () => formatClockHhMm, formatHourSlot: () => formatHourSlot, hassFirstWeekday: () => hassFirstWeekday, fmtNumber: () => fmtNumber, fmtPercent: () => fmtPercent, fmtDistance: () => fmtDistance, fmtAgo: () => fmtAgo, fmtDateTime: () => fmtDateTime, entityLabel: () => entityLabel, issueMessage: () => issueMessage, rssiToPercent: () => rssiToPercent, isValidHexColor: () => isValidHexColor, hsvToRgbJS: () => hsvToRgbJS, hsvToHex: () => hsvToHex, defaultThemeHex: () => defaultThemeHex, copyTextToClipboard: () => copyTextToClipboard, triggerJsonDownload: () => triggerJsonDownload, navigateHaPath: () => navigateHaPath });
//# sourceURL=latter-studio/src/utils/format.ts
});
__latterDef("src/components/controls.ts", (__exports, __req) => {
const { t, tPrefLabel, tPrefOption } = __req("src/i18n/index.ts");
const { Directive, directive, focusSafe, html, noChange, nothing, PartType, repeat } = __req("src/lib/lit.ts");
const { defaultLocaleTimeFormat, entityLabel, fmtNumber, formatHourSlot } = __req("src/utils/format.ts");
/**
 * Shared Lit UI controls for Latter Studio (`D-014`, `D-015`, `D-024`, `D-062`, `D-064`):
 * - Cards & auto-described settings/select/switch/range rows (`aria-describedby` + live `aria-valuetext`)
 * - Shared confirmation `<dialog>` builder (`renderConfirmDialog`, `Q5`)
 * - Reusable WAI-ARIA 1.2 searchable entity combobox (`renderEntityCombobox`, `Q11`)
 * - Pointer drag-handle (`≡`) + keyboard focus-preserving `renderSortableList` & `renderPillList` (`U4`)
 * Note: Event bindings (`@click`, `@change`, `@input`) always precede `class="..."` / `role="radio"`.
 */
function isDeviceTime24h(store) {
  if (store.currentScope !== "system") {
    const raw =
      store.entity.getPref("time_format")?.value ??
      store.state?.config?.time_format;
    const trimmed = raw !== undefined && raw !== null ? String(raw).trim() : "";
    if (trimmed) {
      return trimmed.startsWith("24");
    }
  }
  return defaultLocaleTimeFormat(store.hass).startsWith("24");
}
function slugifyToken(raw) {
  let hash = 0x811c9dc5;
  for (let i = 0; i < raw.length; i += 1) {
    hash ^= raw.charCodeAt(i);
    hash = Math.imul(hash, 0x01000193) >>> 0;
  }
  const clean = raw
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 28);
  // Prefix with non-hex ` row-desc-` / `z` so ID selectors never resemble hex literals.
  return clean ? `${clean}-${hash.toString(36)}` : `z${hash.toString(36)}`;
}
function resolveDescriptionId(opts
 ) {
  if (!opts.hasDescription) return "";
  if (opts.descId) return opts.descId;
  if (opts.forId) return `${opts.forId}-desc`;
  if (opts.id) return `${opts.id}-desc`;
  return `row-desc-${slugifyToken(opts.label || "setting")}`;
}
class AutoDescribeDirective extends Directive {
  constructor(partInfo) {
    super(partInfo);
    if (partInfo.type !== PartType.ELEMENT) {
      throw new Error("autoWireDescribedBy() must be used as an element directive");
    }
  }
  render(_descId) {
    return nothing;
  }
           update(part, [descId]) {
    if (descId && part.element) {
      const container = part.element;
      const apply = () => {
        const target = container.querySelector(
          "input:not([type='hidden']), select, textarea, [role='combobox']",
        );
        if (target && !target.hasAttribute("aria-describedby")) {
          target.setAttribute("aria-describedby", descId);
        }
      };
      apply();
      queueMicrotask(apply);
    }
    return noChange;
  }
}
const autoWireDescribedBy = directive(AutoDescribeDirective);
function renderCard(opts) {
  const headingEl = opts.heading ?? html`<h3 class="card-title">${opts.title || ""}</h3>`;
  const headerInner =
    opts.subtitle || (opts.headerActions && opts.headerActions !== nothing)
      ? html`<div class="card-heading">
            ${headingEl}
            ${opts.subtitle ? html`<p class="card-subtitle">${opts.subtitle}</p>` : nothing}
          </div>
          ${opts.headerActions && opts.headerActions !== nothing
            ? html`<div class="card-header-actions">${opts.headerActions}</div>`
            : nothing}`
      : headingEl;
  const contentCls = opts.contentClass ? `card-content ${opts.contentClass}` : "card-content";
  return html`<div id=${opts.id || nothing} class="card${opts.danger ? " danger" : ""}${opts.handoffActive ? " handoff-active" : ""}">
    <div class="card-header">${headerInner}</div>
    <div class=${contentCls}>${opts.body}</div>
    ${opts.footerActions && opts.footerActions !== nothing
      ? html`<div class="card-actions">${opts.footerActions}</div>`
      : nothing}
  </div>`;
}
function renderSettingsRow(opts) {
  const hasDescription = Boolean(opts.description && opts.description !== nothing);
  const resolvedDescId = resolveDescriptionId({
    descId: opts.descId,
    forId: opts.forId,
    id: opts.id,
    label: opts.label,
    hasDescription,
  });
  const labelEl =
    opts.labelHtml ??
    (opts.forId
      ? html`<label for=${opts.forId} class="row-label">${opts.label || ""}</label>`
      : html`<span class="row-label">${opts.label || ""}</span>`);
  return html`<div id=${opts.id || nothing} class="settings-row${opts.stacked ? " stacked" : ""}">
    <div class="settings-row-text">
      ${labelEl}
      ${hasDescription
        ? html`<p id=${resolvedDescId} class="row-description">${opts.description}</p>`
        : nothing}
    </div>
    <div class="settings-row-control" ${resolvedDescId ? autoWireDescribedBy(resolvedDescId) : nothing}>
      ${opts.control}
    </div>
  </div>`;
}
function renderSelectRow(opts) {
  const cur = String(opts.value ?? "");
  const resolvedDescId = resolveDescriptionId({
    descId: opts.descId,
    forId: opts.id,
    id: opts.rowId,
    label: opts.label,
    hasDescription: Boolean(opts.description && opts.description !== nothing),
  });
  return renderSettingsRow({
    id: opts.rowId,
    label: opts.label,
    forId: opts.id,
    description: opts.description,
    descId: resolvedDescId || undefined,
    control: html`<select
      id=${opts.id || nothing}
      aria-label=${opts.id ? nothing : opts.ariaLabel || opts.label}
      aria-describedby=${resolvedDescId || nothing}
      ?disabled=${Boolean(opts.disabled)}
      .value=${cur}
      @change=${(ev) => opts.onChange((ev.currentTarget).value)}
    >
      ${opts.rawOptions
        ? opts.rawOptions.map(
            (o) => html`<option value=${o.value} ?selected=${o.value === cur}>${o.label}</option>`,
          )
        : renderSelectOptions(opts.choices, cur, opts.emptyOptionLabel)}
    </select>`,
  });
}
function renderSwitchRow(opts) {
  const resolvedDescId = resolveDescriptionId({
    descId: opts.descId,
    forId: opts.id,
    id: opts.rowId,
    label: opts.label,
    hasDescription: Boolean(opts.description && opts.description !== nothing),
  });
  return renderSettingsRow({
    id: opts.rowId,
    label: opts.label,
    forId: opts.id,
    description: opts.description,
    descId: resolvedDescId || undefined,
    control: html`<input
      type="checkbox"
      id=${opts.id || nothing}
      role="switch"
      aria-label=${opts.id ? nothing : opts.ariaLabel || opts.label}
      aria-describedby=${resolvedDescId || nothing}
      ?disabled=${Boolean(opts.disabled)}
      .checked=${opts.checked}
      @change=${(ev) => opts.onChange((ev.currentTarget).checked)}
      class="switch"
    />`,
  });
}
function renderRangeControl(opts) {
  const step = opts.step ?? 1;
  const maxFrac =
    opts.maximumFractionDigits ?? (Number.isInteger(step) ? 0 : 1);
  const isHourSlot = opts.unit === ":00";
  const resolvedIs24h =
    opts.is24h ?? defaultLocaleTimeFormat(opts.hass).startsWith("24");
  const unitSuffix =
    !isHourSlot && opts.unit
      ? opts.unit === "%"
        ? "%"
        : ` ${opts.unit}`
      : "";
  const formatVal = (v) =>
    isHourSlot
      ? formatHourSlot(v, resolvedIs24h)
      : `${fmtNumber(v, opts.hass, maxFrac)}${unitSuffix}`;
  const initialText = formatVal(opts.value);
  const handleLiveInput = (ev) => {
    const inp = ev.currentTarget;
    const raw = Number(inp.value);
    if (!Number.isFinite(raw)) return;
    const nextText = formatVal(raw);
    inp.setAttribute("aria-valuetext", nextText);
    const prev = inp.previousElementSibling;
    if (prev && prev.classList.contains("kv-value")) {
      prev.textContent = nextText;
    }
    opts.onInput?.(raw);
  };
  const handleCommit = (ev) => {
    const raw = Number((ev.currentTarget).value);
    if (Number.isFinite(raw)) {
      opts.onCommit(raw);
    }
  };
  return html`<span class="kv-value">${initialText}</span>
    <input
      type="range"
      id=${opts.id || nothing}
      aria-label=${opts.ariaLabel}
      aria-describedby=${opts.ariaDescribedBy || nothing}
      aria-valuetext=${initialText}
      min=${String(opts.min)}
      max=${String(opts.max)}
      step=${String(step)}
      ?disabled=${Boolean(opts.disabled)}
      .value=${String(opts.value)}
      @input=${handleLiveInput}
      @change=${handleCommit}
    />`;
}
function renderRangeRow(opts) {
  const resolvedDescId = resolveDescriptionId({
    descId: opts.descId,
    forId: opts.id,
    id: opts.rowId,
    label: opts.label,
    hasDescription: Boolean(opts.description && opts.description !== nothing),
  });
  return renderSettingsRow({
    id: opts.rowId,
    label: opts.label,
    forId: opts.id,
    description: opts.description,
    descId: resolvedDescId || undefined,
    control: renderRangeControl({
      ...opts,
      ariaLabel: opts.ariaLabel || opts.label,
      ariaDescribedBy: resolvedDescId || opts.ariaDescribedBy,
    }),
  });
}
function renderHourSelectControl(
  opts,
) {
  const resolvedIs24h =
    opts.is24h ?? defaultLocaleTimeFormat(opts.hass).startsWith("24");
  const normalizedHour = ((Math.round(opts.value) % 24) + 24) % 24;
  const selectValue = opts.mixed ? "__mixed__" : String(normalizedHour);
  return html`<select
    id=${opts.id || nothing}
    aria-label=${opts.ariaLabel}
    aria-describedby=${opts.ariaDescribedBy || nothing}
    ?disabled=${Boolean(opts.disabled)}
    .value=${selectValue}
    @change=${(ev) => {
      const raw = (ev.currentTarget).value;
      if (raw === "__mixed__") return;
      const nextHour = Number(raw);
      if (Number.isFinite(nextHour)) {
        opts.onCommit(((Math.round(nextHour) % 24) + 24) % 24);
      }
    }}
  >
    ${opts.mixed
      ? html`<option value="__mixed__" selected disabled>
          ${opts.mixedLabel || t("batch.mixed_badge")}
        </option>`
      : nothing}
    ${Array.from({ length: 24 }, (_, h) => {
      const valStr = String(h);
      return html`<option
        value=${valStr}
        ?selected=${!opts.mixed && h === normalizedHour}
      >
        ${formatHourSlot(h, resolvedIs24h)}
      </option>`;
    })}
  </select>`;
}
function renderHourSelectRow(opts) {
  const resolvedDescId = resolveDescriptionId({
    descId: opts.descId,
    forId: opts.id,
    id: opts.rowId,
    label: opts.label,
    hasDescription: Boolean(opts.description && opts.description !== nothing),
  });
  return renderSettingsRow({
    id: opts.rowId,
    label: opts.label,
    forId: opts.id,
    description: opts.description,
    descId: resolvedDescId || undefined,
    control: renderHourSelectControl({
      ...opts,
      ariaLabel: opts.ariaLabel || opts.label,
      ariaDescribedBy: resolvedDescId || opts.ariaDescribedBy,
    }),
  });
}
// ---------------------------------------------------------------------------
// Shared Confirmation <dialog> Builder (Q5 / D-064)
// ---------------------------------------------------------------------------
function syncDialogElement(
  dlg,
  wantOpen,
) {
  if (!dlg) return;
  if (!wantOpen) {
    if (dlg.open) {
      try {
        dlg.close();
      } catch {
        dlg.removeAttribute("open");
      }
    }
    return;
  }
  if (!dlg.open) {
    try {
      dlg.showModal();
    } catch {
      dlg.setAttribute("open", "");
    }
  }
}
function renderConfirmDialog(opts) {
  const titleId = `${opts.id}-title`;
  const descId = `${opts.id}-desc`;
  const isDanger = opts.danger !== false;
  const count = opts.blastRadiusCount;
  const blastText =
    opts.blastRadiusLabel ||
    (count !== undefined && count !== null && count > 0
      ? count === 1
        ? t("confirm.blast_radius_one", undefined, opts.overlay)
        : t("confirm.blast_radius_many", { count }, opts.overlay)
      : "");
  const onBackdropClick = (ev) => {
    if (ev.target === ev.currentTarget) {
      opts.onCancel();
    }
  };
  return html`<dialog
    id=${opts.id}
    aria-labelledby=${titleId}
    aria-describedby=${descId}
    @cancel=${(ev) => {
      ev.preventDefault();
      opts.onCancel();
    }}
    @click=${onBackdropClick}
    class="studio-dialog confirm-dialog"
  >
    <div class="dialog-body">
      <div class="dialog-header-row">
        <h3 id=${titleId} class="dialog-title">${opts.title}</h3>
        ${blastText
          ? html`<span class="chip ${isDanger ? "chip-warning" : "chip-primary"} confirm-blast-badge">
              ${blastText}
            </span>`
          : nothing}
      </div>
      ${opts.extraBody && opts.extraBody !== nothing ? opts.extraBody : nothing}
      <p id=${descId} class="dialog-text">${opts.consequence}</p>
      <div class="dialog-actions${opts.onDownloadBackupFirst ? " with-secondary" : ""}">
        ${opts.onDownloadBackupFirst
          ? html`<button
              type="button"
              @click=${opts.onDownloadBackupFirst}
              class="btn btn-text btn-compact"
            >
              ${opts.downloadBackupLabel ||
              t("action.download_backup_first", undefined, opts.overlay)}
            </button>`
          : nothing}
        <div class="dialog-actions-end">
          <button
            type="button"
            @click=${opts.onCancel}
            class="btn btn-secondary"
          >
            ${opts.cancelLabel || t("action.cancel", undefined, opts.overlay)}
          </button>
          <button
            type="button"
            id=${opts.confirmButtonId || nothing}
            ?disabled=${Boolean(opts.busy || opts.confirmDisabled)}
            @click=${opts.onConfirm}
            class="btn ${isDanger ? "btn-danger-filled" : "btn-primary"}"
          >
            ${opts.confirmLabel}
          </button>
        </div>
      </div>
    </div>
  </dialog>`;
}
// ---------------------------------------------------------------------------
// Reusable WAI-ARIA 1.2 Searchable Entity Combobox (Q11 / D-062)
// ---------------------------------------------------------------------------
const COMBOBOX_STATE = new Map();
function getComboboxState(id) {
  let st = COMBOBOX_STATE.get(id);
  if (!st) {
    st = { open: false, query: "", activeIndex: 0 };
    COMBOBOX_STATE.set(id, st);
  }
  return st;
}
function resetComboboxState(id) {
  if (id) {
    COMBOBOX_STATE.delete(id);
  } else {
    COMBOBOX_STATE.clear();
  }
}
function isOrderedSubsequence(needle, haystack) {
  if (!needle) return true;
  if (needle.length > haystack.length) return false;
  let ni = 0;
  for (let hi = 0; hi < haystack.length && ni < needle.length; hi += 1) {
    if (haystack.charCodeAt(hi) === needle.charCodeAt(ni)) {
      ni += 1;
    }
  }
  return ni === needle.length;
}
function matchComboboxOptions(
  options,
  rawQuery,
  maxResults = 80,
) {
  const list = options || [];
  const cap = Math.max(1, maxResults);
  const query = String(rawQuery || "").trim().toLowerCase();
  if (!query) {
    return {
      items: list.slice(0, cap),
      totalMatches: list.length,
    };
  }
  const tokens = query.split(/\s+/).filter(Boolean);
  const scored = [];
  for (const item of list) {
    const idLow = String(item.id || "").toLowerCase();
    const objIdLow = idLow.includes(".") ? idLow.split(".", 2)[1] : idLow;
    const nameLow = String(item.name || item.id || "").toLowerCase();
    const areaLow = String(item.area_name || "").toLowerCase();
    const domLow = String(item.domain || (idLow.includes(".") ? idLow.split(".", 1)[0] : "")).toLowerCase();
    const combined = `${nameLow} ${areaLow} ${idLow} ${domLow}`;
    let matchedAll = true;
    let usedFuzzy = false;
    for (const tok of tokens) {
      if (combined.includes(tok)) {
        continue;
      }
      if (isOrderedSubsequence(tok, `${nameLow} ${idLow}`)) {
        usedFuzzy = true;
        continue;
      }
      matchedAll = false;
      break;
    }
    if (!matchedAll) continue;
    let rank = 4;
    if (!usedFuzzy) {
      if (nameLow === query || idLow === query || objIdLow === query) {
        rank = 0;
      } else if (nameLow.startsWith(query) || objIdLow.startsWith(query) || idLow.startsWith(query)) {
        rank = 1;
      } else if (nameLow.includes(query) || areaLow.includes(query)) {
        rank = 2;
      } else {
        rank = 3;
      }
    }
    scored.push({ item, rank, labelLow: nameLow });
  }
  scored.sort(
    (a, b) =>
      a.rank - b.rank ||
      a.labelLow.localeCompare(b.labelLow) ||
      a.item.id.localeCompare(b.item.id),
  );
  return {
    items: scored.slice(0, cap).map((s) => s.item),
    totalMatches: scored.length,
  };
}
function toneToChipClass(tone) {
  if (tone === "primary") return "chip chip-primary";
  if (tone === "success") return "chip chip-success";
  if (tone === "warning") return "chip chip-warning";
  if (tone === "error") return "chip chip-error";
  return "chip";
}
function renderEntityCombobox(opts) {
  const ui = getComboboxState(opts.id);
  const curVal = String(opts.value ?? "").trim();
  const allOptions = opts.options || [];
  const maxResults = opts.maxResults ?? 80;
  const selectedOpt = curVal ? allOptions.find((o) => o.id === curVal) : undefined;
  const closedDisplayValue = curVal
    ? selectedOpt
      ? selectedOpt.name || selectedOpt.id
      : t("common.missing_suffix", { id: curVal }, opts.overlay)
    : "";
  const { items: matchedItems, totalMatches } = matchComboboxOptions(
    allOptions,
    ui.open ? ui.query : "",
    maxResults,
  );
  const clampedActiveIdx =
    matchedItems.length > 0
      ? Math.max(0, Math.min(matchedItems.length - 1, ui.activeIndex))
      : -1;
  const listboxId = `${opts.id}-listbox`;
  const optionDomId = (idx) => `${opts.id}-opt-${idx}`;
  const activeDescendantId =
    ui.open && clampedActiveIdx >= 0 ? optionDomId(clampedActiveIdx) : "";
  const notifyUi = (rootEl) => {
    opts.onUiChange?.();
    opts.host?.requestUpdate();
    if (!opts.onUiChange && !opts.host && rootEl) {
      const rootNode = typeof rootEl.getRootNode === "function" ? rootEl.getRootNode() : null;
      const hostEl =
        rootNode && "host" in rootNode
          ? ((rootNode).host)
          : null;
      hostEl?.requestUpdate?.();
    }
  };
  const scrollActiveIntoView = (inputEl, nextIdx) => {
    if (!inputEl || nextIdx < 0) return;
    requestAnimationFrame(() => {
      const wrap = inputEl.closest(".combobox");
      const li = wrap?.querySelector(`#${CSS.escape(optionDomId(nextIdx))}`);
      li?.scrollIntoView?.({ block: "nearest" });
    });
  };
  const commitSelection = (nextId, sourceEl) => {
    ui.open = false;
    ui.query = "";
    ui.activeIndex = 0;
    if (nextId !== curVal) {
      opts.onChange(nextId);
    }
    notifyUi(sourceEl);
  };
  const openMenu = (sourceEl) => {
    if (opts.disabled || ui.open) return;
    ui.open = true;
    ui.query = "";
    const curIdx = curVal ? matchedItems.findIndex((o) => o.id === curVal) : -1;
    ui.activeIndex = curIdx >= 0 ? curIdx : 0;
    notifyUi(sourceEl);
  };
  const onInput = (ev) => {
    const inp = ev.currentTarget;
    // Typing ONLY filters options; NEVER mutates the bound entity selection!
    ui.open = true;
    ui.query = inp.value;
    ui.activeIndex = 0;
    notifyUi(inp);
  };
  const onKeyDown = (ev) => {
    const inp = ev.currentTarget;
    if (ev.key === "ArrowDown") {
      ev.preventDefault();
      if (!ui.open) {
        openMenu(inp);
        return;
      }
      if (matchedItems.length > 0) {
        const nextIdx = (clampedActiveIdx + 1) % matchedItems.length;
        ui.activeIndex = nextIdx;
        notifyUi(inp);
        scrollActiveIntoView(inp, nextIdx);
      }
      return;
    }
    if (ev.key === "ArrowUp") {
      ev.preventDefault();
      if (!ui.open) {
        ui.open = true;
        ui.query = "";
        ui.activeIndex = Math.max(0, matchedItems.length - 1);
        notifyUi(inp);
        return;
      }
      if (matchedItems.length > 0) {
        const nextIdx = (clampedActiveIdx - 1 + matchedItems.length) % matchedItems.length;
        ui.activeIndex = nextIdx;
        notifyUi(inp);
        scrollActiveIntoView(inp, nextIdx);
      }
      return;
    }
    if (ui.open && ev.key === "Home" && matchedItems.length > 0) {
      ev.preventDefault();
      ui.activeIndex = 0;
      notifyUi(inp);
      scrollActiveIntoView(inp, 0);
      return;
    }
    if (ui.open && ev.key === "End" && matchedItems.length > 0) {
      ev.preventDefault();
      const last = matchedItems.length - 1;
      ui.activeIndex = last;
      notifyUi(inp);
      scrollActiveIntoView(inp, last);
      return;
    }
    if (ev.key === "Enter" && !ev.isComposing && ev.keyCode !== 229) {
      if (ui.open) {
        ev.preventDefault();
        ev.stopPropagation();
        if (clampedActiveIdx >= 0 && matchedItems[clampedActiveIdx]) {
          commitSelection(matchedItems[clampedActiveIdx].id, inp);
        }
      }
      return;
    }
    if (ev.key === "Escape") {
      if (ui.open) {
        ev.preventDefault();
        ev.stopPropagation();
        ui.open = false;
        ui.query = "";
        inp.value = closedDisplayValue;
        notifyUi(inp);
      }
    }
  };
  const onFocusOut = (ev) => {
    const wrap = ev.currentTarget;
    const rel = ev.relatedTarget;
    if (rel && wrap.contains(rel)) {
      return;
    }
    if (ui.open) {
      ui.open = false;
      ui.query = "";
      const inp = wrap.querySelector("input[role='combobox']");
      if (inp) {
        inp.value = closedDisplayValue;
      }
      notifyUi(wrap);
    }
  };
  const showClear = opts.allowClear !== false && Boolean(curVal) && !opts.disabled;
  const placeholderText =
    opts.placeholder ||
    (curVal
      ? closedDisplayValue
      : opts.emptyOptionLabel || t("combobox.placeholder", undefined, opts.overlay));
  return html`<div @focusout=${onFocusOut} class="combobox">
    <div class="combobox-input-wrap">
      <input
        type="text"
        id=${opts.id}
        role="combobox"
        autocomplete="off"
        spellcheck="false"
        aria-autocomplete="list"
        aria-expanded=${ui.open ? "true" : "false"}
        aria-controls=${listboxId}
        aria-activedescendant=${activeDescendantId || nothing}
        aria-label=${opts.ariaLabel || nothing}
        aria-describedby=${opts.ariaDescribedBy || nothing}
        placeholder=${placeholderText}
        ?disabled=${Boolean(opts.disabled)}
        .value=${ui.open ? focusSafe(ui.query) : closedDisplayValue}
        @focus=${(ev) => openMenu(ev.currentTarget)}
        @click=${(ev) => openMenu(ev.currentTarget)}
        @input=${onInput}
        @keydown=${onKeyDown}
      />
      ${showClear
        ? html`<button
            type="button"
            aria-label=${t("combobox.clear", undefined, opts.overlay)}
            @pointerdown=${(ev) => {
              ev.preventDefault();
              commitSelection("", ev.currentTarget);
            }}
            @click=${(ev) => commitSelection("", ev.currentTarget)}
            class="combobox-clear"
          >
            ×
          </button>`
        : nothing}
    </div>
    <ul
      id=${listboxId}
      role="listbox"
      aria-label=${opts.ariaLabel || t("combobox.placeholder", undefined, opts.overlay)}
      class="combobox-listbox${ui.open ? "" : " hidden"}"
    >
      ${matchedItems.length === 0
        ? html`<li role="presentation" class="combobox-empty">
            ${t("combobox.no_matches", undefined, opts.overlay)}
          </li>`
        : repeat(
            matchedItems,
            (item) => item.id,
            (item, idx) => {
              const dom = item.domain || (item.id.includes(".") ? item.id.split(".", 1)[0] : "");
              const isSel = item.id === curVal;
              const isAct = idx === clampedActiveIdx;
              return html`<li
                id=${optionDomId(idx)}
                role="option"
                aria-selected=${isSel ? "true" : "false"}
                @pointerenter=${(ev) => {
                  if (ui.activeIndex !== idx) {
                    ui.activeIndex = idx;
                    notifyUi(ev.currentTarget);
                  }
                }}
                @pointerdown=${(ev) => {
                  ev.preventDefault();
                  commitSelection(item.id, ev.currentTarget);
                }}
                @click=${(ev) => commitSelection(item.id, ev.currentTarget)}
                class="combobox-option${isAct ? " active" : ""}"
              >
                <div class="combobox-option-main">
                  <span class="combobox-option-title">${item.name || item.id}</span>
                  <span class="combobox-option-id">${item.id}</span>
                </div>
                <span class="combobox-option-chips">
                  ${item.area_name ? html`<span class="chip">${item.area_name}</span>` : nothing}
                  ${dom ? html`<span class="chip">${dom}</span>` : nothing}
                  ${item.state_label
                    ? html`<span class=${toneToChipClass(item.state_tone)}>${item.state_label}</span>`
                    : nothing}
                </span>
              </li>`;
            },
          )}
      ${totalMatches > matchedItems.length
        ? html`<li role="presentation" class="combobox-footer">
            ${t(
              "combobox.showing_top",
              { shown: matchedItems.length, total: totalMatches },
              opts.overlay,
            )}
          </li>`
        : nothing}
    </ul>
  </div>`;
}
// ---------------------------------------------------------------------------
// Pointer Drag-and-Drop (`≡`) + Focus-Preserving Keyboard Sortable Lists & Pills (U4 / D-064)
// ---------------------------------------------------------------------------
let activeDrag = null;
const SORTABLE_LIVE_STATUS = new Map();
function announceReorder(
  listId,
  itemLabel,
  toIndex,
  total,
  overlay,
  rootEl,
) {
  const msg = t(
    "common.reordered_status",
    { item: itemLabel, position: toIndex + 1, total },
    overlay,
  );
  SORTABLE_LIVE_STATUS.set(listId, msg);
  const liveEl = rootEl
    ?.closest("[data-sortable-list]")
    ?.querySelector("[data-sortable-live]");
  if (liveEl) {
    liveEl.textContent = msg;
  }
}
function clearDragDomClasses(listEl) {
  if (!listEl) return;
  for (const el of listEl.querySelectorAll(".dragging, .drag-over-before, .drag-over-after")) {
    el.classList.remove("dragging", "drag-over-before", "drag-over-after");
  }
}
function computeDropTargetIndex(
  fromIndex,
  overIndex,
  insertAfter,
  total,
) {
  let target = insertAfter ? overIndex + 1 : overIndex;
  if (target > fromIndex) {
    target -= 1;
  }
  return Math.max(0, Math.min(total - 1, target));
}
function attachDragHandleHandlers(opts
 ) {
  const onPointerDown = (ev) => {
    if (ev.button !== 0 || opts.total <= 1) return;
    const handle = ev.currentTarget;
    const rowEl = handle.closest("[data-sortable-index]");
    const listEl = handle.closest("[data-sortable-list]");
    if (!rowEl || !listEl) return;
    ev.preventDefault();
    try {
      handle.setPointerCapture(ev.pointerId);
    } catch {
      // Headless test environments may omit setPointerCapture.
    }
    activeDrag = {
      listId: opts.listId,
      pointerId: ev.pointerId,
      orientation: opts.orientation,
      fromIndex: opts.idx,
      overIndex: opts.idx,
      insertAfter: false,
    };
    clearDragDomClasses(listEl);
    rowEl.classList.add("dragging");
  };
  const onPointerMove = (ev) => {
    if (!activeDrag || activeDrag.listId !== opts.listId || activeDrag.pointerId !== ev.pointerId) {
      return;
    }
    const handle = ev.currentTarget;
    const listEl = handle.closest("[data-sortable-list]");
    if (!listEl) return;
    const rows = Array.from(listEl.querySelectorAll (":scope > [data-sortable-index]"));
    if (!rows.length) return;
    const isRtl =
      opts.orientation === "horizontal" &&
      typeof getComputedStyle === "function" &&
      getComputedStyle(listEl).direction === "rtl";
    let bestRow = null;
    let bestIdx = activeDrag.fromIndex;
    let bestDist = Infinity;
    let bestAfter = false;
    for (const r of rows) {
      const rIdx = Number(r.dataset.sortableIndex);
      if (!Number.isFinite(rIdx)) continue;
      const rect = r.getBoundingClientRect();
      if (!rect.width && !rect.height) continue;
      if (opts.orientation === "vertical") {
        const midY = rect.top + rect.height / 2;
        const dist = Math.abs(ev.clientY - midY);
        if (dist < bestDist) {
          bestDist = dist;
          bestRow = r;
          bestIdx = rIdx;
          bestAfter = ev.clientY > midY;
        }
      } else {
        const midX = rect.left + rect.width / 2;
        const midY = rect.top + rect.height / 2;
        const dist = Math.hypot(ev.clientX - midX, (ev.clientY - midY) * 1.5);
        if (dist < bestDist) {
          bestDist = dist;
          bestRow = r;
          bestIdx = rIdx;
          bestAfter = isRtl ? ev.clientX < midX : ev.clientX > midX;
        }
      }
    }
    activeDrag.overIndex = bestIdx;
    activeDrag.insertAfter = bestAfter;
    for (const r of rows) {
      r.classList.remove("drag-over-before", "drag-over-after");
    }
    if (bestRow && bestIdx !== activeDrag.fromIndex) {
      bestRow.classList.add(bestAfter ? "drag-over-after" : "drag-over-before");
    }
  };
  const finishDrag = (ev, cancelled) => {
    if (!activeDrag || activeDrag.listId !== opts.listId || activeDrag.pointerId !== ev.pointerId) {
      return;
    }
    const session = activeDrag;
    activeDrag = null;
    const handle = ev.currentTarget;
    const listEl = handle.closest("[data-sortable-list]");
    try {
      if (typeof handle.hasPointerCapture === "function" && handle.hasPointerCapture(ev.pointerId)) {
        handle.releasePointerCapture(ev.pointerId);
      }
    } catch {
      // Ignore release errors.
    }
    clearDragDomClasses(listEl);
    if (cancelled) return;
    const toIndex = computeDropTargetIndex(
      session.fromIndex,
      session.overIndex,
      session.insertAfter,
      opts.total,
    );
    if (toIndex !== session.fromIndex) {
      opts.onReorder(session.fromIndex, toIndex);
      announceReorder(opts.listId, opts.itemLabel, toIndex, opts.total, opts.overlay, handle);
    }
  };
  return {
    onPointerDown,
    onPointerMove,
    onPointerUp: (ev) => finishDrag(ev, false),
    onPointerCancel: (ev) => finishDrag(ev, true),
  };
}
function triggerKeyboardMoveWithFocusRestore(opts
 ) {
  const root =
    typeof opts.btnEl.getRootNode === "function"
      ? (opts.btnEl.getRootNode())
      : document;
  opts.onReorder(opts.fromIndex, opts.toIndex);
  announceReorder(opts.listId, opts.itemLabel, opts.toIndex, opts.total, opts.overlay, opts.btnEl);
  requestAnimationFrame(() => {
    if (!root || typeof root.querySelector !== "function") return;
    const listEl = root.querySelector(`[data-sortable-list="${CSS.escape(opts.listId)}"]`);
    if (!listEl) return;
    const itemEl = listEl.querySelector(
      `[data-sortable-key="${CSS.escape(opts.itemKey)}"]`,
    );
    if (!itemEl) return;
    const sameBtn = itemEl.querySelector(
      `button[data-move-dir="${opts.preferredDir}"]:not(:disabled)`,
    );
    if (sameBtn) {
      sameBtn.focus({ preventScroll: true });
      return;
    }
    const altBtn = itemEl.querySelector(
      "button[data-move-dir]:not(:disabled), button:not(:disabled)",
    );
    altBtn?.focus({ preventScroll: true });
  });
}
function renderSortableList (opts) {
  const total = opts.items.length;
  const liveMsg = SORTABLE_LIVE_STATUS.get(opts.id) || "";
  if (total === 0) {
    return html`<div id=${opts.id} data-sortable-list=${opts.id} class="sortable-list">
      ${typeof opts.emptyState === "string"
        ? html`<p class="empty-state">${opts.emptyState}</p>`
        : opts.emptyState || nothing}
      <span data-sortable-live role="status" aria-live="polite" class="sr-only">${liveMsg}</span>
    </div>`;
  }
  const seenKeys = new Map();
  const uniqueKeys = opts.items.map((item, idx) => {
    const raw = String(opts.getKey(item, idx));
    const prevCount = seenKeys.get(raw) ?? 0;
    seenKeys.set(raw, prevCount + 1);
    return prevCount === 0 ? raw : `${raw}__dup_${prevCount}`;
  });
  return html`<div
    id=${opts.id}
    data-sortable-list=${opts.id}
    role="group"
    aria-label=${opts.ariaLabel || nothing}
    class="sortable-list"
  >
    ${repeat(
      opts.items,
      (_item, idx) => uniqueKeys[idx],
      (item, idx) => {
        const key = uniqueKeys[idx];
        const label = opts.getLabel(item, idx);
        const movable = opts.canMoveItem ? opts.canMoveItem(item, idx) : true;
        const extraCls =
          typeof opts.rowClass === "function"
            ? opts.rowClass(item, idx)
            : opts.rowClass || "";
        const drag = attachDragHandleHandlers({
          listId: opts.id,
          orientation: "vertical",
          idx,
          total,
          itemLabel: label,
          overlay: opts.overlay,
          onReorder: opts.onReorder,
        });
        return html`<div
          data-sortable-key=${key}
          data-sortable-index=${String(idx)}
          class="sortable-row${extraCls ? ` ${extraCls}` : ""}"
        >
          ${movable && total > 1
            ? html`<button
                type="button"
                tabindex="-1"
                aria-hidden="true"
                title=${t("action.drag_reorder", { item: label }, opts.overlay)}
                @pointerdown=${drag.onPointerDown}
                @pointermove=${drag.onPointerMove}
                @pointerup=${drag.onPointerUp}
                @pointercancel=${drag.onPointerCancel}
                class="drag-handle"
              >
                ≡
              </button>`
            : nothing}
          <div class="sortable-row-content">${opts.renderContent(item, idx)}</div>
          <div class="sortable-row-actions">
            ${movable && total > 1
              ? html`<button
                    type="button"
                    data-move-dir="prev"
                    aria-label=${t("action.move_up", { item: label }, opts.overlay)}
                    ?disabled=${idx === 0}
                    @click=${(ev) =>
                      triggerKeyboardMoveWithFocusRestore({
                        btnEl: ev.currentTarget,
                        listId: opts.id,
                        itemKey: key,
                        itemLabel: label,
                        preferredDir: "prev",
                        fromIndex: idx,
                        toIndex: idx - 1,
                        total,
                        overlay: opts.overlay,
                        onReorder: opts.onReorder,
                      })}
                    class="btn-icon"
                  >
                    ↑
                  </button>
                  <button
                    type="button"
                    data-move-dir="next"
                    aria-label=${t("action.move_down", { item: label }, opts.overlay)}
                    ?disabled=${idx === total - 1}
                    @click=${(ev) =>
                      triggerKeyboardMoveWithFocusRestore({
                        btnEl: ev.currentTarget,
                        listId: opts.id,
                        itemKey: key,
                        itemLabel: label,
                        preferredDir: "next",
                        fromIndex: idx,
                        toIndex: idx + 1,
                        total,
                        overlay: opts.overlay,
                        onReorder: opts.onReorder,
                      })}
                    class="btn-icon"
                  >
                    ↓
                  </button>`
              : nothing}
            ${opts.renderActions ? opts.renderActions(item, idx) : nothing}
          </div>
        </div>`;
      },
    )}
    <span data-sortable-live role="status" aria-live="polite" class="sr-only">${liveMsg}</span>
  </div>`;
}
function renderPillList(opts) {
  const enabledItems = opts.items.filter((it) => it.enabled);
  const disabledItems = opts.items.filter((it) => !it.enabled);
  const enabledCount = enabledItems.length;
  const canReorder = Boolean(opts.onReorder && enabledCount > 1);
  const liveMsg = SORTABLE_LIVE_STATUS.get(opts.id) || "";
  return html`<div
    id=${opts.id}
    data-sortable-list=${opts.id}
    role="group"
    aria-label=${opts.ariaLabel || nothing}
    class="pill-list"
  >
    ${repeat(
      enabledItems,
      (item) => item.token,
      (item, idx) => {
        const drag = opts.onReorder
          ? attachDragHandleHandlers({
              listId: opts.id,
              orientation: "horizontal",
              idx,
              total: enabledCount,
              itemLabel: item.label,
              overlay: opts.overlay,
              onReorder: opts.onReorder,
            })
          : null;
        return html`<span
          data-sortable-key=${item.token}
          data-sortable-index=${canReorder ? String(idx) : nothing}
          class="pill enabled"
        >
          ${canReorder && drag
            ? html`<button
                type="button"
                tabindex="-1"
                aria-hidden="true"
                title=${t("action.drag_reorder", { item: item.label }, opts.overlay)}
                @pointerdown=${drag.onPointerDown}
                @pointermove=${drag.onPointerMove}
                @pointerup=${drag.onPointerUp}
                @pointercancel=${drag.onPointerCancel}
                class="drag-handle"
              >
                ≡
              </button>`
            : nothing}
          ${canReorder && opts.onReorder
            ? html`<button
                type="button"
                data-move-dir="prev"
                aria-label=${t("action.move_earlier", { item: item.label }, opts.overlay)}
                ?disabled=${idx === 0}
                @click=${(ev) =>
                  triggerKeyboardMoveWithFocusRestore({
                    btnEl: ev.currentTarget,
                    listId: opts.id,
                    itemKey: item.token,
                    itemLabel: item.label,
                    preferredDir: "prev",
                    fromIndex: idx,
                    toIndex: idx - 1,
                    total: enabledCount,
                    overlay: opts.overlay,
                    onReorder: opts.onReorder,
                  })}
                class="pill-move"
              >
                ‹
              </button>`
            : nothing}
          <button
            type="button"
            aria-pressed="true"
            ?disabled=${Boolean(item.disabled)}
            @click=${() => opts.onToggle(item.token, false)}
            class="pill-toggle"
          >
            ${item.label}
          </button>
          ${canReorder && opts.onReorder
            ? html`<button
                type="button"
                data-move-dir="next"
                aria-label=${t("action.move_later", { item: item.label }, opts.overlay)}
                ?disabled=${idx === enabledCount - 1}
                @click=${(ev) =>
                  triggerKeyboardMoveWithFocusRestore({
                    btnEl: ev.currentTarget,
                    listId: opts.id,
                    itemKey: item.token,
                    itemLabel: item.label,
                    preferredDir: "next",
                    fromIndex: idx,
                    toIndex: idx + 1,
                    total: enabledCount,
                    overlay: opts.overlay,
                    onReorder: opts.onReorder,
                  })}
                class="pill-move"
              >
                ›
              </button>`
            : nothing}
        </span>`;
      },
    )}
    ${repeat(
      disabledItems,
      (item) => `off:${item.token}`,
      (item) => html`<span class="pill">
        <button
          type="button"
          aria-pressed="false"
          ?disabled=${Boolean(item.disabled)}
          @click=${() => opts.onToggle(item.token, true)}
          class="pill-toggle"
        >
          ${item.label}
        </button>
      </span>`,
    )}
    <span data-sortable-live role="status" aria-live="polite" class="sr-only">${liveMsg}</span>
  </div>`;
}
// ---------------------------------------------------------------------------
// Entity Slot Lists, Select Options, Icons, Table Sort Headers & Pref/Native Rows
// ---------------------------------------------------------------------------
function renderEntitySlotList(opts) {
  if (!opts.items.length) {
    return html`<div id=${opts.id} class="stack">
      <p class="empty-state">${opts.emptyStateText}</p>
    </div>`;
  }
  const renderSlotField = (val, idx) => html`<div
    class="stacked-field list-row-grow"
  >
    ${opts.slotLabel ? html`<span class="field-label">${opts.slotLabel(idx)}</span>` : nothing}
    ${opts.useCombobox
      ? renderEntityCombobox({
          id: `${opts.id}-combo-${idx}`,
          value: val,
          options: opts.choices,
          ariaLabel: opts.selectAriaLabel,
          emptyOptionLabel: opts.emptyOptionLabel,
          host: opts.host,
          onChange: (nextVal) => opts.onChange(idx, nextVal),
        })
      : html`<select
          aria-label=${opts.selectAriaLabel}
          .value=${val}
          @change=${(ev) =>
            opts.onChange(idx, (ev.currentTarget).value)}
        >
          ${renderSelectOptions(opts.choices, val, opts.emptyOptionLabel)}
        </select>`}
  </div>`;
  if (opts.onReorder) {
    return renderSortableList({
      id: opts.id,
      items: opts.items,
      getKey: (val) => (val ? `ent:${val}` : "empty"),
      getLabel: (val, idx) =>
        opts.slotLabel ? opts.slotLabel(idx) : val || `${opts.selectAriaLabel} ${idx + 1}`,
      onReorder: opts.onReorder,
      renderContent: (val, idx) => renderSlotField(val, idx),
      renderActions: (val, idx) => html`
        ${opts.extraActions ? opts.extraActions(val, idx) : nothing}
        ${renderTrashIconButton(opts.removeAriaLabel, () => opts.onRemove(idx))}
      `,
    });
  }
  return html`<div id=${opts.id} class="stack">
    ${opts.items.map(
      (val, idx) => html`<div class="list-row">
        ${renderSlotField(val, idx)}
        ${opts.extraActions ? opts.extraActions(val, idx) : nothing}
        ${renderTrashIconButton(opts.removeAriaLabel, () => opts.onRemove(idx))}
      </div>`,
    )}
  </div>`;
}
function renderSelectOptions(
  choices,
  selectedId,
  emptyOptionLabel = "None",
) {
  const cur = String(selectedId || "");
  const list = choices || [];
  const hasSelected = !cur || list.some((c) => c.id === cur);
  const out = [
    html`<option value="" ?selected=${cur === ""}>${emptyOptionLabel}</option>`,
  ];
  if (cur && !hasSelected) {
    out.push(html`<option value=${cur} selected>${cur} (missing)</option>`);
  }
  for (const item of list) {
    out.push(
      html`<option value=${item.id} ?selected=${item.id === cur}>${item.name || item.id}</option>`,
    );
  }
  return out;
}
function renderSvgIcon(pathD) {
  return html`<svg viewBox="0 0 24 24" aria-hidden="true"><path d=${pathD}></path></svg>`;
}
function renderTrashIconButton(ariaLabel, onRemove) {
  return html`<button
    type="button"
    aria-label=${ariaLabel}
    @click=${onRemove}
    class="btn-icon danger"
  >
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <path d="M9 3v1H4v2h1v13a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V6h1V4h-5V3H9m0 5h2v9H9V8m4 0h2v9h-2V8Z" />
    </svg>
  </button>`;
}
function renderSortHeader(
  store,
  field,
  label,
) {
  const isActive = store.deviceSortField === field;
  const ariaSort = isActive ? (store.deviceSortAsc ? "ascending" : "descending") : "none";
  const indicator = isActive ? (store.deviceSortAsc ? " ▲" : " ▼") : "";
  const onSort = () => {
    if (store.deviceSortField === field) {
      store.deviceSortAsc = !store.deviceSortAsc;
    } else {
      store.deviceSortField = field;
      store.deviceSortAsc = true;
    }
    store.host.requestUpdate();
  };
  return html`<th aria-sort=${ariaSort}>
    <button type="button" @click=${onSort} class="sort-btn">${label}<span aria-hidden="true">${indicator}</span></button>
  </th>`;
}
function getLocaleOverlay(store) {
  const stateAny = store.state;
  const overlay = stateAny?.locale_strings;
  return overlay && typeof overlay === "object"
    ? (overlay)
    : null;
}
function renderNativeControlRow(store, item) {
  const overlay = getLocaleOverlay(store);
  const prefKey = item.pref_key || "";
  const label = prefKey
    ? tPrefLabel(prefKey, entityLabel(item.name || item.entity_id), overlay)
    : entityLabel(item.name || item.entity_id);
  const dom = item.domain;
  const st = String(item.state ?? "");
  const unavailable = !prefKey && (st === "unavailable" || st === "unknown");
  if (dom === "switch") {
    const isOn = st === "on";
    const onToggle = (ev) => {
      const checked = (ev.currentTarget).checked;
      if (prefKey) {
        store.entity.stageDeviceSetting(prefKey, checked);
      } else {
        void store.entity.espAction(item.entity_id, checked ? "turn_on" : "turn_off", checked ? "on" : "off");
      }
    };
    return renderSettingsRow({
      label,
      control: html`<input
        type="checkbox"
        role="switch"
        aria-label=${label}
        ?disabled=${unavailable}
        .checked=${isOn}
        @change=${onToggle}
        class="switch"
      />`,
    });
  }
  if (dom === "select") {
    const opts = item.options || [];
    const onChange = (ev) => {
      const nextVal = (ev.currentTarget).value;
      if (prefKey) {
        store.entity.stageDeviceSetting(prefKey, nextVal);
      } else {
        void store.entity.espSelect(item.entity_id, nextVal);
      }
    };
    return renderSettingsRow({
      label,
      control: html`<select aria-label=${label} ?disabled=${unavailable} .value=${st} @change=${onChange}>
        ${opts.map(
          (opt) =>
            html`<option value=${opt} ?selected=${opt === st}>
              ${tPrefOption(prefKey, opt, overlay)}
            </option>`,
        )}
      </select>`,
    });
  }
  if (dom === "number") {
    const min = item.min ?? 0;
    const max = item.max ?? 100;
    const step = item.step ?? 1;
    const numVal = Number.isFinite(Number(st)) ? Number(st) : min;
    const commitNumber = (raw) => {
      if (prefKey) {
        store.entity.stageDeviceSetting(prefKey, raw);
      } else {
        void store.entity.espNumber(item.entity_id, raw);
      }
    };
    if (max - min <= 250 && item.mode !== "box") {
      return renderSettingsRow({
        label,
        control: renderRangeControl({
          ariaLabel: label,
          value: numVal,
          min,
          max,
          step,
          unit: item.unit,
          is24h: isDeviceTime24h(store),
          disabled: unavailable,
          hass: store.hass,
          onCommit: commitNumber,
        }),
      });
    }
    return renderSettingsRow({
      label,
      control: html`<input
          type="number"
          aria-label=${label}
          min=${String(min)}
          max=${String(max)}
          step=${String(step)}
          ?disabled=${unavailable}
          .value=${focusSafe(String(numVal))}
          @change=${(ev) => {
            const raw = Number((ev.currentTarget).value);
            if (Number.isFinite(raw)) commitNumber(raw);
          }}
        />
        ${item.unit ? html`<span class="help-text">${item.unit}</span>` : nothing}`,
    });
  }
  if (dom === "button") {
    const buttonUnavailable = st === "unavailable";
    const toastMsg = label.toLowerCase().includes("restart")
      ? t("sync.restarting_device", undefined, overlay)
      : t("sync.triggered_action", { label }, overlay);
    const onRun = () => {
      if (item.device_command) {
        void store.entity.runDeviceAction(item.device_command, toastMsg);
      } else {
        void store.entity.espAction(item.entity_id, "press", undefined, toastMsg);
      }
    };
    return renderSettingsRow({
      label,
      control: html`<button
        type="button"
        ?disabled=${buttonUnavailable}
        @click=${onRun}
        class="btn btn-secondary btn-compact"
      >
        ${t("action.run", undefined, overlay)}
      </button>`,
    });
  }
  if (dom === "update") {
    const hasUpdate = st === "on";
    return renderSettingsRow({
      label,
      control: html`<span class="chip ${hasUpdate ? "chip-warning" : ""}">${hasUpdate ? t("status.update", undefined, overlay) : t("status.up_to_date", undefined, overlay)}</span>
        ${hasUpdate
          ? html`<button
              type="button"
              @click=${() => void store.entity.espAction(item.entity_id, "install")}
              class="btn btn-primary btn-compact"
            >
              ${t("action.install", undefined, overlay)}
            </button>`
          : nothing}`,
    });
  }
  const displayVal = unavailable
    ? "—"
    : item.unit && Number.isFinite(Number(st))
      ? `${fmtNumber(Number(st), store.hass)} ${item.unit}`
      : st || "—";
  return html`<div class="kv-row">
    <span>${label}</span>
    <strong>${displayVal}</strong>
  </div>`;
}
function renderPrefControlRow(
  store,
  pref,
  labelOverride,
) {
  const overlay = getLocaleOverlay(store);
  const label =
    labelOverride || tPrefLabel(pref.key, pref.label || entityLabel(pref.key), overlay);
  const dom = pref.domain;
  const val = pref.value;
  if (dom === "switch") {
    const isOn = Boolean(val);
    const onToggle = (ev) => {
      const checked = (ev.currentTarget).checked;
      store.entity.stageDeviceSetting(pref.key, checked);
    };
    return renderSettingsRow({
      label,
      control: html`<input
        type="checkbox"
        role="switch"
        aria-label=${label}
        .checked=${isOn}
        @change=${onToggle}
        class="switch"
      />`,
    });
  }
  if (dom === "select") {
    const opts = pref.options || [];
    const st = String(val ?? "");
    const onChange = (ev) => {
      const nextVal = (ev.currentTarget).value;
      store.entity.stageDeviceSetting(pref.key, nextVal);
    };
    return renderSettingsRow({
      label,
      control: html`<select aria-label=${label} .value=${st} @change=${onChange}>
        ${opts.map(
          (opt) =>
            html`<option value=${opt} ?selected=${opt === st}>
              ${tPrefOption(pref.key, opt, overlay)}
            </option>`,
        )}
      </select>`,
    });
  }
  if (dom === "number") {
    const min = pref.min ?? 0;
    const max = pref.max ?? 100;
    const step = pref.step ?? 1;
    const numVal = Number.isFinite(Number(val)) ? Number(val) : min;
    if (pref.unit === ":00") {
      return renderHourSelectRow({
        label,
        ariaLabel: label,
        value: numVal,
        is24h: isDeviceTime24h(store),
        hass: store.hass,
        onCommit: (raw) => store.entity.stageDeviceSetting(pref.key, raw),
      });
    }
    if (max - min <= 250) {
      return renderSettingsRow({
        label,
        control: renderRangeControl({
          ariaLabel: label,
          value: numVal,
          min,
          max,
          step,
          unit: pref.unit,
          is24h: isDeviceTime24h(store),
          hass: store.hass,
          onCommit: (raw) => store.entity.stageDeviceSetting(pref.key, raw),
        }),
      });
    }
    return renderSettingsRow({
      label,
      control: html`<input
          type="number"
          aria-label=${label}
          min=${String(min)}
          max=${String(max)}
          step=${String(step)}
          .value=${focusSafe(String(numVal))}
          @change=${(ev) => {
            const raw = Number((ev.currentTarget).value);
            if (Number.isFinite(raw)) {
              store.entity.stageDeviceSetting(pref.key, raw);
            }
          }}
        />
        ${pref.unit ? html`<span class="help-text">${pref.unit}</span>` : nothing}`,
    });
  }
  return nothing;
}
const QUICK_ACTION_RANK = {
  find_my: 0,
  voice: 1,
  screensaver: 2,
  hibernate: 3,
  restart: 4,
  other: 5,
};
function quickActionKind(item) {
  const nameLow = (item.name || "").toLowerCase();
  const idTail = item.entity_id.includes(".")
    ? item.entity_id.split(".", 2)[1].toLowerCase()
    : item.entity_id.toLowerCase();
  if (
    item.device_class === "identify" ||
    nameLow.includes("find my") ||
    idTail.endsWith("find_my_device") ||
    idTail.includes("_find_my")
  ) {
    return "find_my";
  }
  if (
    item.device_class === "restart" ||
    nameLow.includes("restart") ||
    idTail.endsWith("_restart_device") ||
    idTail.endsWith("_restart")
  ) {
    return "restart";
  }
  if (nameLow.includes("screensaver") || idTail.includes("screensaver")) {
    return "screensaver";
  }
  if (nameLow.includes("hibernate") || idTail.includes("hibernate")) {
    return "hibernate";
  }
  if (
    nameLow.includes("voice") ||
    nameLow.includes("assist") ||
    idTail.includes("trigger_voice") ||
    idTail.includes("trigger_va")
  ) {
    return "voice";
  }
  return "other";
}
function renderQuickActionIcon(kind) {
  if (kind === "find_my") {
    return html`<svg viewBox="0 0 24 24" aria-hidden="true">
      <path
        d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2m0 18a8 8 0 1 1 8-8 8 8 0 0 1-8 8m0-14a6 6 0 1 0 6 6 6 6 0 0 0-6-6m0 10a4 4 0 1 1 4-4 4 4 0 0 1-4 4m0-6a2 2 0 1 0 2 2 2 2 0 0 0-2-2Z"
      />
    </svg>`;
  }
  if (kind === "voice") {
    return html`<svg viewBox="0 0 24 24" aria-hidden="true">
      <path
        d="M12 2a3 3 0 0 1 3 3v6a3 3 0 0 1-6 0V5a3 3 0 0 1 3-3m7 9c0 3.53-2.61 6.44-6 6.93V21h-2v-3.07c-3.39-.49-6-3.4-6-6.93h2a5 5 0 0 0 10 0h2Z"
      />
    </svg>`;
  }
  if (kind === "screensaver") {
    return html`<svg viewBox="0 0 24 24" aria-hidden="true">
      <path
        d="M20 3H4a2 2 0 0 0-2 2v11a2 2 0 0 0 2 2h6v2H7v2h10v-2h-3v-2h6a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2m0 13H4V5h16v11M11.2 6.8a3.8 3.8 0 1 0 2.4 6 3.5 3.5 0 0 1-2.4-6m5.3-.6.65 1.65 1.65.65-1.65.65-.65 1.65-.65-1.65-1.65-.65 1.65-.65.65-1.65Z"
      />
    </svg>`;
  }
  if (kind === "hibernate") {
    return html`<svg viewBox="0 0 24 24" aria-hidden="true">
      <path
        d="M16.56 5.44l-1.45 1.45A5.969 5.969 0 0 1 18 12a6 6 0 0 1-6 6 6 6 0 0 1-6-6c0-2.17 1.16-4.06 2.88-5.12L7.44 5.44A7.961 7.961 0 0 0 4 12a8 8 0 0 0 8 8 8 8 0 0 0 8-8c0-2.72-1.36-5.12-3.44-6.56M13 3h-2v10h2V3Z"
      />
    </svg>`;
  }
  if (kind === "restart") {
    return html`<svg viewBox="0 0 24 24" aria-hidden="true">
      <path
        d="M17.65 6.35A7.958 7.958 0 0 0 12 4c-4.42 0-7.99 3.58-7.99 8s3.57 8 7.99 8c3.73 0 6.84-2.55 7.73-6h-2.08A5.99 5.99 0 0 1 12 18c-3.31 0-6-2.69-6-6s2.69-6 6-6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35Z"
      />
    </svg>`;
  }
  return html`<svg viewBox="0 0 24 24" aria-hidden="true">
    <path d="M7 2h10l-3.5 7H17l-7 13v-8H6l1-12Z" />
  </svg>`;
}
function sortQuickActionButtons(
  items,
) {
  return [...items].sort((a, b) => {
    const ra = QUICK_ACTION_RANK[quickActionKind(a)];
    const rb = QUICK_ACTION_RANK[quickActionKind(b)];
    if (ra !== rb) return ra - rb;
    return `${a.name || ""} ${a.entity_id}`
      .toLowerCase()
      .localeCompare(`${b.name || ""} ${b.entity_id}`.toLowerCase());
  });
}
function renderQuickActionGrid(
  store,
  buttons,
  forceDisabled = false,
) {
  if (!buttons.length) return nothing;
  const overlay = getLocaleOverlay(store);
  const ordered = sortQuickActionButtons(buttons);
  return html`<div
    class="quick-action-grid"
    role="group"
    aria-label=${t("card.quick_actions", undefined, overlay)}
  >
    ${ordered.map((item) => {
      const kind = quickActionKind(item);
      const label = entityLabel(item.name || item.entity_id);
      const buttonUnavailable = forceDisabled || String(item.state ?? "") === "unavailable";
      const toastMsg =
        kind === "restart"
          ? t("sync.restarting_device", undefined, overlay)
          : kind === "hibernate"
            ? t("sync.hibernating_device", undefined, overlay)
            : t("sync.triggered_action", { label }, overlay);
      const onTrigger = () => {
        if (item.device_command) {
          void store.entity.runDeviceAction(item.device_command, toastMsg);
        } else {
          void store.entity.espAction(item.entity_id, "press", undefined, toastMsg);
        }
      };
      return html`<button
        type="button"
        data-entity-id=${item.entity_id}
        ?disabled=${buttonUnavailable}
        @click=${onTrigger}
        class="btn btn-secondary quick-action-btn"
      >
        ${renderQuickActionIcon(kind)}
        <span>${label}</span>
      </button>`;
    })}
  </div>`;
}
__latterExp(__exports, { isDeviceTime24h: () => isDeviceTime24h, resolveDescriptionId: () => resolveDescriptionId, renderCard: () => renderCard, renderSettingsRow: () => renderSettingsRow, renderSelectRow: () => renderSelectRow, renderSwitchRow: () => renderSwitchRow, renderRangeControl: () => renderRangeControl, renderRangeRow: () => renderRangeRow, renderHourSelectControl: () => renderHourSelectControl, renderHourSelectRow: () => renderHourSelectRow, syncDialogElement: () => syncDialogElement, renderConfirmDialog: () => renderConfirmDialog, resetComboboxState: () => resetComboboxState, matchComboboxOptions: () => matchComboboxOptions, renderEntityCombobox: () => renderEntityCombobox, renderSortableList: () => renderSortableList, renderPillList: () => renderPillList, renderEntitySlotList: () => renderEntitySlotList, renderSelectOptions: () => renderSelectOptions, renderSvgIcon: () => renderSvgIcon, renderTrashIconButton: () => renderTrashIconButton, renderSortHeader: () => renderSortHeader, renderNativeControlRow: () => renderNativeControlRow, renderPrefControlRow: () => renderPrefControlRow, sortQuickActionButtons: () => sortQuickActionButtons, renderQuickActionGrid: () => renderQuickActionGrid });
//# sourceURL=latter-studio/src/components/controls.ts
});
__latterDef("src/mdi-catalog.ts", (__exports, __req) => {
/**
 * Universal Shortcut Engine catalogs: domain action maps, route icon previews,
 * and firmware-verified Material Design Icons (`ui_mdi.cpp` 7,447-icon parity).
 */
const SHORTCUT_DOMAIN_ACTIONS
  = {
  light: [
    { action: "toggle", label: "Toggle" },
    { action: "turn_on", label: "Turn on" },
    { action: "turn_off", label: "Turn off" },
  ],
  switch: [
    { action: "toggle", label: "Toggle" },
    { action: "turn_on", label: "Turn on" },
    { action: "turn_off", label: "Turn off" },
  ],
  input_boolean: [
    { action: "toggle", label: "Toggle" },
    { action: "turn_on", label: "Turn on" },
    { action: "turn_off", label: "Turn off" },
  ],
  fan: [
    { action: "toggle", label: "Toggle" },
    { action: "turn_on", label: "Turn on" },
    { action: "turn_off", label: "Turn off" },
  ],
  cover: [
    { action: "toggle", label: "Toggle" },
    { action: "open_cover", label: "Open" },
    { action: "close_cover", label: "Close" },
    { action: "stop_cover", label: "Stop" },
  ],
  valve: [
    { action: "toggle", label: "Toggle" },
    { action: "open_valve", label: "Open" },
    { action: "close_valve", label: "Close" },
    { action: "stop_valve", label: "Stop" },
  ],
  scene: [{ action: "turn_on", label: "Activate" }],
  script: [
    { action: "turn_on", label: "Run" },
    { action: "turn_off", label: "Stop" },
  ],
  automation: [
    { action: "trigger", label: "Trigger" },
    { action: "toggle", label: "Toggle enable" },
    { action: "turn_on", label: "Enable" },
    { action: "turn_off", label: "Disable" },
  ],
  button: [{ action: "press", label: "Press" }],
  input_button: [{ action: "press", label: "Press" }],
  lock: [
    { action: "lock", label: "Lock" },
    { action: "unlock", label: "Unlock" },
    { action: "open", label: "Unlatch" },
  ],
  alarm_control_panel: [
    { action: "disarm", label: "Disarm" },
    { action: "arm_home", label: "Arm home" },
    { action: "arm_away", label: "Arm away" },
    { action: "arm_night", label: "Arm night" },
    { action: "arm_vacation", label: "Arm vacation" },
  ],
  vacuum: [
    { action: "start", label: "Start" },
    { action: "pause", label: "Pause" },
    { action: "return_to_base", label: "Return to base" },
    { action: "stop", label: "Stop" },
    { action: "clean_spot", label: "Spot clean" },
    { action: "locate", label: "Locate" },
  ],
  lawn_mower: [
    { action: "start_mowing", label: "Start mowing" },
    { action: "pause", label: "Pause" },
    { action: "dock", label: "Dock" },
  ],
  media_player: [
    { action: "media_play_pause", label: "Play / pause" },
    { action: "turn_on", label: "Turn on" },
    { action: "turn_off", label: "Turn off" },
    { action: "media_next_track", label: "Next track" },
  ],
  climate: [
    { action: "turn_on", label: "Turn on" },
    { action: "turn_off", label: "Turn off" },
  ],
  humidifier: [
    { action: "toggle", label: "Toggle" },
    { action: "turn_on", label: "Turn on" },
    { action: "turn_off", label: "Turn off" },
  ],
  siren: [
    { action: "turn_on", label: "Turn on" },
    { action: "turn_off", label: "Turn off" },
  ],
  water_heater: [
    { action: "turn_on", label: "Turn on" },
    { action: "turn_off", label: "Turn off" },
  ],
  select: [
    { action: "select_next", label: "Next option" },
    { action: "select_previous", label: "Previous option" },
  ],
  input_select: [
    { action: "select_next", label: "Next option" },
    { action: "select_previous", label: "Previous option" },
  ],
};
const SHORTCUT_DOMAIN_LABELS = {
  alarm_control_panel: "Security alarm",
  automation: "Automations",
  button: "Buttons",
  climate: "Climate",
  cover: "Covers & blinds",
  fan: "Fans",
  humidifier: "Humidifiers",
  input_boolean: "Input booleans",
  input_button: "Input buttons",
  input_select: "Input selects",
  lawn_mower: "Lawn mowers",
  light: "Lights",
  lock: "Locks",
  media_player: "Media players",
  scene: "Scenes",
  script: "Scripts",
  select: "Selects",
  siren: "Sirens",
  switch: "Switches",
  vacuum: "Vacuums",
  valve: "Valves",
  water_heater: "Water heaters",
};
function shortcutActionLabel(domain, action) {
  const list = SHORTCUT_DOMAIN_ACTIONS[domain] || [];
  const found = list.find((it) => it.action === action);
  return found ? found.label : action;
}
const ROUTE_PREVIEW_ICONS = {
  "app:pinned": "mdi:pin",
  "app:music": "mdi:music",
  "music:speakers": "mdi:speaker-multiple",
  "music:library": "mdi:music-box-outline",
  "music:favorites": "mdi:heart",
  "music:playlists": "mdi:playlist-music",
  "music:queue": "mdi:playlist-play",
  "music:album_tracks": "mdi:album",
  "music:lyrics": "mdi:script-text",
  "music:info": "mdi:information-outline",
  "app:home_hub": "mdi:home",
  "home_hub:alarm": "mdi:shield-home",
  "home_hub:cameras": "mdi:cctv",
  "home_hub:intercom": "mdi:phone-in-talk",
  "home_hub:thermostat": "mdi:thermostat",
  "home_hub:entry": "mdi:lock",
  "home_hub:vacuum": "mdi:robot-vacuum",
  "app:area": "mdi:sofa",
  "area:picker": "mdi:floor-plan",
  "area:scene": "mdi:shimmer",
  "area:light": "mdi:lightbulb",
  "area:cover": "mdi:blinds-horizontal",
  "area:climate": "mdi:thermometer",
  "area:fan": "mdi:ceiling-fan",
  "area:switch": "mdi:toggle-switch",
  "area:media": "mdi:television-speaker",
  "area:all": "mdi:view-grid",
  "app:remote": "mdi:remote-tv",
  "remote:devices": "mdi:remote",
  "app:weather": "mdi:weather-partly-cloudy",
  "weather:current": "mdi:weather-partly-cloudy",
  "weather:forecast": "mdi:calendar-week",
  "weather:sun": "mdi:white-balance-sunny",
  "weather:moon": "mdi:moon-waning-crescent",
  "app:time": "mdi:clock-outline",
  "time:clock": "mdi:clock-outline",
  "time:timers": "mdi:timer-sand",
  "time:alarms": "mdi:alarm",
  "time:stopwatch": "mdi:timer-outline",
  "app:clock": "mdi:clock-outline",
  "app:calendar": "mdi:calendar",
  "calendar:overview": "mdi:calendar-text",
  "calendar:day": "mdi:calendar-today",
  "calendar:week": "mdi:calendar-week",
  "calendar:month": "mdi:calendar-month",
  "app:tools": "mdi:apps",
  "tools:stopwatch": "mdi:timer-outline",
  "tools:level": "mdi:spirit-level",
  "tools:flashlight": "mdi:flashlight",
  "tools:calculator": "mdi:calculator-variant",
  "tools:dice": "mdi:dice-5",
  "tools:coin_flip": "mdi:alpha-c-circle",
  "app:games": "mdi:gamepad-variant",
  "games:marbles": "mdi:billiards",
  "games:archery": "mdi:bullseye-arrow",
  "games:bricks": "mdi:wall",
  "games:chomp": "mdi:pac-man",
  "games:2048": "mdi:numeric-2-box-multiple",
  "games:memory": "mdi:cards",
  "settings:root": "mdi:cog",
  "settings:display": "mdi:brightness-6",
  "settings:sleep": "mdi:power-sleep",
  "settings:sound": "mdi:volume-high",
  "settings:voice": "mdi:microphone",
  "settings:music": "mdi:music-box-outline",
  "settings:home": "mdi:home-outline",
  "settings:actions": "mdi:gesture-tap-button",
  "settings:update": "mdi:cellphone-arrow-down",
  "settings:info": "mdi:information-outline",
};
const MDI_SLUG_PATTERN = /^mdi:[a-z0-9]+(?:-[a-z0-9]+)*$/;
const BARE_MDI_SLUG_PATTERN = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;
function normalizeMdiIconSlug(raw) {
  let clean = String(raw ?? "").trim().toLowerCase().replace(/_/g, "-");
  if (!clean) return "";
  if (clean.startsWith("mdi-")) {
    clean = `mdi:${clean.slice(4)}`;
  } else if (!clean.startsWith("mdi:") && BARE_MDI_SLUG_PATTERN.test(clean)) {
    clean = `mdi:${clean}`;
  }
  return MDI_SLUG_PATTERN.test(clean) ? clean : "";
}
const CURATED_MDI_ICONS = [
  "mdi:pin",
  "mdi:pin-outline",
  "mdi:bell-ring",
  "mdi:bell",
  "mdi:bell-alert",
  "mdi:bullhorn",
  "mdi:lifebuoy",
  "mdi:alert-circle",
  "mdi:hand-wave",
  "mdi:baby-carriage",
  "mdi:baby-bottle-outline",
  "mdi:baby-face-outline",
  "mdi:cradle-outline",
  "mdi:human-male-female-child",
  "mdi:account-heart",
  "mdi:heart",
  "mdi:medical-bag",
  "mdi:phone-in-talk",
  "mdi:message-alert",
  "mdi:flash",
  "mdi:lightning-bolt",
  "mdi:star",
  "mdi:shimmer",
  "mdi:magic-staff",
  "mdi:check-circle",
  "mdi:lightbulb",
  "mdi:lightbulb-on",
  "mdi:lightbulb-outline",
  "mdi:lightbulb-group",
  "mdi:lamp",
  "mdi:desk-lamp",
  "mdi:floor-lamp",
  "mdi:ceiling-light",
  "mdi:chandelier",
  "mdi:coach-lamp",
  "mdi:outdoor-lamp",
  "mdi:wall-sconce",
  "mdi:led-strip-variant",
  "mdi:string-lights",
  "mdi:track-light",
  "mdi:lava-lamp",
  "mdi:candle",
  "mdi:fireplace",
  "mdi:brightness-6",
  "mdi:creation",
  "mdi:palette",
  "mdi:toggle-switch",
  "mdi:toggle-switch-off-outline",
  "mdi:power",
  "mdi:power-plug",
  "mdi:power-socket-us",
  "mdi:power-socket-eu",
  "mdi:light-switch",
  "mdi:battery-charging",
  "mdi:solar-power",
  "mdi:ev-station",
  "mdi:car-electric",
  "mdi:blinds-horizontal",
  "mdi:blinds-horizontal-closed",
  "mdi:blinds-open",
  "mdi:blinds-vertical",
  "mdi:curtains",
  "mdi:curtains-closed",
  "mdi:roller-shade",
  "mdi:roller-shade-closed",
  "mdi:window-shutter",
  "mdi:window-shutter-open",
  "mdi:window-open-variant",
  "mdi:window-closed-variant",
  "mdi:garage",
  "mdi:garage-open",
  "mdi:garage-variant",
  "mdi:garage-open-variant",
  "mdi:gate",
  "mdi:gate-open",
  "mdi:door",
  "mdi:door-open",
  "mdi:door-closed",
  "mdi:door-sliding",
  "mdi:awning-outline",
  "mdi:lock",
  "mdi:lock-open",
  "mdi:lock-smart",
  "mdi:key-variant",
  "mdi:shield-home",
  "mdi:shield-lock",
  "mdi:shield-check",
  "mdi:shield-moon",
  "mdi:shield-airplane",
  "mdi:security",
  "mdi:alarm-light",
  "mdi:cctv",
  "mdi:video",
  "mdi:webcam",
  "mdi:doorbell-video",
  "mdi:motion-sensor",
  "mdi:smoke-detector-variant",
  "mdi:thermostat",
  "mdi:thermometer",
  "mdi:fire",
  "mdi:snowflake",
  "mdi:sun-snowflake-variant",
  "mdi:fan",
  "mdi:ceiling-fan",
  "mdi:air-purifier",
  "mdi:air-humidifier",
  "mdi:water-percent",
  "mdi:water-boiler",
  "mdi:water",
  "mdi:water-pump",
  "mdi:pipe-valve",
  "mdi:sprinkler-variant",
  "mdi:faucet",
  "mdi:radiator",
  "mdi:hvac",
  "mdi:robot-vacuum",
  "mdi:robot-mower",
  "mdi:washing-machine",
  "mdi:tumble-dryer",
  "mdi:dishwasher",
  "mdi:fridge-outline",
  "mdi:stove",
  "mdi:coffee-maker",
  "mdi:kettle-steam",
  "mdi:music",
  "mdi:music-note",
  "mdi:playlist-music",
  "mdi:playlist-play",
  "mdi:radio",
  "mdi:podcast",
  "mdi:speaker",
  "mdi:speaker-multiple",
  "mdi:cast-audio",
  "mdi:television",
  "mdi:television-speaker",
  "mdi:remote",
  "mdi:remote-tv",
  "mdi:play-pause",
  "mdi:play",
  "mdi:pause",
  "mdi:skip-next",
  "mdi:volume-high",
  "mdi:volume-mute",
  "mdi:movie-open",
  "mdi:gamepad-variant",
  "mdi:headphones",
  "mdi:script-text-play",
  "mdi:script-text",
  "mdi:robot",
  "mdi:gesture-tap-button",
  "mdi:cog",
  "mdi:cog-play",
  "mdi:autorenew",
  "mdi:timer-play",
  "mdi:weather-night",
  "mdi:sleep",
  "mdi:bed",
  "mdi:coffee",
  "mdi:silverware-fork-knife",
  "mdi:party-popper",
  "mdi:airplane",
  "mdi:home-export-outline",
  "mdi:home-import-outline",
  "mdi:briefcase",
  "mdi:laptop",
  "mdi:book-open-variant",
  "mdi:meditation",
  "mdi:dumbbell",
  "mdi:home",
  "mdi:home-outline",
  "mdi:sofa",
  "mdi:bed-king-outline",
  "mdi:desk",
  "mdi:countertop-outline",
  "mdi:shower-head",
  "mdi:bathtub-outline",
  "mdi:stairs",
  "mdi:balcony",
  "mdi:flower",
  "mdi:tree",
  "mdi:pine-tree",
  "mdi:pool",
  "mdi:grill",
  "mdi:car",
  "mdi:bicycle",
  "mdi:dog",
  "mdi:cat",
  "mdi:paw",
  "mdi:weather-sunny",
  "mdi:weather-partly-cloudy",
  "mdi:weather-cloudy",
  "mdi:weather-rainy",
  "mdi:weather-pouring",
  "mdi:weather-snowy",
  "mdi:weather-lightning",
  "mdi:weather-windy",
  "mdi:white-balance-sunny",
  "mdi:moon-waning-crescent",
  "mdi:moon-full",
  "mdi:clock-outline",
  "mdi:alarm",
  "mdi:timer-sand",
  "mdi:timer-outline",
  "mdi:calendar",
  "mdi:calculator-variant",
  "mdi:flashlight",
  "mdi:spirit-level",
  "mdi:dice-5",
  "mdi:compass-outline",
  "mdi:map-marker",
  "mdi:apps",
  "mdi:view-grid",
  "mdi:form-select",
];
const MDI_TOTAL_ICON_COUNT = 7447;
// Front-coded Pictogrammers @mdi/js v7.4.47 catalog (exact 1:1 parity with firmware ui_mdi.cpp).
const PACKED_MDI_CHUNKS = [];
// Replaced at bundle build time with `./latter-studio-mdi.js?v=<sha256-16>` while PACKED_MDI_CHUNKS
// stays intact in TypeScript source for cross-repo 7,447-icon firmware parity verification.
const MDI_LAZY_CHUNK_URL = "./latter-studio-mdi.js?v=90a37292b019b68b";
let activePackedMdiChunks = PACKED_MDI_CHUNKS;
let cachedAllMdiIcons = null;
let cachedAllMdiSet = null;
let curatedFallbackSet = null;
let mdiLoadPromise = null;
function unpackMdiChunks(chunks) {
  const out = [];
  let prev = "";
  for (const chunk of chunks) {
    for (const token of chunk.split("|")) {
      if (!token) continue;
      const shared = parseInt(token[0], 36);
      const slug = prev.slice(0, shared) + token.slice(1);
      prev = slug;
      out.push(`mdi:${slug}`);
    }
  }
  return out;
}
function isMdiCatalogLoaded() {
  return activePackedMdiChunks.length > 0;
}
function registerPackedMdiChunks(chunks) {
  if (!Array.isArray(chunks) || chunks.length === 0) return;
  activePackedMdiChunks = chunks;
  cachedAllMdiIcons = null;
  cachedAllMdiSet = null;
}
function ensureMdiCatalogLoaded() {
  if (activePackedMdiChunks.length > 0) {
    return Promise.resolve();
  }
  if (mdiLoadPromise) {
    return mdiLoadPromise;
  }
  mdiLoadPromise = import(MDI_LAZY_CHUNK_URL)
    .then((mod) => {
      if (mod && Array.isArray(mod.PACKED_MDI_CHUNKS)) {
        registerPackedMdiChunks(mod.PACKED_MDI_CHUNKS);
      }
    })
    .catch((err) => {
      mdiLoadPromise = null;
      throw err;
    });
  return mdiLoadPromise;
}
function getAllMdiIcons() {
  if (activePackedMdiChunks.length === 0) {
    return CURATED_MDI_ICONS;
  }
  if (cachedAllMdiIcons !== null) {
    return cachedAllMdiIcons;
  }
  cachedAllMdiIcons = unpackMdiChunks(activePackedMdiChunks);
  return cachedAllMdiIcons;
}
function isKnownMdiIcon(icon) {
  const norm = normalizeMdiIconSlug(icon);
  if (!norm) return false;
  if (activePackedMdiChunks.length === 0) {
    if (curatedFallbackSet === null) {
      curatedFallbackSet = new Set([
        ...CURATED_MDI_ICONS,
        ...Object.values(ROUTE_PREVIEW_ICONS),
      ]);
    }
    return curatedFallbackSet.has(norm);
  }
  if (cachedAllMdiSet === null) {
    cachedAllMdiSet = new Set(getAllMdiIcons());
  }
  return cachedAllMdiSet.has(norm);
}
function searchMdiIcons(
  rawQuery,
  limit = 120,
) {
  const cleaned = String(rawQuery || "")
    .trim()
    .toLowerCase()
    .replace(/^mdi[-:]/, "")
    .replace(/[_\s]+/g, "-");
  const tokens = cleaned.split("-").filter(Boolean);
  if (tokens.length === 0) {
    return {
      items: CURATED_MDI_ICONS.slice(0, limit),
      totalMatches: MDI_TOTAL_ICON_COUNT,
    };
  }
  const exactNeedle = tokens.join("-");
  const ranked = [];
  for (const fullSlug of getAllMdiIcons()) {
    const name = fullSlug.slice(4);
    let allFound = true;
    for (const tok of tokens) {
      if (!name.includes(tok)) {
        allFound = false;
        break;
      }
    }
    if (!allFound) continue;
    let rank = 3;
    if (name === exactNeedle) {
      rank = 0;
    } else if (name.startsWith(exactNeedle)) {
      rank = 1;
    } else if (name.includes(`-${tokens[0]}`) || name.startsWith(tokens[0])) {
      rank = 2;
    }
    ranked.push({ slug: fullSlug, rank });
  }
  ranked.sort((a, b) => a.rank - b.rank || a.slug.localeCompare(b.slug));
  return {
    items: ranked.slice(0, limit).map((r) => r.slug),
    totalMatches: ranked.length,
  };
}
__latterExp(__exports, { SHORTCUT_DOMAIN_ACTIONS: () => SHORTCUT_DOMAIN_ACTIONS, SHORTCUT_DOMAIN_LABELS: () => SHORTCUT_DOMAIN_LABELS, shortcutActionLabel: () => shortcutActionLabel, ROUTE_PREVIEW_ICONS: () => ROUTE_PREVIEW_ICONS, normalizeMdiIconSlug: () => normalizeMdiIconSlug, CURATED_MDI_ICONS: () => CURATED_MDI_ICONS, MDI_TOTAL_ICON_COUNT: () => MDI_TOTAL_ICON_COUNT, isMdiCatalogLoaded: () => isMdiCatalogLoaded, registerPackedMdiChunks: () => registerPackedMdiChunks, ensureMdiCatalogLoaded: () => ensureMdiCatalogLoaded, getAllMdiIcons: () => getAllMdiIcons, isKnownMdiIcon: () => isKnownMdiIcon, searchMdiIcons: () => searchMdiIcons });
//# sourceURL=latter-studio/src/mdi-catalog.ts
});
__latterDef("src/api/ws-client.ts", (__exports, __req) => {
const { MAX_WALLPAPER_UPLOAD_BYTES } = __req("src/constants.ts");
const { DEVICE_WS_COMMANDS, STUDIO_REV, SYSTEM_WS_COMMANDS } = __req("src/protocol-schema.ts");
/**
 * Admin-gated WebSocket & Bearer-authenticated XHR multipart client for Latter Studio (`D-025`, `D-065`).
 * - Sends mandatory `studio_rev: STUDIO_REV` (`34`) on all 9 WS endpoints
 * - Enforces literal-union & runtime `SYSTEM_WS_COMMANDS` / `DEVICE_WS_COMMANDS` checks (`A-25`)
 * - Applies per-command `Promise.race` timeouts (`15_000 ms` standard, `60_000 ms` import/reset/update) (`B-15`)
 * - Supports on-demand 600 s `mint_camera_preview_url`, Discovered `ignore`/`unignore`, & `expected_config_rev`
 */
const WS_STANDARD_TIMEOUT_MS = 15_000;
const WS_LONG_TIMEOUT_MS = 60_000;
function isStudioRevMismatchError(err) {
  if (!err || typeof err !== "object") return false;
  const code = String((err).code || "");
  return code === "studio_rev_mismatch" || code === "version_mismatch";
}
function isConflictError(err) {
  if (!err || typeof err !== "object") return false;
  return String((err).code || "") === "conflict";
}
function formatWsError(err, fallback = "Action failed") {
  if (!err) return fallback;
  if (typeof err === "string") return err;
  if (typeof err === "object" && "message" in err && (err).message) {
    return String((err).message);
  }
  return fallback;
}
function withWsTimeout (promise, timeoutMs) {
  let timer = null;
  const timeoutPromise = new Promise ((_resolve, reject) => {
    timer = setTimeout(() => {
      reject(
        new Error(
          "Request timed out — check your Home Assistant connection and try again.",
        ),
      );
    }, timeoutMs);
  });
  return Promise.race([promise, timeoutPromise]).finally(() => {
    if (timer !== null) {
      clearTimeout(timer);
    }
  });
}
class StudioWsClient {
          hassRef = null;
                   onRevMismatch;
  constructor(onRevMismatch) {
    this.onRevMismatch = onRevMismatch;
  }
  setHass(hass) {
    this.hassRef = hass;
  }
  get hass() {
    return this.hassRef;
  }
          requireHass() {
    if (!this.hassRef) {
      throw new Error("Home Assistant connection is not ready");
    }
    return this.hassRef;
  }
          async callWS (
    msg,
    timeoutMs = WS_STANDARD_TIMEOUT_MS,
  ) {
    const hass = this.requireHass();
    try {
      return await withWsTimeout(hass.callWS (msg), timeoutMs);
    } catch (err) {
      if (isStudioRevMismatchError(err)) {
        this.onRevMismatch();
      }
      throw err;
    }
  }
  async getState(options
   ) {
    return this.callWS ({
      type: "latter/system/get_state",
      subentry_id: options.subentryId || null,
      include_logs: Boolean(options.includeLogs),
      studio_rev: STUDIO_REV,
    });
  }
  async subscribe(
    options
     ,
    onEvent,
  ) {
    const hass = this.requireHass();
    if (!hass.connection) {
      throw new Error("Home Assistant WebSocket connection is unavailable");
    }
    try {
      const msg = {
        type: "latter/system/subscribe",
        subentry_id: options.subentryId || null,
        include_logs: Boolean(options.includeLogs),
        studio_rev: STUDIO_REV,
      };
      if (options.surveySubentryId) {
        msg.survey_subentry_id = options.surveySubentryId;
      }
      return await withWsTimeout(
        hass.connection.subscribeMessage(onEvent, msg),
        WS_STANDARD_TIMEOUT_MS,
      );
    } catch (err) {
      if (isStudioRevMismatchError(err)) {
        this.onRevMismatch();
      }
      throw err;
    }
  }
  async runSystemCommand(
    cmd,
    payload = {},
    selectedSubentryId,
  ) {
    if (!SYSTEM_WS_COMMANDS.has(cmd)) {
      throw new Error(`Unknown System command: ${cmd}`);
    }
    const timeoutMs =
      cmd === "check_system_updates" ? WS_LONG_TIMEOUT_MS : WS_STANDARD_TIMEOUT_MS;
    return this.callWS (
      {
        type: "latter/system/command",
        command: cmd,
        subentry_id: selectedSubentryId || null,
        payload,
        studio_rev: STUDIO_REV,
      },
      timeoutMs,
    );
  }
  async mintCameraPreviewUrl(cameraEntity) {
    if (!SYSTEM_WS_COMMANDS.has("mint_camera_preview_url")) {
      throw new Error("mint_camera_preview_url is not registered in Studio protocol contract");
    }
    return this.callWS ({
      type: "latter/system/command",
      command: "mint_camera_preview_url",
      subentry_id: null,
      payload: { camera_entity: cameraEntity },
      studio_rev: STUDIO_REV,
    });
  }
  async runDeviceCommand(
    subentryId,
    cmd,
    payload = {},
  ) {
    if (!DEVICE_WS_COMMANDS.has(cmd)) {
      throw new Error(`Unknown Device command: ${cmd}`);
    }
    if (!subentryId) {
      throw new Error("Choose a Device first");
    }
    return this.callWS ({
      type: "latter/device/command",
      command: cmd,
      subentry_id: subentryId,
      payload,
      studio_rev: STUDIO_REV,
    });
  }
  async exportBackup(
    scope,
    subentryId,
  ) {
    if (scope === "device") {
      if (!subentryId) throw new Error("Choose a Device to export");
      return this.callWS ({
        type: "latter/device/export",
        subentry_id: subentryId,
        studio_rev: STUDIO_REV,
      });
    }
    return this.callWS ({
      type: "latter/system/export",
      studio_rev: STUDIO_REV,
    });
  }
  async importBackup(options
   ) {
    if (options.scope === "device") {
      if (!options.targetSubentryId) {
        throw new Error("Choose the Device to restore this backup onto");
      }
      return this.callWS (
        {
          type: "latter/device/import",
          subentry_id: options.targetSubentryId,
          bundle: options.bundle,
          studio_rev: STUDIO_REV,
        },
        WS_LONG_TIMEOUT_MS,
      );
    }
    return this.callWS (
      {
        type: "latter/system/import",
        subentry_id: options.selectedSubentryId || null,
        bundle: options.bundle,
        studio_rev: STUDIO_REV,
      },
      WS_LONG_TIMEOUT_MS,
    );
  }
  async resetDevice(options
   ) {
    return this.callWS (
      {
        type: "latter/device/reset",
        subentry_id: options.subentryId,
        device_settings: options.deviceSettings,
        latter_options: options.latterOptions,
        studio_rev: STUDIO_REV,
      },
      WS_LONG_TIMEOUT_MS,
    );
  }
  async signHaPath(path, expires = 300) {
    const signed = await this.callWS ({
      type: "auth/sign_path",
      path,
      expires,
    });
    if (!signed || !signed.path) {
      throw new Error("Could not sign Home Assistant path");
    }
    return signed.path;
  }
          async getAccessToken(forceRefresh = false) {
    const hass = this.requireHass();
    const auth = hass.auth;
    if (!auth) {
      throw new Error("Home Assistant authentication session is not ready");
    }
    if ((forceRefresh || auth.expired) && typeof auth.refreshAccessToken === "function") {
      await auth.refreshAccessToken();
    }
    const token = auth.data?.access_token;
    if (!token) {
      throw new Error("Home Assistant access token is unavailable");
    }
    return token;
  }
  async uploadWallpaperMultipart(options
   ) {
    if (!options.file) {
      throw new Error("Choose an image file first");
    }
    if (options.file.size > MAX_WALLPAPER_UPLOAD_BYTES) {
      throw new Error("Wallpaper image must be 15 MB or smaller");
    }
    if (options.scope === "device" && !options.subentryId) {
      throw new Error("Choose a Device before uploading a Device wallpaper");
    }
    const UPLOAD_PATH = "/api/latter/wallpaper/upload";
    const form = new FormData();
    form.append("file", options.file, options.file.name || "wallpaper.jpg");
    form.append("scope", options.scope);
    if (options.subentryId) {
      form.append("subentry_id", options.subentryId);
    }
    const sendOnce = (bearerToken) =>
      new Promise ((resolve, reject) => {
        const xhr = new XMLHttpRequest();
        xhr.open("POST", UPLOAD_PATH, true);
        xhr.setRequestHeader("Authorization", `Bearer ${bearerToken}`);
        xhr.responseType = "json";
        xhr.timeout = WS_LONG_TIMEOUT_MS;
        if (xhr.upload && options.onProgress) {
          xhr.upload.onprogress = (ev) => {
            if (ev.lengthComputable && ev.total > 0) {
              options.onProgress?.(Math.min(100, Math.round((ev.loaded / ev.total) * 100)));
            }
          };
        }
        xhr.onload = () => {
          const body =
            xhr.response && typeof xhr.response === "object"
              ? (xhr.response)
              : null;
          resolve({ status: xhr.status, body });
        };
        xhr.onerror = () => {
          reject(new Error("Network error while uploading wallpaper"));
        };
        xhr.ontimeout = () => {
          reject(new Error("Wallpaper upload timed out"));
        };
        xhr.onabort = () => {
          reject(new Error("Wallpaper upload was canceled"));
        };
        xhr.send(form);
      });
    let token = await this.getAccessToken(false);
    let response = await sendOnce(token);
    if (
      response.status === 401 &&
      typeof this.hassRef?.auth?.refreshAccessToken === "function"
    ) {
      token = await this.getAccessToken(true);
      response = await sendOnce(token);
    }
    const { status, body } = response;
    if (status >= 200 && status < 300) {
      options.onProgress?.(100);
      return {
        ok: true,
        filename: body?.filename ? String(body.filename) : undefined,
        source_id: body?.source_id ? String(body.source_id) : undefined,
        wallpapers: Array.isArray(body?.wallpapers) ? (body.wallpapers) : undefined,
        system_wallpapers: Array.isArray(body?.system_wallpapers)
          ? (body.system_wallpapers)
          : undefined,
      };
    }
    const errMsg = body?.error
      ? String(body.error)
      : body?.message
        ? String(body.message)
        : `Wallpaper upload failed (HTTP ${status})`;
    throw new Error(errMsg);
  }
}
__latterExp(__exports, { DEVICE_WS_COMMANDS: () => DEVICE_WS_COMMANDS, SYSTEM_WS_COMMANDS: () => SYSTEM_WS_COMMANDS, WS_STANDARD_TIMEOUT_MS: () => WS_STANDARD_TIMEOUT_MS, WS_LONG_TIMEOUT_MS: () => WS_LONG_TIMEOUT_MS, isStudioRevMismatchError: () => isStudioRevMismatchError, isConflictError: () => isConflictError, formatWsError: () => formatWsError, StudioWsClient: () => StudioWsClient });
//# sourceURL=latter-studio/src/api/ws-client.ts
});
__latterDef("src/state/shortcuts-lists-ops.ts", (__exports, __req) => {
const { ACTIVITY_SOURCES_CATALOG, AREA_CATEGORIES_CATALOG, DEFAULT_ACTIVITY_SOURCES_TOKENS, DEFAULT_AREA_CATEGORIES_TOKENS, DEFAULT_DOCK_ROUTES_TOKENS, DEFAULT_GAMES_ITEMS_TOKENS, DEFAULT_HOME_CATEGORIES_TOKENS, DEFAULT_TOOLS_ITEMS_TOKENS, GAMES_ITEMS_CATALOG, HOME_CATEGORIES_CATALOG, MAX_DOCK_ITEMS, MAX_PINNED_ITEMS, NATIVE_DOCK_APP_TOKENS, SHORTCUT_LABEL_MAX, SHORTCUT_ROUTES_CATALOG, TOOLS_ITEMS_CATALOG } = __req("src/constants.ts");
const { ensureMdiCatalogLoaded, isKnownMdiIcon, normalizeMdiIconSlug, SHORTCUT_DOMAIN_ACTIONS } = __req("src/mdi-catalog.ts");
/**
 * Unified trait-driven catalog gate, shared `createTokenListOps` CSV pill factory (`A-14`),
 * shortcut normalization & modal helpers, and System string-list / remote / volume list editors.
 */
/**
 * Single canonical trait-driven capability gate (`A-14`).
 * Never hides or rejects items when `caps` or an individual trait is `undefined` (unknown).
 */
function isCatalogItemSupported(
  item,
  caps,
) {
  const cap = item.capability;
  if (!cap || !caps) return true;
  switch (cap) {
    case "round":
      return caps.is_round !== false;
    case "imu":
      return caps.has_imu !== false;
    case "display_imu":
      return caps.has_display !== false && caps.has_imu !== false;
    case "display":
      return caps.has_display !== false;
    case "battery":
      return caps.has_battery !== false;
    case "display_battery":
      return caps.has_display !== false && caps.has_battery !== false;
    case "beacon_battery":
      return caps.has_ble_beacon !== false && caps.has_battery !== false;
    case "mic":
      return caps.has_voice !== false;
    case "speaker":
      return caps.has_audio !== false;
    default:
      return true;
  }
}
const TOKEN_LIST_SPECS = {
  area_categories: {
    key: "area_categories",
    catalog: AREA_CATEGORIES_CATALOG,
    defaultTokens: DEFAULT_AREA_CATEGORIES_TOKENS,
    minRequired: 1,
    noun: "Area category",
    allowEmpty: false,
    checkPrefFallback: false,
  },
  home_categories: {
    key: "home_categories",
    catalog: HOME_CATEGORIES_CATALOG,
    defaultTokens: DEFAULT_HOME_CATEGORIES_TOKENS,
    minRequired: 1,
    noun: "Home category",
    allowEmpty: false,
    checkPrefFallback: false,
  },
  tools_items: {
    key: "tools_items",
    catalog: TOOLS_ITEMS_CATALOG,
    defaultTokens: DEFAULT_TOOLS_ITEMS_TOKENS,
    minRequired: 1,
    noun: "tool",
    allowEmpty: false,
    checkPrefFallback: true,
  },
  games_items: {
    key: "games_items",
    catalog: GAMES_ITEMS_CATALOG,
    defaultTokens: DEFAULT_GAMES_ITEMS_TOKENS,
    minRequired: 1,
    noun: "game",
    allowEmpty: false,
    checkPrefFallback: true,
  },
  activity_sources: {
    key: "activity_sources",
    catalog: ACTIVITY_SOURCES_CATALOG,
    defaultTokens: DEFAULT_ACTIVITY_SOURCES_TOKENS,
    minRequired: 0,
    noun: "source",
    allowEmpty: true,
    checkPrefFallback: false,
  },
};
function createTokenListOps(store, spec) {
  const knownByToken = new Map(spec.catalog.map((c) => [c.token, c]));
  const isTokenSupportedOnActive = (token) => {
    const item = knownByToken.get(token);
    return item ? isCatalogItemSupported(item, store.state?.capabilities) : false;
  };
  const getEnabled = () => {
    const cfgVal = store.state?.config?.[spec.key];
    const prefVal = spec.checkPrefFallback ? store.entity.getPref(spec.key)?.value : undefined;
    const raw = cfgVal ?? prefVal;
    if (raw === undefined || raw === null) {
      return [...spec.defaultTokens];
    }
    const rawStr = String(raw);
    if (!rawStr.trim()) {
      return spec.allowEmpty ? [] : [...spec.defaultTokens];
    }
    const parsed = rawStr
      .split(",")
      .map((s) => s.trim().toLowerCase())
      .filter((s, i, arr) => Boolean(s) && knownByToken.has(s) && arr.indexOf(s) === i);
    if (parsed.length === 0 && !spec.allowEmpty) {
      return [...spec.defaultTokens];
    }
    return parsed;
  };
  const toggle = (rawToken, forceEnabled) => {
    const token = String(rawToken || "").trim().toLowerCase();
    if (!knownByToken.has(token)) return;
    const current = getEnabled();
    const idx = current.indexOf(token);
    const currentlyOn = idx >= 0;
    const wantOn = forceEnabled !== undefined ? Boolean(forceEnabled) : !currentlyOn;
    if (wantOn === currentlyOn) return;
    if (!wantOn) {
      if (spec.minRequired > 0) {
        const visibleEnabled = current.filter((t) => isTokenSupportedOnActive(t));
        if (
          current.length <= spec.minRequired ||
          (isTokenSupportedOnActive(token) && visibleEnabled.length <= spec.minRequired)
        ) {
          store.showToast(store.t("common.keep_one_enabled", { noun: spec.noun }), true);
          return;
        }
      }
      current.splice(idx, 1);
    } else {
      current.push(token);
    }
    store.entity.stageDeviceSetting(spec.key, current.join(","));
  };
  const move = (rawToken, delta) => {
    const token = String(rawToken || "").trim().toLowerCase();
    const current = getEnabled();
    const idx = current.indexOf(token);
    if (idx < 0) return;
    let swapIdx = idx + delta;
    while (
      swapIdx >= 0 &&
      swapIdx < current.length &&
      !isTokenSupportedOnActive(current[swapIdx])
    ) {
      swapIdx += delta;
    }
    if (swapIdx < 0 || swapIdx >= current.length) return;
    const tmp = current[idx];
    current[idx] = current[swapIdx];
    current[swapIdx] = tmp;
    store.entity.stageDeviceSetting(spec.key, current.join(","));
  };
  const reorder = (fromEnabledIndex, toEnabledIndex) => {
    const current = getEnabled();
    const supportedIndices = [];
    for (let i = 0; i < current.length; i += 1) {
      if (isTokenSupportedOnActive(current[i])) {
        supportedIndices.push(i);
      }
    }
    if (
      fromEnabledIndex < 0 ||
      toEnabledIndex < 0 ||
      fromEnabledIndex >= supportedIndices.length ||
      toEnabledIndex >= supportedIndices.length ||
      fromEnabledIndex === toEnabledIndex
    ) {
      return;
    }
    const visibleTokens = supportedIndices.map((idx) => current[idx]);
    const [moved] = visibleTokens.splice(fromEnabledIndex, 1);
    visibleTokens.splice(toEnabledIndex, 0, moved);
    for (let j = 0; j < supportedIndices.length; j += 1) {
      current[supportedIndices[j]] = visibleTokens[j];
    }
    store.entity.stageDeviceSetting(spec.key, current.join(","));
  };
  return { getEnabled, toggle, move, reorder };
}
// ---------------------------------------------------------------------------
// Shortcuts (`dock_items` & `pinned_items`)
// ---------------------------------------------------------------------------
function sanitizeShortcutLabel(raw) {
  const str = String(raw ?? "");
  let collapsed = "";
  let prevSpace = true;
  for (const ch of str) {
    const code = ch.charCodeAt(0);
    if (
      code < 0x20 ||
      code === 0x7f ||
      ch === "|" ||
      ch === "\x1e" ||
      ch === "\x1f" ||
      ch === " " ||
      ch === "\t" ||
      ch === "\r" ||
      ch === "\n"
    ) {
      if (!prevSpace) {
        collapsed += " ";
        prevSpace = true;
      }
      continue;
    }
    collapsed += ch;
    prevSpace = false;
  }
  const trimmed = collapsed.trim();
  return trimmed.length > SHORTCUT_LABEL_MAX
    ? trimmed.slice(0, SHORTCUT_LABEL_MAX).trimEnd()
    : trimmed;
}
function isProtectedNativeDockItem(item) {
  return (
    item.kind === "route" &&
    NATIVE_DOCK_APP_TOKENS.includes(item.target) &&
    !item.label &&
    !item.icon
  );
}
function defaultDockShortcutItems() {
  return DEFAULT_DOCK_ROUTES_TOKENS.map((tok) => ({
    kind: "route",
    target: tok,
    action: "",
    label: "",
    icon: "",
    confirm: false,
  }));
}
function normalizeShortcutArray(raw, isDock) {
  if (!Array.isArray(raw)) {
    return isDock ? defaultDockShortcutItems() : [];
  }
  const knownRoutes = new Map(SHORTCUT_ROUTES_CATALOG.map((r) => [r.token, r]));
  const maxItems = isDock ? MAX_DOCK_ITEMS : MAX_PINNED_ITEMS;
  const out = [];
  const seen = new Set();
  for (const entry of raw) {
    if (!entry || typeof entry !== "object") continue;
    const rec = entry;
    const kind = String(rec.kind || "").trim().toLowerCase();
    if (kind === "route") {
      const target = String(rec.target || "").trim().toLowerCase();
      if (isDock && (target === "settings:root" || target === "app:settings")) {
        continue;
      }
      const spec = knownRoutes.get(target);
      if (!spec || (!isDock && spec.dockOnly)) continue;
      const dedupKey = `route|${target}|`;
      if (seen.has(dedupKey)) continue;
      seen.add(dedupKey);
      const isNativeDockApp = isDock && NATIVE_DOCK_APP_TOKENS.includes(target);
      out.push({
        kind: "route",
        target,
        action: "",
        label: isNativeDockApp ? "" : sanitizeShortcutLabel(rec.label),
        icon: isNativeDockApp ? "" : normalizeMdiIconSlug(rec.icon),
        confirm: false,
      });
    } else if (kind === "entity") {
      const target = String(rec.target || "").trim().toLowerCase();
      const dotIdx = target.indexOf(".");
      if (dotIdx <= 0) continue;
      const domain = target.slice(0, dotIdx);
      const validActions = SHORTCUT_DOMAIN_ACTIONS[domain];
      if (!validActions || validActions.length === 0) continue;
      const rawAct = String(rec.action || "").trim().toLowerCase();
      const action = validActions.some((a) => a.action === rawAct)
        ? rawAct
        : validActions[0].action;
      const dedupKey = `entity|${target}|${action}`;
      if (seen.has(dedupKey)) continue;
      seen.add(dedupKey);
      out.push({
        kind: "entity",
        target,
        action,
        label: sanitizeShortcutLabel(rec.label),
        icon: normalizeMdiIconSlug(rec.icon),
        confirm: rec.confirm === undefined ? isDock : Boolean(rec.confirm),
      });
    }
    if (out.length >= maxItems) break;
  }
  return out;
}
function openShortcutModalOp(
  store,
  listKey,
  editIndex = null,
) {
  const isDock = listKey === "dock_items";
  if (
    listKey === "pinned_items" &&
    store.appConfigModal?.open &&
    store.appConfigModal.app === "pinned"
  ) {
    store.returnToPinnedModal = true;
    store.appConfigModal = { open: false, app: null };
  } else {
    store.returnToPinnedModal = false;
  }
  const current = isDock ? store.entity.getDockItems() : store.entity.getPinnedItems();
  const caps = store.state?.capabilities;
  const compatibleRoutes = SHORTCUT_ROUTES_CATALOG.filter((r) => {
    if (!isDock && r.dockOnly) return false;
    if (isDock && (r.token === "settings:root" || NATIVE_DOCK_APP_TOKENS.includes(r.token))) {
      return false;
    }
    return isCatalogItemSupported(r, caps);
  });
  const firstRoute = compatibleRoutes[0]?.token || "weather:moon";
  const entities = store.state?.catalog?.shortcut_entities || [];
  const firstEnt = entities[0];
  const firstDomain = firstEnt ? firstEnt.domain : "light";
  const firstAction = SHORTCUT_DOMAIN_ACTIONS[firstDomain]?.[0]?.action || "toggle";
  if (editIndex !== null && editIndex >= 0 && editIndex < current.length) {
    const existing = current[editIndex];
    if (existing.kind === "entity") {
      const dom = existing.target.split(".", 1)[0] || firstDomain;
      store.shortcutModal = {
        open: true,
        listKey,
        editIndex,
        kind: "entity",
        routeTarget: firstRoute,
        entityDomainFilter: "all",
        entitySearch: "",
        entityTarget: existing.target,
        action: existing.action || SHORTCUT_DOMAIN_ACTIONS[dom]?.[0]?.action || "toggle",
        label: existing.label,
        icon: existing.icon,
        iconSearch: "",
        confirm: Boolean(existing.confirm),
      };
    } else {
      store.shortcutModal = {
        open: true,
        listKey,
        editIndex,
        kind: "route",
        routeTarget: existing.target,
        entityDomainFilter: "all",
        entitySearch: "",
        entityTarget: firstEnt?.id || "",
        action: firstAction,
        label: existing.label,
        icon: existing.icon,
        iconSearch: "",
        confirm: isDock,
      };
    }
  } else {
    store.shortcutModal = {
      open: true,
      listKey,
      editIndex: null,
      kind: isDock ? "route" : entities.length > 0 ? "entity" : "route",
      routeTarget: firstRoute,
      entityDomainFilter: "all",
      entitySearch: "",
      entityTarget: firstEnt?.id || "",
      action: firstAction,
      label: "",
      icon: "",
      iconSearch: "",
      confirm: isDock,
    };
  }
  store.host.requestUpdate();
  void ensureMdiCatalogLoaded()
    .then(() => {
      if (store.shortcutModal.open) {
        store.host.requestUpdate();
      }
    })
    .catch(() => {
      // Curated icons remain synchronously available offline.
    });
}
function saveShortcutModalOp(store) {
  const modal = store.shortcutModal;
  const isDock = modal.listKey === "dock_items";
  const maxItems = isDock ? MAX_DOCK_ITEMS : MAX_PINNED_ITEMS;
  const current = (isDock ? store.entity.getDockItems() : store.entity.getPinnedItems()).map(
    (it) => ({ ...it }),
  );
  if (modal.editIndex === null && current.length >= maxItems) {
    store.showToast(
      `${isDock ? "App Dock" : "Pinned app"} supports up to ${maxItems} shortcuts`,
      true,
    );
    return;
  }
  const rawSelectedIcon = modal.icon.trim();
  const rawTypedIcon = modal.iconSearch.trim();
  let cleanIcon = "";
  if (rawSelectedIcon) {
    const candidate = normalizeMdiIconSlug(rawSelectedIcon);
    if (!candidate || !isKnownMdiIcon(candidate)) {
      store.showToast("Select a supported Material Design Icon", true);
      return;
    }
    cleanIcon = candidate;
  } else if (rawTypedIcon) {
    const candidate = normalizeMdiIconSlug(rawTypedIcon);
    if (candidate && isKnownMdiIcon(candidate)) {
      cleanIcon = candidate;
    } else {
      store.showToast("Click one of the matching icons below (or clear the icon search)", true);
      return;
    }
  }
  const cleanLabel = sanitizeShortcutLabel(modal.label);
  let built;
  if (modal.kind === "route") {
    const routeTok = modal.routeTarget.trim().toLowerCase();
    const spec = SHORTCUT_ROUTES_CATALOG.find((r) => r.token === routeTok);
    if (
      !spec ||
      (!isDock && spec.dockOnly) ||
      (isDock && (routeTok === "settings:root" || NATIVE_DOCK_APP_TOKENS.includes(routeTok))) ||
      !isCatalogItemSupported(spec, store.state?.capabilities)
    ) {
      store.showToast("Select an app or page to pin", true);
      return;
    }
    built = {
      kind: "route",
      target: routeTok,
      action: "",
      label: cleanLabel,
      icon: cleanIcon,
      confirm: false,
    };
  } else {
    const entId = modal.entityTarget.trim().toLowerCase();
    const dotIdx = entId.indexOf(".");
    if (dotIdx <= 0) {
      store.showToast("Select a Home Assistant entity", true);
      return;
    }
    const dom = entId.slice(0, dotIdx);
    const validActs = SHORTCUT_DOMAIN_ACTIONS[dom] || [];
    const act = validActs.some((a) => a.action === modal.action)
      ? modal.action
      : validActs[0]?.action || "";
    if (!act) {
      store.showToast(`Unsupported entity domain '${dom}'`, true);
      return;
    }
    built = {
      kind: "entity",
      target: entId,
      action: act,
      label: cleanLabel,
      icon: cleanIcon,
      confirm: Boolean(modal.confirm),
    };
  }
  const dupIdx = current.findIndex(
    (it, idx) =>
      idx !== modal.editIndex &&
      it.kind === built.kind &&
      it.target === built.target &&
      it.action === built.action,
  );
  if (dupIdx >= 0) {
    store.showToast("That shortcut is already in this list", true);
    return;
  }
  if (modal.editIndex !== null && modal.editIndex >= 0 && modal.editIndex < current.length) {
    current[modal.editIndex] = built;
  } else {
    current.push(built);
  }
  const reopenPinned = Boolean(store.returnToPinnedModal);
  store.returnToPinnedModal = false;
  store.shortcutModal = { ...store.shortcutModal, open: false };
  if (reopenPinned) {
    store.appConfigModal = { open: true, app: "pinned" };
  }
  store.entity.stageDeviceSetting(modal.listKey, current);
}
// ---------------------------------------------------------------------------
// System String-List Slots, Volume Overrides, & Remote Control Groups
// ---------------------------------------------------------------------------
const STRING_LIST_KEYS = [
  "calendar_entities",
  "camera_entities",
  "remotes_list",
  "thermostat_entities",
  "lock_entities",
  "garage_entities",
  "vacuum_entities",
];
const STRING_LIST_MAX_ITEMS = {
  camera_entities: 10,
  remotes_list: 10,
  calendar_entities: 50,
  thermostat_entities: 8,
  lock_entities: 8,
  garage_entities: 6,
  vacuum_entities: 6,
};
function isStringListKey(key) {
  return (
    key === "calendar_entities" ||
    key === "camera_entities" ||
    key === "remotes_list" ||
    key === "thermostat_entities" ||
    key === "lock_entities" ||
    key === "garage_entities" ||
    key === "vacuum_entities"
  );
}
function cleanPersistedStringList(items, maxItems) {
  const out = [];
  for (const raw of items) {
    const ent = String(raw || "").trim();
    if (ent && !out.includes(ent)) {
      out.push(ent);
      if (out.length >= maxItems) break;
    }
  }
  return out;
}
function mergePersistedWithBlankSlots(
  persisted,
  blankCount,
  maxItems,
  prevUiList,
) {
  const cleaned = cleanPersistedStringList(persisted, maxItems);
  const clampedBlankCount = Math.max(0, Math.min(blankCount, maxItems - cleaned.length));
  if (clampedBlankCount === 0) {
    return { uiList: cleaned, clampedBlankCount: 0 };
  }
  if (prevUiList && prevUiList.some((v) => !String(v || "").trim())) {
    const uiList = [];
    let cleanIdx = 0;
    let blanksPlaced = 0;
    for (const slot of prevUiList) {
      if (uiList.length >= maxItems) break;
      if (!String(slot || "").trim()) {
        if (blanksPlaced < clampedBlankCount) {
          uiList.push("");
          blanksPlaced += 1;
        }
      } else if (cleanIdx < cleaned.length) {
        uiList.push(cleaned[cleanIdx]);
        cleanIdx += 1;
      }
    }
    while (cleanIdx < cleaned.length && uiList.length < maxItems) {
      uiList.push(cleaned[cleanIdx]);
      cleanIdx += 1;
    }
    while (blanksPlaced < clampedBlankCount && uiList.length < maxItems) {
      uiList.push("");
      blanksPlaced += 1;
    }
    return { uiList, clampedBlankCount: blanksPlaced };
  }
  return {
    uiList: [...cleaned, ...Array (clampedBlankCount).fill("")],
    clampedBlankCount,
  };
}
function overlayPendingBlankListSlots(
  store,
  payload,
  prevSysConfig,
) {
  if (!payload.system_config) return;
  let mutated = false;
  const nextSys = { ...payload.system_config };
  for (const key of STRING_LIST_KEYS) {
    const wantBlanks = store.pendingBlankListSlots[key] || 0;
    if (wantBlanks <= 0) continue;
    const maxItems = STRING_LIST_MAX_ITEMS[key];
    const base = Array.isArray(nextSys[key]) ? nextSys[key] : [];
    const { uiList, clampedBlankCount } = mergePersistedWithBlankSlots(
      base,
      wantBlanks,
      maxItems,
      prevSysConfig?.[key],
    );
    store.pendingBlankListSlots[key] = clampedBlankCount;
    nextSys[key] = uiList;
    mutated = true;
  }
  if (mutated) {
    payload.system_config = nextSys;
  }
}
function updateStringListRowOp(
  store,
  key,
  index,
  value,
) {
  const maxItems = STRING_LIST_MAX_ITEMS[key];
  const prevUiList = [...(store.state?.system_config?.[key] || [])];
  if (index < 0 || index >= prevUiList.length) return;
  const prevPersisted = cleanPersistedStringList(prevUiList, maxItems);
  const nextRaw = [...prevUiList];
  nextRaw[index] = String(value || "").trim();
  const seen = new Set();
  const nextUiList = [];
  for (const item of nextRaw) {
    const ent = String(item || "").trim();
    if (!ent) {
      nextUiList.push("");
    } else if (!seen.has(ent)) {
      seen.add(ent);
      nextUiList.push(ent);
    }
    if (nextUiList.length >= maxItems) break;
  }
  const nextPersisted = nextUiList.filter(Boolean);
  store.pendingBlankListSlots[key] = nextUiList.length - nextPersisted.length;
  const persistedChanged =
    prevPersisted.length !== nextPersisted.length ||
    prevPersisted.some((v, i) => v !== nextPersisted[i]);
  if (persistedChanged) {
    store.entity.stageSystemSetting(key, nextPersisted);
    if (store.state?.system_config && store.pendingBlankListSlots[key] > 0) {
      store.state = {
        ...store.state,
        system_config: {
          ...store.state.system_config,
          [key]: nextUiList,
        },
      };
      store.host.requestUpdate();
    }
  } else if (store.state?.system_config) {
    store.state = {
      ...store.state,
      system_config: {
        ...store.state.system_config,
        [key]: nextUiList,
      },
    };
    store.host.requestUpdate();
  }
}
function addStringListRowOp(
  store,
  key,
  defaultEntity = "",
  maxLen = STRING_LIST_MAX_ITEMS[key],
) {
  const cap = Math.min(maxLen, STRING_LIST_MAX_ITEMS[key]);
  const list = [...(store.state?.system_config?.[key] || [])];
  if (list.length >= cap) {
    store.showToast(`Maximum of ${cap} entries reached`, true);
    return;
  }
  const cleanDefault = String(defaultEntity || "").trim();
  if (!cleanDefault) {
    list.push("");
    store.pendingBlankListSlots[key] = list.filter((s) => !String(s || "").trim()).length;
    if (store.state?.system_config) {
      store.state = {
        ...store.state,
        system_config: {
          ...store.state.system_config,
          [key]: list,
        },
      };
    }
    store.host.requestUpdate();
    return;
  }
  const nextPersisted = cleanPersistedStringList([...list, cleanDefault], cap);
  const wantBlanks = Math.max(
    0,
    Math.min(store.pendingBlankListSlots[key] || 0, cap - nextPersisted.length),
  );
  store.pendingBlankListSlots[key] = wantBlanks;
  store.entity.stageSystemSetting(key, nextPersisted);
  if (store.state?.system_config && wantBlanks > 0) {
    store.state = {
      ...store.state,
      system_config: {
        ...store.state.system_config,
        [key]: [...nextPersisted, ...Array (wantBlanks).fill("")],
      },
    };
    store.host.requestUpdate();
  }
}
function removeStringListRowOp(
  store,
  key,
  index,
) {
  const maxItems = STRING_LIST_MAX_ITEMS[key];
  const list = [...(store.state?.system_config?.[key] || [])];
  if (index < 0 || index >= list.length) return;
  const [removed] = list.splice(index, 1);
  const wasBlank = !String(removed || "").trim();
  store.pendingBlankListSlots[key] = list.filter((s) => !String(s || "").trim()).length;
  if (wasBlank) {
    if (store.state?.system_config) {
      store.state = {
        ...store.state,
        system_config: {
          ...store.state.system_config,
          [key]: list,
        },
      };
    }
    store.host.requestUpdate();
    return;
  }
  const nextPersisted = cleanPersistedStringList(list, maxItems);
  store.entity.stageSystemSetting(key, nextPersisted);
  if (store.state?.system_config && store.pendingBlankListSlots[key] > 0) {
    const { uiList, clampedBlankCount } = mergePersistedWithBlankSlots(
      nextPersisted,
      store.pendingBlankListSlots[key],
      maxItems,
      list,
    );
    store.pendingBlankListSlots[key] = clampedBlankCount;
    store.state = {
      ...store.state,
      system_config: {
        ...store.state.system_config,
        [key]: uiList,
      },
    };
    store.host.requestUpdate();
  }
}
function reorderStringListRowsOp(
  store,
  key,
  fromIndex,
  toIndex,
) {
  const maxItems = STRING_LIST_MAX_ITEMS[key];
  const list = [...(store.state?.system_config?.[key] || [])];
  if (
    fromIndex < 0 ||
    fromIndex >= list.length ||
    toIndex < 0 ||
    toIndex >= list.length ||
    fromIndex === toIndex
  ) {
    return;
  }
  const prevPersisted = cleanPersistedStringList(list, maxItems);
  const [moved] = list.splice(fromIndex, 1);
  list.splice(toIndex, 0, moved);
  const nextPersisted = cleanPersistedStringList(list, maxItems);
  store.pendingBlankListSlots[key] = list.filter((s) => !String(s || "").trim()).length;
  const persistedChanged =
    prevPersisted.length !== nextPersisted.length ||
    prevPersisted.some((v, i) => v !== nextPersisted[i]);
  if (persistedChanged) {
    store.entity.stageSystemSetting(key, nextPersisted);
    if (store.state?.system_config && store.pendingBlankListSlots[key] > 0) {
      store.state = {
        ...store.state,
        system_config: {
          ...store.state.system_config,
          [key]: list,
        },
      };
      store.host.requestUpdate();
    }
  } else if (store.state?.system_config) {
    store.state = {
      ...store.state,
      system_config: {
        ...store.state.system_config,
        [key]: list,
      },
    };
    store.host.requestUpdate();
  }
}
function addVolumeOverrideRowOp(store) {
  const list = [...(store.state?.system_config?.volume_overrides || [])];
  if (list.length >= 10) {
    store.showToast("Maximum of 10 volume overrides reached", true);
    return;
  }
  const speakers = store.state?.catalog?.ma_speakers || [];
  const targets = store.state?.catalog?.volume_targets || store.state?.catalog?.remotes || [];
  list.push({
    speaker: speakers[0]?.id || "",
    target: targets[0]?.id || speakers[0]?.id || "",
  });
  store.entity.stageSystemSetting("volume_overrides", list);
}
function updateVolumeOverrideRowOp(
  store,
  index,
  field,
  value,
) {
  const list = (store.state?.system_config?.volume_overrides || []).map((v) => ({
    ...v,
  }));
  if (!list[index]) return;
  list[index][field] = value;
  store.entity.stageSystemSetting("volume_overrides", list);
}
function removeVolumeOverrideRowOp(store, index) {
  const list = [...(store.state?.system_config?.volume_overrides || [])];
  list.splice(index, 1);
  store.entity.stageSystemSetting("volume_overrides", list);
}
function addRemoteGroupRowOp(store) {
  const groups = (store.state?.system_config?.remote_groups || []).map((g) => ({
    ...g,
    remotes: [...(g.remotes || [])],
  }));
  const id = `group_${Date.now().toString(36)}`;
  groups.push({ id, name: "New remote group", area_id: "", remotes: [] });
  store.entity.stageSystemSetting("remote_groups", groups);
}
function updateRemoteGroupFieldOp(
  store,
  groupId,
  field,
  value,
) {
  const groups = (store.state?.system_config?.remote_groups || []).map((g) =>
    g.id === groupId ? { ...g, [field]: value } : { ...g, remotes: [...(g.remotes || [])] },
  );
  store.entity.stageSystemSetting("remote_groups", groups);
}
function toggleRemoteInGroupOp(
  store,
  groupId,
  remoteEntity,
) {
  const groups = (store.state?.system_config?.remote_groups || []).map((g) => {
    if (g.id !== groupId) return { ...g, remotes: [...(g.remotes || [])] };
    const remotes = [...(g.remotes || [])];
    const idx = remotes.indexOf(remoteEntity);
    if (idx >= 0) remotes.splice(idx, 1);
    else remotes.push(remoteEntity);
    return { ...g, remotes };
  });
  store.entity.stageSystemSetting("remote_groups", groups);
}
function removeRemoteGroupRowOp(store, groupId) {
  const groups = (store.state?.system_config?.remote_groups || []).filter((g) => g.id !== groupId);
  store.entity.stageSystemSetting("remote_groups", groups);
}
__latterExp(__exports, { isCatalogItemSupported: () => isCatalogItemSupported, TOKEN_LIST_SPECS: () => TOKEN_LIST_SPECS, createTokenListOps: () => createTokenListOps, sanitizeShortcutLabel: () => sanitizeShortcutLabel, isProtectedNativeDockItem: () => isProtectedNativeDockItem, defaultDockShortcutItems: () => defaultDockShortcutItems, normalizeShortcutArray: () => normalizeShortcutArray, openShortcutModalOp: () => openShortcutModalOp, saveShortcutModalOp: () => saveShortcutModalOp, STRING_LIST_KEYS: () => STRING_LIST_KEYS, STRING_LIST_MAX_ITEMS: () => STRING_LIST_MAX_ITEMS, isStringListKey: () => isStringListKey, cleanPersistedStringList: () => cleanPersistedStringList, mergePersistedWithBlankSlots: () => mergePersistedWithBlankSlots, overlayPendingBlankListSlots: () => overlayPendingBlankListSlots, updateStringListRowOp: () => updateStringListRowOp, addStringListRowOp: () => addStringListRowOp, removeStringListRowOp: () => removeStringListRowOp, reorderStringListRowsOp: () => reorderStringListRowsOp, addVolumeOverrideRowOp: () => addVolumeOverrideRowOp, updateVolumeOverrideRowOp: () => updateVolumeOverrideRowOp, removeVolumeOverrideRowOp: () => removeVolumeOverrideRowOp, addRemoteGroupRowOp: () => addRemoteGroupRowOp, updateRemoteGroupFieldOp: () => updateRemoteGroupFieldOp, toggleRemoteInGroupOp: () => toggleRemoteInGroupOp, removeRemoteGroupRowOp: () => removeRemoteGroupRowOp });
//# sourceURL=latter-studio/src/state/shortcuts-lists-ops.ts
});
__latterDef("src/state/entity-controller.ts", (__exports, __req) => {
const { formatWsError, isConflictError } = __req("src/api/ws-client.ts");
const { ALLOWED_DEVICE_ACTIONS, DEVICE_PREF_SPECS_MAP, GROUP_BEHAVIOR_NON_PREF_KEYS, GROUP_DISPLAY_NON_PREF_KEYS, GROUP_INTERFACE_NON_PREF_KEYS, MAX_DOCK_ITEMS, NATIVE_DOCK_APP_TOKENS } = __req("src/constants.ts");
const { isValidHexColor } = __req("src/utils/format.ts");
const { addRemoteGroupRowOp, addStringListRowOp, addVolumeOverrideRowOp, cleanPersistedStringList, createTokenListOps, defaultDockShortcutItems, isCatalogItemSupported, isProtectedNativeDockItem, isStringListKey, normalizeShortcutArray, openShortcutModalOp, overlayPendingBlankListSlots, removeRemoteGroupRowOp, removeStringListRowOp, removeVolumeOverrideRowOp, reorderStringListRowsOp, saveShortcutModalOp, STRING_LIST_MAX_ITEMS, TOKEN_LIST_SPECS, toggleRemoteInGroupOp, updateRemoteGroupFieldOp, updateStringListRowOp, updateVolumeOverrideRowOp } = __req("src/state/shortcuts-lists-ops.ts");
/**
 * `store.entity` Controller (`EntityController`, `D-062`, `D-064`, `D-065`):
 * - Serialized System & per-Device `saveChain` queues with `inFlight` patch overlays (`B-08`)
 * - Monotonic per-key edit ownership so failed saves never clobber newer pending/in-flight edits (`B-09`)
 * - `expected_config_rev` optimistic concurrency with automatic `"conflict"` state resync (`D-064`)
 * - Optimistic ESPHome entity actions, unified `tokenListOps`, shortcuts, wallpapers, & 600 s camera signing (`D-065`)
 */
const SAVE_DEBOUNCE_MS = 220;
const ENTITY_OPTIMISTIC_TTL_MS = 8000;
const BEHAVIOR_NON_PREF_KEY_SET = new Set (GROUP_BEHAVIOR_NON_PREF_KEYS);
const DISPLAY_NON_PREF_KEY_SET = new Set (GROUP_DISPLAY_NON_PREF_KEYS);
const INTERFACE_NON_PREF_KEY_SET = new Set (GROUP_INTERFACE_NON_PREF_KEYS);
const ALLOWED_DEVICE_ACTION_SET = new Set (ALLOWED_DEVICE_ACTIONS);
function activeGroupKeySet(
  grp,
  devicePrefs,
) {
  const keys = new Set (BEHAVIOR_NON_PREF_KEY_SET);
  for (const p of devicePrefs) {
    if (p.group_tier === "behavior") keys.add(p.key);
    else if (p.group_tier === "display" && grp.include_display) keys.add(p.key);
    else if (p.group_tier === "interface" && grp.include_interface) keys.add(p.key);
  }
  if (grp.include_display) {
    for (const k of DISPLAY_NON_PREF_KEY_SET) keys.add(k);
  }
  if (grp.include_interface) {
    for (const k of INTERFACE_NON_PREF_KEY_SET) keys.add(k);
  }
  return keys;
}
function sameGroupControlVal(a, b) {
  if (a === b) return true;
  if (
    Array.isArray(a) ||
    (a && typeof a === "object") ||
    Array.isArray(b) ||
    (b && typeof b === "object")
  ) {
    return JSON.stringify(a) === JSON.stringify(b);
  }
  return String(a) === String(b);
}
function expandDevicePrefPatch(
  currentCfg,
  rawPatch,
) {
  const expanded = { ...rawPatch };
  if (rawPatch.home_screen_enabled === false) {
    const effStart = String(rawPatch.start_screen ?? currentCfg.start_screen ?? "Home");
    if (effStart === "Home") {
      expanded.start_screen = "Time App";
    }
  }
  return expanded;
}
function overlayDevicePrefsOnSections(
  payload,
  rawPatch,
) {
  if (!rawPatch || Object.keys(rawPatch).length === 0) return;
  const curCfg = (payload.config || {});
  const expanded = expandDevicePrefPatch(curCfg, rawPatch);
  const groups = payload.device_groups || [];
  const devicePrefs = payload.device_prefs || [];
  const supportedPrefKeys = new Set(devicePrefs.map((p) => p.key));
  const isRoaming = curCfg.is_roaming !== false;
  if ("device_group" in rawPatch) {
    const targetGrpId = String(rawPatch.device_group || "custom").trim() || "custom";
    expanded.device_group = targetGrpId;
    if (targetGrpId !== "custom") {
      const grp = groups.find((g) => g.id === targetGrpId);
      if (grp?.device_config) {
        const enforcedKeys = activeGroupKeySet(grp, devicePrefs);
        for (const [gk, gv] of Object.entries(grp.device_config)) {
          if (gk in rawPatch || gv === undefined || gv === null) continue;
          if (!enforcedKeys.has(gk)) continue;
          if ((gk === "sync_device_area" || gk === "area_follow_dwell_s") && !isRoaming) continue;
          if (
            BEHAVIOR_NON_PREF_KEY_SET.has(gk) ||
            DISPLAY_NON_PREF_KEY_SET.has(gk) ||
            INTERFACE_NON_PREF_KEY_SET.has(gk) ||
            supportedPrefKeys.has(gk)
          ) {
            expanded[gk] = gv;
          }
        }
      }
    }
  } else {
    const curGrpId = String(curCfg.device_group || "custom").trim() || "custom";
    if (curGrpId !== "custom") {
      const grp = groups.find((g) => g.id === curGrpId);
      if (grp?.device_config) {
        const enforcedKeys = activeGroupKeySet(grp, devicePrefs);
        for (const [ek, ev] of Object.entries(expanded)) {
          if ((ek === "sync_device_area" || ek === "area_follow_dwell_s") && !isRoaming) continue;
          if (
            enforcedKeys.has(ek) &&
            grp.device_config[ek] !== undefined &&
            !sameGroupControlVal(grp.device_config[ek], ev)
          ) {
            expanded.device_group = "custom";
            break;
          }
        }
      }
    }
  }
  payload.config = {
    ...payload.config,
    ...expanded,
  };
  if ("device_group" in expanded && Array.isArray(payload.system_devices) && payload.subentry_id) {
    const nextGrp = String(expanded.device_group || "custom");
    const nextGrpName =
      nextGrp === "custom" ? "Custom" : groups.find((g) => g.id === nextGrp)?.name || nextGrp;
    payload.system_devices = payload.system_devices.map((d) =>
      d.subentry_id === payload.subentry_id
        ? { ...d, device_group: nextGrp, device_group_name: nextGrpName }
        : d,
    );
  }
  if (payload.device_prefs) {
    payload.device_prefs = payload.device_prefs.map((p) =>
      p.key in expanded ? { ...p, value: expanded[p.key] } : p,
    );
  }
  const sections = payload?.esphome?.sections;
  if (!sections) return;
  payload.esphome = {
    ...payload.esphome,
    sections: sections.map((sec) => ({
      ...sec,
      items: (sec.items || []).map((item) => {
        if (item.pref_key && item.pref_key in expanded) {
          const val = expanded[item.pref_key];
          const nextState = item.domain === "switch" ? (val ? "on" : "off") : String(val ?? "");
          return { ...item, state: nextState };
        }
        if (
          "volume_step_size" in expanded &&
          item.domain === "number" &&
          item.entity_id.startsWith("media_player.")
        ) {
          const stepNum = Number(expanded.volume_step_size);
          if (Number.isFinite(stepNum) && stepNum > 0) {
            return { ...item, step: stepNum };
          }
        }
        return item;
      }),
    })),
  };
}
function overlayPendingEntityStates(
  payload,
  pendingMap,
) {
  const now = Date.now();
  for (const [eid, entry] of pendingMap.entries()) {
    if (entry.expires <= now) {
      pendingMap.delete(eid);
    }
  }
  const sections = payload?.esphome?.sections;
  if (!sections || pendingMap.size === 0) return;
  payload.esphome = {
    ...payload.esphome,
    sections: sections.map((sec) => ({
      ...sec,
      items: (sec.items || []).map((item) => {
        const pending = pendingMap.get(item.entity_id);
        if (!pending) return item;
        const curState = String(item.state ?? "");
        const sameNumeric =
          curState !== "" &&
          pending.state !== "" &&
          Number.isFinite(Number(curState)) &&
          Number.isFinite(Number(pending.state)) &&
          Number(curState) === Number(pending.state);
        if (curState === pending.state || sameNumeric) {
          pendingMap.delete(item.entity_id);
          return item;
        }
        return { ...item, state: pending.state };
      }),
    })),
  };
}
class EntityController {
                   store;
          editSeqCounter = 0;
          systemSaveChain = Promise.resolve();
                   inFlightSystemPatch = {};
                   systemKeySeqs = new Map();
          pendingSystemKeySeqs = {};
                   deviceSaveChains = new Map();
                   inFlightDevicePatches = new Map();
                   deviceKeySeqs = new Map();
                   cameraPreviewCache = new Map();
           tokenLists;
  constructor(store) {
    this.store = store;
    this.tokenLists = {
      area_categories: createTokenListOps(store, TOKEN_LIST_SPECS.area_categories),
      home_categories: createTokenListOps(store, TOKEN_LIST_SPECS.home_categories),
      tools_items: createTokenListOps(store, TOKEN_LIST_SPECS.tools_items),
      games_items: createTokenListOps(store, TOKEN_LIST_SPECS.games_items),
      activity_sources: createTokenListOps(store, TOKEN_LIST_SPECS.activity_sources),
    };
  }
  isCatalogItemSupported(item, caps) {
    return isCatalogItemSupported(item, caps ?? this.store.state?.capabilities);
  }
  getEffectiveSystemPatch() {
    return {
      ...this.inFlightSystemPatch,
      ...this.store.pendingSystemPatch,
    };
  }
  getEffectiveDevicePatch(subentryId) {
    const inFlight = this.inFlightDevicePatches.get(subentryId) || {};
    const pending = this.store.pendingDeviceBuckets.get(subentryId)?.patch || {};
    return { ...inFlight, ...pending };
  }
  discardDeviceBucket(subentryId) {
    const bucket = this.store.pendingDeviceBuckets.get(subentryId);
    if (bucket?.timer) {
      clearTimeout(bucket.timer);
      bucket.timer = null;
    }
    this.store.pendingDeviceBuckets.delete(subentryId);
    this.inFlightDevicePatches.delete(subentryId);
  }
          getDeviceKeySeqMap(subentryId) {
    let map = this.deviceKeySeqs.get(subentryId);
    if (!map) {
      map = new Map();
      this.deviceKeySeqs.set(subentryId, map);
    }
    return map;
  }
  // ---------- Device & System Settings Staging + Serialized Flushing ----------
  stageDeviceSetting(
    key,
    value,
    controlDomId,
    debounceMs = SAVE_DEBOUNCE_MS,
  ) {
    const targetSubentryId = this.store.activeSubentryId;
    if (!targetSubentryId || this.store.deviceLoading) return;
    let bucket = this.store.pendingDeviceBuckets.get(targetSubentryId);
    const activeDevEntry = this.store.state?.system_devices?.find(
      (d) => d.subentry_id === targetSubentryId,
    );
    const targetTitle =
      (this.store.state?.subentry_id === targetSubentryId ? this.store.state.title : "") ||
      activeDevEntry?.title ||
      targetSubentryId;
    if (!bucket) {
      bucket = {
        targetSubentryId,
        targetTitle,
        patch: {},
        previousValues: {},
        keySeqs: {},
        timer: null,
      };
      this.store.pendingDeviceBuckets.set(targetSubentryId, bucket);
    }
    const curCfg =
      this.store.state && this.store.state.subentry_id === targetSubentryId
        ? ((this.store.state.config || {}))
        : {};
    const snapshotKey = (k) => {
      if (!(k in bucket.previousValues)) {
        bucket.previousValues[k] = curCfg[k];
      }
    };
    snapshotKey(key);
    snapshotKey("device_group");
    if (key === "home_screen_enabled") {
      snapshotKey("start_screen");
    }
    if (controlDomId && !(`__dom:${controlDomId}` in bucket.previousValues)) {
      bucket.previousValues[`__dom:${controlDomId}`] = bucket.previousValues[key];
    }
    const seq = ++this.editSeqCounter;
    const seqMap = this.getDeviceKeySeqMap(targetSubentryId);
    seqMap.set(key, seq);
    bucket.keySeqs[key] = seq;
    if (controlDomId) {
      seqMap.set(`__dom:${controlDomId}`, seq);
      bucket.keySeqs[`__dom:${controlDomId}`] = seq;
    }
    bucket.patch[key] = value;
    if (this.store.state) {
      const nextSystemDevices =
        key === "device_remote_group" && Array.isArray(this.store.state.system_devices)
          ? this.store.state.system_devices.map((d) =>
              d.subentry_id === targetSubentryId
                ? { ...d, device_remote_group: String(value || "area_auto") }
                : d,
            )
          : this.store.state.system_devices;
      if (this.store.state.subentry_id === targetSubentryId) {
        const nextPayload = {
          ...this.store.state,
          system_devices: nextSystemDevices,
          config: { ...this.store.state.config },
        };
        overlayDevicePrefsOnSections(nextPayload, { [key]: value });
        this.store.state = nextPayload;
      } else if (nextSystemDevices !== this.store.state.system_devices) {
        this.store.state = {
          ...this.store.state,
          system_devices: nextSystemDevices,
        };
      }
    }
    if (bucket.timer) clearTimeout(bucket.timer);
    bucket.timer = setTimeout(() => {
      void this.flushDeviceBucket(targetSubentryId);
    }, Math.max(0, debounceMs));
    this.store.host.requestUpdate();
  }
  flushDeviceBucket(targetSubentryId) {
    const bucket = this.store.pendingDeviceBuckets.get(targetSubentryId);
    const prevChain = this.deviceSaveChains.get(targetSubentryId) ?? Promise.resolve();
    if (!bucket) return prevChain;
    if (bucket.timer) {
      clearTimeout(bucket.timer);
      bucket.timer = null;
    }
    const patch = { ...bucket.patch };
    const previousValues = { ...bucket.previousValues };
    const batchKeySeqs = { ...bucket.keySeqs };
    const targetTitle = bucket.targetTitle;
    this.store.pendingDeviceBuckets.delete(targetSubentryId);
    if (Object.keys(patch).length === 0) return prevChain;
    const inFlight = this.inFlightDevicePatches.get(targetSubentryId) || {};
    Object.assign(inFlight, patch);
    this.inFlightDevicePatches.set(targetSubentryId, inFlight);
    const nextChain = prevChain.then(async() => {
      const seqMap = this.getDeviceKeySeqMap(targetSubentryId);
      const clearOwnedInFlight = () => {
        const curInFlight = this.inFlightDevicePatches.get(targetSubentryId);
        if (!curInFlight) return;
        for (const k of Object.keys(patch)) {
          if (seqMap.get(k) === batchKeySeqs[k]) {
            delete curInFlight[k];
          }
        }
        if (Object.keys(curInFlight).length === 0) {
          this.inFlightDevicePatches.delete(targetSubentryId);
        }
      };
      const expectedRev = this.store.getKnownDeviceConfigRev(targetSubentryId);
      const reqPayload = { config: patch };
      if (expectedRev > 0) {
        reqPayload.expected_config_rev = expectedRev;
      }
      try {
        const res = await this.store.ws.runDeviceCommand(
          targetSubentryId,
          "save_device_config",
          reqPayload,
        );
        clearOwnedInFlight();
        if (res) {
          if (res.subentry_id === targetSubentryId && res.device_config_rev > 0) {
            this.store.recordKnownDeviceConfigRev(targetSubentryId, res.device_config_rev);
          }
          if (this.store.activeSubentryId === targetSubentryId) {
            this.store.ingestPayload(res, false);
          } else if (this.store.state && Array.isArray(res.system_devices)) {
            this.store.state = {
              ...this.store.state,
              system_devices: res.system_devices,
              issues: res.issues ?? this.store.state.issues,
            };
            this.store.host.requestUpdate();
          }
        }
        this.store.announcePolite(this.store.t("shell.saved_status"));
      } catch (err) {
        clearOwnedInFlight();
        if (isConflictError(err)) {
          void this.store.refreshState();
          this.store.showToast(this.store.t("sync.conflict_reloaded"), true);
          return;
        }
        const controlRevert = {};
        for (const [k, v] of Object.entries(previousValues)) {
          if (k.startsWith("__dom:")) {
            if (seqMap.get(k) !== batchKeySeqs[k]) continue;
            const domId = k.slice(6);
            if (typeof v === "boolean") controlRevert[domId] = v;
            else if (v !== undefined && v !== null) controlRevert[domId] = String(v);
            else controlRevert[domId] = "";
          }
        }
        const remoteGroupOwned =
          "device_remote_group" in previousValues &&
          seqMap.get("device_remote_group") === batchKeySeqs.device_remote_group;
        if (this.store.state) {
          const nextSystemDevices =
            remoteGroupOwned && Array.isArray(this.store.state.system_devices)
              ? this.store.state.system_devices.map((d) =>
                  d.subentry_id === targetSubentryId
                    ? {
                        ...d,
                        device_remote_group: String(
                          previousValues.device_remote_group || "area_auto",
                        ),
                      }
                    : d,
                )
              : this.store.state.system_devices;
          if (this.store.state.subentry_id === targetSubentryId) {
            const restoredConfig = {
              ...(this.store.state.config),
            };
            const restoredPrefs = {};
            for (const [k, v] of Object.entries(previousValues)) {
              if (k.startsWith("__dom:")) continue;
              if (k in batchKeySeqs && seqMap.get(k) !== batchKeySeqs[k]) continue;
              restoredConfig[k] = v;
              if (v !== undefined) {
                restoredPrefs[k] = v;
              }
            }
            const nextPayload = {
              ...this.store.state,
              system_devices: nextSystemDevices,
              config: restoredConfig,
            };
            if (Object.keys(restoredPrefs).length > 0) {
              overlayDevicePrefsOnSections(nextPayload, restoredPrefs);
            }
            const newerPatch = this.getEffectiveDevicePatch(targetSubentryId);
            if (Object.keys(newerPatch).length > 0) {
              overlayDevicePrefsOnSections(nextPayload, newerPatch);
            }
            this.store.state = nextPayload;
          } else if (nextSystemDevices !== this.store.state.system_devices) {
            this.store.state = {
              ...this.store.state,
              system_devices: nextSystemDevices,
            };
          }
        }
        if (this.store.activeSubentryId === targetSubentryId && Object.keys(controlRevert).length > 0) {
          this.store.mergeDomRevert(controlRevert);
        }
        const rawReason = formatWsError(err, this.store.t("sync.save_device_failed"));
        const msg =
          this.store.activeSubentryId !== targetSubentryId && targetTitle
            ? this.store.t("sync.save_device_named_failed", {
                title: targetTitle,
                error: rawReason,
              })
            : rawReason;
        this.store.showToast(msg, true);
        this.store.host.requestUpdate();
      }
    });
    this.deviceSaveChains.set(targetSubentryId, nextChain);
    return nextChain;
  }
  stageSystemSetting (
    key,
    value,
    controlDomId,
    debounceMs = SAVE_DEBOUNCE_MS,
  ) {
    const keyStr = String(key);
    if (!(keyStr in this.store.pendingSystemPrevious)) {
      const prev = (this.store.state?.system_config)?.[keyStr];
      if (isStringListKey(keyStr) && Array.isArray(prev)) {
        this.store.pendingSystemPrevious[keyStr] = cleanPersistedStringList(
          prev,
          STRING_LIST_MAX_ITEMS[keyStr],
        );
      } else {
        this.store.pendingSystemPrevious[keyStr] =
          prev !== undefined ? structuredClone(prev) : undefined;
      }
    }
    if (controlDomId && !(`__dom:${controlDomId}` in this.store.pendingSystemPrevious)) {
      const prevScalar = this.store.pendingSystemPrevious[keyStr];
      if (
        typeof prevScalar === "string" ||
        typeof prevScalar === "number" ||
        typeof prevScalar === "boolean"
      ) {
        this.store.pendingSystemPrevious[`__dom:${controlDomId}`] = prevScalar;
      }
    }
    const seq = ++this.editSeqCounter;
    this.systemKeySeqs.set(keyStr, seq);
    this.pendingSystemKeySeqs[keyStr] = seq;
    if (controlDomId) {
      this.systemKeySeqs.set(`__dom:${controlDomId}`, seq);
      this.pendingSystemKeySeqs[`__dom:${controlDomId}`] = seq;
    }
    this.store.pendingSystemPatch[keyStr] = value;
    if (this.store.state?.system_config) {
      this.store.state = {
        ...this.store.state,
        system_config: {
          ...this.store.state.system_config,
          [keyStr]: value,
        },
      };
    }
    if (this.store.systemSaveTimer) clearTimeout(this.store.systemSaveTimer);
    this.store.systemSaveTimer = setTimeout(() => {
      void this.flushSystemSettings();
    }, Math.max(0, debounceMs));
    this.store.host.requestUpdate();
  }
  flushSystemSettings() {
    if (this.store.systemSaveTimer) {
      clearTimeout(this.store.systemSaveTimer);
      this.store.systemSaveTimer = null;
    }
    const patch = { ...this.store.pendingSystemPatch };
    const previousValues = { ...this.store.pendingSystemPrevious };
    const batchKeySeqs = { ...this.pendingSystemKeySeqs };
    this.store.pendingSystemPatch = {};
    this.store.pendingSystemPrevious = {};
    this.pendingSystemKeySeqs = {};
    if (Object.keys(patch).length === 0) return this.systemSaveChain;
    Object.assign(this.inFlightSystemPatch, patch);
    this.systemSaveChain = this.systemSaveChain.then(async() => {
      const clearOwnedInFlight = () => {
        for (const k of Object.keys(patch)) {
          if (this.systemKeySeqs.get(k) === batchKeySeqs[k]) {
            delete this.inFlightSystemPatch[k];
          }
        }
      };
      const expectedRev = this.store.state?.system_config_rev ?? 0;
      const reqPayload = { config: patch };
      if (expectedRev > 0) {
        reqPayload.expected_config_rev = expectedRev;
      }
      try {
        const res = await this.store.ws.runSystemCommand(
          "save_system_config",
          reqPayload,
          this.store.activeSubentryId || null,
        );
        clearOwnedInFlight();
        if (res) {
          this.store.ingestPayload(res, false);
        }
        this.store.announcePolite(this.store.t("shell.saved_status"));
      } catch (err) {
        clearOwnedInFlight();
        if (isConflictError(err)) {
          void this.store.refreshState();
          this.store.showToast(this.store.t("sync.conflict_reloaded"), true);
          return;
        }
        const controlRevert = {};
        if (this.store.state?.system_config) {
          const prevUiSys = this.store.state.system_config;
          const restored = {
            ...(prevUiSys),
          };
          for (const [k, v] of Object.entries(previousValues)) {
            if (k in batchKeySeqs && this.systemKeySeqs.get(k) !== batchKeySeqs[k]) continue;
            if (k.startsWith("__dom:")) {
              const domId = k.slice(6);
              controlRevert[domId] = typeof v === "boolean" ? v : String(v ?? "");
            } else if (v !== undefined) {
              restored[k] = v;
            }
          }
          const newerSys = this.getEffectiveSystemPatch();
          Object.assign(restored, newerSys);
          const nextPayload = {
            ...this.store.state,
            system_config: restored,
          };
          overlayPendingBlankListSlots(this.store, nextPayload, prevUiSys);
          this.store.state = nextPayload;
        }
        if (Object.keys(controlRevert).length > 0) {
          this.store.mergeDomRevert(controlRevert);
        }
        this.store.showToast(
          formatWsError(err, this.store.t("sync.save_system_failed")),
          true,
        );
        this.store.host.requestUpdate();
      }
    });
    return this.systemSaveChain;
  }
  async flushAllPendingSettings() {
    const tasks = [];
    if (Object.keys(this.store.pendingSystemPatch).length > 0) {
      tasks.push(this.flushSystemSettings());
    }
    for (const subId of Array.from(this.store.pendingDeviceBuckets.keys())) {
      tasks.push(this.flushDeviceBucket(subId));
    }
    await Promise.allSettled(tasks);
  }
  // ---------- Device Preferences & ESPHome Entity Actions ----------
  getPref(key) {
    return (this.store.state?.device_prefs || []).find((p) => p.key === key);
  }
  getPrefs(keys) {
    const all = this.store.state?.device_prefs || [];
    if (!keys || keys.length === 0) return all;
    const keySet = new Set(keys);
    return all.filter((p) => keySet.has(p.key));
  }
  getPrefSpec(key) {
    const fromPayload = this.store.state?.pref_specs?.find((s) => s.key === key);
    return fromPayload ?? DEVICE_PREF_SPECS_MAP[key];
  }
  getSectionItems(sectionId) {
    const sec = (this.store.state?.esphome?.sections || []).find((s) => s.id === sectionId);
    return sec?.items || [];
  }
          currentEntityState(entityId) {
    for (const sec of this.store.state?.esphome?.sections || []) {
      for (const it of sec.items || []) {
        if (it.entity_id === entityId) return it.state;
      }
    }
    return "";
  }
          applyOptimisticEntity(entityId, nextState) {
    const prev = this.currentEntityState(entityId);
    this.store.pendingEntityStates.set(entityId, {
      state: nextState,
      previousValue: prev,
      expires: Date.now() + ENTITY_OPTIMISTIC_TTL_MS,
    });
    if (this.store.state?.esphome?.sections) {
      const nextPayload = { ...this.store.state };
      overlayPendingEntityStates(nextPayload, this.store.pendingEntityStates);
      this.store.state = nextPayload;
      this.store.host.requestUpdate();
    }
    return prev;
  }
          rollbackOptimisticEntity(entityId, prev) {
    this.store.pendingEntityStates.delete(entityId);
    if (this.store.state?.esphome?.sections) {
      this.store.state = {
        ...this.store.state,
        esphome: {
          ...this.store.state.esphome,
          sections: this.store.state.esphome.sections.map((sec) => ({
            ...sec,
            items: (sec.items || []).map((it) =>
              it.entity_id === entityId ? { ...it, state: prev } : it,
            ),
          })),
        },
      };
    }
    this.store.host.requestUpdate();
  }
  async executeEntityAction(
    entityId,
    optimisticState,
    body,
    errorPrefix,
  ) {
    const targetSubentryId = this.store.activeSubentryId;
    if (!targetSubentryId || !entityId) return false;
    const prev =
      optimisticState !== undefined ? this.applyOptimisticEntity(entityId, optimisticState) : "";
    try {
      const res = await this.store.ws.runDeviceCommand(targetSubentryId, "esphome_entity_action", {
        entity_id: entityId,
        ...body,
      });
      if (res && this.store.activeSubentryId === targetSubentryId) {
        this.store.ingestPayload(res, false);
      }
      return true;
    } catch (err) {
      if (optimisticState !== undefined) this.rollbackOptimisticEntity(entityId, prev);
      this.store.showToast(formatWsError(err, errorPrefix), true);
      return false;
    }
  }
  async espAction(
    entityId,
    action,
    optimisticState,
    toastMessage,
  ) {
    const ok = await this.executeEntityAction(
      entityId,
      optimisticState,
      { action },
      "Device action failed",
    );
    if (ok && toastMessage) {
      this.store.showToast(toastMessage);
    }
    return ok;
  }
  async espSelect(entityId, option) {
    await this.executeEntityAction(entityId, option, { option }, "Could not update option");
  }
  async espNumber(entityId, level) {
    if (!Number.isFinite(level)) return;
    await this.executeEntityAction(
      entityId,
      String(level),
      { level },
      "Could not update level",
    );
  }
  async runDeviceAction(action, toastMessage) {
    const targetSubentryId = this.store.activeSubentryId;
    const cleanAction = String(action || "").trim().toLowerCase();
    if (!targetSubentryId || !cleanAction) return false;
    if (!ALLOWED_DEVICE_ACTION_SET.has(cleanAction)) {
      this.store.showToast(`Unsupported Device action: ${cleanAction}`, true);
      return false;
    }
    try {
      const res = await this.store.ws.runDeviceCommand(targetSubentryId, "device_action", {
        action: cleanAction,
      });
      if (res && this.store.activeSubentryId === targetSubentryId) {
        this.store.ingestPayload(res, false);
      }
      if (toastMessage) {
        this.store.showToast(toastMessage);
      }
      return true;
    } catch (err) {
      this.store.showToast(formatWsError(err, "Device action failed"), true);
      return false;
    }
  }
  async triggerHeaderFirmwareUpdate() {
    const updEntity = this.store.state?.live?.fw_update_entity || "";
    if (!updEntity) return;
    if (await this.espAction(updEntity, "install")) {
      this.store.showToast("Firmware update started");
    }
  }
  // ---------- Token Lists (Area, Home, Tools, Games, Activity Sources) ----------
  getEnabledAreaCategories() {
    return this.tokenLists.area_categories.getEnabled();
  }
  toggleAreaCategoryToken(token, forceEnabled) {
    this.tokenLists.area_categories.toggle(token, forceEnabled);
  }
  moveAreaCategoryToken(token, delta) {
    this.tokenLists.area_categories.move(token, delta);
  }
  reorderAreaCategories(fromIndex, toIndex) {
    this.tokenLists.area_categories.reorder(fromIndex, toIndex);
  }
  getEnabledHomeCategories() {
    return this.tokenLists.home_categories.getEnabled();
  }
  toggleHomeCategoryToken(token, forceEnabled) {
    this.tokenLists.home_categories.toggle(token, forceEnabled);
  }
  moveHomeCategoryToken(token, delta) {
    this.tokenLists.home_categories.move(token, delta);
  }
  reorderHomeCategories(fromIndex, toIndex) {
    this.tokenLists.home_categories.reorder(fromIndex, toIndex);
  }
  getEnabledToolsItems() {
    return this.tokenLists.tools_items.getEnabled();
  }
  toggleToolItemToken(token, forceEnabled) {
    this.tokenLists.tools_items.toggle(token, forceEnabled);
  }
  moveToolItemToken(token, delta) {
    this.tokenLists.tools_items.move(token, delta);
  }
  reorderToolsItems(fromIndex, toIndex) {
    this.tokenLists.tools_items.reorder(fromIndex, toIndex);
  }
  getEnabledGamesItems() {
    return this.tokenLists.games_items.getEnabled();
  }
  toggleGameItemToken(token, forceEnabled) {
    this.tokenLists.games_items.toggle(token, forceEnabled);
  }
  moveGameItemToken(token, delta) {
    this.tokenLists.games_items.move(token, delta);
  }
  reorderGamesItems(fromIndex, toIndex) {
    this.tokenLists.games_items.reorder(fromIndex, toIndex);
  }
  getEnabledActivitySources() {
    return this.tokenLists.activity_sources.getEnabled();
  }
  toggleActivitySource(sourceId, forceEnabled) {
    this.tokenLists.activity_sources.toggle(sourceId, forceEnabled);
  }
  reorderActivitySources(fromIndex, toIndex) {
    this.tokenLists.activity_sources.reorder(fromIndex, toIndex);
  }
  // ---------- Shortcuts (`dock_items` & `pinned_items`) + App Config Modal ----------
  getDockItems() {
    const raw = this.store.state?.config?.dock_items;
    if (raw === undefined || raw === null) {
      return defaultDockShortcutItems();
    }
    return normalizeShortcutArray(raw, true);
  }
  getPinnedItems() {
    const raw = this.store.state?.config?.pinned_items;
    if (raw === undefined || raw === null) {
      return [];
    }
    return normalizeShortcutArray(raw, false);
  }
  moveShortcutItem(listKey, idx, delta) {
    this.reorderShortcutItems(listKey, idx, idx + delta);
  }
  reorderShortcutItems(
    listKey,
    fromIndex,
    toIndex,
  ) {
    const current = listKey === "dock_items" ? this.getDockItems() : this.getPinnedItems();
    if (
      fromIndex < 0 ||
      toIndex < 0 ||
      fromIndex >= current.length ||
      toIndex >= current.length ||
      fromIndex === toIndex
    ) {
      return;
    }
    const next = current.map((it) => ({ ...it }));
    const [moved] = next.splice(fromIndex, 1);
    next.splice(toIndex, 0, moved);
    this.stageDeviceSetting(listKey, next);
  }
  removeShortcutItem(listKey, idx) {
    const current = listKey === "dock_items" ? this.getDockItems() : this.getPinnedItems();
    if (idx < 0 || idx >= current.length) return;
    const next = current.filter((_, i) => i !== idx).map((it) => ({ ...it }));
    this.stageDeviceSetting(listKey, next);
  }
  resetDockItemsToDefault() {
    this.stageDeviceSetting("dock_items", defaultDockShortcutItems());
    this.store.showToast("Restored default App Dock");
  }
  requestResetDockItems() {
    this.store.openConfirm({
      kind: "reset_dock",
      title: this.store.t("confirm.reset_dock.title"),
      consequence: this.store.t("confirm.reset_dock.body"),
      confirmLabel: this.store.t("confirm.reset_dock.confirm"),
      danger: true,
      blastRadiusCount: 1,
      onConfirm: () => {
        this.resetDockItemsToDefault();
      },
    });
  }
  toggleNativeDockApp(routeToken, enabled) {
    const target = String(routeToken || "").trim().toLowerCase();
    if (!NATIVE_DOCK_APP_TOKENS.includes(target)) return;
    const current = this.getDockItems().map((it) => ({ ...it }));
    if (!enabled) {
      const next = current.filter((it) => !(it.kind === "route" && it.target === target));
      this.stageDeviceSetting("dock_items", next);
      return;
    }
    if (current.some((it) => it.kind === "route" && it.target === target)) {
      return;
    }
    if (current.length >= MAX_DOCK_ITEMS) {
      this.store.showToast(`App Dock supports up to ${MAX_DOCK_ITEMS} shortcuts`, true);
      return;
    }
    current.push({
      kind: "route",
      target,
      action: "",
      label: "",
      icon: "",
      confirm: false,
    });
    this.stageDeviceSetting("dock_items", current);
  }
  openAppConfigModal(app) {
    this.store.returnToPinnedModal = false;
    if (this.store.shortcutModal.open) {
      this.store.shortcutModal = { ...this.store.shortcutModal, open: false };
    }
    this.store.appConfigModal = { open: true, app };
    this.store.host.requestUpdate();
  }
  closeAppConfigModal() {
    this.store.appConfigModal = { open: false, app: null };
    this.store.host.requestUpdate();
  }
  openShortcutModal(
    listKey,
    editIndex = null,
  ) {
    openShortcutModalOp(this.store, listKey, editIndex);
  }
  closeShortcutModal() {
    const reopenPinned = this.store.returnToPinnedModal;
    this.store.returnToPinnedModal = false;
    this.store.shortcutModal = { ...this.store.shortcutModal, open: false };
    if (reopenPinned) {
      this.store.appConfigModal = { open: true, app: "pinned" };
    }
    this.store.host.requestUpdate();
  }
  saveShortcutModal() {
    saveShortcutModalOp(this.store);
  }
  // ---------- Colors & Wallpapers ----------
  applyDeviceCustomColor(hex, switchColorProfile = true) {
    if (!isValidHexColor(hex)) return;
    this.stageDeviceSetting("device_custom_color", hex.toUpperCase());
    if (switchColorProfile) {
      this.stageDeviceSetting("color_profile", "Custom");
    }
  }
  deleteCustomPalette(hex) {
    const target = hex.toUpperCase();
    const next = (this.store.state?.system_config?.custom_palettes || []).filter(
      (p) => p.hex.toUpperCase() !== target,
    );
    this.stageSystemSetting("custom_palettes", next);
  }
  async uploadWallpaper(scope) {
    const file =
      scope === "device"
        ? this.store.selectedDeviceWallpaperFile
        : this.store.selectedSystemWallpaperFile;
    if (!file) {
      this.store.showToast("Choose an image file first", true);
      return;
    }
    const targetSubentryId = scope === "device" ? this.store.activeSubentryId : undefined;
    if (scope === "device" && !targetSubentryId) {
      this.store.showToast("Choose a Device first", true);
      return;
    }
    this.store.uploadScope = scope;
    this.store.uploadBusy = true;
    this.store.uploadPercent = 0;
    this.store.host.requestUpdate();
    try {
      const result = await this.store.ws.uploadWallpaperMultipart({
        scope,
        subentryId: targetSubentryId,
        file,
        onProgress: (pct) => {
          this.store.uploadPercent = pct;
          this.store.host.requestUpdate();
        },
      });
      if (scope === "device") {
        this.store.selectedDeviceWallpaperFile = null;
      } else {
        this.store.selectedSystemWallpaperFile = null;
      }
      const inputId = scope === "device" ? "input-upload-wp" : "input-upload-sys-wp";
      this.store.mergeDomRevert({ [inputId]: "" });
      if (this.store.state) {
        if (
          result.wallpapers &&
          scope === "device" &&
          this.store.activeSubentryId === targetSubentryId
        ) {
          this.store.state = { ...this.store.state, wallpapers: result.wallpapers };
        }
        if (result.system_wallpapers) {
          this.store.state = {
            ...this.store.state,
            system_wallpapers: result.system_wallpapers,
          };
        }
      }
      await this.store.refreshState();
      this.store.showToast("Uploaded wallpaper");
    } catch (err) {
      this.store.showToast(formatWsError(err, "Wallpaper upload failed"), true);
    } finally {
      this.store.uploadBusy = false;
      this.store.uploadScope = null;
      this.store.uploadPercent = 0;
      this.store.host.requestUpdate();
    }
  }
          clearPendingWallpaperCycle(targetSubentryId) {
    const bucket = this.store.pendingDeviceBuckets.get(targetSubentryId);
    if (!bucket || !("wallpaper_cycle_minutes" in bucket.patch)) return;
    delete bucket.patch.wallpaper_cycle_minutes;
    delete bucket.previousValues.wallpaper_cycle_minutes;
    delete bucket.previousValues["__dom:cfg-wallpaper_cycle_minutes"];
    if (Object.keys(bucket.patch).length === 0) {
      if (bucket.timer) clearTimeout(bucket.timer);
      this.store.pendingDeviceBuckets.delete(targetSubentryId);
    }
  }
  async selectWallpaperSource(sourceId) {
    const targetSubentryId = this.store.activeSubentryId;
    if (!targetSubentryId) return;
    this.clearPendingWallpaperCycle(targetSubentryId);
    try {
      const res = await this.store.ws.runDeviceCommand(targetSubentryId, "select_wallpaper", {
        source_id: sourceId,
      });
      if (res && this.store.activeSubentryId === targetSubentryId) {
        this.store.ingestPayload(res, false);
      }
      this.store.showToast(sourceId ? "Wallpaper applied" : "Wallpaper turned off");
    } catch (err) {
      this.store.showToast(formatWsError(err, "Could not select wallpaper"), true);
    }
  }
  async setWallpaperRotation(minutes) {
    const targetSubentryId = this.store.activeSubentryId;
    if (!targetSubentryId) return;
    const cleanMins = Math.max(0, Math.round(Number(minutes) || 0));
    this.clearPendingWallpaperCycle(targetSubentryId);
    this.stageDeviceSetting("wallpaper_cycle_minutes", cleanMins, "cfg-wallpaper_cycle_minutes", 0);
    await this.flushDeviceBucket(targetSubentryId);
  }
  async toggleWallpaperFav(sourceId) {
    const targetSubentryId = this.store.activeSubentryId;
    if (!targetSubentryId) return;
    try {
      const res = await this.store.ws.runDeviceCommand(
        targetSubentryId,
        "toggle_wallpaper_favorite",
        { source_id: sourceId },
      );
      if (res && this.store.activeSubentryId === targetSubentryId) {
        this.store.ingestPayload(res, false);
      }
    } catch (err) {
      this.store.showToast(formatWsError(err, "Could not update favorite"), true);
    }
  }
  async setAllWallpaperFavorites(sourceIds) {
    const targetSubentryId = this.store.activeSubentryId;
    if (!targetSubentryId) return;
    try {
      const res = await this.store.ws.runDeviceCommand(
        targetSubentryId,
        "toggle_wallpaper_favorite",
        { source_ids: [...sourceIds] },
      );
      if (res && this.store.activeSubentryId === targetSubentryId) {
        this.store.ingestPayload(res, false);
      }
      this.store.showToast(
        sourceIds.length > 0 ? "Starred all wallpapers" : "Cleared starred wallpapers",
      );
    } catch (err) {
      this.store.showToast(formatWsError(err, "Could not update favorites"), true);
    }
  }
  async deleteWallpaper(sourceId) {
    const cleanId = String(sourceId || "").trim();
    if (!cleanId) return;
    try {
      const res = await this.store.ws.runSystemCommand(
        "delete_wallpaper",
        { source_id: cleanId },
        this.store.activeSubentryId || null,
      );
      if (res) this.store.ingestPayload(res, false);
      this.store.showToast("Deleted wallpaper");
    } catch (err) {
      this.store.showToast(formatWsError(err, "Could not delete wallpaper"), true);
    }
  }
  requestDeleteWallpaper(sourceId, name) {
    const cleanId = String(sourceId || "").trim();
    if (!cleanId) return;
    const label = String(name || cleanId).trim();
    this.store.openConfirm({
      kind: "delete_wallpaper",
      title: this.store.t("confirm.delete_wallpaper.title", { name: label }),
      consequence: this.store.t("confirm.delete_wallpaper.body"),
      confirmLabel: this.store.t("confirm.delete_wallpaper.confirm"),
      danger: true,
      onConfirm: async() => {
        await this.deleteWallpaper(cleanId);
      },
    });
  }
  // ---------- System String Lists, Volume Overrides, Remote Groups & Camera Preview ----------
  updateStringListRow(key, index, value) {
    updateStringListRowOp(this.store, key, index, value);
  }
  addStringListRow(key, defaultEntity = "", maxLen) {
    addStringListRowOp(this.store, key, defaultEntity, maxLen);
  }
  removeStringListRow(key, index) {
    removeStringListRowOp(this.store, key, index);
  }
  moveStringListRow(key, index, direction) {
    reorderStringListRowsOp(this.store, key, index, index + direction);
  }
  reorderStringListRows(key, fromIndex, toIndex) {
    reorderStringListRowsOp(this.store, key, fromIndex, toIndex);
  }
  addVolumeOverrideRow() {
    addVolumeOverrideRowOp(this.store);
  }
  updateVolumeOverrideRow(index, field, value) {
    updateVolumeOverrideRowOp(this.store, index, field, value);
  }
  removeVolumeOverrideRow(index) {
    removeVolumeOverrideRowOp(this.store, index);
  }
  addRemoteGroupRow() {
    addRemoteGroupRowOp(this.store);
  }
  updateRemoteGroupField(groupId, field, value) {
    updateRemoteGroupFieldOp(this.store, groupId, field, value);
  }
  toggleRemoteInGroup(groupId, remoteEntity) {
    toggleRemoteInGroupOp(this.store, groupId, remoteEntity);
  }
  removeRemoteGroupRow(groupId) {
    removeRemoteGroupRowOp(this.store, groupId);
  }
  clearCameraPreviewCache() {
    this.cameraPreviewCache.clear();
  }
  async previewCamera(cameraEntity, bustCache = false) {
    const cleanEntity = String(cameraEntity || "").trim();
    if (!cleanEntity) {
      this.closeCameraPreview();
      return;
    }
    const now = Date.now();
    const cached = this.cameraPreviewCache.get(cleanEntity);
    if (!bustCache && cached && cached.expiresAtMs > now) {
      this.store.activeCameraPreviewEntity = cleanEntity;
      this.store.cameraPreviewUrl = cached.url;
      this.store.host.requestUpdate();
      return;
    }
    try {
      const minted = await this.store.ws.mintCameraPreviewUrl(cleanEntity);
      const ttlSec = Math.max(30, Number(minted.expires_in || 600) - 30);
      this.cameraPreviewCache.set(cleanEntity, {
        url: minted.preview_url,
        expiresAtMs: now + ttlSec * 1000,
      });
      const sep = minted.preview_url.includes("?") ? "&" : "?";
      this.store.activeCameraPreviewEntity = cleanEntity;
      this.store.cameraPreviewUrl = bustCache
        ? `${minted.preview_url}${sep}_ts=${now}`
        : minted.preview_url;
      this.store.host.requestUpdate();
    } catch (err) {
      this.store.showToast(formatWsError(err, "Could not load camera preview"), true);
    }
  }
  closeCameraPreview() {
    this.store.activeCameraPreviewEntity = "";
    this.store.cameraPreviewUrl = "";
    this.store.host.requestUpdate();
  }
  async testDoorbellSpeaker() {
    const cams = (this.store.state?.system_config?.camera_entities || [])
      .map((c) => String(c || "").trim())
      .filter(Boolean);
    if (!cams[0]) {
      this.store.showToast("Add a camera in Shared entities first", true);
      return;
    }
    if (!this.store.doorbellTestSubentryId) {
      this.store.showToast("Choose a Device to test from", true);
      return;
    }
    const message = this.store.doorbellTestReply.trim() || "Testing Latter doorbell audio.";
    await this.flushSystemSettings();
    try {
      const res = await this.store.ws.runSystemCommand(
        "test_doorbell_speaker",
        {
          subentry_id: this.store.doorbellTestSubentryId,
          camera_entity: cams[0],
          message,
        },
        this.store.activeSubentryId || null,
      );
      if (res) this.store.ingestPayload(res, false);
      this.store.showToast("Played test message on door speaker");
    } catch (err) {
      this.store.showToast(formatWsError(err, "Door speaker test failed"), true);
    }
  }
}
__latterExp(__exports, { isCatalogItemSupported: () => isCatalogItemSupported, isProtectedNativeDockItem: () => isProtectedNativeDockItem, overlayPendingBlankListSlots: () => overlayPendingBlankListSlots, overlayDevicePrefsOnSections: () => overlayDevicePrefsOnSections, overlayPendingEntityStates: () => overlayPendingEntityStates, EntityController: () => EntityController });
//# sourceURL=latter-studio/src/state/entity-controller.ts
});
__latterDef("src/state/groups-controller.ts", (__exports, __req) => {
const { formatWsError } = __req("src/api/ws-client.ts");
const { isValidHexColor } = __req("src/utils/format.ts");
/**
 * `store.groups` Controller (`GroupsController`, `D-050`, `D-064` / `Q6`):
 * - Device Groups CRUD, scope toggles (`include_display`, `include_interface`), & baseline updates
 * - Staged `Batch controls` draft state (`batchDraft` + per-Device `Mixed`-safe `batchPillDrafts`)
 *   with **Apply to N Devices** / **Reset** and automatic `Custom` detachment toast
 * - Walk-Around BLE calibration, scanner antenna trim, & Area sensor fusion
 */
function slugifyGroupName(raw) {
  return raw
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "");
}
function parseCsvTokens(raw) {
  return String(raw || "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);
}
class GroupsController {
                   store;
  /** Per-`pref_key` token delta map (`{ [token]: true | false }`) preserving untouched per-Device tokens (`Q6`). */
           batchPillDrafts = new Map();
                   batchEntityDrafts = new Map();
  batchBusy = false;
  constructor(store) {
    this.store = store;
  }
  get batchDraft() {
    return this.store.batchDraft;
  }
  get batchDraftCount() {
    const keys = new Set (this.store.batchDraft.keys());
    for (const [pk, deltas] of this.batchPillDrafts.entries()) {
      if (Object.keys(deltas).length > 0) {
        keys.add(pk);
      }
    }
    for (const ek of this.batchEntityDrafts.keys()) {
      keys.add(`entity:${ek}`);
    }
    return keys.size;
  }
  get hasBatchDraft() {
    return this.batchDraftCount > 0;
  }
  // ---------- Device Groups CRUD & Baseline Updates ----------
  toggleNewGroupForm(open) {
    const nextOpen = open !== undefined ? Boolean(open) : !this.store.newGroupFormOpen;
    this.store.newGroupFormOpen = nextOpen;
    if (!nextOpen) {
      this.store.newGroupName = "";
      this.store.newGroupDesc = "";
      this.store.newGroupSourceSubentryId = "";
      this.store.newGroupIncludeDisplay = false;
      this.store.newGroupIncludeInterface = false;
    }
    this.store.host.requestUpdate();
    if (nextOpen && typeof globalThis.requestAnimationFrame === "function") {
      globalThis.requestAnimationFrame(() => {
        const root =
          (this.store.host).renderRoot ||
          this.store.host.shadowRoot;
        const inputEl = root?.getElementById("new-group-name");
        if (inputEl && typeof inputEl.focus === "function") {
          try {
            inputEl.focus({ preventScroll: true });
          } catch {
            inputEl.focus();
          }
        }
      });
    }
  }
  async createDeviceGroup() {
    const name = this.store.newGroupName.trim();
    const description = this.store.newGroupDesc.trim();
    const sourceSubentryId = this.store.newGroupSourceSubentryId.trim();
    if (!name) {
      this.store.showToast("Enter a Device group name", true);
      return;
    }
    try {
      const payload = { name, description };
      if (sourceSubentryId) {
        payload.source_subentry_id = sourceSubentryId;
      }
      if (this.store.newGroupIncludeDisplay) {
        payload.include_display = true;
      }
      if (this.store.newGroupIncludeInterface) {
        payload.include_interface = true;
      }
      const res = await this.store.ws.runSystemCommand(
        "create_device_group",
        payload,
        this.store.activeSubentryId || null,
      );
      const createdId = slugifyGroupName(name) || "group";
      this.store.newGroupFormOpen = false;
      this.store.newGroupName = "";
      this.store.newGroupDesc = "";
      this.store.newGroupSourceSubentryId = "";
      this.store.newGroupIncludeDisplay = false;
      this.store.newGroupIncludeInterface = false;
      this.store.openGroupIds.add(createdId);
      if (res) this.store.ingestPayload(res, false);
      this.store.showToast(`Created group "${name}"`);
    } catch (err) {
      this.store.showToast(formatWsError(err, "Could not create Device group"), true);
    }
  }
  openSaveGroupModal() {
    if (!this.store.activeSubentryId) return;
    const devTitle = this.store.state?.title || "";
    this.store.saveGroupModal = {
      open: true,
      subentryId: this.store.activeSubentryId,
      name: "",
      description: devTitle ? `Saved from ${devTitle}` : "",
      includeDisplay: false,
      includeInterface: false,
      busy: false,
    };
    this.store.host.requestUpdate();
  }
  closeSaveGroupModal() {
    this.store.saveGroupModal = { ...this.store.saveGroupModal, open: false, busy: false };
    this.store.host.requestUpdate();
  }
  async confirmSaveGroupModal() {
    const name = this.store.saveGroupModal.name.trim();
    const description = this.store.saveGroupModal.description.trim();
    const sourceSubentryId = this.store.saveGroupModal.subentryId || this.store.activeSubentryId;
    const includeDisplay = Boolean(this.store.saveGroupModal.includeDisplay);
    const includeInterface = Boolean(this.store.saveGroupModal.includeInterface);
    if (!name) {
      this.store.showToast("Enter a Device group name", true);
      return;
    }
    if (!sourceSubentryId) {
      this.store.showToast("Choose a Device first", true);
      return;
    }
    this.store.saveGroupModal = { ...this.store.saveGroupModal, busy: true };
    this.store.host.requestUpdate();
    try {
      const payload = {
        name,
        description,
        source_subentry_id: sourceSubentryId,
        assign_source: true,
      };
      if (includeDisplay) payload.include_display = true;
      if (includeInterface) payload.include_interface = true;
      const res = await this.store.ws.runSystemCommand(
        "create_device_group",
        payload,
        this.store.activeSubentryId || null,
      );
      this.store.saveGroupModal = {
        open: false,
        subentryId: "",
        name: "",
        description: "",
        includeDisplay: false,
        includeInterface: false,
        busy: false,
      };
      if (res) this.store.ingestPayload(res, false);
      else this.store.host.requestUpdate();
      this.store.showToast(`Saved custom group "${name}"`);
    } catch (err) {
      this.store.saveGroupModal = { ...this.store.saveGroupModal, busy: false };
      this.store.host.requestUpdate();
      this.store.showToast(formatWsError(err, "Could not save custom Device group"), true);
    }
  }
  async deleteDeviceGroup(groupId) {
    const cleanId = String(groupId || "").trim();
    if (!cleanId) return;
    try {
      const res = await this.store.ws.runSystemCommand(
        "delete_device_group",
        { group_id: cleanId },
        this.store.activeSubentryId || null,
      );
      this.store.openGroupIds.delete(cleanId);
      this.store.groupCopySourceDrafts.delete(cleanId);
      if (this.store.batchTargetFilter === `group:${cleanId}`) {
        this.store.batchTargetFilter = "all";
        this.resetBatchDraft();
      }
      if (res) this.store.ingestPayload(res, false);
      this.store.showToast("Deleted Device group");
    } catch (err) {
      this.store.showToast(formatWsError(err, "Could not delete Device group"), true);
    }
  }
  requestDeleteDeviceGroup(groupId, groupName, memberCount) {
    const cleanId = String(groupId || "").trim();
    if (!cleanId) return;
    const grp = this.store.state?.device_groups?.find((g) => g.id === cleanId);
    const name = groupName || grp?.name || cleanId;
    const count =
      memberCount ??
      (this.store.state?.system_devices || []).filter(
        (d) => d.kind !== "ble_tag" && d.device_group === cleanId,
      ).length;
    this.store.openConfirm({
      kind: "delete_group",
      title: this.store.t("confirm.delete_group.title", { name }),
      consequence: this.store.t("confirm.delete_group.body"),
      confirmLabel: this.store.t("confirm.delete_group.confirm"),
      danger: true,
      blastRadiusCount: count > 0 ? count : null,
      onConfirm: async() => {
        await this.deleteDeviceGroup(cleanId);
      },
    });
  }
  async resetDeviceGroupPreset(groupId, groupName) {
    const cleanId = String(groupId || "").trim();
    if (!cleanId) return;
    const grp = this.store.state?.device_groups?.find((g) => g.id === cleanId);
    const name = groupName || grp?.name || cleanId;
    try {
      const res = await this.store.ws.runSystemCommand(
        "update_group_baseline",
        {
          group_id: cleanId,
          reset_to_default: true,
        },
        this.store.activeSubentryId || null,
      );
      if (res) this.store.ingestPayload(res, false);
      this.store.showToast(this.store.t("groups.reset_preset_toast", { name }));
    } catch (err) {
      this.store.showToast(formatWsError(err, "Could not reset group preset"), true);
    }
  }
  requestResetDeviceGroup(groupId, groupName, memberCount) {
    const cleanId = String(groupId || "").trim();
    if (!cleanId) return;
    const grp = this.store.state?.device_groups?.find((g) => g.id === cleanId);
    const name = groupName || grp?.name || cleanId;
    const count =
      memberCount ??
      (this.store.state?.system_devices || []).filter(
        (d) => d.kind !== "ble_tag" && d.device_group === cleanId,
      ).length;
    this.store.openConfirm({
      kind: "reset_group",
      title: this.store.t("confirm.reset_group.title", { name }),
      consequence: this.store.t("confirm.reset_group.body"),
      confirmLabel: this.store.t("confirm.reset_group.confirm"),
      danger: false,
      blastRadiusCount: count > 0 ? count : null,
      onConfirm: async() => {
        await this.resetDeviceGroupPreset(cleanId, name);
      },
    });
  }
  async updateGroupBaseline(groupId, patch) {
    if (!groupId) return;
    try {
      const res = await this.store.ws.runSystemCommand(
        "update_group_baseline",
        {
          group_id: groupId,
          config: patch,
        },
        this.store.activeSubentryId || null,
      );
      if (res) this.store.ingestPayload(res, false);
      this.store.announcePolite(this.store.t("shell.saved_status"));
    } catch (err) {
      this.store.showToast(formatWsError(err, "Could not update group baseline"), true);
    }
  }
  async updateGroupScope(
    groupId,
    scope,
  ) {
    if (!groupId) return;
    try {
      const res = await this.store.ws.runSystemCommand(
        "update_group_baseline",
        {
          group_id: groupId,
          ...scope,
        },
        this.store.activeSubentryId || null,
      );
      if (res) this.store.ingestPayload(res, false);
      this.store.announcePolite(this.store.t("shell.saved_status"));
    } catch (err) {
      this.store.showToast(formatWsError(err, "Could not update group scope"), true);
    }
  }
  async copyDeviceToGroupBaseline(
    groupId,
    sourceSubentryId,
    copyKeys,
  ) {
    if (!groupId || !sourceSubentryId) {
      this.store.showToast("Choose a Device to copy settings from", true);
      return;
    }
    try {
      const payload = {
        group_id: groupId,
        source_subentry_id: sourceSubentryId,
      };
      if (copyKeys && copyKeys.length) {
        payload.copy_keys = copyKeys;
      }
      const res = await this.store.ws.runSystemCommand(
        "update_group_baseline",
        payload,
        this.store.activeSubentryId || null,
      );
      if (res) this.store.ingestPayload(res, false);
      this.store.showToast("Copied Device settings into group baseline");
    } catch (err) {
      this.store.showToast(formatWsError(err, "Could not copy Device settings"), true);
    }
  }
  // ---------- Staged Batch Controls (`Q6` / `D-064`) ----------
  resolvedBatchTargetId() {
    const filter = this.store.batchTargetFilter || "all";
    if (filter.startsWith("group:")) return filter.slice(6);
    return filter;
  }
  setBatchTargetFilter(nextFilter) {
    const cleaned = String(nextFilter || "all").trim() || "all";
    if (this.store.batchTargetFilter === cleaned) return;
    this.store.batchTargetFilter = cleaned;
    this.resetBatchDraft();
  }
  matchingBatchDevices() {
    const filter = this.store.batchTargetFilter || "all";
    const devs = (this.store.state?.system_devices || []).filter((d) => d.kind !== "ble_tag");
    return devs.filter((d) => {
      if (filter === "all") return true;
      if (filter === "online") return Boolean(d.is_online);
      if (filter === "roaming") return Boolean(d.is_roaming);
      if (filter === "stationary") return !d.is_roaming;
      const grpId = filter.startsWith("group:") ? filter.slice(6) : filter;
      return (d.device_group || "custom") === grpId;
    });
  }
  filteredControlTargets(ctrl) {
    const filter = this.store.batchTargetFilter || "all";
    return (ctrl.targets || []).filter((t) => {
      if (filter === "all") return true;
      if (filter === "online") return Boolean(t.is_online);
      if (filter === "roaming") return Boolean(t.is_roaming);
      if (filter === "stationary") return !t.is_roaming;
      const grpId = filter.startsWith("group:") ? filter.slice(6) : filter;
      return (t.device_group || "custom") === grpId;
    });
  }
  filteredControlEntityIds(ctrl) {
    return this.filteredControlTargets(ctrl)
      .map((t) => t.entity_id || "")
      .filter(Boolean);
  }
  getEffectiveBatchValue(ctrl)
    {
    const prefKey = ctrl.pref_key || "";
    if (prefKey && this.store.batchDraft.has(prefKey)) {
      const raw = this.store.batchDraft.get(prefKey);
      const valStr =
        ctrl.domain === "switch" ? (raw ? "on" : "off") : String(raw ?? "");
      return { value: valStr, mixed: false, staged: true };
    }
    const entKey = ctrl.key || ctrl.canonical_key || "";
    if (!prefKey && entKey && this.batchEntityDrafts.has(entKey)) {
      const entDraft = this.batchEntityDrafts.get(entKey);
      const valStr =
        entDraft.action === "turn_on"
          ? "on"
          : entDraft.action === "turn_off"
            ? "off"
            : entDraft.option !== undefined
              ? entDraft.option
              : String(entDraft.level ?? "");
      return { value: valStr, mixed: false, staged: true };
    }
    const targets = this.filteredControlTargets(ctrl);
    if (targets.length === 0) {
      return { value: String(ctrl.state ?? ""), mixed: false, staged: false };
    }
    const unique = new Set(targets.map((t) => String(t.state ?? "")));
    if (unique.size > 1) {
      return { value: String(targets[0].state ?? ""), mixed: true, staged: false };
    }
    return { value: String(targets[0].state ?? ""), mixed: false, staged: false };
  }
          applyTokenDeltasToCsv(
    baseCsv,
    deltas,
    canonicalOrder,
  ) {
    const current = parseCsvTokens(baseCsv);
    const active = new Set(current);
    for (const [tok, wantOn] of Object.entries(deltas)) {
      if (wantOn) active.add(tok);
      else active.delete(tok);
    }
    // Preserve each target Device's existing relative token order first, appending newly enabled tokens in canonical order.
    const preserved = current.filter((tok) => active.has(tok));
    const preservedSet = new Set(preserved);
    const appended = canonicalOrder.filter((tok) => active.has(tok) && !preservedSet.has(tok));
    const extras = Array.from(active).filter(
      (tok) => !preservedSet.has(tok) && !appended.includes(tok),
    );
    return [...preserved, ...appended, ...extras].join(",");
  }
  getEffectiveBatchPillStates(ctrl) {
    const prefKey = ctrl.pref_key || "";
    const options = ctrl.options || [];
    const labels = ctrl.option_labels || {};
    const targets = this.filteredControlTargets(ctrl);
    const deltas = (prefKey && this.batchPillDrafts.get(prefKey)) || {};
    const explicitCsv =
      prefKey && this.store.batchDraft.has(prefKey)
        ? String(this.store.batchDraft.get(prefKey) ?? "")
        : null;
    return options.map((token) => {
      const label = labels[token] || token;
      if (explicitCsv !== null) {
        const set = new Set(parseCsvTokens(explicitCsv));
        return {
          token,
          label,
          state: set.has(token) ? "on" : "off",
          staged: true,
        };
      }
      if (token in deltas) {
        return {
          token,
          label,
          state: deltas[token] ? "on" : "off",
          staged: true,
        };
      }
      if (targets.length === 0) {
        return { token, label, state: "off", staged: false };
      }
      let onCount = 0;
      for (const t of targets) {
        if (parseCsvTokens(t.state).includes(token)) {
          onCount += 1;
        }
      }
      const state =
        onCount === 0 ? "off" : onCount === targets.length ? "on" : "mixed";
      return { token, label, state, staged: false };
    });
  }
  stageBatchSetting(key, value) {
    const cleanKey = String(key || "").trim();
    if (!cleanKey) return;
    this.batchPillDrafts.delete(cleanKey);
    this.store.batchDraft.set(cleanKey, value);
    this.store.host.requestUpdate();
  }
  stageBatchColor(ctrl, hex) {
    const cleaned = String(hex || "").trim().toUpperCase();
    if (!ctrl.pref_key || !isValidHexColor(cleaned)) return;
    this.store.batchDraft.set(ctrl.pref_key, cleaned);
    this.store.batchDraft.set("color_profile", "Custom");
    this.store.host.requestUpdate();
  }
  stageBatchEntityControl(
    ctrl,
    mutation,
  ) {
    if (ctrl.pref_key) {
      if (mutation.action !== undefined) {
        this.stageBatchSetting(ctrl.pref_key, mutation.action === "turn_on");
      } else if (mutation.option !== undefined) {
        this.stageBatchSetting(ctrl.pref_key, mutation.option);
      } else if (mutation.level !== undefined && Number.isFinite(mutation.level)) {
        this.stageBatchSetting(ctrl.pref_key, mutation.level);
      }
      return;
    }
    const entKey = ctrl.key || ctrl.canonical_key || ctrl.name;
    if (!entKey) return;
    this.batchEntityDrafts.set(entKey, { ctrl, ...mutation });
    this.store.host.requestUpdate();
  }
  /**
   * Stages a per-token pill toggle across matching target Devices (`Q6`).
   * Never copies `states[0]` over `Mixed` target Devices: untouched tokens stay intact per Device.
   */
  stageBatchPillToggle(
    ctrl,
    rawToken,
    forceEnabled,
  ) {
    const prefKey = ctrl.pref_key || "";
    const token = String(rawToken || "").trim();
    if (!prefKey || !token) return;
    const pillStates = this.getEffectiveBatchPillStates(ctrl);
    const currentPill = pillStates.find((p) => p.token === token);
    const wantOn =
      forceEnabled !== undefined
        ? Boolean(forceEnabled)
        : currentPill?.state !== "on";
    const targets = this.filteredControlTargets(ctrl);
    const order = ctrl.options || [];
    const existingDeltas = { ...(this.batchPillDrafts.get(prefKey) || {}) };
    // If a full CSV override was previously staged on `batchDraft`, fold it into per-token deltas first.
    if (this.store.batchDraft.has(prefKey)) {
      const fullSet = new Set(parseCsvTokens(String(this.store.batchDraft.get(prefKey) ?? "")));
      for (const opt of order) {
        existingDeltas[opt] = fullSet.has(opt);
      }
      this.store.batchDraft.delete(prefKey);
    }
    const candidateDeltas = {
      ...existingDeltas,
      [token]: wantOn,
    };
    const minRequired = ctrl.min ?? 0;
    if (!wantOn && minRequired > 0 && targets.length > 0) {
      const violatesMin = targets.some((t) => {
        const nextCsv = this.applyTokenDeltasToCsv(t.state, candidateDeltas, order);
        return parseCsvTokens(nextCsv).length < minRequired;
      });
      if (violatesMin) {
        const noun =
          prefKey === "tools_items"
            ? "tool"
            : prefKey === "games_items"
              ? "game"
              : "category";
        this.store.showToast(this.store.t("common.keep_one_enabled", { noun }), true);
        return;
      }
    }
    // Prune delta if it matches the server's unmodified state on every matching target Device.
    if (
      targets.length > 0 &&
      targets.every((t) => parseCsvTokens(t.state).includes(token) === wantOn)
    ) {
      delete candidateDeltas[token];
    }
    if (Object.keys(candidateDeltas).length === 0) {
      this.batchPillDrafts.delete(prefKey);
    } else {
      this.batchPillDrafts.set(prefKey, candidateDeltas);
    }
    this.store.host.requestUpdate();
  }
  resetBatchDraft() {
    this.store.batchDraft.clear();
    this.batchPillDrafts.clear();
    this.batchEntityDrafts.clear();
    this.store.host.requestUpdate();
  }
  previewBatchDetachmentCount() {
    if (!this.hasBatchDraft) return 0;
    const hasDetachingKey =
      this.batchPillDrafts.size > 0 ||
      this.batchEntityDrafts.size > 0 ||
      Array.from(this.store.batchDraft.keys()).some((key) => {
        const spec = this.store.entity.getPrefSpec(key);
        return !spec || spec.group_tier !== null;
      });
    if (!hasDetachingKey) return 0;
    return this.matchingBatchDevices().filter(
      (d) => Boolean(d.device_group && d.device_group !== "custom"),
    ).length;
  }
  requestApplyBatchDraft() {
    if (!this.hasBatchDraft || this.batchBusy) return;
    const targets = this.matchingBatchDevices();
    if (targets.length === 0) {
      this.store.showToast(this.store.t("batch.no_targets"), true);
      return;
    }
    if (targets.length === 1) {
      void this.applyBatchDraft();
      return;
    }
    const count = targets.length;
    const settingCount = this.batchDraftCount;
    this.store.openConfirm({
      kind: "apply_batch",
      title: this.store.t("confirm.apply_batch.title", { count }),
      consequence: this.store.t("confirm.apply_batch.body", {
        settingCount,
        count,
      }),
      confirmLabel: this.store.t("confirm.apply_batch.confirm"),
      danger: false,
      blastRadiusCount: count,
      onConfirm: async() => {
        await this.applyBatchDraft();
      },
    });
  }
  async applyBatchDraft() {
    if (!this.hasBatchDraft || this.batchBusy) return;
    const matchedDevices = this.matchingBatchDevices();
    if (matchedDevices.length === 0) {
      this.store.showToast(this.store.t("batch.no_targets"), true);
      return;
    }
    const beforeGroups = new Map();
    const subentryBySlug = new Map();
    for (const d of matchedDevices) {
      subentryBySlug.set(d.device_slug, d.subentry_id);
      if (d.device_group && d.device_group !== "custom") {
        beforeGroups.set(d.subentry_id, { title: d.title, group: d.device_group });
      }
    }
    const uniformPatch = Object.fromEntries(
      this.store.batchDraft.entries(),
    );
    const perDevicePatches = new Map();
    const controls = this.store.state?.system_controls || [];
    for (const [prefKey, deltas] of this.batchPillDrafts.entries()) {
      if (Object.keys(deltas).length === 0) continue;
      const ctrl = controls.find((c) => c.pref_key === prefKey);
      const order = ctrl?.options || [];
      const targets = ctrl ? this.filteredControlTargets(ctrl) : [];
      if (targets.length === 0) continue;
      const resolvedPerTarget = [];
      for (const t of targets) {
        const subId = t.subentry_id || (t.device_slug ? subentryBySlug.get(t.device_slug) : "") || "";
        const csv = this.applyTokenDeltasToCsv(t.state, deltas, order);
        if (subId) {
          resolvedPerTarget.push({ subentryId: subId, csv });
        }
      }
      if (resolvedPerTarget.length === 0) continue;
      const distinctCsvs = new Set(resolvedPerTarget.map((r) => r.csv));
      if (distinctCsvs.size === 1) {
        uniformPatch[prefKey] = resolvedPerTarget[0].csv;
      } else {
        for (const item of resolvedPerTarget) {
          const cur = perDevicePatches.get(item.subentryId) || {};
          cur[prefKey] = item.csv;
          perDevicePatches.set(item.subentryId, cur);
        }
      }
    }
    const entityActions = Array.from(this.batchEntityDrafts.values());
    this.batchBusy = true;
    this.store.host.requestUpdate();
    try {
      let lastRes = null;
      if (Object.keys(uniformPatch).length > 0) {
        lastRes = await this.store.ws.runSystemCommand(
          "apply_batch_device_setting",
          {
            target: this.store.batchTargetFilter || "all",
            config: uniformPatch,
          },
          this.store.activeSubentryId || null,
        );
      }
      for (const [subentryId, devPatch] of perDevicePatches.entries()) {
        const devRes = await this.store.ws.runDeviceCommand(subentryId, "save_device_config", {
          config: devPatch,
        });
        if (devRes) {
          lastRes = devRes;
        }
      }
      for (const entAct of entityActions) {
        const entityIds = this.filteredControlEntityIds(entAct.ctrl);
        if (!entityIds.length) continue;
        const body = { entity_ids: entityIds };
        if (entAct.action !== undefined) body.action = entAct.action;
        if (entAct.option !== undefined) body.option = entAct.option;
        if (entAct.level !== undefined) body.level = entAct.level;
        const entRes = await this.store.ws.runSystemCommand(
          "system_entity_action",
          body,
          this.store.activeSubentryId || null,
        );
        if (entRes) {
          lastRes = entRes;
        }
      }
      this.store.batchDraft.clear();
      this.batchPillDrafts.clear();
      this.batchEntityDrafts.clear();
      if (lastRes) {
        this.store.ingestPayload(lastRes, false);
      }
      const afterDevs = this.store.state?.system_devices || [];
      const detachedTitles = [];
      for (const [subId, prev] of beforeGroups.entries()) {
        const cur = afterDevs.find((d) => d.subentry_id === subId);
        if (cur && cur.device_group === "custom" && prev.group !== "custom") {
          detachedTitles.push(prev.title);
        }
      }
      if (detachedTitles.length === 1) {
        this.store.showToast(
          this.store.t("groups.detached_toast", { title: detachedTitles[0] }),
        );
      } else if (detachedTitles.length > 1) {
        this.store.showToast(
          this.store.t("groups.detached_many_toast", { count: detachedTitles.length }),
        );
      } else {
        const count = matchedDevices.length;
        this.store.showToast(
          count === 1
            ? this.store.t("batch.applied_to_one")
            : this.store.t("batch.applied_to_n", { count }),
        );
      }
    } catch (err) {
      this.store.showToast(formatWsError(err, "Could not apply staged batch settings"), true);
    } finally {
      this.batchBusy = false;
      this.store.host.requestUpdate();
    }
  }
  async applyBatchCopyFromDevice(sourceSubentryId, copyKeys) {
    if (!sourceSubentryId || !copyKeys.length) {
      this.store.showToast("Choose a template Device first", true);
      return;
    }
    try {
      const res = await this.store.ws.runSystemCommand(
        "apply_batch_device_setting",
        {
          target: this.store.batchTargetFilter || "all",
          source_subentry_id: sourceSubentryId,
          copy_keys: copyKeys,
        },
        this.store.activeSubentryId || null,
      );
      if (res) this.store.ingestPayload(res, false);
      this.store.showToast("Pushed list from template Device");
    } catch (err) {
      this.store.showToast(formatWsError(err, "Could not copy list across target Devices"), true);
    }
  }
  // ---------- Walk-Around BLE Calibration & Area Sensor Fusion ----------
  selectBleSurveyDevice(subentryId) {
    this.store.bleSurveySubentryId = subentryId;
    this.store.host.requestUpdate();
    void this.store.ensureSubscription(false);
  }
  selectBleCalibrateArea(areaId, fromAreaCard = false) {
    this.store.bleCalibrateAreaId = String(areaId || "");
    if (fromAreaCard) {
      this.store.handoffTargetIds.clear();
      this.store.bleCalibrateHandoffActive = true;
    }
    this.store.host.requestUpdate();
    if (fromAreaCard && typeof globalThis.requestAnimationFrame === "function") {
      globalThis.requestAnimationFrame(() => {
        const root =
          (this.store.host).renderRoot ||
          this.store.host.shadowRoot;
        const cardEl =
          root?.getElementById("card-ble-calibration") ||
          root?.getElementById("ble-calibrate-target-box");
        if (cardEl && typeof cardEl.scrollIntoView === "function") {
          cardEl.scrollIntoView({ behavior: "smooth", block: "start" });
        }
        const selectEl = root?.getElementById(
          "ble-calibrate-area-select",
        );
        if (selectEl && typeof selectEl.focus === "function") {
          try {
            selectEl.focus({ preventScroll: true });
          } catch {
            selectEl.focus();
          }
        }
      });
    }
  }
  toggleBleLiveStream(enabled) {
    if (!enabled) {
      this.store.bleSurveyFrozen.clear();
      for (const dev of this.store.state?.system_devices || []) {
        if (!dev.subentry_id) continue;
        this.store.bleSurveyFrozen.set(dev.subentry_id, {
          rows: (dev.ble_survey_rows || []).map((r) => ({ ...r })),
          packetsSeen: dev.ble_packets_seen ?? 0,
          activeAreaName: dev.active_area_name || "",
        });
      }
      this.store.bleLiveStreamActive = false;
      this.store.host.requestUpdate();
      void this.store.ensureSubscription(false);
      return;
    }
    this.store.bleSurveyFrozen.clear();
    this.store.bleLiveStreamActive = true;
    this.store.host.requestUpdate();
    void this.store.ensureSubscription(false);
  }
  getActiveSurveyDevice() {
    const devs = this.store.state?.system_devices || [];
    const bleDevs = devs.filter((d) => d.ble_tracked || d.kind === "ble_tag");
    return bleDevs.find((d) => d.subentry_id === this.store.bleSurveySubentryId);
  }
  async setBleScannerOffset(scannerSource, offsetDb) {
    const source = String(scannerSource || "").trim();
    if (!source) {
      this.store.showToast("Missing BLE scanner source", true);
      return;
    }
    try {
      const res = await this.store.ws.runSystemCommand(
        "set_ble_scanner_offset",
        { scanner_source: source, offset_db: offsetDb },
        this.store.activeSubentryId || null,
      );
      if (res) {
        if (!this.store.bleLiveStreamActive && Array.isArray(res.system_devices)) {
          const sourceNorm = source.toLowerCase();
          for (const incomingDev of res.system_devices) {
            if (!incomingDev.subentry_id) continue;
            const frozen = this.store.bleSurveyFrozen.get(incomingDev.subentry_id);
            if (!frozen) continue;
            const incomingRow = (incomingDev.ble_survey_rows || []).find(
              (r) => String(r.scanner_source || "").trim().toLowerCase() === sourceNorm,
            );
            if (!incomingRow) continue;
            frozen.rows = frozen.rows.map((r) => {
              if (String(r.scanner_source || "").trim().toLowerCase() !== sourceNorm) {
                return r;
              }
              return {
                ...r,
                offset_db: incomingRow.offset_db,
                effective_rssi: incomingRow.effective_rssi,
              };
            });
          }
        }
        this.store.ingestPayload(res, false);
      }
    } catch (err) {
      this.store.showToast(formatWsError(err, "Could not update BLE scanner offset"), true);
    }
  }
  async captureBleAreaSignature(areaId) {
    const sysDevs = this.store.state?.system_devices;
    const activeDev = Array.isArray(sysDevs)
      ? this.getActiveSurveyDevice() ||
        sysDevs.find((d) => d.ble_tracked || d.kind === "ble_tag")
      : undefined;
    const surveySubentryId = Array.isArray(sysDevs)
      ? activeDev?.subentry_id || ""
      : this.store.bleSurveySubentryId;
    if (!surveySubentryId) {
      this.store.showToast("Select a calibration Device first", true);
      return;
    }
    try {
      const res = await this.store.ws.runSystemCommand(
        "capture_ble_area_signature",
        { area_id: areaId, survey_subentry_id: surveySubentryId },
        this.store.activeSubentryId || null,
      );
      this.store.bleCalibrateHandoffActive = false;
      if (res) this.store.ingestPayload(res, false);
      else this.store.host?.requestUpdate?.();
      this.store.showToast("Captured Area signature");
    } catch (err) {
      this.store.showToast(formatWsError(err, "Signature capture failed"), true);
    }
  }
  async clearBleAreaSignature(areaId) {
    const cleanId = String(areaId || "").trim();
    if (!cleanId) return;
    try {
      const res = await this.store.ws.runSystemCommand(
        "clear_ble_area_signature",
        { area_id: cleanId },
        this.store.activeSubentryId || null,
      );
      if (res) this.store.ingestPayload(res, false);
      this.store.showToast("Cleared Area signature");
    } catch (err) {
      this.store.showToast(formatWsError(err, "Could not clear Area signature"), true);
    }
  }
  requestClearBleAreaSignature(areaId, areaName) {
    const cleanId = String(areaId || "").trim();
    if (!cleanId) return;
    const area = areaName || cleanId;
    this.store.openConfirm({
      kind: "clear_ble_signature",
      title: this.store.t("confirm.clear_ble_signature.title", { area }),
      consequence: this.store.t("confirm.clear_ble_signature.body", { area }),
      confirmLabel: this.store.t("confirm.clear_ble_signature.confirm"),
      danger: true,
      onConfirm: async() => {
        await this.clearBleAreaSignature(cleanId);
      },
    });
  }
  async setAreaFusion(
    areaId,
    update,
  ) {
    try {
      const res = await this.store.ws.runSystemCommand(
        "set_area_fusion",
        { area_id: areaId, ...update },
        this.store.activeSubentryId || null,
      );
      if (res) this.store.ingestPayload(res, false);
      this.store.announcePolite(this.store.t("shell.saved_status"));
    } catch (err) {
      this.store.showToast(formatWsError(err, "Could not update Area fusion"), true);
    }
  }
}
__latterExp(__exports, { GroupsController: () => GroupsController });
//# sourceURL=latter-studio/src/state/groups-controller.ts
});
__latterDef("src/state/tools-controller.ts", (__exports, __req) => {
const { formatWsError } = __req("src/api/ws-client.ts");
const { STUDIO_REV } = __req("src/constants.ts");
const { copyTextToClipboard, defaultThemeHex, fmtDateTime, isValidHexColor, triggerJsonDownload } = __req("src/utils/format.ts");
/**
 * `store.tools` Controller (`ToolsController`, `D-064` / `Q5`, `D-066`):
 * - Shared confirmation dialog orchestration (`confirmModal`, `openConfirm`, `closeConfirm`, `runConfirmedAction`)
 * - Security PIN, HMAC signing key rotation, System & Device diagnostics, & Support version copy
 * - Modals (`colorWheelModal.painted`, `removeModal`, `resetModal`, `addBleModal`)
 * - Discovered `adopt` (with post-adopt jump to `adopted_subentry_id` `E-10`) + `ignore` / `unignore`
 * - Announcements, strict v3 backup/restore, & timezone-formatted System/Device logs
 */
function emptyConfirmModalState() {
  return {
    open: false,
    kind: "",
    title: "",
    consequence: "",
    confirmLabel: "",
    cancelLabel: "",
    danger: true,
    blastRadiusCount: null,
    blastRadiusLabel: "",
    busy: false,
    onConfirm: null,
    onDownloadBackupFirst: null,
  };
}
class ToolsController {
                   store;
  constructor(store) {
    this.store = store;
  }
  // ---------- Shared Confirmation Dialog (`Q5` / `D-064`) ----------
  openConfirm(opts) {
    this.store.confirmModal = {
      open: true,
      kind: opts.kind || "confirm",
      title: opts.title,
      consequence: opts.consequence,
      confirmLabel: opts.confirmLabel,
      cancelLabel: opts.cancelLabel || this.store.t("action.cancel"),
      danger: opts.danger !== false,
      blastRadiusCount: opts.blastRadiusCount ?? null,
      blastRadiusLabel: opts.blastRadiusLabel || "",
      busy: false,
      onConfirm: opts.onConfirm,
      onDownloadBackupFirst: opts.onDownloadBackupFirst ?? null,
    };
    this.store.host.requestUpdate();
  }
  closeConfirm() {
    if (this.store.confirmModal.busy) return;
    this.store.confirmModal = emptyConfirmModalState();
    this.store.host.requestUpdate();
  }
  async runConfirmedAction() {
    const action = this.store.confirmModal.onConfirm;
    if (!action || this.store.confirmModal.busy) return;
    this.store.confirmModal = { ...this.store.confirmModal, busy: true };
    this.store.host.requestUpdate();
    try {
      await action();
      this.store.confirmModal = emptyConfirmModalState();
    } finally {
      if (this.store.confirmModal.busy) {
        this.store.confirmModal = { ...this.store.confirmModal, busy: false };
      }
      this.store.host.requestUpdate();
    }
  }
  // ---------- Security PIN & Signing Key Rotation ----------
  async saveSecurityPin(fromScope) {
    const rawPin = (
      fromScope === "device" ? this.store.devicePinDraft : this.store.systemPinDraft
    ).trim();
    if (!/^\d{4,12}$/.test(rawPin)) {
      this.store.showToast("Security PIN must be 4 to 12 digits", true);
      return;
    }
    const targetSubentryId = fromScope === "device" ? this.store.activeSubentryId : "";
    this.store.pinBusy = true;
    this.store.host.requestUpdate();
    try {
      const payload = { pin: rawPin };
      if (targetSubentryId) payload.subentry_id = targetSubentryId;
      const res = await this.store.ws.runSystemCommand(
        "set_security_pin",
        payload,
        this.store.activeSubentryId || null,
      );
      this.store.devicePinDraft = "";
      this.store.systemPinDraft = "";
      if (res) this.store.ingestPayload(res, false);
      this.store.showToast("Saved security PIN");
    } catch (err) {
      this.store.showToast(formatWsError(err, "Could not save security PIN"), true);
    } finally {
      this.store.pinBusy = false;
      this.store.host.requestUpdate();
    }
  }
  async clearSecurityPin(fromScope) {
    const targetSubentryId = fromScope === "device" ? this.store.activeSubentryId : "";
    this.store.pinBusy = true;
    this.store.host.requestUpdate();
    try {
      const payload = { clear: true };
      if (targetSubentryId) payload.subentry_id = targetSubentryId;
      const res = await this.store.ws.runSystemCommand(
        "set_security_pin",
        payload,
        this.store.activeSubentryId || null,
      );
      this.store.devicePinDraft = "";
      this.store.systemPinDraft = "";
      if (res) this.store.ingestPayload(res, false);
      this.store.showToast("Cleared security PIN");
    } catch (err) {
      this.store.showToast(formatWsError(err, "Could not clear security PIN"), true);
    } finally {
      this.store.pinBusy = false;
      this.store.host.requestUpdate();
    }
  }
  requestClearSecurityPin(fromScope) {
    const displayCount =
      fromScope === "system"
        ? (this.store.state?.system_devices || []).filter((d) => d.kind !== "ble_tag").length
        : 1;
    this.openConfirm({
      kind: "clear_pin",
      title: this.store.t("confirm.clear_pin.title"),
      consequence: this.store.t("confirm.clear_pin.body"),
      confirmLabel: this.store.t("confirm.clear_pin.confirm"),
      danger: true,
      blastRadiusCount: displayCount > 0 ? displayCount : null,
      onConfirm: async() => {
        await this.clearSecurityPin(fromScope);
      },
    });
  }
  async rotateSigningKey() {
    try {
      const res = await this.store.ws.runSystemCommand(
        "rotate_signing_key",
        {},
        this.store.activeSubentryId || null,
      );
      this.store.entity.clearCameraPreviewCache();
      if (res) this.store.ingestPayload(res, false);
      this.store.showToast("Rotated HTTP resource signing key");
    } catch (err) {
      this.store.showToast(formatWsError(err, "Could not rotate signing key"), true);
    }
  }
  requestRotateSigningKey() {
    const displayCount = (this.store.state?.system_devices || []).filter(
      (d) => d.kind !== "ble_tag",
    ).length;
    this.openConfirm({
      kind: "rotate_signing_key",
      title: this.store.t("confirm.rotate_signing_key.title"),
      consequence: this.store.t("confirm.rotate_signing_key.body"),
      confirmLabel: this.store.t("confirm.rotate_signing_key.confirm"),
      danger: true,
      blastRadiusCount: displayCount > 0 ? displayCount : null,
      onConfirm: async() => {
        await this.rotateSigningKey();
      },
    });
  }
  // ---------- Diagnostics & Support Card (`D-066`) ----------
          async resolveConfigEntryId() {
    const fromLinks = this.store.state?.links?.entry_id || "";
    if (fromLinks) return fromLinks;
    const hass = this.store.hass;
    if (!hass) return "";
    try {
      const entries = await hass.callWS ({
        type: "config_entries/get",
        domain: "latter",
      });
      return String(entries?.[0]?.entry_id || "");
    } catch {
      return "";
    }
  }
          async triggerSignedPathDownload(rawPath) {
    const signedPath = await this.store.ws.signHaPath(rawPath, 300);
    const a = document.createElement("a");
    a.href = signedPath;
    a.download = "";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  }
  async downloadDeviceDiagnostics() {
    const entryId = await this.resolveConfigEntryId();
    const latterDeviceId = this.store.state?.links?.latter_device_id || "";
    if (!entryId) {
      this.store.showToast("Diagnostics entry ID is not available", true);
      return;
    }
    const rawPath = latterDeviceId
      ? `/api/diagnostics/config_entry/${encodeURIComponent(entryId)}/device/${encodeURIComponent(latterDeviceId)}`
      : `/api/diagnostics/config_entry/${encodeURIComponent(entryId)}`;
    try {
      await this.triggerSignedPathDownload(rawPath);
    } catch (err) {
      this.store.showToast(formatWsError(err, "Could not download diagnostics"), true);
    }
  }
  async downloadSystemDiagnostics() {
    const entryId = await this.resolveConfigEntryId();
    if (!entryId) {
      this.store.showToast("Diagnostics entry ID is not available", true);
      return;
    }
    const rawPath = `/api/diagnostics/config_entry/${encodeURIComponent(entryId)}`;
    try {
      await this.triggerSignedPathDownload(rawPath);
    } catch (err) {
      this.store.showToast(formatWsError(err, "Could not download System diagnostics"), true);
    }
  }
  formatSystemInfoSummary() {
    const info = this.store.state?.system_info;
    const haVer = info?.ha_version || this.store.hass?.config?.version || "—";
    const intVer = info?.integration_version || this.store.state?.version || "—";
    const sdkRev = info?.min_firmware_sdk_rev
      ? String(info.min_firmware_sdk_rev)
      : "—";
    const studioRev = String(info?.studio_rev ?? STUDIO_REV);
    const devs = this.store.state?.system_devices || [];
    const displayCount = devs.filter((d) => d.kind !== "ble_tag").length;
    const bleTagCount = devs.filter((d) => d.kind === "ble_tag").length;
    return [
      `Home Assistant: ${haVer}`,
      `Latter integration: v${intVer}`,
      `Minimum firmware SDK: ${sdkRev}`,
      `Studio contract: rev ${studioRev}`,
      `Managed Devices: ${devs.length} (${displayCount} displays, ${bleTagCount} BLE trackers)`,
    ].join("\n");
  }
  async copySystemInfoSummary() {
    const root =
      (this.store.host).renderRoot ||
      this.store.host.shadowRoot;
    const ok = await copyTextToClipboard(this.formatSystemInfoSummary(), root);
    this.store.showToast(
      ok ? this.store.t("support.copied_summary") : "Could not copy version summary",
      !ok,
    );
  }
  // ---------- Color Wheel Modal (`A-24`: per-store `painted` flag) ----------
  openColorWheelModal(targetScope) {
    const initial =
      targetScope === "device" && isValidHexColor(this.store.state?.config?.device_custom_color)
        ? String(this.store.state?.config?.device_custom_color).toUpperCase()
        : defaultThemeHex(this.store.host);
    this.store.colorWheelModal = {
      open: true,
      targetScope,
      hex: initial,
      name: "",
      busy: false,
      painted: this.store.colorWheelModal.painted,
    };
    this.store.host.requestUpdate();
  }
  closeColorWheelModal() {
    this.store.colorWheelModal = {
      ...this.store.colorWheelModal,
      open: false,
      busy: false,
    };
    this.store.host.requestUpdate();
  }
  async saveColorWheelSelection() {
    const hex = this.store.colorWheelModal.hex.trim().toUpperCase();
    if (!isValidHexColor(hex)) {
      this.store.showToast("Enter a valid 6-digit hex color", true);
      return;
    }
    this.store.colorWheelModal = { ...this.store.colorWheelModal, busy: true };
    this.store.host.requestUpdate();
    try {
      const name = this.store.colorWheelModal.name.trim() || hex;
      const existing = [
        ...(this.store.state?.system_config?.custom_palettes || []),
      ];
      if (!existing.some((p) => p.hex.toUpperCase() === hex)) {
        existing.push({ name, hex });
        this.store.entity.stageSystemSetting("custom_palettes", existing);
        await this.store.entity.flushSystemSettings();
      }
      if (this.store.colorWheelModal.targetScope === "device" && this.store.activeSubentryId) {
        this.store.entity.applyDeviceCustomColor(hex, true);
        await this.store.entity.flushDeviceBucket(this.store.activeSubentryId);
      }
      this.closeColorWheelModal();
    } finally {
      if (this.store.colorWheelModal.busy) {
        this.store.colorWheelModal = { ...this.store.colorWheelModal, busy: false };
        this.store.host.requestUpdate();
      }
    }
  }
  // ---------- Remove & Reset Device Modals ----------
  openRemoveDeviceModal(subentryId, title) {
    if (!subentryId) return;
    this.store.removeModal = {
      open: true,
      subentryId,
      title: title || "Device",
      busy: false,
    };
    this.store.host.requestUpdate();
  }
  closeRemoveDeviceModal() {
    this.store.removeModal = { ...this.store.removeModal, open: false, busy: false };
    this.store.host.requestUpdate();
  }
  async removeDeviceById(subentryId) {
    const subId = String(subentryId || "").trim();
    if (!subId) return;
    try {
      this.store.entity.discardDeviceBucket(subId);
      const res = await this.store.ws.runSystemCommand(
        "remove_device",
        { subentry_id: subId },
        this.store.activeSubentryId || null,
      );
      this.closeRemoveDeviceModal();
      if (this.store.activeSubentryId === subId) {
        this.store.onActiveDeviceChanged(subId, "", { discardPrevPending: true });
        this.store.currentScope = "device";
        this.store.currentViewId = "select_device_prompt";
        this.store.syncUrl(true);
      }
      if (res) this.store.ingestPayload(res, false);
      this.store.showToast("Removed Device from Latter");
    } catch (err) {
      this.store.showToast(formatWsError(err, "Could not remove Device"), true);
      throw err;
    }
  }
  async confirmRemoveDevice() {
    const subId = this.store.removeModal.subentryId;
    if (!subId) return;
    this.store.removeModal = { ...this.store.removeModal, busy: true };
    this.store.host.requestUpdate();
    try {
      await this.removeDeviceById(subId);
    } catch {
      this.store.removeModal = { ...this.store.removeModal, busy: false };
      this.store.host.requestUpdate();
    }
  }
  requestRemoveDevice(subentryId, title) {
    const subId = String(subentryId || "").trim();
    if (!subId) return;
    const cleanTitle = title || "Device";
    this.openConfirm({
      kind: "remove_device",
      title: this.store.t("confirm.remove_device.title", { title: cleanTitle }),
      consequence: this.store.t("confirm.remove_device.body", { title: cleanTitle }),
      confirmLabel: this.store.t("confirm.remove_device.confirm"),
      danger: true,
      blastRadiusCount: 1,
      onDownloadBackupFirst: () => {
        void this.exportBackup(subId);
      },
      onConfirm: async() => {
        await this.removeDeviceById(subId);
      },
    });
  }
  openResetDeviceModal() {
    if (!this.store.activeSubentryId) return;
    const isBleTag = this.store.state?.config?.kind === "ble_tag";
    this.store.resetModal = {
      open: true,
      deviceSettings: !isBleTag,
      latterOptions: true,
      busy: false,
    };
    this.store.host.requestUpdate();
  }
  closeResetDeviceModal() {
    this.store.resetModal = { ...this.store.resetModal, open: false, busy: false };
    this.store.host.requestUpdate();
  }
  async confirmResetDevice() {
    const targetSubentryId = this.store.activeSubentryId;
    if (!targetSubentryId) return;
    if (!this.store.resetModal.deviceSettings && !this.store.resetModal.latterOptions) return;
    this.store.resetModal = { ...this.store.resetModal, busy: true };
    this.store.host.requestUpdate();
    try {
      this.store.entity.discardDeviceBucket(targetSubentryId);
      const res = await this.store.ws.resetDevice({
        subentryId: targetSubentryId,
        deviceSettings: this.store.resetModal.deviceSettings,
        latterOptions: this.store.resetModal.latterOptions,
      });
      this.closeResetDeviceModal();
      if (res && this.store.activeSubentryId === targetSubentryId) {
        this.store.ingestPayload(res, false);
      }
      this.store.showToast("Reset Device to defaults");
    } catch (err) {
      this.store.resetModal = { ...this.store.resetModal, busy: false };
      this.store.showToast(formatWsError(err, "Could not reset Device"), true);
      this.store.host.requestUpdate();
    }
  }
  // ---------- Discovered Devices: Adopt (`E-10`), Ignore, & Add BLE Tag ----------
  openAddBleModal(prefill) {
    this.store.addBleModal = {
      open: true,
      candidateAddr: prefill?.address || "",
      name: prefill?.name || "",
      address: prefill?.address || "",
      assignedPerson: "",
      bleCategory: "auto",
      busy: false,
    };
    this.store.host.requestUpdate();
  }
  closeAddBleModal() {
    this.store.addBleModal = { ...this.store.addBleModal, open: false, busy: false };
    this.store.host.requestUpdate();
  }
  selectBleCandidateInModal(addr) {
    const cand = (this.store.state?.discovered_ble_devices || []).find(
      (c) => c.target_address === addr,
    );
    const candAddr = cand ? cand.target_address || addr : addr;
    const candTitle = cand ? cand.title || "" : "";
    this.store.addBleModal = {
      ...this.store.addBleModal,
      candidateAddr: addr,
      address: cand ? candAddr : this.store.addBleModal.address,
      name: candTitle || this.store.addBleModal.name,
    };
    this.store.host.requestUpdate();
  }
  async adoptLatterDevice(
    esphomeDeviceId,
    title,
    deviceGroup = "auto",
    assignedPerson = "",
  ) {
    if (!esphomeDeviceId) return;
    try {
      const res = await this.store.ws.runSystemCommand(
        "add_latter_device",
        {
          esphome_device_id: esphomeDeviceId,
          device_group: deviceGroup || "auto",
          assigned_person: assignedPerson,
        },
        this.store.activeSubentryId || null,
      );
      this.store.discoveredLatterGroupDrafts.delete(esphomeDeviceId);
      this.store.discoveredLatterPersonDrafts.delete(esphomeDeviceId);
      if (res) {
        this.store.ingestPayload(res, false);
        if (res.adopted_subentry_id) {
          await this.store.switchSystemDevice(res.adopted_subentry_id, "dashboard");
        }
      }
      this.store.showToast(
        this.store.t("discovered.adopted_toast", { title: title || "Device" }),
      );
    } catch (err) {
      this.store.showToast(formatWsError(err, "Could not adopt Latter Device"), true);
    }
  }
  async ignoreDiscoveredDevice(esphomeDeviceId, title) {
    const cleanId = String(esphomeDeviceId || "").trim();
    if (!cleanId) return;
    try {
      const res = await this.store.ws.runSystemCommand(
        "ignore_discovered_device",
        { esphome_device_id: cleanId },
        this.store.activeSubentryId || null,
      );
      if (res) this.store.ingestPayload(res, false);
      this.store.showToast(
        this.store.t("discovered.ignored_toast", { title: title || cleanId }),
      );
    } catch (err) {
      this.store.showToast(formatWsError(err, "Could not ignore discovered Device"), true);
    }
  }
  async unignoreDiscoveredDevice(esphomeDeviceId, title) {
    const cleanId = String(esphomeDeviceId || "").trim();
    if (!cleanId) return;
    try {
      const res = await this.store.ws.runSystemCommand(
        "unignore_discovered_device",
        { esphome_device_id: cleanId },
        this.store.activeSubentryId || null,
      );
      if (res) this.store.ingestPayload(res, false);
      this.store.showToast(
        this.store.t("discovered.restored_toast", { title: title || cleanId }),
      );
    } catch (err) {
      this.store.showToast(formatWsError(err, "Could not restore discovered Device"), true);
    }
  }
  async quickAdoptBleCandidate(
    title,
    targetAddress,
    assignedPerson = "",
    bleCategory = "auto",
  ) {
    if (!title || !targetAddress) return;
    try {
      const res = await this.store.ws.runSystemCommand(
        "add_ble_device",
        {
          name: title,
          target_address: targetAddress,
          assigned_person: assignedPerson,
          ble_category: bleCategory || "auto",
        },
        this.store.activeSubentryId || null,
      );
      this.store.evictAdoptedBleCandidate(targetAddress);
      if (res) {
        this.store.ingestPayload(res, false);
        if (res.adopted_subentry_id) {
          await this.store.switchSystemDevice(res.adopted_subentry_id, "dashboard");
        }
      }
      this.store.showToast(this.store.t("discovered.adopted_toast", { title }));
    } catch (err) {
      this.store.showToast(formatWsError(err, "Could not add BLE tag"), true);
    }
  }
  async confirmAddBleModal() {
    const name = this.store.addBleModal.name.trim();
    const targetAddress = this.store.addBleModal.address.trim();
    if (!name || !targetAddress) {
      this.store.showToast("Enter both a name and a Bluetooth address or entity", true);
      return;
    }
    this.store.addBleModal = { ...this.store.addBleModal, busy: true };
    this.store.host.requestUpdate();
    try {
      const res = await this.store.ws.runSystemCommand(
        "add_ble_device",
        {
          name,
          target_address: targetAddress,
          assigned_person: this.store.addBleModal.assignedPerson,
          ble_category: this.store.addBleModal.bleCategory || "auto",
        },
        this.store.activeSubentryId || null,
      );
      this.store.evictAdoptedBleCandidate(targetAddress);
      this.closeAddBleModal();
      if (res) {
        this.store.ingestPayload(res, false);
        if (res.adopted_subentry_id) {
          await this.store.switchSystemDevice(res.adopted_subentry_id, "dashboard");
        }
      }
      this.store.showToast(this.store.t("discovered.adopted_toast", { title: name }));
    } catch (err) {
      this.store.addBleModal = { ...this.store.addBleModal, busy: false };
      this.store.showToast(formatWsError(err, "Could not add BLE tag"), true);
      this.store.host.requestUpdate();
    }
  }
  // ---------- Firmware Updates, Announcements, Backup & Restore, & Logs ----------
  async checkSystemUpdates() {
    this.store.showToast("Checking firmware updates…");
    try {
      const res = await this.store.ws.runSystemCommand(
        "check_system_updates",
        {},
        this.store.activeSubentryId || null,
      );
      if (res) {
        this.store.ingestPayload(res, false);
        const info = res.update_check;
        if (info) {
          this.store.showToast(
            info.available > 0
              ? `${info.available} firmware update(s) available across ${info.checked} checked Device(s)`
              : `Checked ${info.checked} Device(s) — all firmware is up to date`,
          );
          return;
        }
      }
      this.store.showToast("Firmware update check finished");
    } catch (err) {
      this.store.showToast(formatWsError(err, "Firmware update check failed"), true);
    }
  }
  async sendAnnouncement() {
    const message = this.store.announceMessage.trim();
    if (!message) {
      this.store.showToast("Enter a message", true);
      return;
    }
    const payload = {
      mode: this.store.announceMode,
      target_device: this.store.announceTarget || "all",
      message,
    };
    if (this.store.announceMode === "notify") {
      const title = this.store.announceTitle.trim();
      if (!title) {
        this.store.showToast("Enter a notification title", true);
        return;
      }
      payload.title = title;
      payload.priority = this.store.announcePriority;
      payload.include_camera = this.store.announceIncludeCamera;
    }
    try {
      const res = await this.store.ws.runSystemCommand(
        "send_announcement",
        payload,
        this.store.activeSubentryId || null,
      );
      if (res) this.store.ingestPayload(res, false);
      this.store.showToast(
        this.store.announceMode === "notify"
          ? "Sent notification"
          : "Broadcast announcement sent",
      );
    } catch (err) {
      this.store.showToast(formatWsError(err, "Could not send announcement"), true);
    }
  }
  async exportBackup(explicitSubentryId) {
    try {
      const dateStr = new Date().toISOString().slice(0, 10);
      if (explicitSubentryId) {
        const { bundle } = await this.store.ws.exportBackup("device", explicitSubentryId);
        const slug = String(
          bundle.target_device || this.store.state?.config?.device_slug || "esphome",
        );
        triggerJsonDownload(`latter-device-${slug}-backup-${dateStr}.json`, bundle);
        this.store.showToast("Downloaded the Device backup");
        return;
      }
      const choice = this.store.backupExportScope || "system";
      const deviceId = choice.startsWith("device:")
        ? choice.slice(7)
        : choice !== "system"
          ? choice
          : "";
      if (!deviceId) {
        const { bundle } = await this.store.ws.exportBackup("system");
        triggerJsonDownload(`latter-system-backup-${dateStr}.json`, bundle);
        this.store.showToast("Downloaded the System backup");
      } else {
        const { bundle } = await this.store.ws.exportBackup("device", deviceId);
        const slug = String(bundle.target_device || deviceId);
        triggerJsonDownload(`latter-device-${slug}-backup-${dateStr}.json`, bundle);
        this.store.showToast("Downloaded the Device backup");
      }
    } catch (err) {
      this.store.showToast(formatWsError(err, "Backup export failed"), true);
    }
  }
          async parseBackupBundleFile()
            {
    if (!this.store.selectedBackupFile) {
      this.store.showToast("Choose a JSON backup file first", true);
      return null;
    }
    const text = await this.store.selectedBackupFile.text();
    const parsed = JSON.parse(text);
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
      throw new Error("Invalid backup JSON format");
    }
    const bundle = parsed;
    const rawScope = String(bundle.scope || "");
    if (rawScope !== "system" && rawScope !== "device") {
      throw new Error("Backup file is missing a valid 'system' or 'device' scope");
    }
    const scope = rawScope;
    const targetId = scope === "device" ? this.store.backupRestoreSubentryId || "" : "";
    if (scope === "device" && !targetId) {
      this.store.showToast("Choose the Device to restore this Device backup onto", true);
      return null;
    }
    return { bundle, scope, targetId };
  }
  async restoreFromUploadedFile() {
    try {
      const parsed = await this.parseBackupBundleFile();
      if (!parsed) return;
      const { bundle, scope, targetId } = parsed;
      const res = await this.store.ws.importBackup({
        scope,
        bundle,
        targetSubentryId: targetId || null,
        selectedSubentryId: this.store.activeSubentryId || null,
      });
      this.store.selectedBackupFile = null;
      this.store.mergeDomRevert({ "input-restore-backup": "" });
      if (res) this.store.ingestPayload(res, false);
      this.store.showToast(
        scope === "device" ? "Restored the Device backup" : "Restored the System backup",
      );
    } catch (err) {
      this.store.showToast(formatWsError(err, "Backup restore failed"), true);
    }
  }
  async requestRestoreFromUploadedFile() {
    try {
      const parsed = await this.parseBackupBundleFile();
      if (!parsed) return;
      const { scope, targetId } = parsed;
      const blastCount =
        scope === "device"
          ? 1
          : Math.max(1, (this.store.state?.system_devices || []).length);
      this.openConfirm({
        kind: "restore_backup",
        title: this.store.t("confirm.restore_backup.title"),
        consequence: this.store.t("confirm.restore_backup.body"),
        confirmLabel: this.store.t("confirm.restore_backup.confirm"),
        danger: true,
        blastRadiusCount: blastCount,
        onDownloadBackupFirst: () => {
          void this.exportBackup(scope === "device" ? targetId : undefined);
        },
        onConfirm: async() => {
          await this.restoreFromUploadedFile();
        },
      });
    } catch (err) {
      this.store.showToast(formatWsError(err, "Backup restore failed"), true);
    }
  }
  onToggleLogsDetails(open) {
    if (this.store.logsOpen === open) return;
    this.store.logsOpen = open;
    this.store.host.requestUpdate();
    void this.store.ensureSubscription(false);
  }
  formatVisibleLogs() {
    const entries = this.store.state?.internal_logs || [];
    const filter = this.store.logFilter || "all";
    const filtered = entries.filter((e) => {
      const lvl = String(e.level || "").toUpperCase();
      const src = String(e.source || "").toLowerCase();
      if (filter === "latter") {
        return src === "studio" || src === "system" || src.includes("latter");
      }
      if (filter === "errors") {
        return lvl === "WARNING" || lvl === "WARN" || lvl === "ERROR" || lvl === "CRITICAL";
      }
      if (filter.startsWith("device:")) {
        const slug = filter.slice(7).toLowerCase();
        return src === slug || String(e.message || "").toLowerCase().includes(slug);
      }
      return true;
    });
    if (!filtered.length) return "No events logged yet.";
    return filtered
      .map((e) => {
        const rawTs = e.timestamp ?? e.ts ?? "";
        const formattedTs = rawTs !== "" ? fmtDateTime(rawTs, this.store.hass) : "";
        const lvl = String(e.level || "INFO").toUpperCase();
        const src = String(e.source || "latter");
        return `${formattedTs ? `[${formattedTs}] ` : ""}${lvl} (${src}): ${String(e.message || "")}`;
      })
      .join("\n");
  }
  async copyLogsToClipboard() {
    const root =
      (this.store.host).renderRoot ||
      this.store.host.shadowRoot;
    const ok = await copyTextToClipboard(this.formatVisibleLogs(), root);
    this.store.showToast(ok ? "Copied logs to clipboard" : "Could not copy logs", !ok);
  }
  async clearInternalLogs() {
    try {
      const res = await this.store.ws.runSystemCommand(
        "clear_internal_logs",
        {},
        this.store.activeSubentryId || null,
      );
      if (res) this.store.ingestPayload(res, true);
      this.store.showToast("Cleared internal logs");
    } catch (err) {
      this.store.showToast(formatWsError(err, "Could not clear logs"), true);
    }
  }
}
__latterExp(__exports, { emptyConfirmModalState: () => emptyConfirmModalState, ToolsController: () => ToolsController });
//# sourceURL=latter-studio/src/state/tools-controller.ts
});
__latterDef("src/state/store.ts", (__exports, __req) => {
const { formatWsError, isStudioRevMismatchError, StudioWsClient } = __req("src/api/ws-client.ts");
const { DEVICE_VIEW_SLUGS, SYSTEM_VIEW_SLUGS, VIEW_TITLE_KEYS } = __req("src/constants.ts");
const { t, tPrefLabel, tPrefOption } = __req("src/i18n/index.ts");
const { navigateHaPath } = __req("src/utils/format.ts");
const { EntityController, isCatalogItemSupported, isProtectedNativeDockItem, overlayDevicePrefsOnSections, overlayPendingBlankListSlots, overlayPendingEntityStates } = __req("src/state/entity-controller.ts");
const { GroupsController } = __req("src/state/groups-controller.ts");
const { emptyConfirmModalState, ToolsController } = __req("src/state/tools-controller.ts");
/**
 * Encapsulated Reactive Store for Latter Studio (`StudioStore`, `D-023`, `D-062`, `D-064`, `D-065`).
 *
 * Architecture:
 * - Zero `window.*` globals and zero 1-line pass-through wrappers (`A-15` / `Q10`).
 * - Namespaced domain controllers: `store.entity`, `store.groups`, `store.tools`.
 * - Event-first `latter/system/subscribe` bootstrap (`STUDIO_REV = 34`), section-hash preservation,
 *   `"ready"` reconnect resync, exponential backoff (`2s -> 5s -> 15s -> 60s`), and `subentry_id`
 *   payload isolation (`deviceLoading` guard).
 * - Isolated local 1 Hz `liveClockNowMs` interval active strictly on `Device -> Overview` when a
 *   timer or stopwatch is running (`F-01`, `B-17`).
 */
const RECONNECT_BACKOFF_MS = [2_000, 5_000, 15_000, 60_000];
const INFO_TOAST_DURATION_MS = 3_500;
function slugToView (map, slug) {
  const cleaned = String(slug || "").trim().toLowerCase();
  for (const [viewId, s] of Object.entries(map)) {
    if (s === cleaned) return viewId;
  }
  return null;
}
/**
 * Shared capability predicate used by BOTH sidebar navigation and payload capability redirect (`B-06`, `E-14`).
 * Never redirects or hides a tab when capability flags are `undefined` (not yet loaded).
 */
function deviceHasView(
  viewId,
  caps,
  kind,
) {
  if (
    viewId === "select_device_prompt" ||
    viewId === "discovered_devices" ||
    viewId === "dashboard" ||
    viewId === "presence" ||
    viewId === "tools"
  ) {
    return true;
  }
  if (kind === "ble_tag") return false;
  if (!caps) return true;
  if (viewId === "display" || viewId === "interface") {
    return caps.has_display !== false;
  }
  if (viewId === "audio_voice") {
    return !(caps.has_audio === false && caps.has_voice === false);
  }
  if (viewId === "power") {
    return caps.has_power !== false;
  }
  return true;
}
class StudioStore {
           host;
           ws;
  // Namespaced domain controllers (`Q10`)
           entity;
           groups;
           tools;
  // Core navigation & lifecycle state (`D-001`: starts on Devices landing list)
  currentScope = "device";
  currentViewId = "select_device_prompt";
  activeSubentryId = "";
  deviceSelected = false;
  deviceLoading = false;
  state = null;
  loading = true;
  loadError = "";
  studioRevMismatch = false;
  // Live regions & toast feedback (`D-01`, `D-02`)
  toastMessage = "";
  toastIsError = false;
  politeAnnouncement = "";
  assertiveAnnouncement = "";
          politeSeq = 0;
          assertiveSeq = 0;
          toastTimer = null;
  // Local 1 Hz clock tick strictly for active Device Overview timer/stopwatch (`F-01`, `B-17`)
  liveClockNowMs = Date.now();
          liveClockTimer = null;
  // Upload state (`XMLHttpRequest` multipart <= 15 MB)
  uploadScope = null;
  uploadBusy = false;
  uploadPercent = 0;
  selectedDeviceWallpaperFile = null;
  selectedSystemWallpaperFile = null;
  selectedBackupFile = null;
  // Devices table & Discovered UI state
  deviceSortField = "title";
  deviceSortAsc = true;
  deviceCategoryFilter = "all";
  discoveredBleSearch = "";
  discoveredBleKindFilter = "all";
  discoveredBleSort = "name";
  discoveredBlePaused = false;
  discoveredBleFrozenSnapshot = null;
  discoveredIgnoredOpen = false;
           discoveredBlePersonDrafts = new Map();
           discoveredLatterGroupDrafts = new Map();
           discoveredLatterPersonDrafts = new Map();
                   discoveredBleSeenCache = new Map
   ();
  // Device Security & Time UI draft state
  devicePinDraft = "";
  systemPinDraft = "";
  pinBusy = false;
  worldClockNewLabel = "";
  worldClockNewZone = "";
  overviewAlarmsOpen = false;
  // System Shared Entities UI state
  activeCameraPreviewEntity = "";
  cameraPreviewUrl = "";
  // System Device Groups & Staged Batch Controls UI state (`Q6`)
  newGroupFormOpen = false;
  newGroupName = "";
  newGroupDesc = "";
  newGroupSourceSubentryId = "";
  newGroupIncludeDisplay = false;
  newGroupIncludeInterface = false;
           openGroupIds = new Set();
           groupCopySourceDrafts = new Map();
  batchTargetFilter = "all";
  batchCategoryFilter = "all";
  batchCopySourceSubentryId = "";
           openBatchCategories = new Set();
           batchDraft = new Map();
  // System BLE & Area Presence UI state
  bleSurveySubentryId = "";
  bleCalibrateAreaId = "";
  bleCalibrateHandoffActive = false;
  bleLiveStreamActive = true;
           bleSurveyFrozen = new Map
   ();
           openProxyTrims = new Set();
  advancedBleOpen = false;
           openFusionAreas = new Set();
  // System Tools UI state
  announceMode = "notify";
  announceTarget = "all";
  announceTitle = "";
  announceMessage = "";
  announcePriority = "normal";
  announceIncludeCamera = false;
  doorbellTestSubentryId = "";
  doorbellTestReply = "";
  backupExportScope = "system";
  backupRestoreSubentryId = "";
  logsOpen = false;
  logFilter = "all";
  // Modal states
  confirmModal = emptyConfirmModalState();
  removeModal = { open: false, subentryId: "", title: "", busy: false };
  resetModal = { open: false, deviceSettings: true, latterOptions: true, busy: false };
  addBleModal = {
    open: false,
    candidateAddr: "",
    name: "",
    address: "",
    assignedPerson: "",
    bleCategory: "auto",
    busy: false,
  };
  colorWheelModal = {
    open: false,
    targetScope: "system",
    hex: "",
    name: "",
    busy: false,
    painted: false,
  };
  saveGroupModal = {
    open: false,
    subentryId: "",
    name: "",
    description: "",
    includeDisplay: false,
    includeInterface: false,
    busy: false,
  };
  shortcutModal = {
    open: false,
    listKey: "pinned_items",
    editIndex: null,
    kind: "route",
    routeTarget: "weather:moon",
    entityDomainFilter: "all",
    entitySearch: "",
    entityTarget: "",
    action: "",
    label: "",
    icon: "",
    iconSearch: "",
    confirm: false,
  };
  appConfigModal = {
    open: false,
    app: null,
  };
  returnToPinnedModal = false;
  pendingScrollCardId = "";
           handoffTargetIds = new Set();
  pendingDomRevert = null;
          scrollGen = 0;
          handoffArming = false;
  // Snapshot-isolated pending settings queues & per-Device config_rev tracker
  pendingSystemPatch = {};
  pendingSystemPrevious = {};
  systemSaveTimer = null;
           pendingBlankListSlots = {
    calendar_entities: 0,
    camera_entities: 0,
    remotes_list: 0,
    thermostat_entities: 0,
    lock_entities: 0,
    garage_entities: 0,
    vacuum_entities: 0,
  };
           pendingDeviceBuckets = new Map();
           pendingEntityStates = new Map();
                   deviceConfigRevs = new Map();
  // Subscription & reconnect state
          subGen = 0;
          stateReqSeq = 0;
          lastAppliedReqSeq = 0;
          wsUnsub = null;
          subscribedKey = "";
          reconnectTimer = null;
          reconnectAttempt = 0;
          boundConnection = null;
          routeApplying = false;
                   onConnectionReady = () => {
    if (this.studioRevMismatch || !this.host.isConnected) return;
    this.reconnectAttempt = 0;
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    void this.ensureSubscription(true);
  };
  constructor(host) {
    this.host = host;
    this.ws = new StudioWsClient(() => {
      this.handleStudioRevMismatch();
    });
    this.entity = new EntityController(this);
    this.groups = new GroupsController(this);
    this.tools = new ToolsController(this);
  }
  // ---------- Convenience i18n & Confirm Shortcuts ----------
  get localeOverlay() {
    const raw = this.state?.locale_strings;
    return raw && typeof raw === "object" ? raw : null;
  }
  t(key, vars) {
    return t(key, vars, this.localeOverlay);
  }
  tPrefLabel(key, fallback) {
    return tPrefLabel(key, fallback, this.localeOverlay);
  }
  tPrefOption(prefKey, opt) {
    return tPrefOption(prefKey, opt, this.localeOverlay);
  }
  openConfirm(opts) {
    this.tools.openConfirm(opts);
  }
  closeConfirm() {
    this.tools.closeConfirm();
  }
  async runConfirmedAction() {
    await this.tools.runConfirmedAction();
  }
  // ---------- Config Revision & Live Clock Helpers ----------
  getKnownDeviceConfigRev(subentryId) {
    if (this.state?.subentry_id === subentryId && this.state.device_config_rev > 0) {
      return this.state.device_config_rev;
    }
    return this.deviceConfigRevs.get(subentryId) ?? 0;
  }
  recordKnownDeviceConfigRev(subentryId, rev) {
    if (subentryId && rev > 0) {
      this.deviceConfigRevs.set(subentryId, rev);
    }
  }
  activeTimerRemainingSec() {
    const live = this.state?.live;
    if (!live) return 0;
    if (live.timer_running && live.timer_ends_at) {
      const endsMs = Date.parse(live.timer_ends_at);
      if (Number.isFinite(endsMs)) {
        return Math.max(0, Math.ceil((endsMs - this.liveClockNowMs) / 1000));
      }
    }
    return Math.max(0, Math.round(Number(live.timer_remaining_sec || 0)));
  }
  activeStopwatchElapsedSec() {
    const live = this.state?.live;
    if (!live) return 0;
    if (live.stopwatch_running && live.stopwatch_started_at) {
      const startedMs = Date.parse(live.stopwatch_started_at);
      if (Number.isFinite(startedMs)) {
        return Math.max(0, Math.floor((this.liveClockNowMs - startedMs) / 1000));
      }
    }
    return Math.max(0, Math.round(Number(live.stopwatch_elapsed_sec || 0)));
  }
          syncLiveClockTimer() {
    const live = this.state?.live;
    const shouldTick =
      this.host.isConnected &&
      this.currentScope === "device" &&
      this.deviceSelected &&
      !this.deviceLoading &&
      this.currentViewId === "dashboard" &&
      Boolean(
        (live?.timer_running && live.timer_ends_at) ||
          (live?.stopwatch_running && live.stopwatch_started_at),
      );
    if (shouldTick) {
      this.liveClockNowMs = Date.now();
      if (this.liveClockTimer === null) {
        this.liveClockTimer = setInterval(() => {
          this.liveClockNowMs = Date.now();
          this.host.requestUpdate();
        }, 1000);
      }
    } else if (this.liveClockTimer !== null) {
      clearInterval(this.liveClockTimer);
      this.liveClockTimer = null;
    }
  }
  // ---------- Controller Lifecycle ----------
  hostConnected() {
    this.syncConnectionListener();
    this.syncLiveClockTimer();
    if (this.ws.hass && !this.studioRevMismatch) {
      void this.ensureSubscription(false);
    }
  }
  hostDisconnected() {
    if (this.toastTimer) {
      clearTimeout(this.toastTimer);
      this.toastTimer = null;
    }
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    if (this.liveClockTimer !== null) {
      clearInterval(this.liveClockTimer);
      this.liveClockTimer = null;
    }
    this.detachConnectionListener();
    void this.entity.flushAllPendingSettings();
    this.teardownSubscription();
  }
  hostUpdated() {
    if (this.pendingDomRevert) {
      const rev = this.pendingDomRevert;
      this.pendingDomRevert = null;
      const root = (this.host).renderRoot;
      if (root) {
        for (const [id, val] of Object.entries(rev.controlIds)) {
          const el = root.getElementById(id);
          if (!el) continue;
          if (typeof val === "boolean" && "checked" in el) {
            (el).checked = val;
          } else {
            el.value = String(val);
          }
        }
      }
    }
    if (this.pendingScrollCardId) {
      const cardId = this.pendingScrollCardId;
      this.pendingScrollCardId = "";
      const root =
        (this.host).renderRoot ||
        this.host.shadowRoot;
      const target = root?.getElementById(cardId);
      if (target && typeof target.scrollIntoView === "function") {
        const myGen = ++this.scrollGen;
        const reducedMotion = Boolean(
          typeof globalThis.matchMedia === "function" &&
            globalThis.matchMedia("(prefers-reduced-motion: reduce)").matches,
        );
        void this.scrollIntoViewAsync(target, {
          behavior: reducedMotion ? "auto" : "smooth",
          block: "start",
        }).then(() => {
          if (myGen !== this.scrollGen || !this.handoffTargetIds.has(cardId)) return;
          if (typeof target.focus === "function") {
            if (
              typeof target.hasAttribute === "function" &&
              !target.hasAttribute("tabindex")
            ) {
              target.setAttribute?.("tabindex", "-1");
            }
            try {
              target.focus({ preventScroll: true });
            } catch {
              target.focus();
            }
          }
        });
      }
    }
    this.handoffArming = false;
  }
  mergeDomRevert(controlIds) {
    this.pendingDomRevert = {
      controlIds: {
        ...(this.pendingDomRevert?.controlIds || {}),
        ...controlIds,
      },
    };
  }
          scrollIntoViewAsync(
    element,
    options,
  ) {
    const result = element.scrollIntoView(options);
    if (result instanceof Promise) {
      return result;
    }
    const scroller = globalThis.window;
    if (!scroller || typeof scroller.addEventListener !== "function") {
      return Promise.resolve();
    }
    return new Promise ((resolve) => {
      let timeoutId;
      const finish = () => {
        clearTimeout(timeoutId);
        scroller.removeEventListener("scrollend", finish);
        scroller.removeEventListener("scroll", onScroll);
        resolve();
      };
      const onScroll = () => {
        clearTimeout(timeoutId);
        timeoutId = setTimeout(finish, 100);
      };
      scroller.addEventListener("scrollend", finish, { once: true });
      scroller.addEventListener("scroll", onScroll, { passive: true });
      timeoutId = setTimeout(finish, 100);
    });
  }
  // ---------- Handoff Highlighting & Focus ----------
  isHandoffTarget(targetId) {
    return Boolean(targetId) && this.handoffTargetIds.has(targetId);
  }
  clearHandoffTargets() {
    this.bleCalibrateHandoffActive = false;
    this.handoffTargetIds.clear();
    this.handoffArming = false;
  }
          applySectionHandoff(scrollId = "", highlightIds) {
    const cleanScroll = String(scrollId || "").trim();
    this.pendingScrollCardId = cleanScroll;
    const ids =
      highlightIds && highlightIds.length > 0
        ? highlightIds
        : cleanScroll
          ? [cleanScroll]
          : [];
    for (const rawId of ids) {
      const id = String(rawId || "").trim();
      if (id) this.handoffTargetIds.add(id);
    }
    if (this.handoffTargetIds.size > 0) {
      this.handoffArming = true;
      this.host.requestUpdate();
    }
  }
  onMainFocusIn(ev) {
    if (this.handoffArming || this.handoffTargetIds.size === 0) return;
    const path = typeof ev.composedPath === "function" ? ev.composedPath() : [];
    const target = (path[0] ?? ev.target);
    if (!target || typeof target.tagName !== "string") return;
    const tag = target.tagName.toUpperCase();
    if (
      tag !== "BUTTON" &&
      tag !== "INPUT" &&
      tag !== "SELECT" &&
      tag !== "TEXTAREA" &&
      tag !== "SUMMARY" &&
      tag !== "A"
    ) {
      return;
    }
    let cur = target;
    while (cur) {
      if (cur.id && this.handoffTargetIds.has(cur.id)) {
        return;
      }
      cur = cur.parentElement;
    }
    this.handoffTargetIds.clear();
    this.host.requestUpdate();
  }
  // ---------- Home Assistant Connection & Live Announcements ----------
          syncConnectionListener() {
    const nextConn = this.host.isConnected ? (this.ws.hass?.connection ?? null) : null;
    if (this.boundConnection === nextConn) return;
    this.detachConnectionListener();
    if (nextConn && typeof nextConn.addEventListener === "function") {
      nextConn.addEventListener("ready", this.onConnectionReady);
      this.boundConnection = nextConn;
    }
  }
          detachConnectionListener() {
    if (this.boundConnection && typeof this.boundConnection.removeEventListener === "function") {
      try {
        this.boundConnection.removeEventListener("ready", this.onConnectionReady);
      } catch {
        // Ignore teardown errors on closed sockets.
      }
    }
    this.boundConnection = null;
  }
          handleStudioRevMismatch() {
    this.studioRevMismatch = true;
    this.loading = false;
    this.deviceLoading = false;
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    this.teardownSubscription();
    this.host.requestUpdate();
  }
  setHass(hass) {
    const prevConn = this.ws.hass?.connection ?? null;
    this.ws.setHass(hass);
    this.syncConnectionListener();
    const connChanged = Boolean(hass?.connection && hass.connection !== prevConn);
    if (connChanged && this.host.isConnected && !this.studioRevMismatch) {
      void this.ensureSubscription(false);
    }
  }
  get hass() {
    return this.ws.hass;
  }
  reloadPage() {
    globalThis.location.reload();
  }
  announcePolite(message) {
    const clean = String(message || "").trim();
    if (!clean) return;
    this.politeSeq += 1;
    this.politeAnnouncement = this.politeSeq % 2 === 0 ? `${clean}\u200B` : clean;
    this.host.requestUpdate();
  }
  announceAssertive(message) {
    const clean = String(message || "").trim();
    if (!clean) return;
    this.assertiveSeq += 1;
    this.assertiveAnnouncement = this.assertiveSeq % 2 === 0 ? `${clean}\u200B` : clean;
    this.host.requestUpdate();
  }
  showToast(message, isError = false) {
    const clean = String(message || "");
    this.toastMessage = clean;
    this.toastIsError = isError;
    if (this.toastTimer) {
      clearTimeout(this.toastTimer);
      this.toastTimer = null;
    }
    if (isError) {
      this.announceAssertive(clean);
    } else {
      this.announcePolite(clean);
      this.toastTimer = setTimeout(() => {
        this.toastMessage = "";
        this.host.requestUpdate();
      }, INFO_TOAST_DURATION_MS);
    }
    this.host.requestUpdate();
  }
  dismissToast() {
    if (this.toastTimer) {
      clearTimeout(this.toastTimer);
      this.toastTimer = null;
    }
    this.toastMessage = "";
    this.toastIsError = false;
    this.host.requestUpdate();
  }
  shouldIncludeLogs() {
    return (
      this.currentScope === "system" &&
      this.currentViewId === "system_tools" &&
      this.logsOpen
    );
  }
  get pageTitle() {
    const key = VIEW_TITLE_KEYS[this.currentViewId] || "view.select_device_prompt";
    return this.t(key);
  }
  get pageSubtitle() {
    if (
      this.currentScope === "device" &&
      this.deviceSelected &&
      this.currentViewId !== "select_device_prompt" &&
      this.currentViewId !== "discovered_devices"
    ) {
      if (this.state?.subentry_id === this.activeSubentryId && this.state.title) {
        return this.state.title;
      }
      const entry = this.state?.system_devices?.find(
        (d) => d.subentry_id === this.activeSubentryId,
      );
      return entry?.title || "";
    }
    return "";
  }
  get hasConfiguredSecurityPin() {
    return Boolean(
      this.state?.config?.has_security_pin ??
        this.state?.live?.has_security_pin ??
        this.state?.has_security_pin,
    );
  }
  deviceHasView(viewId) {
    if (this.state?.subentry_id !== this.activeSubentryId) {
      const entry = this.state?.system_devices?.find(
        (d) => d.subentry_id === this.activeSubentryId,
      );
      if (entry?.kind === "ble_tag") {
        return deviceHasView(viewId, undefined, "ble_tag");
      }
      return deviceHasView(viewId, undefined, undefined);
    }
    return deviceHasView(viewId, this.state?.capabilities, this.state?.config?.kind);
  }
  // ---------- Unified Active Device Transition & Routing ----------
  /**
   * Single transition helper clearing Device-scoped drafts/modals and flushing (or discarding)
   * pending edits across `applyRoute`, `switchSystemDevice`, and removal/invalid redirects (`B-07`, `B-24`).
   */
  onActiveDeviceChanged(
    prevId,
    nextId,
    options,
  ) {
    const cleanPrev = String(prevId || "").trim();
    const cleanNext = String(nextId || "").trim();
    if (cleanPrev && cleanPrev !== cleanNext) {
      if (options?.discardPrevPending) {
        this.entity.discardDeviceBucket(cleanPrev);
      } else {
        void this.entity.flushDeviceBucket(cleanPrev);
      }
    }
    if (cleanPrev !== cleanNext) {
      this.devicePinDraft = "";
      this.worldClockNewLabel = "";
      this.worldClockNewZone = "";
      this.overviewAlarmsOpen = false;
      this.selectedDeviceWallpaperFile = null;
      this.appConfigModal = { open: false, app: null };
      this.shortcutModal = { ...this.shortcutModal, open: false };
      this.saveGroupModal = { ...this.saveGroupModal, open: false, busy: false };
      this.resetModal = { ...this.resetModal, open: false, busy: false };
      this.removeModal = { ...this.removeModal, open: false, busy: false };
      this.returnToPinnedModal = false;
      this.clearHandoffTargets();
    }
    this.activeSubentryId = cleanNext;
    this.deviceSelected = Boolean(cleanNext);
    this.deviceLoading = Boolean(cleanNext && this.state?.subentry_id !== cleanNext);
    this.syncLiveClockTimer();
  }
  applyRoute(route) {
    let rawPath = String(route?.path ?? "");
    if (!rawPath && !route && typeof globalThis.location?.pathname === "string") {
      const locPath = globalThis.location.pathname;
      if (locPath.startsWith("/latter/")) {
        rawPath = locPath.slice("/latter/".length);
      }
    }
    const parts = rawPath
      .split("/")
      .filter(Boolean)
      .map((seg) => {
        try {
          return decodeURIComponent(seg);
        } catch {
          return seg;
        }
      });
    const prevScope = this.currentScope;
    const prevViewId = this.currentViewId;
    const prevSubId = this.activeSubentryId;
    this.routeApplying = true;
    try {
      if (parts[0] === "devices" && parts[1]?.toLowerCase() === "discovered") {
        this.onActiveDeviceChanged(prevSubId, "");
        if (prevScope !== "device" || prevViewId !== "discovered_devices") {
          this.clearHandoffTargets();
        }
        this.currentScope = "device";
        this.currentViewId = "discovered_devices";
      } else if (parts[0] === "devices" && parts[1]) {
        const nextSubId = parts[1];
        if (
          this.state &&
          Array.isArray(this.state.system_devices) &&
          !this.state.system_devices.some((d) => d.subentry_id === nextSubId)
        ) {
          this.redirectInvalidDeviceRoute(nextSubId);
          return;
        }
        const requestedView = slugToView(DEVICE_VIEW_SLUGS, parts[2] || "overview") || "dashboard";
        this.onActiveDeviceChanged(prevSubId, nextSubId);
        const validView = this.deviceHasView(requestedView) ? requestedView : "dashboard";
        if (prevScope !== "device" || prevViewId !== validView || prevSubId !== nextSubId) {
          this.clearHandoffTargets();
        }
        this.currentScope = "device";
        this.currentViewId = validView;
        if (validView !== requestedView) {
          navigateHaPath(
            `/latter/devices/${encodeURIComponent(nextSubId)}/${DEVICE_VIEW_SLUGS[validView]}`,
            true,
          );
        }
      } else if (parts[0] === "system") {
        this.onActiveDeviceChanged(prevSubId, "");
        const viewId = slugToView(SYSTEM_VIEW_SLUGS, parts[1] || "overview") || "system_overview";
        if (prevScope !== "system" || prevViewId !== viewId) {
          this.clearHandoffTargets();
        } else if (viewId !== "area_tracking") {
          this.bleCalibrateHandoffActive = false;
        }
        this.currentScope = "system";
        this.currentViewId = viewId;
        if (viewId === "area_tracking") {
          this.ensureDefaultSurveyDevice();
        }
      } else {
        this.onActiveDeviceChanged(prevSubId, "");
        if (prevScope !== "device" || prevViewId !== "select_device_prompt") {
          this.clearHandoffTargets();
        }
        this.currentScope = "device";
        this.currentViewId = "select_device_prompt";
      }
      this.syncLiveClockTimer();
      this.host.requestUpdate();
    } finally {
      this.routeApplying = false;
    }
    if (this.host.isConnected && this.ws.hass && !this.studioRevMismatch) {
      void this.ensureSubscription(false);
    }
  }
  redirectInvalidDeviceRoute(invalidId) {
    const dropId = invalidId ?? this.activeSubentryId;
    this.onActiveDeviceChanged(dropId, "", { discardPrevPending: true });
    this.currentScope = "device";
    this.currentViewId = "select_device_prompt";
    navigateHaPath("/latter/devices", true);
    if (dropId) {
      this.showToast(this.t("sync.device_not_found"), false);
    }
    this.host.requestUpdate();
    if (this.host.isConnected && this.ws.hass && !this.studioRevMismatch) {
      void this.ensureSubscription(false);
    }
  }
  syncUrl(replace = false) {
    if (this.routeApplying) return;
    let targetPath = "/latter/devices";
    if (this.currentScope === "system") {
      const slug = SYSTEM_VIEW_SLUGS[this.currentViewId ] || "overview";
      targetPath = `/latter/system/${slug}`;
    } else if (this.currentViewId === "discovered_devices") {
      targetPath = "/latter/devices/discovered";
    } else if (
      this.deviceSelected &&
      this.activeSubentryId &&
      this.currentViewId !== "select_device_prompt"
    ) {
      const slug =
        DEVICE_VIEW_SLUGS[
          this.currentViewId
        ] || "overview";
      targetPath = `/latter/devices/${encodeURIComponent(this.activeSubentryId)}/${slug}`;
    }
    if (globalThis.location?.pathname !== targetPath) {
      navigateHaPath(targetPath, replace);
    }
  }
  openDevicesLanding() {
    this.onActiveDeviceChanged(this.activeSubentryId, "");
    this.clearHandoffTargets();
    this.currentScope = "device";
    this.currentViewId = "select_device_prompt";
    this.syncLiveClockTimer();
    this.syncUrl();
    this.host.requestUpdate();
    void this.ensureSubscription(false);
  }
  openDiscoveredDevices(cardId = "") {
    this.onActiveDeviceChanged(this.activeSubentryId, "");
    this.clearHandoffTargets();
    this.currentScope = "device";
    this.currentViewId = "discovered_devices";
    this.syncLiveClockTimer();
    this.syncUrl();
    this.host.requestUpdate();
    this.applySectionHandoff(cardId);
    void this.ensureSubscription(false);
  }
  openDevicesWithCategory(category) {
    this.deviceCategoryFilter = category;
    this.openDevicesLanding();
  }
  setScope(scope, explicitViewId) {
    if (scope === "device" && this.currentScope !== "device") {
      void this.entity.flushSystemSettings();
    } else if (scope === "system") {
      this.onActiveDeviceChanged(this.activeSubentryId, "");
    }
    this.clearHandoffTargets();
    this.currentScope = scope;
    if (explicitViewId) {
      this.currentViewId = explicitViewId;
    } else if (scope === "system") {
      this.currentViewId = "system_overview";
    } else {
      this.currentViewId =
        this.deviceSelected && this.activeSubentryId ? "dashboard" : "select_device_prompt";
    }
    if (this.currentViewId === "area_tracking") {
      this.ensureDefaultSurveyDevice();
    }
    this.syncLiveClockTimer();
    this.syncUrl();
    this.host.requestUpdate();
    void this.ensureSubscription(false);
  }
  switchView(viewId) {
    if (viewId === "select_device_prompt") {
      this.openDevicesLanding();
      return;
    }
    if (viewId === "discovered_devices") {
      this.openDiscoveredDevices();
      return;
    }
    this.clearHandoffTargets();
    const isSys = Object.prototype.hasOwnProperty.call(SYSTEM_VIEW_SLUGS, viewId);
    if (isSys) {
      this.onActiveDeviceChanged(this.activeSubentryId, "");
    }
    this.currentScope = isSys ? "system" : "device";
    this.currentViewId = viewId;
    if (viewId === "area_tracking") {
      this.ensureDefaultSurveyDevice();
    }
    this.syncLiveClockTimer();
    this.syncUrl();
    this.host.requestUpdate();
    void this.ensureSubscription(false);
  }
  openSystemSection(
    viewId,
    cardId = "",
    highlightIds,
  ) {
    this.switchView(viewId);
    this.applySectionHandoff(cardId, highlightIds);
  }
  openDeviceSection(
    viewId,
    cardId = "",
    highlightIds,
  ) {
    this.switchView(viewId);
    this.applySectionHandoff(cardId, highlightIds);
  }
  openManageGroups(groupId = "") {
    const cleanId = String(groupId || "").trim();
    if (cleanId && cleanId !== "custom") {
      this.openGroupIds.add(cleanId);
      this.openSystemSection("system_sync", `group-box-${cleanId}`);
      return;
    }
    this.openSystemSection("system_sync");
  }
  async switchSystemDevice(
    nextSubentryId,
    targetView = "dashboard",
  ) {
    const cleanNext = String(nextSubentryId || "").trim();
    if (!cleanNext) return;
    this.onActiveDeviceChanged(this.activeSubentryId, cleanNext);
    this.currentScope = "device";
    const desired =
      targetView === "select_device_prompt" || targetView === "discovered_devices"
        ? "dashboard"
        : targetView;
    this.currentViewId = this.deviceHasView(desired) ? desired : "dashboard";
    this.syncLiveClockTimer();
    this.syncUrl();
    this.host.requestUpdate();
    await this.ensureSubscription(false);
  }
  openHaPage(path) {
    navigateHaPath(path, false);
  }
  openDeviceInHa(preferLatterEntry = false) {
    const links = this.state?.links;
    const devId = preferLatterEntry
      ? links?.latter_device_id || links?.esphome_device_id || ""
      : links?.esphome_device_id || links?.latter_device_id || "";
    if (devId) {
      this.openHaPage(`/config/devices/device/${encodeURIComponent(devId)}`);
    } else {
      this.openHaPage("/config/integrations/integration/latter");
    }
  }
  toggleParentHaSidebar() {
    this.host.dispatchEvent(
      new CustomEvent("hass-toggle-menu", { bubbles: true, composed: true }),
    );
  }
  // ---------- Subscription, Backoff & State Ingestion ----------
  teardownSubscription() {
    this.subGen += 1;
    if (typeof this.wsUnsub === "function") {
      try {
        this.wsUnsub();
      } catch {
        // Ignore stale unsubscribe errors on disconnect.
      }
    }
    this.wsUnsub = null;
    this.subscribedKey = "";
  }
  desiredSubscriptionKey() {
    const sub = this.deviceSelected ? this.activeSubentryId || "" : "";
    const survey =
      this.currentScope === "system" &&
      this.currentViewId === "area_tracking" &&
      this.bleLiveStreamActive
        ? this.bleSurveySubentryId || ""
        : "";
    const logs = this.shouldIncludeLogs() ? "1" : "0";
    return `${sub}|${survey}|${logs}`;
  }
  async ensureSubscription(forceResubscribe = false) {
    if (this.studioRevMismatch || !this.ws.hass?.connection) return;
    const nextKey = this.desiredSubscriptionKey();
    if (!forceResubscribe && this.wsUnsub && this.subscribedKey === nextKey) {
      return;
    }
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    this.teardownSubscription();
    const myGen = ++this.subGen;
    const targetSubId = this.deviceSelected ? this.activeSubentryId || null : null;
    const surveyId =
      this.currentScope === "system" &&
      this.currentViewId === "area_tracking" &&
      this.bleLiveStreamActive
        ? this.bleSurveySubentryId || null
        : null;
    const includeLogs = this.shouldIncludeLogs();
    try {
      const unsub = await this.ws.subscribe(
        {
          subentryId: targetSubId,
          surveySubentryId: surveyId,
          includeLogs,
        },
        (eventPayload) => {
          if (myGen !== this.subGen || !eventPayload) return;
          this.handleSubscriptionEvent(eventPayload, includeLogs);
        },
      );
      if (myGen !== this.subGen) {
        try {
          unsub();
        } catch {
          // Ignore stale teardown.
        }
        return;
      }
      this.wsUnsub = unsub;
      this.subscribedKey = nextKey;
      this.reconnectAttempt = 0;
    } catch (err) {
      if (isStudioRevMismatchError(err) || this.studioRevMismatch) {
        this.handleStudioRevMismatch();
        return;
      }
      if (!this.state) {
        this.loading = false;
        this.loadError = formatWsError(err, "Latter Studio could not connect.");
        this.host.requestUpdate();
      }
      const delay =
        RECONNECT_BACKOFF_MS[
          Math.min(this.reconnectAttempt, RECONNECT_BACKOFF_MS.length - 1)
        ];
      this.reconnectAttempt += 1;
      if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
      this.reconnectTimer = setTimeout(() => {
        this.reconnectTimer = null;
        if (this.host.isConnected && !this.studioRevMismatch) {
          void this.ensureSubscription(true);
        }
      }, delay);
    }
  }
  async refreshState(options) {
    if (this.studioRevMismatch || !this.ws.hass) return;
    const reqSeq = ++this.stateReqSeq;
    const targetSubId = this.deviceSelected ? this.activeSubentryId || null : null;
    const includeLogs = options?.includeLogs ?? this.shouldIncludeLogs();
    try {
      const payload = await this.ws.getState({
        subentryId: targetSubId,
        includeLogs,
      });
      if (reqSeq < this.lastAppliedReqSeq) return;
      this.lastAppliedReqSeq = reqSeq;
      this.loadError = "";
      this.loading = false;
      this.ingestPayload(payload, includeLogs);
      if (!this.wsUnsub && this.host.isConnected && !this.studioRevMismatch) {
        void this.ensureSubscription(false);
      }
    } catch (err) {
      if (isStudioRevMismatchError(err) || this.studioRevMismatch) {
        this.handleStudioRevMismatch();
        return;
      }
      if (reqSeq < this.lastAppliedReqSeq) return;
      this.loading = false;
      this.loadError = formatWsError(err, "Latter Studio could not load.");
      this.host.requestUpdate();
    }
  }
          handleSubscriptionEvent(raw, subscribedWithLogs) {
    if (!raw || typeof raw !== "object") return;
    const rec = raw;
    if (rec.type === "ble_survey_delta") {
      this.applyBleSurveyDelta(rec);
      return;
    }
    const payload = raw;
    this.loading = false;
    this.loadError = "";
    this.ingestPayload(payload, subscribedWithLogs);
  }
  applyBleSurveyDelta(delta) {
    if (!this.state) return;
    if (!this.bleLiveStreamActive) {
      let updated = false;
      if (Array.isArray(delta.ble_area_signatures)) {
        this.state = {
          ...this.state,
          ble_area_signatures: delta.ble_area_signatures,
        };
        updated = true;
      }
      if (Array.isArray(delta.area_presence_grid) && this.state.live) {
        this.state = {
          ...this.state,
          live: {
            ...this.state.live,
            area_presence_grid: delta.area_presence_grid,
          },
        };
        updated = true;
      }
      if (updated) {
        this.host.requestUpdate();
      }
      return;
    }
    const targetId = String(
      delta.subentry_id || this.bleSurveySubentryId || this.state.subentry_id || "",
    );
    let nextDevices = this.state.system_devices;
    let nextLive = this.state.live;
    if (Array.isArray(delta.ble_survey_rows)) {
      const nextRows = delta.ble_survey_rows;
      const winRow = nextRows.find((r) => r.is_winner);
      if (Array.isArray(nextDevices) && targetId) {
        nextDevices = nextDevices.map((dev) => {
          if (dev.subentry_id !== targetId) return dev;
          return {
            ...dev,
            ble_survey_rows: nextRows,
            ble_packets_seen:
              typeof delta.ble_packets_seen === "number"
                ? delta.ble_packets_seen
                : dev.ble_packets_seen,
            active_area_name: winRow?.area_name || dev.active_area_name,
          };
        });
      }
      if (
        this.state.subentry_id === targetId &&
        nextLive &&
        typeof delta.ble_closest_proxy === "string"
      ) {
        nextLive = {
          ...nextLive,
          ble_closest_proxy: delta.ble_closest_proxy,
        };
      }
    }
    if (Array.isArray(delta.area_presence_grid) && nextLive) {
      nextLive = {
        ...nextLive,
        area_presence_grid: delta.area_presence_grid,
      };
    }
    this.state = {
      ...this.state,
      system_devices: nextDevices,
      ble_area_signatures: Array.isArray(delta.ble_area_signatures)
        ? (delta.ble_area_signatures)
        : this.state.ble_area_signatures,
      live: nextLive,
    };
    this.host.requestUpdate();
  }
          mergeFrozenBleRows(
    devices,
  ) {
    if (this.bleLiveStreamActive || !Array.isArray(devices)) return devices;
    return devices.map((dev) => {
      if (!dev.subentry_id) return dev;
      const frozen = this.bleSurveyFrozen.get(dev.subentry_id);
      if (frozen) {
        return {
          ...dev,
          ble_survey_rows: frozen.rows.map((r) => ({ ...r })),
          ble_packets_seen: frozen.packetsSeen,
          active_area_name: frozen.activeAreaName,
        };
      }
      this.bleSurveyFrozen.set(dev.subentry_id, {
        rows: (dev.ble_survey_rows || []).map((r) => ({ ...r })),
        packetsSeen: dev.ble_packets_seen ?? 0,
        activeAreaName: dev.active_area_name || "",
      });
      return dev;
    });
  }
  ingestPayload(incoming, logsWereRequested) {
    const prev = this.state;
    const prevSysConfig = prev?.system_config;
    // Resolve section-hash omitted fields (`#10`)
    const mergedCatalog = incoming.catalog ?? prev?.catalog;
    const mergedPrefSpecs = incoming.pref_specs ?? prev?.pref_specs;
    const mergedWorldClockZones = incoming.world_clock_zones ?? prev?.world_clock_zones;
    const mergedSystemWallpapers =
      incoming.system_wallpapers ?? prev?.system_wallpapers ?? [];
    const mergedBleSignatures =
      incoming.ble_area_signatures ?? prev?.ble_area_signatures;
    const mergedDiscoveredBle =
      incoming.discovered_ble_devices !== undefined
        ? this.stabilizeDiscoveredBle(
            incoming.discovered_ble_devices,
            incoming.system_devices,
          )
        : prev?.discovered_ble_devices ?? [];
    const mergedLogs =
      logsWereRequested ||
      (Array.isArray(incoming.internal_logs) && incoming.internal_logs.length > 0)
        ? incoming.internal_logs || []
        : prev?.internal_logs || [];
    const mergedSystemDevices = this.mergeFrozenBleRows(incoming.system_devices);
    if (incoming.subentry_id && incoming.device_config_rev > 0) {
      this.recordKnownDeviceConfigRev(incoming.subentry_id, incoming.device_config_rev);
    }
    // Active Device missing from `system_devices` -> discard pending edits & redirect to `/latter/devices` (`B-19`, `B-24`)
    if (
      this.deviceSelected &&
      this.activeSubentryId &&
      Array.isArray(mergedSystemDevices) &&
      !mergedSystemDevices.some((d) => d.subentry_id === this.activeSubentryId)
    ) {
      const sysOnly = {
        ...incoming,
        system_devices: mergedSystemDevices,
        discovered_ble_devices: mergedDiscoveredBle,
        system_wallpapers: mergedSystemWallpapers,
        ble_area_signatures: mergedBleSignatures,
        catalog: mergedCatalog,
        pref_specs: mergedPrefSpecs,
        world_clock_zones: mergedWorldClockZones,
        internal_logs: mergedLogs,
        device_prefs: incoming.device_prefs || [],
      };
      const effSysPatch = this.entity.getEffectiveSystemPatch();
      if (Object.keys(effSysPatch).length > 0 && sysOnly.system_config) {
        sysOnly.system_config = {
          ...sysOnly.system_config,
          ...(effSysPatch),
        };
      }
      overlayPendingBlankListSlots(this, sysOnly, prevSysConfig);
      this.state = sysOnly;
      this.redirectInvalidDeviceRoute(this.activeSubentryId);
      return;
    }
    // Cross-Device payload guard (`B-01`, `B-02`, `R-2`):
    // When a Device is selected, never clobber Device-specific sections with a mismatched `subentry_id` payload.
    if (
      this.deviceSelected &&
      this.activeSubentryId &&
      incoming.subentry_id !== this.activeSubentryId
    ) {
      const keepPrevDevice = prev && prev.subentry_id === this.activeSubentryId;
      const sysMerged = {
        ...(keepPrevDevice ? prev : incoming),
        version: incoming.version,
        studio_rev: incoming.studio_rev ?? prev?.studio_rev,
        system_config_rev: incoming.system_config_rev,
        system_info: incoming.system_info ?? prev?.system_info,
        locale_strings: incoming.locale_strings ?? prev?.locale_strings,
        internal_logs: mergedLogs,
        system_devices: mergedSystemDevices,
        issues: incoming.issues,
        ble_proxy_count: incoming.ble_proxy_count,
        ble_area_signatures: mergedBleSignatures,
        discovered_latter_devices: incoming.discovered_latter_devices,
        ignored_latter_devices:
          incoming.ignored_latter_devices ?? prev?.ignored_latter_devices,
        discovered_ble_devices: mergedDiscoveredBle,
        system_controls: incoming.system_controls,
        device_groups: incoming.device_groups,
        system_config: incoming.system_config,
        has_security_pin: incoming.has_security_pin,
        system_wallpapers: mergedSystemWallpapers,
        doorbells: incoming.doorbells,
        catalog: mergedCatalog,
        pref_specs: mergedPrefSpecs,
        world_clock_zones: mergedWorldClockZones,
        // Preserve active Device fields if already loaded, else clean empty placeholders while `deviceLoading` stays true
        subentry_id: keepPrevDevice ? prev.subentry_id : "",
        title: keepPrevDevice ? prev.title : "",
        device_config_rev: keepPrevDevice ? prev.device_config_rev : 0,
        capabilities: keepPrevDevice ? prev.capabilities : {},
        config: keepPrevDevice ? prev.config : {},
        device_prefs: keepPrevDevice ? prev.device_prefs : [],
        quick_actions: keepPrevDevice ? prev.quick_actions : [],
        speaker_volume: keepPrevDevice ? prev.speaker_volume : null,
        esphome: keepPrevDevice ? prev.esphome : { device: {}, sections: [] },
        wallpapers: keepPrevDevice ? prev.wallpapers : [],
        links: keepPrevDevice ? prev.links : undefined,
        live: keepPrevDevice
          ? {
              ...prev.live,
              area_presence_grid:
                incoming.live?.area_presence_grid ?? prev.live.area_presence_grid,
            }
          : { area_presence_grid: incoming.live?.area_presence_grid },
      };
      const effSysPatch = this.entity.getEffectiveSystemPatch();
      if (Object.keys(effSysPatch).length > 0 && sysMerged.system_config) {
        sysMerged.system_config = {
          ...sysMerged.system_config,
          ...(effSysPatch),
        };
      }
      overlayPendingBlankListSlots(this, sysMerged, prevSysConfig);
      this.deviceLoading = !keepPrevDevice;
      this.state = sysMerged;
      this.ensureDefaultSurveyDevice();
      this.ensureDefaultDoorbellTester();
      this.ensureValidBatchTargetFilter();
      this.syncLiveClockTimer();
      this.host.requestUpdate();
      if (!keepPrevDevice && this.host.isConnected && this.ws.hass && !this.studioRevMismatch) {
        void this.ensureSubscription(false);
      }
      return;
    }
    // Matching payload (either System/list view or matching `activeSubentryId`)
    this.deviceLoading = false;
    const merged = {
      ...incoming,
      system_devices: mergedSystemDevices,
      discovered_ble_devices: mergedDiscoveredBle,
      system_wallpapers: mergedSystemWallpapers,
      ble_area_signatures: mergedBleSignatures,
      catalog: mergedCatalog,
      pref_specs: mergedPrefSpecs,
      world_clock_zones: mergedWorldClockZones,
      internal_logs: mergedLogs,
      device_prefs: incoming.device_prefs || [],
    };
    const effSysPatch = this.entity.getEffectiveSystemPatch();
    if (Object.keys(effSysPatch).length > 0 && merged.system_config) {
      merged.system_config = {
        ...merged.system_config,
        ...(effSysPatch),
      };
    }
    overlayPendingBlankListSlots(this, merged, prevSysConfig);
    if (merged.subentry_id) {
      const effDevPatch = this.entity.getEffectiveDevicePatch(merged.subentry_id);
      if (Object.keys(effDevPatch).length > 0 && merged.config) {
        overlayDevicePrefsOnSections(merged, effDevPatch);
      }
    }
    overlayPendingEntityStates(merged, this.pendingEntityStates);
    if (
      this.currentScope === "device" &&
      this.deviceSelected &&
      merged.subentry_id === this.activeSubentryId &&
      !deviceHasView(
        this.currentViewId,
        merged.capabilities,
        merged.config?.kind,
      )
    ) {
      this.currentViewId = "dashboard";
      this.syncUrl(true);
    }
    this.state = merged;
    this.ensureDefaultSurveyDevice();
    this.ensureDefaultDoorbellTester();
    this.ensureValidBatchTargetFilter();
    this.syncLiveClockTimer();
    this.host.requestUpdate();
  }
          stabilizeDiscoveredBle(
    candidates,
    systemDevices,
  ) {
    const RETENTION_MS = 90_000;
    const now = Date.now();
    const onboardedSlugs = new Set(
      (systemDevices || [])
        .map((d) => String(d.device_slug || "").trim().toLowerCase())
        .filter(Boolean),
    );
    for (const [addrKey, entry] of this.discoveredBleSeenCache.entries()) {
      const candSlug = String(
        (entry.candidate).slug || "",
      )
        .trim()
        .toLowerCase();
      if (
        now - entry.lastSeenMs > RETENTION_MS ||
        (candSlug && onboardedSlugs.has(candSlug))
      ) {
        this.discoveredBleSeenCache.delete(addrKey);
      }
    }
    const extraNoKey = [];
    for (const c of candidates) {
      const addrKey = String(c.target_address || "").trim().toLowerCase();
      if (addrKey) {
        this.discoveredBleSeenCache.set(addrKey, { candidate: c, lastSeenMs: now });
      } else {
        extraNoKey.push(c);
      }
    }
    return [
      ...Array.from(this.discoveredBleSeenCache.values(), (entry) => entry.candidate),
      ...extraNoKey,
    ];
  }
  toggleDiscoveredBlePause(paused) {
    const next = paused ?? !this.discoveredBlePaused;
    this.discoveredBlePaused = next;
    if (next) {
      this.discoveredBleFrozenSnapshot = [...(this.state?.discovered_ble_devices || [])];
    } else {
      this.discoveredBleFrozenSnapshot = null;
    }
    this.host.requestUpdate();
  }
  evictAdoptedBleCandidate(targetAddress) {
    const addrKey = String(targetAddress || "").trim().toLowerCase();
    if (!addrKey) return;
    this.discoveredBleSeenCache.delete(addrKey);
    this.discoveredBlePersonDrafts.delete(addrKey);
    if (this.discoveredBleFrozenSnapshot) {
      this.discoveredBleFrozenSnapshot = this.discoveredBleFrozenSnapshot.filter(
        (c) => String(c.target_address || "").trim().toLowerCase() !== addrKey,
      );
    }
  }
          ensureDefaultSurveyDevice() {
    const devs = this.state?.system_devices || [];
    const bleDevs = devs.filter((d) => d.ble_tracked || d.kind === "ble_tag");
    if (
      this.bleSurveySubentryId &&
      bleDevs.some((d) => d.subentry_id === this.bleSurveySubentryId)
    ) {
      return;
    }
    const current = bleDevs.find((d) => d.subentry_id === this.activeSubentryId);
    this.bleSurveySubentryId = current?.subentry_id || bleDevs[0]?.subentry_id || "";
  }
          ensureDefaultDoorbellTester() {
    const devs = (this.state?.system_devices || []).filter((d) => d.kind !== "ble_tag");
    if (
      this.doorbellTestSubentryId &&
      devs.some((d) => d.subentry_id === this.doorbellTestSubentryId)
    ) {
      return;
    }
    this.doorbellTestSubentryId = devs[0]?.subentry_id || "";
  }
          ensureValidBatchTargetFilter() {
    if (!this.batchTargetFilter.startsWith("group:")) return;
    const gid = this.batchTargetFilter.slice(6);
    if (gid === "custom") return;
    const groups = this.state?.device_groups || [];
    if (!groups.some((g) => g.id === gid)) {
      this.batchTargetFilter = "all";
      this.groups.resetBatchDraft();
    }
  }
}
__latterExp(__exports, { EntityController: () => EntityController, GroupsController: () => GroupsController, isCatalogItemSupported: () => isCatalogItemSupported, isProtectedNativeDockItem: () => isProtectedNativeDockItem, overlayDevicePrefsOnSections: () => overlayDevicePrefsOnSections, overlayPendingEntityStates: () => overlayPendingEntityStates, ToolsController: () => ToolsController, deviceHasView: () => deviceHasView, StudioStore: () => StudioStore });
//# sourceURL=latter-studio/src/state/store.ts
});
__latterDef("src/components/dialogs/world-clocks.ts", (__exports, __req) => {
const { MAX_WORLD_CLOCKS, WORLD_CLOCK_ZONES_CATALOG } = __req("src/constants.ts");
const { focusSafe, html, nothing } = __req("src/lib/lit.ts");
const { defaultLocaleTimeFormat } = __req("src/utils/format.ts");
const { renderSelectRow, renderSettingsRow, renderSortableList, renderSwitchRow, renderTrashIconButton } = __req("src/components/controls.ts");
/**
 * World Clocks & Time App Configuration Helpers (`#latter-app-config-modal` `time`, `D-038`, `D-039`, `D-064`).
 * - Sortable World Clocks list via `renderSortableList` (`≡` drag handle + focus-preserving `↑`/`↓`)
 * - `focusSafe` text bindings so live WS pushes never clobber typing
 */
const PINNED_UTC_ZONES = new Set([
  "UTC",
  "Etc/UTC",
  "GMT",
  "Etc/GMT",
  "Etc/GMT+0",
  "Etc/GMT-0",
  "Etc/GMT0",
]);
const IANA_ZONE_PATTERN = /^[A-Za-z0-9_+-]+(?:\/[A-Za-z0-9_+-]+)+$/;
const TEXT_INPUT_DEBOUNCE_MS = 600;
function isImeSafeEnter(ev) {
  return ev.key === "Enter" && !ev.isComposing && ev.keyCode !== 229;
}
function sanitizeClockLabel(raw, maxBytes = 32) {
  const str = String(raw ?? "");
  let collapsed = "";
  let prevSpace = true;
  for (const ch of str) {
    const code = ch.charCodeAt(0);
    if (
      code < 0x20 ||
      code === 0x7f ||
      ch === "|" ||
      ch === ";" ||
      ch === "\x1e" ||
      ch === "\x1f" ||
      ch === " " ||
      ch === "\t" ||
      ch === "\r" ||
      ch === "\n"
    ) {
      if (!prevSpace) {
        collapsed += " ";
        prevSpace = true;
      }
      continue;
    }
    collapsed += ch;
    prevSpace = false;
  }
  const trimmed = collapsed.trim();
  if (typeof TextEncoder === "undefined") {
    return trimmed.slice(0, maxBytes).trimEnd();
  }
  const enc = new TextEncoder();
  if (enc.encode(trimmed).length <= maxBytes) {
    return trimmed;
  }
  let out = "";
  for (const cp of trimmed) {
    if (enc.encode(out + cp).length > maxBytes) break;
    out += cp;
  }
  return out.trimEnd();
}
function fallbackLabelForIana(iana) {
  const tail = iana.split("/").pop() || iana;
  return sanitizeClockLabel(tail.replace(/_/g, " ")) || iana;
}
function parseWorldClocksSpec(raw) {
  const out = [];
  const seen = new Set();
  for (const part of String(raw ?? "").split(";")) {
    const rec = part.trim();
    if (!rec) continue;
    const pipeIdx = rec.indexOf("|");
    if (pipeIdx < 0) continue;
    const rawLbl = rec.slice(0, pipeIdx);
    const iana = rec.slice(pipeIdx + 1).trim();
    if (!iana || PINNED_UTC_ZONES.has(iana) || !IANA_ZONE_PATTERN.test(iana)) {
      continue;
    }
    const label = sanitizeClockLabel(rawLbl) || fallbackLabelForIana(iana);
    const dedupKey = `${label.toLowerCase()}|${iana}`;
    if (seen.has(dedupKey)) continue;
    seen.add(dedupKey);
    out.push({ label, iana });
    if (out.length >= MAX_WORLD_CLOCKS) break;
  }
  return out;
}
function serializeWorldClocksSpec(items) {
  return items
    .slice(0, MAX_WORLD_CLOCKS)
    .map((item) => {
      const cleaned = sanitizeClockLabel(item.label);
      return cleaned ? `${cleaned}|${item.iana}` : "";
    })
    .filter(Boolean)
    .join(";");
}
function renderTimeAppConfigBody(store) {
  const data = store.state;
  const cfg = data?.config || {};
  const zonesCatalog = data?.world_clock_zones?.length
    ? data.world_clock_zones
    : WORLD_CLOCK_ZONES_CATALOG;
  const knownZoneSet = new Set(zonesCatalog.map((z) => z.iana));
  const localClockLabelPref = store.entity.getPref("local_clock_label");
  const localClockLabelValue = sanitizeClockLabel(
    localClockLabelPref?.value ?? cfg.local_clock_label ?? "",
  );
  const showUtcClockPref = store.entity.getPref("show_utc_clock");
  const showUtcClock = showUtcClockPref
    ? Boolean(showUtcClockPref.value)
    : Boolean(cfg.show_utc_clock);
  const worldClocksPref = store.entity.getPref("world_clocks");
  const enabledWorldClocks = parseWorldClocksSpec(
    worldClocksPref?.value ?? cfg.world_clocks ?? "",
  );
  const atWorldClockLimit = enabledWorldClocks.length >= MAX_WORLD_CLOCKS;
  const renderWorldClockZoneOptions = (selectedIana) => {
    const missingSelected =
      selectedIana && !knownZoneSet.has(selectedIana)
        ? html`<option value=${selectedIana} selected>${selectedIana}</option>`
        : nothing;
    return html`${missingSelected}${zonesCatalog.map(
      (z) =>
        html`<option value=${z.iana} ?selected=${z.iana === selectedIana}>${z.label}</option>`,
    )}`;
  };
  const updateWorldClocks = (
    nextItems,
    focusId,
    debounceMs,
  ) => {
    store.entity.stageDeviceSetting(
      "world_clocks",
      serializeWorldClocksSpec(nextItems),
      focusId,
      debounceMs,
    );
  };
  const updateWorldClockItem = (
    idx,
    patch,
    focusId,
    debounceMs,
  ) => {
    if (idx < 0 || idx >= enabledWorldClocks.length) return;
    const prev = enabledWorldClocks[idx];
    const nextIana = (patch.iana ?? prev.iana).trim();
    if (!nextIana || PINNED_UTC_ZONES.has(nextIana) || !IANA_ZONE_PATTERN.test(nextIana)) {
      return;
    }
    const nextLabel =
      patch.label !== undefined ? sanitizeClockLabel(patch.label) : prev.label;
    if (!nextLabel) return;
    const dup = enabledWorldClocks.some(
      (item, i) =>
        i !== idx &&
        item.iana === nextIana &&
        item.label.toLowerCase() === nextLabel.toLowerCase(),
    );
    if (dup) return;
    const next = enabledWorldClocks.map((item, i) =>
      i === idx ? { label: nextLabel, iana: nextIana } : { ...item },
    );
    updateWorldClocks(next, focusId, debounceMs);
  };
  const reorderWorldClocks = (fromIdx, toIdx) => {
    if (
      fromIdx < 0 ||
      toIdx < 0 ||
      fromIdx >= enabledWorldClocks.length ||
      toIdx >= enabledWorldClocks.length ||
      fromIdx === toIdx
    ) {
      return;
    }
    const next = [...enabledWorldClocks];
    const [picked] = next.splice(fromIdx, 1);
    next.splice(toIdx, 0, picked);
    updateWorldClocks(next);
  };
  const removeWorldClock = (idx) => {
    updateWorldClocks(enabledWorldClocks.filter((_, i) => i !== idx));
  };
  const getRenderRoot = () =>
    (store.host)?.renderRoot ?? null;
  const onAddWorldClock = () => {
    if (atWorldClockLimit) return;
    const root = getRenderRoot();
    const newLabelEl = root?.getElementById(
      "cfg-world_clock_new_label",
    );
    const zoneSelEl = root?.getElementById(
      "cfg-world_clocks_add",
    );
    const typedLabel = sanitizeClockLabel(newLabelEl?.value ?? store.worldClockNewLabel);
    const picked = (zoneSelEl?.value ?? store.worldClockNewZone).trim();
    if (!typedLabel) {
      store.showToast(store.t("dialogs.toast_enter_city"), true);
      newLabelEl?.focus();
      return;
    }
    if (!picked || PINNED_UTC_ZONES.has(picked) || !IANA_ZONE_PATTERN.test(picked)) {
      store.showToast(store.t("dialogs.toast_select_tz"), true);
      zoneSelEl?.focus();
      return;
    }
    const dup = enabledWorldClocks.some(
      (item) =>
        item.iana === picked && item.label.toLowerCase() === typedLabel.toLowerCase(),
    );
    if (dup) {
      store.showToast(store.t("dialogs.toast_dup_world_clock"), true);
      return;
    }
    store.worldClockNewLabel = "";
    store.worldClockNewZone = "";
    if (newLabelEl) newLabelEl.value = "";
    if (zoneSelEl) zoneSelEl.value = "";
    updateWorldClocks(
      [...enabledWorldClocks, { label: typedLabel, iana: picked }],
      "btn-world_clock_add",
    );
  };
  const timeFormatPref = store.entity.getPref("time_format");
  const timeFormatSpec = store.entity.getPrefSpec("time_format");
  const rawTimeFormatOpts =
    timeFormatPref?.options && timeFormatPref.options.length > 0
      ? timeFormatPref.options
      : timeFormatSpec?.options || [];
  const rawTimeFormatCandidate = timeFormatPref?.value ?? cfg.time_format;
  const resolvedTimeFormat =
    rawTimeFormatCandidate !== undefined &&
    rawTimeFormatCandidate !== null &&
    String(rawTimeFormatCandidate).trim() !== ""
      ? String(rawTimeFormatCandidate)
      : defaultLocaleTimeFormat(store.hass);
  return html`<div class="settings-list">
    ${rawTimeFormatOpts.length > 0
      ? renderSelectRow({
          id: "cfg-time_format",
          label: store.tPrefLabel("time_format"),
          description: store.t("dev_interface.time_format_desc"),
          value: rawTimeFormatOpts.includes(resolvedTimeFormat)
            ? resolvedTimeFormat
            : rawTimeFormatOpts[0],
          rawOptions: rawTimeFormatOpts.map((opt) => ({
            value: opt,
            label: store.tPrefOption("time_format", opt),
          })),
          onChange: (val) =>
            store.entity.stageDeviceSetting("time_format", val, "cfg-time_format"),
        })
      : nothing}
    ${renderSettingsRow({
      id: "time-local-clock-label",
      label: store.t("dialogs.local_clock_label"),
      forId: "cfg-local_clock_label",
      description: store.t("dialogs.local_clock_desc"),
      control: html`<input
        type="text"
        id="cfg-local_clock_label"
        maxlength="32"
        enterkeyhint="done"
        placeholder=${store.t("dialogs.optional_label_placeholder")}
        .value=${focusSafe(localClockLabelValue)}
        @input=${(ev) => {
          const cleaned = sanitizeClockLabel((ev.currentTarget).value);
          store.entity.stageDeviceSetting(
            "local_clock_label",
            cleaned,
            "cfg-local_clock_label",
            TEXT_INPUT_DEBOUNCE_MS,
          );
        }}
        @change=${(ev) => {
          const el = ev.currentTarget;
          const cleaned = sanitizeClockLabel(el.value);
          el.value = cleaned;
          store.entity.stageDeviceSetting("local_clock_label", cleaned, "cfg-local_clock_label");
        }}
        @keydown=${(ev) => {
          if (!isImeSafeEnter(ev)) return;
          ev.preventDefault();
          const el = ev.currentTarget;
          const cleaned = sanitizeClockLabel(el.value);
          el.value = cleaned;
          store.entity.stageDeviceSetting("local_clock_label", cleaned, "cfg-local_clock_label");
          void store.entity.flushAllPendingSettings();
        }}
      />`,
    })}
    ${renderSwitchRow({
      id: "cfg-show_utc_clock",
      label: store.t("dialogs.show_utc_label"),
      description: store.t("dialogs.show_utc_desc"),
      checked: showUtcClock,
      onChange: (checked) => {
        store.entity.stageDeviceSetting("show_utc_clock", checked, "cfg-show_utc_clock");
      },
    })}
    ${renderSettingsRow({
      id: "time-world-clocks",
      label: store.t("dialogs.world_clocks_label"),
      description: store.t("dialogs.world_clocks_desc"),
      stacked: true,
      control: html`<div class="stack">
        ${enabledWorldClocks.length > 0
          ? renderSortableList({
              id: "world-clocks-list",
              ariaLabel: store.t("dialogs.world_clocks_aria"),
              items: enabledWorldClocks,
              getKey: (entry) => `${entry.label.toLowerCase()}|${entry.iana}`,
              getLabel: (entry) => entry.label,
              onReorder: reorderWorldClocks,
              overlay: store.localeOverlay,
              renderContent: (entry, idx) => {
                const lblId = `cfg-world_clock_${idx + 1}_label`;
                const zoneId = `cfg-world_clock_${idx + 1}_zone`;
                return html`<div class="list-row-main">
                  <div class="stacked-field">
                    <label for=${lblId}>
                      ${store.t("dialogs.world_clock_city_label", { index: idx + 1 })}
                    </label>
                    <input
                      type="text"
                      id=${lblId}
                      maxlength="32"
                      enterkeyhint="done"
                      placeholder=${store.t("dialogs.city_label_placeholder")}
                      .value=${focusSafe(entry.label)}
                      @input=${(ev) => {
                        const cleaned = sanitizeClockLabel(
                          (ev.currentTarget).value,
                        );
                        if (cleaned) {
                          updateWorldClockItem(
                            idx,
                            { label: cleaned },
                            lblId,
                            TEXT_INPUT_DEBOUNCE_MS,
                          );
                        }
                      }}
                      @change=${(ev) => {
                        const el = ev.currentTarget;
                        const cleaned = sanitizeClockLabel(el.value);
                        if (!cleaned) {
                          el.value = entry.label;
                          store.showToast(store.t("dialogs.toast_city_empty"), true);
                          return;
                        }
                        el.value = cleaned;
                        updateWorldClockItem(idx, { label: cleaned }, lblId);
                      }}
                      @keydown=${(ev) => {
                        if (!isImeSafeEnter(ev)) return;
                        ev.preventDefault();
                        const el = ev.currentTarget;
                        const cleaned = sanitizeClockLabel(el.value);
                        if (!cleaned) {
                          el.value = entry.label;
                          store.showToast(store.t("dialogs.toast_city_empty"), true);
                          return;
                        }
                        el.value = cleaned;
                        updateWorldClockItem(idx, { label: cleaned }, lblId);
                        void store.entity.flushAllPendingSettings();
                      }}
                    />
                  </div>
                  <div class="stacked-field">
                    <label for=${zoneId}>
                      ${store.t("dialogs.world_clock_zone_label", { index: idx + 1 })}
                    </label>
                    <select
                      id=${zoneId}
                      .value=${entry.iana}
                      @change=${(ev) =>
                        updateWorldClockItem(
                          idx,
                          { iana: (ev.currentTarget).value },
                          zoneId,
                        )}
                    >
                      ${renderWorldClockZoneOptions(entry.iana)}
                    </select>
                  </div>
                </div>`;
              },
              renderActions: (entry, idx) =>
                renderTrashIconButton(
                  store.t("action.remove_item", {
                    item: `${entry.label} (${entry.iana})`,
                  }),
                  () => removeWorldClock(idx),
                ),
            })
          : nothing}
        <div class="list-row">
          <div class="list-row-main">
            <div class="stacked-field">
              <label for="cfg-world_clock_new_label">
                ${store.t("dialogs.new_city_label")}
              </label>
              <input
                type="text"
                id="cfg-world_clock_new_label"
                maxlength="32"
                enterkeyhint="done"
                placeholder=${store.t("dialogs.city_label_placeholder")}
                ?disabled=${atWorldClockLimit}
                .value=${focusSafe(store.worldClockNewLabel)}
                @input=${(ev) => {
                  store.worldClockNewLabel = (ev.currentTarget).value;
                  store.host.requestUpdate();
                }}
                @keydown=${(ev) => {
                  if (!isImeSafeEnter(ev)) return;
                  ev.preventDefault();
                  onAddWorldClock();
                }}
              />
            </div>
            <div class="stacked-field">
              <label for="cfg-world_clocks_add">${store.t("dialogs.add_time_zone")}</label>
              <select
                id="cfg-world_clocks_add"
                ?disabled=${atWorldClockLimit}
                .value=${store.worldClockNewZone}
                @change=${(ev) => {
                  store.worldClockNewZone = (ev.currentTarget).value;
                  store.host.requestUpdate();
                }}
              >
                <option value="" ?selected=${!store.worldClockNewZone}>
                  ${atWorldClockLimit
                    ? store.t("dialogs.max_world_clocks")
                    : store.t("dialogs.select_tz_placeholder")}
                </option>
                ${atWorldClockLimit
                  ? nothing
                  : renderWorldClockZoneOptions(store.worldClockNewZone)}
              </select>
            </div>
          </div>
          <button
            type="button"
            id="btn-world_clock_add"
            ?disabled=${atWorldClockLimit}
            @click=${() => onAddWorldClock()}
            class="btn btn-primary"
          >
            ${store.t("action.add")}
          </button>
        </div>
      </div>`,
    })}
  </div>`;
}
__latterExp(__exports, { sanitizeClockLabel: () => sanitizeClockLabel, parseWorldClocksSpec: () => parseWorldClocksSpec, serializeWorldClocksSpec: () => serializeWorldClocksSpec, renderTimeAppConfigBody: () => renderTimeAppConfigBody });
//# sourceURL=latter-studio/src/components/dialogs/world-clocks.ts
});
__latterDef("src/components/dialogs/app-config.ts", (__exports, __req) => {
const { AREA_CATEGORIES_CATALOG, CALENDAR_LOOKAHEAD_OPTIONS, CALENDAR_WEEK_START_OPTIONS, GAMES_ITEMS_CATALOG, HOME_CATEGORIES_CATALOG, MAX_PINNED_ITEMS, SHORTCUT_ROUTES_CATALOG, TOOLS_ITEMS_CATALOG } = __req("src/constants.ts");
const { html, nothing } = __req("src/lib/lit.ts");
const { ROUTE_PREVIEW_ICONS, shortcutActionLabel } = __req("src/mdi-catalog.ts");
const { isCatalogItemSupported } = __req("src/state/store.ts");
const { defaultLocaleTimeFormat } = __req("src/utils/format.ts");
const { renderNativeControlRow, renderPillList, renderSelectRow, renderSettingsRow, renderSortableList, renderTrashIconButton } = __req("src/components/controls.ts");
const { renderTimeAppConfigBody } = __req("src/components/dialogs/world-clocks.ts");
/**
 * Native App Configuration Modal (`#latter-app-config-modal`, `D-053`, `D-054`, `D-064`, `Q7`).
 * - Short-circuits closed `<dialog>` body (`F-06`, `B-18`, `R-5`)
 * - Zero `FALLBACK_*` option arrays & zero `typeof store.x === "function"` guards (`A-12`, `A-13`, `F-16`)
 * - Editable `Clock` modal (`app === "clock"`, `Q7`)
 * - `renderSortableList` / `renderPillList` across Pinned, World clocks, Home categories, Area categories, Tools, & Games (`U4`)
 * - Single `isCatalogItemSupported(item, caps)` gate (`A-14`)
 */
const APP_MODAL_TITLE_KEYS = {
  pinned: "dialogs.app_pinned",
  home_hub: "dialogs.app_home_hub",
  area: "dialogs.app_area",
  music: "dialogs.app_music",
  remote: "dialogs.app_remote",
  time: "dialogs.app_time",
  calendar: "dialogs.app_calendar",
  clock: "dialogs.app_clock",
  tools: "dialogs.app_tools",
  games: "dialogs.app_games",
};
function buildOrderedPillItems(
  catalog,
  enabledTokens,
  caps,
) {
  const supported = catalog.filter((c) => isCatalogItemSupported(c, caps));
  const byToken = new Map(supported.map((c) => [c.token, c]));
  const enabledSet = new Set();
  const out = [];
  for (const tok of enabledTokens) {
    const meta = byToken.get(tok);
    if (!meta || enabledSet.has(tok)) continue;
    enabledSet.add(tok);
    out.push({ token: tok, label: meta.label, enabled: true });
  }
  for (const item of supported) {
    if (enabledSet.has(item.token)) continue;
    out.push({ token: item.token, label: item.label, enabled: false });
  }
  return out;
}
function resolvePrefOptions(
  store,
  key,
  caps,
) {
  const livePref = store.entity.getPref(key);
  const spec = store.entity.getPrefSpec(key);
  const base =
    livePref?.options && livePref.options.length > 0
      ? livePref.options
      : spec?.options || [];
  if (key === "clock_face" && caps?.is_round === false) {
    return base.filter((opt) => opt !== "Modern Analog");
  }
  return base;
}
function resolvePrefStringValue(
  store,
  key,
  options,
) {
  const livePref = store.entity.getPref(key);
  const cfgVal = store.state?.config?.[key];
  const spec = store.entity.getPrefSpec(key);
  const rawCandidate = livePref?.value ?? cfgVal;
  const fallbackVal =
    key === "time_format"
      ? defaultLocaleTimeFormat(store.hass)
      : spec?.default ?? "";
  const raw =
    rawCandidate !== undefined && rawCandidate !== null && String(rawCandidate).trim() !== ""
      ? String(rawCandidate)
      : String(fallbackVal);
  if (options.length > 0 && !options.includes(raw)) {
    return options[0];
  }
  return raw;
}
function renderEditableSelectPref(
  store,
  key,
  domId,
  caps,
) {
  const options = resolvePrefOptions(store, key, caps);
  if (options.length === 0) return nothing;
  const curVal = resolvePrefStringValue(store, key, options);
  return renderSelectRow({
    id: domId || undefined,
    label: store.tPrefLabel(key),
    value: curVal,
    rawOptions: options.map((opt) => ({
      value: opt,
      label: store.tPrefOption(key, opt),
    })),
    onChange: (val) => store.entity.stageDeviceSetting(key, val, domId || undefined),
  });
}
function renderAppConfigModalBody(store) {
  const app = store.appConfigModal.app;
  if (!app) return nothing;
  const data = store.state;
  const cfg = data?.config || {};
  const caps = data?.capabilities;
  const titleKey = APP_MODAL_TITLE_KEYS[app];
  const title = titleKey ? store.t(titleKey) : store.t("dialogs.app_fallback");
  let body;
  let extraAction = nothing;
  let donePrimary = true;
  if (app === "pinned") {
    donePrimary = false;
    const pinnedItems = store.entity.getPinnedItems();
    const shortcutEntityMap = new Map(
      (data?.catalog?.shortcut_entities || []).map((e) => [e.id, e]),
    );
    const routeSpecMap = new Map(SHORTCUT_ROUTES_CATALOG.map((r) => [r.token, r]));
    const resolvePinnedMeta = (
      item,
    ) => {
      if (item.kind === "route") {
        const spec = routeSpecMap.get(item.target);
        return {
          displayTitle: item.label || spec?.label || item.target,
          metaLine: spec ? `${spec.group} • ${spec.label}` : item.target,
          iconSlug: item.icon || ROUTE_PREVIEW_ICONS[item.target] || "mdi:apps",
        };
      }
      const ent = shortcutEntityMap.get(item.target);
      const dom = item.target.split(".", 1)[0] || "";
      const actLbl = shortcutActionLabel(dom, item.action);
      const modeLbl = item.confirm
        ? store.t("dialogs.pinned_confirm_mode")
        : store.t("dialogs.pinned_one_tap_mode");
      return {
        displayTitle: item.label || ent?.name || item.target,
        metaLine: `${actLbl} • ${modeLbl} • ${item.target}`,
        iconSlug: item.icon || ent?.icon || "mdi:flash",
      };
    };
    body = html`<div class="settings-list">
      ${renderSettingsRow({
        id: "pinned-shortcuts-row",
        label: store.t("dialogs.pinned_label"),
        description: store.t("dialogs.pinned_desc"),
        stacked: true,
        control: html`<div class="stack">
          ${renderSortableList({
            id: "pinned-shortcuts-container",
            ariaLabel: store.t("dialogs.pinned_aria"),
            items: pinnedItems,
            rowClass: "shortcut-item-row",
            emptyState: store.t("dialogs.pinned_empty"),
            overlay: store.localeOverlay,
            getKey: (item) => `${item.kind}|${item.target}|${item.action}`,
            getLabel: (item) => resolvePinnedMeta(item).displayTitle,
            onReorder: (fromIdx, toIdx) =>
              store.entity.reorderShortcutItems("pinned_items", fromIdx, toIdx),
            renderContent: (item, idx) => {
              const info = resolvePinnedMeta(item);
              const pageNum = Math.floor(idx / 6) + 1;
              return html`<div class="shortcut-icon-row">
                <span class="shortcut-icon-badge" aria-hidden="true">
                  <ha-icon .icon=${info.iconSlug}></ha-icon>
                </span>
                <div class="shortcut-item-info">
                  <span class="shortcut-item-title">${info.displayTitle}</span>
                  <span class="shortcut-item-meta">${info.metaLine}</span>
                </div>
                <span class="chip">
                  ${store.t("dialogs.pinned_page_slot", { page: pageNum })}
                </span>
              </div>`;
            },
            renderActions: (item, idx) => {
              const info = resolvePinnedMeta(item);
              return html`<button
                  type="button"
                  aria-label=${store.t("action.edit_item", { item: info.displayTitle })}
                  @click=${() => store.entity.openShortcutModal("pinned_items", idx)}
                  class="btn btn-secondary btn-compact"
                >
                  ${store.t("action.edit")}
                </button>
                ${renderTrashIconButton(
                  store.t("action.remove_item", { item: info.displayTitle }),
                  () => store.entity.removeShortcutItem("pinned_items", idx),
                )}`;
            },
          })}
          <div class="shortcut-toolbar">
            <button
              type="button"
              id="btn-add-pinned-item"
              ?disabled=${pinnedItems.length >= MAX_PINNED_ITEMS}
              @click=${() => store.entity.openShortcutModal("pinned_items", null)}
              class="btn btn-primary"
            >
              ${store.t("action.add_pinned_item")}
            </button>
          </div>
        </div>`,
      })}
    </div>`;
  } else if (app === "home_hub") {
    const enabledHomeCats = store.entity.getEnabledHomeCategories();
    const pillItems = buildOrderedPillItems(HOME_CATEGORIES_CATALOG, enabledHomeCats, caps);
    body = html`<div class="settings-list">
      ${renderSettingsRow({
        label: store.t("dialogs.home_cats_label"),
        description: store.t("dialogs.home_cats_desc"),
        stacked: true,
        control: renderPillList({
          id: "home-categories-pills",
          ariaLabel: store.t("dialogs.home_cats_label"),
          items: pillItems,
          onToggle: (tok, next) => store.entity.toggleHomeCategoryToken(tok, next),
          onReorder: (fromIdx, toIdx) => store.entity.reorderHomeCategories(fromIdx, toIdx),
          overlay: store.localeOverlay,
        }),
      })}
    </div>`;
    extraAction = html`<button
      type="button"
      @click=${() => {
        store.entity.closeAppConfigModal();
        store.openSystemSection("shared_entities", "card-whole-home", [
          "card-whole-home",
          "card-cameras-doorbell",
        ]);
      }}
      class="btn btn-text"
    >
      ${store.t("action.open_shared_entities")}
    </button>`;
  } else if (app === "area") {
    const enabledAreaCats = store.entity.getEnabledAreaCategories();
    const pillItems = buildOrderedPillItems(AREA_CATEGORIES_CATALOG, enabledAreaCats, caps);
    const areaExtraItems = store.entity
      .getSectionItems("area")
      .filter((it) => it.key !== "ble_beacon_mode");
    body = html`<div class="settings-list">
      ${renderSettingsRow({
        label: store.t("dialogs.area_cats_label"),
        description: store.t("dialogs.area_cats_desc"),
        stacked: true,
        control: renderPillList({
          id: "area-categories-pills",
          ariaLabel: store.t("dialogs.area_cats_label"),
          items: pillItems,
          onToggle: (tok, next) => store.entity.toggleAreaCategoryToken(tok, next),
          onReorder: (fromIdx, toIdx) => store.entity.reorderAreaCategories(fromIdx, toIdx),
          overlay: store.localeOverlay,
        }),
      })}
      ${areaExtraItems.map((it) => renderNativeControlRow(store, it))}
    </div>`;
  } else if (app === "music") {
    const musicKeys = [
      "album_art_style",
      "music_overlay_style",
      "album_sort_order",
      "artist_album_sort_order",
      "podcast_sort_order",
    ];
    body = html`<div class="settings-list">
      ${musicKeys.map((k) => renderEditableSelectPref(store, k, `cfg-${k}`, caps))}
    </div>`;
  } else if (app === "remote") {
    const remoteGroups = data?.system_config?.remote_groups || [];
    const curDevEntry = (data?.system_devices || []).find(
      (d) => d.subentry_id === store.activeSubentryId,
    );
    const curRemoteMode =
      String(cfg.device_remote_group || curDevEntry?.device_remote_group || "area_auto").trim() ||
      "area_auto";
    const remoteModeOptions = [
      { value: "area_auto", label: store.t("dialogs.remote_follow_area") },
      ...remoteGroups.map((g) => ({
        value: `group:${g.id}`,
        label: store.t("dialogs.remote_group_option", { name: g.name }),
      })),
      { value: "all", label: store.t("dialogs.remote_all_system") },
    ];
    if (!remoteModeOptions.some((o) => o.value === curRemoteMode)) {
      const rawId = curRemoteMode.startsWith("group:") ? curRemoteMode.slice(6) : curRemoteMode;
      remoteModeOptions.push({
        value: curRemoteMode,
        label: store.t("dialogs.remote_missing_group", { id: rawId }),
      });
    }
    const remoteEspItems = store.entity.getSectionItems("remote");
    body = html`<div class="settings-list">
      ${renderSelectRow({
        id: "cfg-device_remote_group",
        label: store.t("dialogs.remote_group_label"),
        description: store.t("dialogs.remote_group_desc"),
        value: curRemoteMode,
        rawOptions: remoteModeOptions,
        onChange: (val) =>
          store.entity.stageDeviceSetting("device_remote_group", val, "cfg-device_remote_group"),
      })}
      ${remoteEspItems.map((it) => renderNativeControlRow(store, it))}
    </div>`;
    extraAction = html`<button
      type="button"
      @click=${() => {
        store.entity.closeAppConfigModal();
        store.openSystemSection("remotes", "card-remote-groups");
      }}
      class="btn btn-text"
    >
      ${store.t("dialogs.manage_remote_groups")}
    </button>`;
  } else if (app === "time") {
    donePrimary = false;
    body = renderTimeAppConfigBody(store);
  } else if (app === "clock") {
    body = html`<div class="settings-list">
      ${renderEditableSelectPref(store, "clock_face", "cfg-clock_face", caps)}
      ${renderEditableSelectPref(store, "time_format", "cfg-time_format", caps)}
    </div>`;
  } else if (app === "calendar") {
    const lookaheadPref = store.entity.getPref("calendar_lookahead_days");
    const rawLookahead = Number(lookaheadPref?.value ?? cfg.calendar_lookahead_days ?? 30);
    const lookaheadDays =
      rawLookahead <= 10 ? 7 : rawLookahead <= 21 ? 14 : rawLookahead <= 45 ? 30 : 60;
    const weekStartOpts = resolvePrefOptions(store, "calendar_week_start", caps);
    const resolvedWeekOpts = weekStartOpts.length > 0 ? weekStartOpts : CALENDAR_WEEK_START_OPTIONS;
    const weekStartVal = resolvePrefStringValue(
      store,
      "calendar_week_start",
      resolvedWeekOpts,
    );
    body = html`<div class="settings-list">
      ${renderSelectRow({
        id: "cfg-calendar_lookahead_days",
        label: store.t("dialogs.calendar_lookahead_label"),
        description: store.t("dialogs.calendar_lookahead_desc"),
        value: String(lookaheadDays),
        rawOptions: CALENDAR_LOOKAHEAD_OPTIONS.map((o) => ({
          value: String(o.value),
          label: o.label,
        })),
        onChange: (val) =>
          store.entity.stageDeviceSetting(
            "calendar_lookahead_days",
            Number(val),
            "cfg-calendar_lookahead_days",
          ),
      })}
      ${renderSelectRow({
        id: "cfg-calendar_week_start",
        label: store.t("dialogs.calendar_week_start_label"),
        description: store.t("dialogs.calendar_week_start_desc"),
        value: weekStartVal,
        rawOptions: resolvedWeekOpts.map((opt) => ({
          value: opt,
          label: store.tPrefOption("calendar_week_start", opt),
        })),
        onChange: (val) =>
          store.entity.stageDeviceSetting("calendar_week_start", val, "cfg-calendar_week_start"),
      })}
    </div>`;
    extraAction = html`<button
      type="button"
      @click=${() => {
        store.entity.closeAppConfigModal();
        store.openSystemSection("shared_entities", "card-calendars");
      }}
      class="btn btn-text"
    >
      ${store.t("action.open_shared_entities")}
    </button>`;
  } else if (app === "tools") {
    const enabledTools = store.entity.getEnabledToolsItems();
    const pillItems = buildOrderedPillItems(TOOLS_ITEMS_CATALOG, enabledTools, caps);
    body = html`<div class="settings-list">
      ${renderSettingsRow({
        label: store.t("dialogs.tools_label"),
        description: store.t("dialogs.tools_desc"),
        stacked: true,
        control: renderPillList({
          id: "tools-items-pills",
          ariaLabel: store.t("dialogs.tools_label"),
          items: pillItems,
          onToggle: (tok, next) => store.entity.toggleToolItemToken(tok, next),
          onReorder: (fromIdx, toIdx) => store.entity.reorderToolsItems(fromIdx, toIdx),
          overlay: store.localeOverlay,
        }),
      })}
    </div>`;
  } else {
    const enabledGames = store.entity.getEnabledGamesItems();
    const pillItems = buildOrderedPillItems(GAMES_ITEMS_CATALOG, enabledGames, caps);
    body = html`<div class="settings-list">
      ${renderSettingsRow({
        label: store.t("dialogs.games_label"),
        description: store.t("dialogs.games_desc"),
        stacked: true,
        control: renderPillList({
          id: "games-items-pills",
          ariaLabel: store.t("dialogs.games_label"),
          items: pillItems,
          onToggle: (tok, next) => store.entity.toggleGameItemToken(tok, next),
          onReorder: (fromIdx, toIdx) => store.entity.reorderGamesItems(fromIdx, toIdx),
          overlay: store.localeOverlay,
        }),
      })}
    </div>`;
  }
  return html`<div class="dialog-body">
    <h3 id="latter-app-config-title" class="dialog-title">${title}</h3>
    ${body}
    <div class="dialog-actions">
      ${extraAction}
      <button
        type="button"
        id="app-config-done-btn"
        @click=${() => store.entity.closeAppConfigModal()}
        class="btn ${donePrimary ? "btn-primary" : "btn-secondary"}"
      >
        ${store.t("action.done")}
      </button>
    </div>
  </div>`;
}
function renderAppConfigDialog(store) {
  const close = () => store.entity.closeAppConfigModal();
  const onBackdropClick = (ev) => {
    if (ev.target === ev.currentTarget) {
      close();
    }
  };
  return html`<dialog
    id="latter-app-config-modal"
    aria-labelledby="latter-app-config-title"
    @cancel=${close}
    @click=${onBackdropClick}
    class="studio-dialog shortcut-dialog"
  >
    ${store.appConfigModal.open ? renderAppConfigModalBody(store) : nothing}
  </dialog>`;
}
__latterExp(__exports, { renderAppConfigModalBody: () => renderAppConfigModalBody, renderAppConfigDialog: () => renderAppConfigDialog });
//# sourceURL=latter-studio/src/components/dialogs/app-config.ts
});
__latterDef("src/components/dialogs/color-wheel.ts", (__exports, __req) => {
const { focusSafe, html, nothing } = __req("src/lib/lit.ts");
const { hsvToHex, hsvToRgbJS, isValidHexColor } = __req("src/utils/format.ts");
/**
 * Custom HSV Color Wheel Modal (`#latter-cw-modal`, `A-24`).
 * - Short-circuits closed `<dialog>` body
 * - Uses per-store `store.colorWheelModal.painted` flag (zero module-global state)
 * - Uses component-scoped pointer capture on `<canvas>` and `focusSafe` text inputs
 */
function paintHsvColorWheel(canvas) {
  const ctx = canvas.getContext("2d");
  if (!ctx) return;
  const size = canvas.width;
  const radius = size / 2;
  const img = ctx.createImageData(size, size);
  const data = img.data;
  for (let y = 0; y < size; y += 1) {
    for (let x = 0; x < size; x += 1) {
      const dx = x - radius;
      const dy = y - radius;
      const dist = Math.sqrt(dx * dx + dy * dy);
      const idx = (y * size + x) * 4;
      if (dist > radius) {
        data[idx + 3] = 0;
        continue;
      }
      const sat = Math.min(1, dist / radius);
      const angle = ((Math.atan2(dy, dx) * 180) / Math.PI + 360) % 360;
      const [r, g, b] = hsvToRgbJS(angle, sat, 1);
      data[idx] = r;
      data[idx + 1] = g;
      data[idx + 2] = b;
      data[idx + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);
}
function pickWheelHexFromEvent(canvas, ev) {
  const rect = canvas.getBoundingClientRect();
  if (!rect.width || !rect.height) return null;
  const cx = rect.width / 2;
  const cy = rect.height / 2;
  const dx = ev.clientX - rect.left - cx;
  const dy = ev.clientY - rect.top - cy;
  const radius = Math.min(cx, cy);
  const sat = Math.min(1, Math.sqrt(dx * dx + dy * dy) / radius);
  const angle = ((Math.atan2(dy, dx) * 180) / Math.PI + 360) % 360;
  return hsvToHex(angle, sat, 1);
}
function syncColorWheelCanvas(renderRoot, store) {
  if (store.colorWheelModal.open && !store.colorWheelModal.painted) {
    const canvas = renderRoot.getElementById("latter-cw-canvas");
    if (canvas) {
      paintHsvColorWheel(canvas);
      store.colorWheelModal.painted = true;
    }
  } else if (!store.colorWheelModal.open && store.colorWheelModal.painted) {
    store.colorWheelModal.painted = false;
  }
}
function renderColorWheelDialog(store) {
  const modal = store.colorWheelModal;
  const onBackdropClick = (ev) => {
    if (ev.target === ev.currentTarget) {
      store.tools.closeColorWheelModal();
    }
  };
  if (!modal.open) {
    return html`<dialog
      id="latter-cw-modal"
      aria-labelledby="latter-cw-title"
      @cancel=${() => store.tools.closeColorWheelModal()}
      @click=${onBackdropClick}
      class="studio-dialog"
    >
      ${nothing}
    </dialog>`;
  }
  const onCwPointerDown = (ev) => {
    const pev = ev;
    const canvas = pev.currentTarget;
    canvas.setPointerCapture?.(pev.pointerId);
    const hex = pickWheelHexFromEvent(canvas, pev);
    if (hex) {
      store.colorWheelModal = { ...store.colorWheelModal, hex };
      store.host.requestUpdate();
    }
  };
  const onCwPointerMove = (ev) => {
    const pev = ev;
    if (pev.buttons === 0) return;
    const canvas = pev.currentTarget;
    const hex = pickWheelHexFromEvent(canvas, pev);
    if (hex) {
      store.colorWheelModal = { ...store.colorWheelModal, hex };
      store.host.requestUpdate();
    }
  };
  const onCwPointerUp = (ev) => {
    const pev = ev;
    const canvas = pev.currentTarget;
    if (canvas.hasPointerCapture?.(pev.pointerId)) {
      canvas.releasePointerCapture(pev.pointerId);
    }
  };
  const onCwHexInput = (ev) => {
    const raw = (ev.currentTarget).value;
    store.colorWheelModal = { ...store.colorWheelModal, hex: raw.toUpperCase() };
    store.host.requestUpdate();
  };
  const onCwNameInput = (ev) => {
    store.colorWheelModal = {
      ...store.colorWheelModal,
      name: (ev.currentTarget).value,
    };
  };
  const cwValidHex = isValidHexColor(modal.hex) ? modal.hex : "#3898FF";
  return html`<dialog
    id="latter-cw-modal"
    aria-labelledby="latter-cw-title"
    @cancel=${() => store.tools.closeColorWheelModal()}
    @click=${onBackdropClick}
    class="studio-dialog"
  >
    <div class="dialog-body">
      <h3 id="latter-cw-title" class="dialog-title">${store.t("dialogs.cw_title")}</h3>
      <div class="color-wheel" aria-hidden="true">
        <canvas
          id="latter-cw-canvas"
          width="220"
          height="220"
          @pointerdown=${onCwPointerDown}
          @pointermove=${onCwPointerMove}
          @pointerup=${onCwPointerUp}
        ></canvas>
      </div>
      <div class="color-hex-row">
        <input
          type="color"
          id="latter-cw-native"
          aria-label=${store.t("dialogs.cw_color_aria")}
          .value=${cwValidHex}
          @input=${onCwHexInput}
        />
        <input
          type="text"
          id="latter-cw-hex"
          aria-label=${store.t("dialogs.cw_hex_aria")}
          placeholder="#RRGGBB"
          maxlength="7"
          .value=${focusSafe(modal.hex)}
          @input=${onCwHexInput}
        />
      </div>
      <div class="stacked-field">
        <label for="latter-cw-name">${store.t("dialogs.cw_name_label")}</label>
        <input
          type="text"
          id="latter-cw-name"
          placeholder=${store.t("dialogs.cw_name_placeholder")}
          .value=${focusSafe(modal.name)}
          @input=${onCwNameInput}
        />
      </div>
      <div class="dialog-actions">
        <button
          type="button"
          @click=${() => store.tools.closeColorWheelModal()}
          class="btn btn-secondary"
        >
          ${store.t("action.cancel")}
        </button>
        <button
          type="button"
          ?disabled=${modal.busy}
          @click=${() => void store.tools.saveColorWheelSelection()}
          class="btn btn-primary"
        >
          ${store.t("action.save_color")}
        </button>
      </div>
    </div>
  </dialog>`;
}
__latterExp(__exports, { syncColorWheelCanvas: () => syncColorWheelCanvas, renderColorWheelDialog: () => renderColorWheelDialog });
//# sourceURL=latter-studio/src/components/dialogs/color-wheel.ts
});
__latterDef("src/components/dialogs/device-modals.ts", (__exports, __req) => {
const { focusSafe, html, nothing } = __req("src/lib/lit.ts");
const { renderSelectOptions, renderSwitchRow } = __req("src/components/controls.ts");
/**
 * Device & Group Lifecycle Modals (`#latter-rm-modal`, `#latter-reset-modal`,
 * `#latter-add-dev-modal`, `#latter-save-group-modal`, `Q5`, `E-19`, `F-06`).
 * - Short-circuits closed `<dialog>` shells
 * - Inline "Download backup first" + explicit consequence text on Remove & Reset
 * - `focusSafe` text inputs across BLE tag & Save custom group forms
 */
function bindBackdropClose(ev, closeFn) {
  if (ev.target === ev.currentTarget) {
    closeFn();
  }
}
function renderRemoveDeviceDialog(store) {
  const rm = store.removeModal;
  const close = () => store.tools.closeRemoveDeviceModal();
  if (!rm.open) {
    return html`<dialog
      id="latter-rm-modal"
      aria-labelledby="latter-rm-title"
      @cancel=${close}
      @click=${(ev) => bindBackdropClose(ev, close)}
      class="studio-dialog confirm-dialog"
    >
      ${nothing}
    </dialog>`;
  }
  const devTitle = rm.title || "Device";
  return html`<dialog
    id="latter-rm-modal"
    aria-labelledby="latter-rm-title"
    aria-describedby="latter-rm-desc"
    @cancel=${close}
    @click=${(ev) => bindBackdropClose(ev, close)}
    class="studio-dialog confirm-dialog"
  >
    <div class="dialog-body">
      <div class="dialog-header-row">
        <h3 id="latter-rm-title" class="dialog-title">
          ${store.t("confirm.remove_device.title", { title: devTitle })}
        </h3>
        <span class="chip chip-warning confirm-blast-badge">
          ${store.t("confirm.blast_radius_one")}
        </span>
      </div>
      <p id="latter-rm-desc" class="dialog-text">
        ${store.t("confirm.remove_device.body", { title: devTitle })}
      </p>
      <div class="dialog-actions with-secondary">
        <button
          type="button"
          ?disabled=${rm.busy || !rm.subentryId}
          @click=${() => void store.tools.exportBackup(rm.subentryId)}
          class="btn btn-text btn-compact"
        >
          ${store.t("action.download_backup_first")}
        </button>
        <div class="dialog-actions-end">
          <button type="button" @click=${close} class="btn btn-secondary">
            ${store.t("action.cancel")}
          </button>
          <button
            type="button"
            ?disabled=${rm.busy}
            @click=${() => void store.tools.confirmRemoveDevice()}
            class="btn btn-danger-filled"
          >
            ${store.t("confirm.remove_device.confirm")}
          </button>
        </div>
      </div>
    </div>
  </dialog>`;
}
function renderResetDeviceDialog(store) {
  const rs = store.resetModal;
  const close = () => store.tools.closeResetDeviceModal();
  if (!rs.open) {
    return html`<dialog
      id="latter-reset-modal"
      aria-labelledby="latter-reset-title"
      @cancel=${close}
      @click=${(ev) => bindBackdropClose(ev, close)}
      class="studio-dialog confirm-dialog"
    >
      ${nothing}
    </dialog>`;
  }
  return html`<dialog
    id="latter-reset-modal"
    aria-labelledby="latter-reset-title"
    aria-describedby="latter-reset-desc"
    @cancel=${close}
    @click=${(ev) => bindBackdropClose(ev, close)}
    class="studio-dialog confirm-dialog"
  >
    <div class="dialog-body">
      <div class="dialog-header-row">
        <h3 id="latter-reset-title" class="dialog-title">
          ${store.t("confirm.reset_device.title")}
        </h3>
        <span class="chip chip-warning confirm-blast-badge">
          ${store.t("confirm.blast_radius_one")}
        </span>
      </div>
      <div class="settings-list">
        ${renderSwitchRow({
          id: "latter-reset-device-settings",
          label: store.t("confirm.reset_device.device_settings"),
          description: store.t("confirm.reset_device.device_settings_desc"),
          checked: rs.deviceSettings,
          onChange: (checked) => {
            store.resetModal = { ...store.resetModal, deviceSettings: checked };
            store.host.requestUpdate();
          },
        })}
        ${renderSwitchRow({
          id: "latter-reset-latter-options",
          label: store.t("confirm.reset_device.latter_options"),
          description: store.t("confirm.reset_device.latter_options_desc"),
          checked: rs.latterOptions,
          onChange: (checked) => {
            store.resetModal = { ...store.resetModal, latterOptions: checked };
            store.host.requestUpdate();
          },
        })}
      </div>
      <p id="latter-reset-desc" class="dialog-text">
        ${store.t("confirm.reset_device.body")}
      </p>
      <div class="dialog-actions with-secondary">
        <button
          type="button"
          ?disabled=${rs.busy || !store.activeSubentryId}
          @click=${() => void store.tools.exportBackup(store.activeSubentryId)}
          class="btn btn-text btn-compact"
        >
          ${store.t("action.download_backup_first")}
        </button>
        <div class="dialog-actions-end">
          <button type="button" @click=${close} class="btn btn-secondary">
            ${store.t("action.cancel")}
          </button>
          <button
            type="button"
            id="latter-reset-confirm-btn"
            ?disabled=${rs.busy || (!rs.deviceSettings && !rs.latterOptions)}
            @click=${() => void store.tools.confirmResetDevice()}
            class="btn btn-danger-filled"
          >
            ${store.t("confirm.reset_device.confirm")}
          </button>
        </div>
      </div>
    </div>
  </dialog>`;
}
function renderAddBleDialog(store) {
  const modal = store.addBleModal;
  const close = () => store.tools.closeAddBleModal();
  if (!modal.open) {
    return html`<dialog
      id="latter-add-dev-modal"
      aria-labelledby="latter-add-dev-title"
      @cancel=${close}
      @click=${(ev) => bindBackdropClose(ev, close)}
      class="studio-dialog"
    >
      ${nothing}
    </dialog>`;
  }
  const persons = store.state?.catalog?.persons || [];
  const candidates = store.state?.discovered_ble_devices || [];
  return html`<dialog
    id="latter-add-dev-modal"
    aria-labelledby="latter-add-dev-title"
    @cancel=${close}
    @click=${(ev) => bindBackdropClose(ev, close)}
    class="studio-dialog"
  >
    <div class="dialog-body">
      <h3 id="latter-add-dev-title" class="dialog-title">${store.t("dialogs.ble_title")}</h3>
      <p class="dialog-text">${store.t("dialogs.ble_body")}</p>
      <div class="stacked-field">
        <label for="ble-candidate-picker">${store.t("dialogs.ble_discovered_label")}</label>
        <select
          id="ble-candidate-picker"
          .value=${modal.candidateAddr}
          @change=${(ev) =>
            store.tools.selectBleCandidateInModal((ev.currentTarget).value)}
        >
          <option value="">${store.t("dialogs.ble_enter_manually")}</option>
          ${candidates.map((c) => {
            const addr = c.target_address || "";
            const lbl =
              c.label ||
              `${c.title || addr}${c.area_name ? ` (${c.area_name})` : ""}`;
            return html`<option value=${addr} ?selected=${addr === modal.candidateAddr}>
              ${lbl}
            </option>`;
          })}
        </select>
      </div>
      <div class="stacked-field">
        <label for="ble-custom-name">${store.t("dialogs.ble_name_label")}</label>
        <input
          type="text"
          id="ble-custom-name"
          placeholder=${store.t("dialogs.ble_name_placeholder")}
          .value=${focusSafe(modal.name)}
          @input=${(ev) => {
            store.addBleModal = {
              ...store.addBleModal,
              name: (ev.currentTarget).value,
            };
          }}
        />
      </div>
      <div class="stacked-field">
        <label for="ble-custom-addr">${store.t("dialogs.ble_addr_label")}</label>
        <input
          type="text"
          id="ble-custom-addr"
          placeholder=${store.t("dialogs.ble_addr_placeholder")}
          .value=${focusSafe(modal.address)}
          @input=${(ev) => {
            store.addBleModal = {
              ...store.addBleModal,
              address: (ev.currentTarget).value,
            };
          }}
          class="mono"
        />
        <span class="help-text">${store.t("dialogs.ble_addr_help")}</span>
      </div>
      <div class="stacked-field">
        <label for="ble-custom-person">${store.t("dialogs.ble_person_label")}</label>
        <select
          id="ble-custom-person"
          .value=${modal.assignedPerson}
          @change=${(ev) => {
            store.addBleModal = {
              ...store.addBleModal,
              assignedPerson: (ev.currentTarget).value,
            };
          }}
        >
          ${renderSelectOptions(persons, modal.assignedPerson, store.t("common.unassigned"))}
        </select>
      </div>
      <div class="dialog-actions">
        <button type="button" @click=${close} class="btn btn-secondary">
          ${store.t("action.cancel")}
        </button>
        <button
          type="button"
          ?disabled=${modal.busy}
          @click=${() => void store.tools.confirmAddBleModal()}
          class="btn btn-primary"
        >
          ${store.t("action.add_ble_tag")}
        </button>
      </div>
    </div>
  </dialog>`;
}
function renderSaveGroupDialog(store) {
  const modal = store.saveGroupModal;
  const close = () => store.groups.closeSaveGroupModal();
  if (!modal.open) {
    return html`<dialog
      id="latter-save-group-modal"
      aria-labelledby="latter-save-group-title"
      @cancel=${close}
      @click=${(ev) => bindBackdropClose(ev, close)}
      class="studio-dialog"
    >
      ${nothing}
    </dialog>`;
  }
  return html`<dialog
    id="latter-save-group-modal"
    aria-labelledby="latter-save-group-title"
    @cancel=${close}
    @click=${(ev) => bindBackdropClose(ev, close)}
    class="studio-dialog"
  >
    <div class="dialog-body">
      <h3 id="latter-save-group-title" class="dialog-title">
        ${store.t("dialogs.save_group_title")}
      </h3>
      <p class="dialog-text">${store.t("dialogs.save_group_body")}</p>
      <div class="stacked-field">
        <label for="save-group-name">${store.t("groups.group_name")}</label>
        <input
          type="text"
          id="save-group-name"
          placeholder=${store.t("dialogs.save_group_name_placeholder")}
          .value=${focusSafe(modal.name)}
          @input=${(ev) => {
            store.saveGroupModal = {
              ...store.saveGroupModal,
              name: (ev.currentTarget).value,
            };
          }}
        />
      </div>
      <div class="stacked-field">
        <label for="save-group-desc">${store.t("groups.description_optional")}</label>
        <input
          type="text"
          id="save-group-desc"
          placeholder=${store.t("dialogs.save_group_desc_placeholder")}
          .value=${focusSafe(modal.description)}
          @input=${(ev) => {
            store.saveGroupModal = {
              ...store.saveGroupModal,
              description: (ev.currentTarget).value,
            };
          }}
        />
      </div>
      <div class="settings-list">
        ${renderSwitchRow({
          id: "save-group-include-display",
          label: store.t("groups.include_display"),
          description: store.t("groups.include_display_desc"),
          checked: Boolean(modal.includeDisplay),
          onChange: (checked) => {
            store.saveGroupModal = {
              ...store.saveGroupModal,
              includeDisplay: checked,
            };
            store.host.requestUpdate();
          },
        })}
        ${renderSwitchRow({
          id: "save-group-include-interface",
          label: store.t("groups.include_interface"),
          description: store.t("groups.include_interface_desc"),
          checked: Boolean(modal.includeInterface),
          onChange: (checked) => {
            store.saveGroupModal = {
              ...store.saveGroupModal,
              includeInterface: checked,
            };
            store.host.requestUpdate();
          },
        })}
      </div>
      <div class="dialog-actions">
        <button type="button" @click=${close} class="btn btn-secondary">
          ${store.t("action.cancel")}
        </button>
        <button
          type="button"
          id="latter-save-group-confirm-btn"
          ?disabled=${Boolean(modal.busy)}
          @click=${() => void store.groups.confirmSaveGroupModal()}
          class="btn btn-primary"
        >
          ${store.t("action.save_group")}
        </button>
      </div>
    </div>
  </dialog>`;
}
__latterExp(__exports, { renderRemoveDeviceDialog: () => renderRemoveDeviceDialog, renderResetDeviceDialog: () => renderResetDeviceDialog, renderAddBleDialog: () => renderAddBleDialog, renderSaveGroupDialog: () => renderSaveGroupDialog });
//# sourceURL=latter-studio/src/components/dialogs/device-modals.ts
});
__latterDef("src/components/dialogs/shortcut-modal.ts", (__exports, __req) => {
const { NATIVE_DOCK_APP_TOKENS, SHORTCUT_LABEL_MAX, SHORTCUT_ROUTES_CATALOG } = __req("src/constants.ts");
const { formatHaEntityState } = __req("src/i18n/index.ts");
const { focusSafe, html, nothing } = __req("src/lib/lit.ts");
const { isKnownMdiIcon, isMdiCatalogLoaded, MDI_TOTAL_ICON_COUNT, normalizeMdiIconSlug, ROUTE_PREVIEW_ICONS, searchMdiIcons, SHORTCUT_DOMAIN_ACTIONS, SHORTCUT_DOMAIN_LABELS } = __req("src/mdi-catalog.ts");
const { isCatalogItemSupported } = __req("src/state/store.ts");
const { fmtNumber } = __req("src/utils/format.ts");
const { renderEntityCombobox, renderSwitchRow } = __req("src/components/controls.ts");
/**
 * Add / Edit Shortcut Modal (`#latter-shortcut-modal`, `D-047`, `D-062`, `Q11`).
 * - Short-circuits closed `<dialog>` body (`F-06`, `B-18`, `R-5`)
 * - Roving-arrow `tablist` + `tabpanel` for Shortcut type (`D-07`)
 * - WAI-ARIA `renderEntityCombobox` replacing 1,000+-option `<select>` (`Q11`, `D-18`)
 * - Accessible MDI icon picker (`role="group"` of `aria-pressed` buttons + humanized labels + cached `searchMdiIcons`, `D-08`, `F-07`)
 * - `focusSafe` text inputs
 */
let mdiSearchCache = null;
function getCachedMdiSearch(rawQuery) {
  const queryKey = String(rawQuery || "").trim().toLowerCase();
  const loaded = isMdiCatalogLoaded();
  if (
    mdiSearchCache &&
    mdiSearchCache.queryKey === queryKey &&
    mdiSearchCache.loaded === loaded
  ) {
    return { items: mdiSearchCache.items, totalMatches: mdiSearchCache.totalMatches };
  }
  const result = searchMdiIcons(rawQuery, 120);
  mdiSearchCache = {
    queryKey,
    loaded,
    items: result.items,
    totalMatches: result.totalMatches,
  };
  return result;
}
function humanizeMdiIconLabel(slug) {
  const clean = slug.startsWith("mdi:") ? slug.slice(4) : slug;
  const words = clean.replace(/[-_]+/g, " ").trim();
  if (!words) return slug;
  const sentence = words.charAt(0).toUpperCase() + words.slice(1);
  return `${sentence} (${slug})`;
}
function renderShortcutDialog(store) {
  const scModal = store.shortcutModal;
  const close = () => store.entity.closeShortcutModal();
  const onBackdropClick = (ev) => {
    if (ev.target === ev.currentTarget) {
      close();
    }
  };
  if (!scModal.open) {
    return html`<dialog
      id="latter-shortcut-modal"
      aria-labelledby="latter-shortcut-title"
      @cancel=${close}
      @click=${onBackdropClick}
      class="studio-dialog shortcut-dialog"
    >
      ${nothing}
    </dialog>`;
  }
  const scIsDock = scModal.listKey === "dock_items";
  const scTitle =
    scModal.editIndex !== null
      ? scIsDock
        ? store.t("dialogs.sc_edit_dock")
        : store.t("dialogs.sc_edit_pinned")
      : scIsDock
        ? store.t("dialogs.sc_add_dock")
        : store.t("dialogs.sc_add_pinned");
  const devCaps = store.state?.capabilities;
  const availableRoutes = SHORTCUT_ROUTES_CATALOG.filter((r) => {
    if (!scIsDock && r.dockOnly) return false;
    if (scIsDock && (r.token === "settings:root" || NATIVE_DOCK_APP_TOKENS.includes(r.token))) {
      return false;
    }
    return isCatalogItemSupported(r, devCaps);
  });
  const routeGroups = [];
  for (const r of availableRoutes) {
    const grpName = r.group || "Apps";
    const existingGrp = routeGroups.find((g) => g.group === grpName);
    if (existingGrp) {
      existingGrp.items.push(r);
    } else {
      routeGroups.push({ group: grpName, items: [r] });
    }
  }
  const allShortcutEntities = store.state?.catalog?.shortcut_entities || [];
  const availableDomains = Array.from(
    new Set(allShortcutEntities.map((e) => e.domain)),
  ).sort();
  const domainFilteredEntities = allShortcutEntities.filter(
    (e) => scModal.entityDomainFilter === "all" || e.domain === scModal.entityDomainFilter,
  );
  const comboboxOptions = domainFilteredEntities.map((e) => {
    const stateLbl = formatHaEntityState(store.hass, e.id);
    return {
      id: e.id,
      name: e.name,
      domain: e.domain,
      area_name: e.area_name,
      icon: e.icon,
      state_label: stateLbl || undefined,
    };
  });
  const selectedEntityObj =
    allShortcutEntities.find((e) => e.id === scModal.entityTarget) || null;
  const selectedEntityDomain = selectedEntityObj
    ? selectedEntityObj.domain
    : scModal.entityTarget.split(".", 1)[0] || "";
  const availableEntityActions = SHORTCUT_DOMAIN_ACTIONS[selectedEntityDomain] || [];
  const effectiveRouteTarget = availableRoutes.some((r) => r.token === scModal.routeTarget)
    ? scModal.routeTarget
    : availableRoutes[0]?.token || scModal.routeTarget;
  const selectedRouteSpec =
    availableRoutes.find((r) => r.token === effectiveRouteTarget) ||
    SHORTCUT_ROUTES_CATALOG.find((r) => r.token === effectiveRouteTarget);
  const autoDefaultLabel =
    scModal.kind === "route"
      ? selectedRouteSpec?.label || store.t("dialogs.sc_default_shortcut")
      : selectedEntityObj?.name ||
        scModal.entityTarget ||
        store.t("dialogs.sc_default_entity_action");
  const autoDefaultIcon =
    scModal.kind === "route"
      ? ROUTE_PREVIEW_ICONS[effectiveRouteTarget] || "mdi:apps"
      : selectedEntityObj?.icon || "mdi:flash";
  const selectedCustomIcon = normalizeMdiIconSlug(scModal.icon);
  const typedSearchIcon = normalizeMdiIconSlug(scModal.iconSearch);
  const previewIcon =
    selectedCustomIcon ||
    (isKnownMdiIcon(typedSearchIcon) ? typedSearchIcon : autoDefaultIcon);
  const hasIconQuery = scModal.iconSearch.trim().length > 0;
  const { items: filteredMdiIcons, totalMatches: mdiMatchCount } = getCachedMdiSearch(
    scModal.iconSearch,
  );
  const totalIconsText = fmtNumber(MDI_TOTAL_ICON_COUNT, store.hass, 0);
  const setShortcutKind = (nextKind, focusTabEl) => {
    store.shortcutModal = { ...store.shortcutModal, kind: nextKind };
    store.host.requestUpdate();
    if (focusTabEl) {
      requestAnimationFrame(() => {
        focusTabEl.focus();
      });
    }
  };
  const onTypeTabKeyDown = (ev) => {
    if (
      ev.key !== "ArrowLeft" &&
      ev.key !== "ArrowRight" &&
      ev.key !== "Home" &&
      ev.key !== "End"
    ) {
      return;
    }
    ev.preventDefault();
    let nextKind;
    if (ev.key === "Home") {
      nextKind = "route";
    } else if (ev.key === "End") {
      nextKind = "entity";
    } else {
      nextKind = scModal.kind === "route" ? "entity" : "route";
    }
    const tablist = (ev.currentTarget).parentElement;
    const targetBtn = tablist?.querySelector(
      nextKind === "route" ? "#shortcut-tab-route" : "#shortcut-tab-entity",
    );
    setShortcutKind(nextKind, targetBtn);
  };
  const isRouteTab = scModal.kind === "route";
  return html`<dialog
    id="latter-shortcut-modal"
    aria-labelledby="latter-shortcut-title"
    @cancel=${close}
    @click=${onBackdropClick}
    class="studio-dialog shortcut-dialog"
  >
    <div class="dialog-body">
      <h3 id="latter-shortcut-title" class="dialog-title">${scTitle}</h3>

      <div role="tablist" aria-label=${store.t("dialogs.sc_type_aria")} class="scope-tabs">
        <button
          type="button"
          id="shortcut-tab-route"
          role="tab"
          aria-selected=${isRouteTab ? "true" : "false"}
          aria-controls="shortcut-tabpanel"
          tabindex=${isRouteTab ? "0" : "-1"}
          @click=${() => setShortcutKind("route")}
          @keydown=${onTypeTabKeyDown}
          class="scope-tab ${isRouteTab ? "active" : ""}"
        >
          ${scIsDock ? store.t("dialogs.sc_tab_subpage") : store.t("dialogs.sc_tab_app_page")}
        </button>
        <button
          type="button"
          id="shortcut-tab-entity"
          role="tab"
          aria-selected=${!isRouteTab ? "true" : "false"}
          aria-controls="shortcut-tabpanel"
          tabindex=${!isRouteTab ? "0" : "-1"}
          @click=${() => setShortcutKind("entity")}
          @keydown=${onTypeTabKeyDown}
          class="scope-tab ${!isRouteTab ? "active" : ""}"
        >
          ${store.t("dialogs.sc_tab_entity")}
        </button>
      </div>

      <div
        id="shortcut-tabpanel"
        role="tabpanel"
        aria-labelledby=${isRouteTab ? "shortcut-tab-route" : "shortcut-tab-entity"}
        class="stack"
      >
        ${isRouteTab
          ? html`<div class="stacked-field">
              <label for="shortcut-route-select">
                ${scIsDock
                  ? store.t("dialogs.sc_target_subpage")
                  : store.t("dialogs.sc_target_app_page")}
              </label>
              <select
                id="shortcut-route-select"
                .value=${effectiveRouteTarget}
                @change=${(ev) => {
                  const val = (ev.currentTarget).value;
                  store.shortcutModal = { ...store.shortcutModal, routeTarget: val };
                  store.host.requestUpdate();
                }}
              >
                ${routeGroups.map(
                  (grp) => html`<optgroup label=${grp.group}>
                    ${grp.items.map(
                      (item) => html`<option
                        value=${item.token}
                        ?selected=${item.token === effectiveRouteTarget}
                      >
                        ${item.label}
                      </option>`,
                    )}
                  </optgroup>`,
                )}
              </select>
            </div>`
          : html`<div class="stacked-field">
                <label for="shortcut-domain-filter">
                  ${store.t("dialogs.sc_domain_filter")}
                </label>
                <select
                  id="shortcut-domain-filter"
                  .value=${scModal.entityDomainFilter}
                  @change=${(ev) => {
                    const nextDom = (ev.currentTarget).value;
                    const nextList = allShortcutEntities.filter(
                      (e) => nextDom === "all" || e.domain === nextDom,
                    );
                    const keepEnt = nextList.some((e) => e.id === scModal.entityTarget)
                      ? scModal.entityTarget
                      : nextList[0]?.id || "";
                    const effDom = keepEnt.split(".", 1)[0] || nextDom;
                    const nextAct = SHORTCUT_DOMAIN_ACTIONS[effDom]?.[0]?.action || "";
                    store.shortcutModal = {
                      ...store.shortcutModal,
                      entityDomainFilter: nextDom,
                      entityTarget: keepEnt,
                      action: nextAct,
                    };
                    store.host.requestUpdate();
                  }}
                >
                  <option value="all" ?selected=${scModal.entityDomainFilter === "all"}>
                    ${store.t("dialogs.sc_all_domains")}
                  </option>
                  ${availableDomains.map(
                    (dom) => html`<option
                      value=${dom}
                      ?selected=${dom === scModal.entityDomainFilter}
                    >
                      ${SHORTCUT_DOMAIN_LABELS[dom] || dom}
                    </option>`,
                  )}
                </select>
              </div>
              <div class="stacked-field">
                <label for="shortcut-entity-select">
                  ${store.t("dialogs.shortcut_entity_label")}
                </label>
                ${renderEntityCombobox({
                  id: "shortcut-entity-select",
                  value: scModal.entityTarget,
                  options: comboboxOptions,
                  ariaLabel: store.t("dialogs.shortcut_entity_label"),
                  placeholder: store.t("combobox.placeholder"),
                  allowClear: false,
                  host: store.host,
                  overlay: store.localeOverlay,
                  onChange: (nextEnt) => {
                    const dom = nextEnt.split(".", 1)[0] || "";
                    const acts = SHORTCUT_DOMAIN_ACTIONS[dom] || [];
                    const nextAct = acts.some((a) => a.action === scModal.action)
                      ? scModal.action
                      : acts[0]?.action || "";
                    store.shortcutModal = {
                      ...store.shortcutModal,
                      entityTarget: nextEnt,
                      action: nextAct,
                    };
                    store.host.requestUpdate();
                  },
                })}
              </div>
              <div class="stacked-field">
                <label for="shortcut-action-select">
                  ${store.t("dialogs.sc_action_label")}
                </label>
                <select
                  id="shortcut-action-select"
                  .value=${scModal.action}
                  @change=${(ev) => {
                    store.shortcutModal = {
                      ...store.shortcutModal,
                      action: (ev.currentTarget).value,
                    };
                    store.host.requestUpdate();
                  }}
                >
                  ${availableEntityActions.map(
                    (act) => html`<option
                      value=${act.action}
                      ?selected=${act.action === scModal.action}
                    >
                      ${act.label}
                    </option>`,
                  )}
                </select>
              </div>
              ${renderSwitchRow({
                id: "shortcut-confirm-switch",
                label: store.t("dialogs.sc_confirm_label"),
                description: scIsDock
                  ? store.t("dialogs.sc_confirm_dock_desc")
                  : store.t("dialogs.sc_confirm_pinned_desc"),
                checked: scModal.confirm,
                onChange: (checked) => {
                  store.shortcutModal = { ...store.shortcutModal, confirm: checked };
                  store.host.requestUpdate();
                },
              })}`}
      </div>

      <div class="stacked-field">
        <label for="shortcut-label-input">${store.t("dialogs.sc_custom_label")}</label>
        <input
          type="text"
          id="shortcut-label-input"
          maxlength=${String(SHORTCUT_LABEL_MAX)}
          placeholder=${autoDefaultLabel}
          .value=${focusSafe(scModal.label)}
          @input=${(ev) => {
            store.shortcutModal = {
              ...store.shortcutModal,
              label: (ev.currentTarget).value,
            };
          }}
        />
      </div>

      <div class="stacked-field">
        <label for="shortcut-icon-input">${store.t("dialogs.sc_icon_label")}</label>
        <div class="shortcut-icon-row">
          <span class="shortcut-icon-badge" aria-hidden="true">
            <ha-icon .icon=${previewIcon}></ha-icon>
          </span>
          <input
            type="text"
            id="shortcut-icon-input"
            placeholder=${store.t("dialogs.sc_icon_search_placeholder", {
              total: totalIconsText,
            })}
            .value=${focusSafe(scModal.iconSearch)}
            @input=${(ev) => {
              const raw = (ev.currentTarget).value;
              store.shortcutModal = {
                ...store.shortcutModal,
                iconSearch: raw,
              };
              store.host.requestUpdate();
            }}
          />
          ${scModal.icon || scModal.iconSearch
            ? html`<button
                type="button"
                @click=${() => {
                  store.shortcutModal = {
                    ...store.shortcutModal,
                    icon: "",
                    iconSearch: "",
                  };
                  store.host.requestUpdate();
                }}
                class="btn btn-text btn-compact"
              >
                ${store.t("action.default_icon")}
              </button>`
            : nothing}
        </div>
        <p class="row-description">
          ${selectedCustomIcon
            ? store.t("dialogs.sc_icon_selected", { icon: selectedCustomIcon })
            : store.t("dialogs.sc_icon_default", { icon: autoDefaultIcon })}
          •
          ${hasIconQuery
            ? mdiMatchCount === 0
              ? store.t("dialogs.sc_icon_no_matches")
              : mdiMatchCount > filteredMdiIcons.length
                ? store.t("dialogs.sc_icon_showing_subset", {
                    shown: fmtNumber(filteredMdiIcons.length, store.hass, 0),
                    total: fmtNumber(mdiMatchCount, store.hass, 0),
                  })
                : mdiMatchCount === 1
                  ? store.t("dialogs.sc_icon_matches_one")
                  : store.t("dialogs.sc_icon_matches_many", {
                      count: fmtNumber(mdiMatchCount, store.hass, 0),
                    })
            : store.t("dialogs.sc_icon_popular", { total: totalIconsText })}
        </p>
        <div
          role="group"
          aria-label=${store.t("dialogs.sc_mdi_group_aria")}
          class="mdi-picker-grid"
        >
          ${filteredMdiIcons.map((slug) => {
            const isSelected = selectedCustomIcon === slug;
            return html`<button
              type="button"
              title=${slug}
              aria-label=${humanizeMdiIconLabel(slug)}
              aria-pressed=${isSelected ? "true" : "false"}
              @click=${() => {
                store.shortcutModal = {
                  ...store.shortcutModal,
                  icon: slug,
                };
                store.host.requestUpdate();
              }}
              class="mdi-picker-btn ${isSelected ? "selected" : ""}"
            >
              <ha-icon .icon=${slug}></ha-icon>
            </button>`;
          })}
        </div>
      </div>

      <div class="dialog-actions">
        <button type="button" @click=${close} class="btn btn-secondary">
          ${store.t("action.cancel")}
        </button>
        <button
          type="button"
          id="shortcut-save-btn"
          @click=${() => store.entity.saveShortcutModal()}
          class="btn btn-primary"
        >
          ${store.t("action.save_shortcut")}
        </button>
      </div>
    </div>
  </dialog>`;
}
__latterExp(__exports, { renderShortcutDialog: () => renderShortcutDialog });
//# sourceURL=latter-studio/src/components/dialogs/shortcut-modal.ts
});
__latterDef("src/components/dialogs.ts", (__exports, __req) => {
const { html } = __req("src/lib/lit.ts");
const { renderAppConfigDialog, renderAppConfigModalBody } = __req("src/components/dialogs/app-config.ts");
const { renderColorWheelDialog, syncColorWheelCanvas } = __req("src/components/dialogs/color-wheel.ts");
const { renderAddBleDialog, renderRemoveDeviceDialog, renderResetDeviceDialog, renderSaveGroupDialog } = __req("src/components/dialogs/device-modals.ts");
const { renderShortcutDialog } = __req("src/components/dialogs/shortcut-modal.ts");
/**
 * Modular Native `<dialog>` Orchestrator for Latter Studio (`D-053`, `D-062`, `D-064`).
 * - Two-pass close-before-open orchestration so two modals are never open simultaneously
 * - Closed `<dialog>` shells render empty (`!modal.open` short-circuit, `F-06`, `B-18`, `R-5`)
 * - Zero dead `setAttribute("open")` catch fallback (`A-22`) & zero module-global `cwWheelPainted` (`A-24`)
 */
function syncStudioDialogs(renderRoot, store) {
  const pairs = [
    ["latter-rm-modal", store.removeModal.open],
    ["latter-reset-modal", store.resetModal.open],
    ["latter-add-dev-modal", store.addBleModal.open],
    ["latter-cw-modal", store.colorWheelModal.open],
    ["latter-save-group-modal", store.saveGroupModal.open],
    ["latter-app-config-modal", store.appConfigModal.open],
    ["latter-shortcut-modal", store.shortcutModal.open],
  ];
  // Pass 1: close any open dialog that should now be closed BEFORE opening another modal.
  for (const [id, wantOpen] of pairs) {
    if (wantOpen) continue;
    const dlg = renderRoot.getElementById(id);
    if (dlg && dlg.open && typeof dlg.close === "function") {
      dlg.close();
    }
  }
  // Pass 2: open the active dialog natively via `showModal()` (never > 1 open simultaneously).
  for (const [id, wantOpen] of pairs) {
    if (!wantOpen) continue;
    const dlg = renderRoot.getElementById(id);
    if (dlg && !dlg.open && typeof dlg.showModal === "function") {
      dlg.showModal();
    }
  }
  syncColorWheelCanvas(renderRoot, store);
}
function renderStudioDialogs(store) {
  return html`
    ${renderRemoveDeviceDialog(store)}
    ${renderResetDeviceDialog(store)}
    ${renderAddBleDialog(store)}
    ${renderColorWheelDialog(store)}
    ${renderSaveGroupDialog(store)}
    ${renderAppConfigDialog(store)}
    ${renderShortcutDialog(store)}
  `;
}
__latterExp(__exports, { renderAppConfigModalBody: () => renderAppConfigModalBody, syncStudioDialogs: () => syncStudioDialogs, renderStudioDialogs: () => renderStudioDialogs });
//# sourceURL=latter-studio/src/components/dialogs.ts
});
__latterDef("src/styles/base.ts", (__exports, __req) => {
const { css } = __req("src/lib/lit.ts");
/**
 * Latter Studio Design System Tokens, RTL Root Direction, Banners, & Reduced-Motion Reset
 * (`docs/studio-design.md` §3, `D-061`, `D-066`).
 * Literal font sizes, pixel spacing, and colors appear ONLY inside `:host` / `:host([dark])`.
 */
const BASE_STYLES = css`:host{--studio-font-family:var(--ha-font-family-body,inherit);--studio-font-code:var(--ha-font-family-code,monospace);--studio-font-title:var(--ha-font-size-xl,20px);--studio-font-section:var(--ha-font-size-l,16px);--studio-font-body:var(--ha-font-size-m,14px);--studio-font-secondary:var(--ha-font-size-s,12px);--studio-font-caption:var(--ha-font-size-s,12px);--studio-weight-regular:var(--ha-font-weight-normal,400);--studio-weight-medium:var(--ha-font-weight-medium,500);--studio-line-height:var(--ha-line-height-normal,1.6);--studio-line-height-condensed:var(--ha-line-height-condensed,1.2);--studio-font-card-title:var(--ha-card-header-font-size,var(--ha-font-size-2xl,24px));--studio-card-title-tracking:-0.012em;--studio-space-1:var(--ha-space-1,4px);--studio-space-2:var(--ha-space-2,8px);--studio-space-3:var(--ha-space-3,12px);--studio-space-4:var(--ha-space-4,16px);--studio-space-card-top:var(--ha-space-5,20px);--studio-space-5:var(--ha-space-6,24px);--studio-radius-card:var(--ha-card-border-radius,var(--ha-border-radius-lg,12px));--studio-radius-control:var(--ha-border-radius-md,8px);--studio-radius-field:var(--ha-border-radius-sm,4px);--studio-radius-button:var(--ha-button-border-radius,var(--ha-border-radius-pill,9999px));--studio-radius-dialog:var(--ha-dialog-border-radius,var(--ha-border-radius-3xl,24px));--studio-radius-pill:var(--ha-border-radius-pill,9999px);--studio-card-border-width:var(--ha-card-border-width,1px);--studio-control-height:var(--ha-button-height,40px);--studio-control-height-compact:32px;--studio-row-min-height:56px;--studio-header-height:var(--header-height,56px);--studio-sidebar-width:244px;--studio-bg:var(--primary-background-color,#fafafa);--studio-surface:var(--ha-card-background,var(--card-background-color,#ffffff));--studio-surface-alt:var(--secondary-background-color,#f0f0f0);--studio-header-bg:var(--app-header-background-color,var(--sidebar-background-color,#ffffff));--studio-header-text:var(--app-header-text-color,var(--primary-text-color,#212121));--studio-header-icon:var(--sidebar-icon-color,var(--secondary-text-color,#616161));--studio-header-border:var(--app-header-border-bottom,1px solid var(--divider-color,rgba(0,0,0,0.12)));--studio-sidebar-bg:var(--sidebar-background-color,var(--card-background-color,#ffffff));--studio-input-bg:var(--input-fill-color,rgba(0,0,0,0.04));--studio-field-bg:var(--ha-color-form-background,var(--input-fill-color,#f5f5f5));--studio-field-bg-hover:var(--ha-color-form-background-hover,var(--studio-field-bg));--studio-field-line:var(--ha-color-border-neutral-loud,var(--input-idle-line-color,rgba(0,0,0,0.42)));--studio-popup-bg:var(--card-background-color,#ffffff);--studio-divider:var(--divider-color,rgba(0,0,0,0.12));--studio-card-border:var(--ha-card-border-color,var(--divider-color,rgba(0,0,0,0.12)));--studio-text:var(--primary-text-color,#212121);--studio-text-secondary:var(--secondary-text-color,#5f6368);--studio-text-disabled:var(--disabled-text-color,#9e9e9e);--studio-primary:var(--primary-color,#009ac7);--studio-primary-tint:rgba(var(--rgb-primary-color,0,154,199),0.12);--studio-primary-tint-strong:rgba(var(--rgb-primary-color,0,154,199),0.24);--studio-hover:rgba(var(--rgb-primary-text-color,33,33,33),0.06);--studio-btn-accent-bg:var(--ha-color-fill-primary-loud-resting,var(--primary-color,#007da3));--studio-btn-accent-bg-hover:var(--ha-color-fill-primary-loud-hover,var(--studio-btn-accent-bg));--studio-btn-accent-text:var(--ha-color-on-primary-loud,var(--text-primary-color,#ffffff));--studio-btn-tonal-bg:var(--ha-color-fill-primary-normal-resting,#d8eff7);--studio-btn-tonal-bg-hover:var(--ha-color-fill-primary-normal-hover,#c2e6f2);--studio-btn-tonal-text:var(--ha-color-on-primary-normal,#005b78);--studio-btn-plain-hover:var(--ha-color-fill-primary-quiet-resting,var(--studio-primary-tint));--studio-nav-active-bg:var(--ha-color-fill-primary-normal-resting,#d8eff7);--studio-nav-active-text:var(--ha-color-on-primary-normal,#005b78);--studio-chip-primary-bg:var(--ha-color-fill-primary-normal-resting,#d8eff7);--studio-chip-primary-text:var(--ha-color-on-primary-normal,#005b78);--studio-chip-success-bg:var(--ha-color-fill-success-normal-resting,#dcf2df);--studio-chip-success-text:var(--ha-color-on-success-normal,#1b5e20);--studio-chip-warning-bg:var(--ha-color-fill-warning-normal-resting,#fff0d1);--studio-chip-warning-text:var(--ha-color-on-warning-normal,#7a4900);--studio-chip-danger-bg:var(--ha-color-fill-danger-normal-resting,#fbe4e2);--studio-chip-danger-text:var(--ha-color-on-danger-normal,#9e1c13);--studio-danger-tonal-bg:var(--ha-color-fill-danger-normal-resting,#fbe4e2);--studio-danger-tonal-text:var(--ha-color-on-danger-normal,#9e1c13);--studio-danger-loud-bg:var(--ha-color-fill-danger-loud-resting,var(--error-color,#c62828));--studio-danger-loud-text:var(--ha-color-on-danger-loud,#ffffff);--studio-switch-track:var(--ha-switch-background-color,var(--ha-color-fill-disabled-quiet-resting,#e0e0e0));--studio-switch-border:var(--ha-switch-border-color,var(--ha-color-border-neutral-normal,#7a7a7a));--studio-switch-thumb:var(--ha-switch-thumb-background-color,var(--ha-color-on-neutral-normal,#616161));--studio-switch-on-track:var(--ha-switch-checked-background-color,var(--ha-color-fill-primary-normal-resting,#d8eff7));--studio-switch-on-border:var(--ha-switch-checked-border-color,var(--ha-color-border-primary-loud,var(--primary-color,#009ac7)));--studio-switch-on-thumb:var(--ha-switch-checked-thumb-background-color,var(--ha-color-on-primary-normal,#005b78));--studio-switch-thumb-shadow:var(--ha-switch-thumb-box-shadow,var(--ha-box-shadow-s,0 1px 2px rgba(0,0,0,0.3)));--studio-toast-bg:var(--primary-text-color,#212121);--studio-toast-text:var(--card-background-color,#ffffff);--studio-scrollbar-thumb:var(--scrollbar-thumb-color,rgb(140,140,140));--studio-success:var(--success-color,#2e7d32);--studio-warning:var(--warning-color,#ef6c00);--studio-error:var(--error-color,#c62828);--studio-info:var(--info-color,#0277bd);--studio-success-tint:color-mix(in srgb,var(--studio-success) 14%,transparent);--studio-warning-tint:color-mix(in srgb,var(--studio-warning) 14%,transparent);--studio-error-tint:color-mix(in srgb,var(--studio-error) 14%,transparent);--studio-info-tint:color-mix(in srgb,var(--studio-info) 14%,transparent);--studio-card-shadow:var(--ha-card-box-shadow,none);--studio-handoff-surface:color-mix(in srgb,var(--studio-primary) 8%,var(--studio-surface));--studio-handoff-ring:inset 0 0 0 1px var(--studio-primary);--studio-card-handoff-shadow:inset 0 0 0 1px var(--studio-primary),var(--studio-card-shadow);--studio-overlay-shadow:0 8px 24px rgba(0,0,0,0.35);--studio-scrim:rgba(0,0,0,0.5);--studio-media-bg:var(--secondary-background-color,#000000);--studio-nav-scroll-mask:linear-gradient( to right,transparent 0,#000000 12px,#000000 calc(100% - 16px),transparent 100% );display:block;min-height:100vh;min-height:100dvh;background:var(--studio-bg);color:var(--studio-text);font-family:var(--studio-font-family);font-size:var(--studio-font-body);font-weight:var(--studio-weight-regular);line-height:var(--studio-line-height);-webkit-tap-highlight-color:transparent;color-scheme:light;scrollbar-color:var(--studio-scrollbar-thumb) transparent;scrollbar-width:thin;}:host([dark]){--studio-bg:var(--primary-background-color,#111111);--studio-surface:var(--ha-card-background,var(--card-background-color,#1c1c1c));--studio-surface-alt:var(--secondary-background-color,#282828);--studio-header-bg:var(--app-header-background-color,var(--sidebar-background-color,#1c1c1c));--studio-header-text:var(--app-header-text-color,var(--primary-text-color,#e1e1e1));--studio-header-icon:var(--sidebar-icon-color,var(--secondary-text-color,#9b9b9b));--studio-header-border:var(--app-header-border-bottom,1px solid var(--divider-color,rgba(225,225,225,0.12)));--studio-sidebar-bg:var(--sidebar-background-color,var(--card-background-color,#1c1c1c));--studio-input-bg:var(--input-fill-color,rgba(255,255,255,0.05));--studio-field-bg:var(--ha-color-form-background,var(--input-fill-color,#363636));--studio-field-line:var(--ha-color-border-neutral-loud,var(--input-idle-line-color,rgba(255,255,255,0.42)));--studio-popup-bg:var(--card-background-color,#1c1c1c);--studio-divider:var(--divider-color,rgba(225,225,225,0.12));--studio-card-border:var(--ha-card-border-color,var(--divider-color,rgba(225,225,225,0.12)));--studio-text:var(--primary-text-color,#e1e1e1);--studio-text-secondary:var(--secondary-text-color,#a8a8a8);--studio-text-disabled:var(--disabled-text-color,#6f6f6f);--studio-hover:rgba(var(--rgb-primary-text-color,225,225,225),0.06);--studio-btn-tonal-bg:var(--ha-color-fill-primary-normal-resting,#0b3545);--studio-btn-tonal-bg-hover:var(--ha-color-fill-primary-normal-hover,#104559);--studio-btn-tonal-text:var(--ha-color-on-primary-normal,#7bd6f5);--studio-nav-active-bg:var(--ha-color-fill-primary-normal-resting,#0b3545);--studio-nav-active-text:var(--ha-color-on-primary-normal,#7bd6f5);--studio-chip-primary-bg:var(--ha-color-fill-primary-normal-resting,#0b3545);--studio-chip-primary-text:var(--ha-color-on-primary-normal,#7bd6f5);--studio-chip-success-bg:var(--ha-color-fill-success-normal-resting,#143619);--studio-chip-success-text:var(--ha-color-on-success-normal,#81e287);--studio-chip-warning-bg:var(--ha-color-fill-warning-normal-resting,#3b2a07);--studio-chip-warning-text:var(--ha-color-on-warning-normal,#ffd166);--studio-chip-danger-bg:var(--ha-color-fill-danger-normal-resting,#3d1614);--studio-chip-danger-text:var(--ha-color-on-danger-normal,#ff9b93);--studio-danger-tonal-bg:var(--ha-color-fill-danger-normal-resting,#3d1614);--studio-danger-tonal-text:var(--ha-color-on-danger-normal,#ff9b93);--studio-danger-loud-bg:var(--ha-color-fill-danger-loud-resting,var(--error-color,#db4437));--studio-danger-loud-text:var(--ha-color-on-danger-loud,#ffffff);--studio-switch-track:var(--ha-switch-background-color,var(--ha-color-fill-disabled-quiet-resting,#202020));--studio-switch-border:var(--ha-switch-border-color,var(--ha-color-border-neutral-normal,#7a7a7a));--studio-switch-thumb:var(--ha-switch-thumb-background-color,var(--ha-color-on-neutral-normal,#989898));--studio-switch-on-track:var(--ha-switch-checked-background-color,var(--ha-color-fill-primary-normal-resting,#0b3545));--studio-switch-on-border:var(--ha-switch-checked-border-color,var(--ha-color-border-primary-loud,var(--primary-color,#009ac7)));--studio-switch-on-thumb:var(--ha-switch-checked-thumb-background-color,var(--ha-color-on-primary-normal,#7bd6f5));--studio-toast-bg:var(--primary-text-color,#e1e1e1);--studio-toast-text:var(--card-background-color,#1c1c1c);--studio-scrollbar-thumb:var(--scrollbar-thumb-color,rgb(110,110,110));--studio-success:var(--success-color,#43a047);--studio-warning:var(--warning-color,#ffa600);--studio-error:var(--error-color,#db4437);--studio-info:var(--info-color,#039be5);color-scheme:dark;}*{box-sizing:border-box;}.hidden{display:none !important;}.studio-root{min-height:100vh;min-height:100dvh;display:flex;flex-direction:column;background:var(--studio-bg);}h2,h3,h4,p{margin:0;}code,.mono{font-family:var(--studio-font-code);font-size:var(--studio-font-secondary);}a{color:var(--studio-primary);}.studio-rev-banner{display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:var(--studio-space-3);padding:var(--studio-space-2) var(--studio-space-4);background:var(--studio-chip-warning-bg);border-block-end:1px solid var(--studio-warning);color:var(--studio-chip-warning-text);z-index:40;}.offline-banner{display:flex;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;gap:var(--studio-space-3);padding:var(--studio-space-3) var(--studio-space-4);border:1px solid var(--studio-divider);border-inline-start:4px solid var(--studio-warning);border-radius:var(--studio-radius-control);background:var(--studio-surface);color:var(--studio-text);}.offline-banner-body{display:flex;flex-direction:column;gap:var(--studio-space-1);min-inline-size:0;flex:1 1 260px;}.offline-banner-body>span{color:var(--studio-text-secondary);font-size:var(--studio-font-secondary);}@media (prefers-reduced-motion:reduce){*,*::before,*::after{animation-duration:0.01ms !important;animation-iteration-count:1 !important;transition-duration:0.01ms !important;scroll-behavior:auto !important;}}`;
__latterExp(__exports, { BASE_STYLES: () => BASE_STYLES });
//# sourceURL=latter-studio/src/styles/base.ts
});
__latterDef("src/styles/cards.ts", (__exports, __req) => {
const { css } = __req("src/lib/lit.ts");
/**
 * Card surfaces, collapsible drawers, Home Hub domain boxes, & Area presence containers.
 */
const CARD_STYLES = css`.card{min-inline-size:0;container-type:inline-size;background:var(--studio-surface);border:var(--studio-card-border-width) solid var(--studio-card-border);border-radius:var(--studio-radius-card);box-shadow:var(--studio-card-shadow);color:var(--studio-text);scroll-margin-top:calc(var(--studio-header-height) + var(--studio-space-4));transition:border-color 0.2s ease,background-color 0.2s ease,box-shadow 0.2s ease;}.card.danger{border-color:var(--studio-error);}.card.handoff-active{border-color:var(--studio-primary);box-shadow:var(--studio-card-handoff-shadow);background:var(--studio-handoff-surface);}.handoff-active[tabindex="-1"]:focus-visible{outline:none;}.card-header{display:flex;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;gap:var(--studio-space-3);padding-block:var(--studio-space-card-top) 0;padding-inline:var(--studio-space-4);}.card-heading{display:flex;flex-direction:column;gap:var(--studio-space-2);min-inline-size:0;flex:1 1 240px;}.card-title{font-size:var(--studio-font-card-title);font-weight:var(--studio-weight-regular);letter-spacing:var(--studio-card-title-tracking);line-height:var(--studio-line-height-condensed);}.card-subtitle,.row-description,.help-text{color:var(--studio-text-secondary);font-size:var(--studio-font-secondary);}.card-header-actions{display:flex;align-items:center;flex-wrap:wrap;gap:var(--studio-space-2);}.card-content{display:flex;flex-direction:column;gap:var(--studio-space-3);padding:var(--studio-space-4);}.card-actions{display:flex;justify-content:flex-end;flex-wrap:wrap;gap:var(--studio-space-2);padding:var(--studio-space-2);border-block-start:1px solid var(--studio-divider);}details.card>summary{list-style:none;cursor:pointer;padding-block-end:var(--studio-space-card-top);}details.card>summary::-webkit-details-marker{display:none;}details.card>summary::after{content:"▾";color:var(--studio-text-secondary);transition:transform 0.15s ease;}details.card[open]>summary::after{transform:rotate(180deg);}details.card[open]>summary{border-block-end:1px solid var(--studio-divider);}details.sub-collapsible{border-block-start:1px solid var(--studio-divider);padding-block-start:var(--studio-space-3);}details.sub-collapsible>summary{cursor:pointer;font-weight:var(--studio-weight-medium);}details.sub-collapsible>.card-content{padding-block:var(--studio-space-3) 0;padding-inline:0;}details.sub-collapsible.summary-row>summary{display:flex;align-items:center;justify-content:space-between;gap:var(--studio-space-2);list-style:none;}details.sub-collapsible.summary-row>summary::-webkit-details-marker{display:none;}.summary-row-end{display:inline-flex;align-items:center;gap:var(--studio-space-2);}.summary-chevron{color:var(--studio-text-secondary);transition:transform 0.15s ease;}details.sub-collapsible.summary-row[open]>summary .summary-chevron{transform:rotate(180deg);}.hub-domain-box{display:flex;flex-direction:column;gap:var(--studio-space-2);padding-block:var(--studio-space-2);padding-inline:var(--studio-space-3);border:1px solid var(--studio-divider);border-radius:var(--studio-radius-control);background:var(--studio-input-bg);}.hub-domain-head{display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:var(--studio-space-2);min-height:var(--studio-control-height-compact);}.hub-domain-title{display:inline-flex;align-items:center;flex-wrap:wrap;gap:var(--studio-space-2);font-weight:var(--studio-weight-medium);}.hub-domain-title svg{width:18px;height:18px;fill:var(--studio-primary);flex-shrink:0;}.hub-domain-empty{color:var(--studio-text-secondary);font-size:var(--studio-font-secondary);font-weight:var(--studio-weight-regular);}.hub-slot-row{display:flex;align-items:center;flex-wrap:wrap;gap:var(--studio-space-2);padding-block-start:var(--studio-space-2);border-block-start:1px solid var(--studio-divider);}.hub-slot-row>select,.hub-slot-row>.combobox{flex:1 1 200px;min-inline-size:0;}.hub-slot-meta{display:inline-flex;align-items:center;flex-wrap:wrap;gap:var(--studio-space-1);}.area-presence-box{display:flex;flex-direction:column;gap:var(--studio-space-2);padding-block:var(--studio-space-3);padding-inline:var(--studio-space-4);border:1px solid var(--studio-divider);border-radius:var(--studio-radius-control);background:var(--studio-input-bg);scroll-margin-top:calc(var(--studio-header-height) + var(--studio-space-4));transition:border-color 0.2s ease,background-color 0.2s ease,box-shadow 0.2s ease;}.area-presence-box.handoff-active{border-color:var(--studio-primary);box-shadow:var(--studio-handoff-ring);background:var(--studio-primary-tint);}.area-box-head{display:flex;align-items:safe center;justify-content:space-between;flex-wrap:wrap;gap:var(--studio-space-2);}.area-box-heading{display:flex;align-items:safe center;flex-wrap:wrap;gap:var(--studio-space-2);}.area-box-title{flex:1 1 140px;min-inline-size:0;font-size:var(--studio-font-section);font-weight:var(--studio-weight-medium);line-height:var(--studio-line-height-condensed);}.area-box-actions{display:flex;align-items:safe center;flex-wrap:wrap;gap:var(--studio-space-2);margin-inline-start:auto;}.area-box-badges{display:flex;align-items:safe center;flex-wrap:wrap;gap:var(--studio-space-2);}.area-box-meta{color:var(--studio-text-secondary);font-size:var(--studio-font-secondary);}.area-presence-box>.settings-row{min-height:var(--studio-control-height);padding-block:var(--studio-space-2) 0;padding-inline:0;border-block-start:1px solid var(--studio-divider);}.area-presence-box>details.sub-collapsible{padding-block-start:var(--studio-space-2);}.area-presence-box>details.sub-collapsible>summary{color:var(--studio-text-secondary);font-size:var(--studio-font-secondary);}.area-presence-box>details.sub-collapsible[open]>summary,.area-presence-box>details.sub-collapsible>summary:hover{color:var(--studio-text);}.subsection-title{padding-block-start:var(--studio-space-3);border-block-start:1px solid var(--studio-divider);font-size:var(--studio-font-body);font-weight:var(--studio-weight-medium);}.card-content>.subsection-title:first-child{padding-block-start:0;border-block-start:none;}`;
__latterExp(__exports, { CARD_STYLES: () => CARD_STYLES });
//# sourceURL=latter-studio/src/styles/cards.ts
});
__latterDef("src/styles/controls.ts", (__exports, __req) => {
const { css } = __req("src/lib/lit.ts");
/**
 * Settings rows, form controls, RTL switches, buttons, WAI-ARIA combobox (`Q11`),
 * and pointer/keyboard sortable drag-and-drop rows (`U4`).
 */
const CONTROL_STYLES = css`.settings-list{display:flex;flex-direction:column;}.settings-row{display:grid;grid-template-columns:minmax(0,1fr) auto;align-items:center;gap:var(--studio-space-4);min-height:var(--studio-row-min-height);padding-block:var(--studio-space-2);padding-inline:0;}.settings-row-text{display:flex;flex-direction:column;gap:var(--studio-space-1);min-inline-size:0;}.row-label{font-weight:var(--studio-weight-regular);}.row-description{line-height:normal;}.settings-row-control{display:flex;align-items:center;justify-content:flex-end;flex-wrap:wrap;gap:var(--studio-space-2);}.settings-row-control select,.settings-row-control .combobox,.settings-row-control input[type="text"],.settings-row-control input[type="search"],.settings-row-control input[type="number"],.settings-row-control input[type="time"],.settings-row-control input[type="password"]{inline-size:260px;max-inline-size:100%;}.settings-row-control input[type="number"],.settings-row-control input[type="time"],.settings-row-control input[type="password"]{inline-size:140px;}.settings-row.stacked{grid-template-columns:minmax(0,1fr);}.settings-row.stacked .settings-row-control{justify-content:stretch;}.settings-row.stacked .settings-row-control>*{flex:1 1 200px;inline-size:auto;}select,input[type="text"],input[type="search"],input[type="number"],input[type="time"],input[type="password"],textarea{min-height:var(--studio-control-height);padding-block:0;padding-inline:var(--studio-space-3);border:none;border-block-end:1px solid var(--studio-field-line);border-radius:var(--studio-radius-field) var(--studio-radius-field) 0 0;background:var(--studio-field-bg);color:var(--studio-text);color-scheme:inherit;font:inherit;transition:background-color 0.15s ease-out;}textarea{padding-block:var(--studio-space-2);padding-inline:var(--studio-space-3);resize:vertical;}select:hover,input[type="text"]:hover,input[type="search"]:hover,input[type="number"]:hover,input[type="time"]:hover,input[type="password"]:hover,textarea:hover{background:var(--studio-field-bg-hover);}select option,select optgroup{background-color:var(--studio-popup-bg);color:var(--studio-text);}input::placeholder,textarea::placeholder{color:var(--studio-text-secondary);opacity:1;}input[readonly]{color:var(--studio-text-secondary);}input[type="file"]{color:var(--studio-text-secondary);font:inherit;}input[type="range"]{inline-size:140px;accent-color:var(--studio-primary);}select:focus-visible,input:focus-visible,textarea:focus-visible,button:focus-visible,a:focus-visible,summary:focus-visible,[tabindex]:focus-visible{outline:2px solid var(--studio-primary);outline-offset:2px;}select:focus-visible,input[type="text"]:focus-visible,input[type="search"]:focus-visible,input[type="number"]:focus-visible,input[type="time"]:focus-visible,input[type="password"]:focus-visible,textarea:focus-visible{outline:none;border-block-end-color:var(--studio-primary);box-shadow:inset 0 -1px 0 var(--studio-primary);}.switch{appearance:none;position:relative;inline-size:48px;block-size:24px;margin:0;border:1px solid var(--studio-switch-border);border-radius:var(--studio-radius-pill);background:var(--studio-switch-track);cursor:pointer;flex-shrink:0;transition:background-color 0.15s ease,border-color 0.15s ease;}.switch::after{content:"";position:absolute;inset-block-start:2px;inset-inline-start:2px;inline-size:18px;block-size:18px;border-radius:50%;background:var(--studio-switch-thumb);box-shadow:var(--studio-switch-thumb-shadow);transition:transform 0.15s ease,background-color 0.15s ease;}.switch:checked{background:var(--studio-switch-on-track);border-color:var(--studio-switch-on-border);}.switch:checked::after{transform:translateX(24px);background:var(--studio-switch-on-thumb);}:host(:dir(rtl)) .switch:checked::after{transform:translateX(-24px);}.switch:disabled{opacity:0.3;cursor:not-allowed;}.input-action-row{display:flex;align-items:center;flex-wrap:wrap;gap:var(--studio-space-2);}.input-action-row>input:not([type="file"]),.input-action-row>select,.input-action-row>.combobox{flex:1 1 180px;min-inline-size:0;}.input-action-row>input[type="file"]{flex:0 1 auto;max-inline-size:100%;}.segmented{display:inline-flex;gap:var(--studio-space-1);padding:var(--studio-space-1);border:1px solid var(--studio-divider);border-radius:var(--studio-radius-pill);}.segmented button{min-height:var(--studio-control-height-compact);padding-block:0;padding-inline:var(--studio-space-3);border:none;border-radius:var(--studio-radius-pill);background:transparent;color:var(--studio-text-secondary);font:inherit;cursor:pointer;}.segmented button[aria-checked="true"]{background:var(--studio-btn-tonal-bg);color:var(--studio-btn-tonal-text);}.inline-switch{display:inline-flex;align-items:center;gap:var(--studio-space-2);cursor:pointer;white-space:nowrap;}.list-row{display:flex;align-items:flex-end;gap:var(--studio-space-2);padding:var(--studio-space-3);border:1px solid var(--studio-divider);border-radius:var(--studio-radius-control);}.list-row-main{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:var(--studio-space-2);flex:1;min-inline-size:0;}.list-row-grow{flex:1;min-inline-size:0;}.list-block{display:flex;flex-direction:column;gap:var(--studio-space-3);padding:var(--studio-space-3);border:1px solid var(--studio-divider);border-radius:var(--studio-radius-control);}.list-row-head{display:flex;align-items:flex-end;gap:var(--studio-space-2);}.stacked-field{display:flex;flex-direction:column;gap:var(--studio-space-1);min-inline-size:0;}.stacked-field>label,.stacked-field>.field-label{color:var(--studio-text-secondary);font-size:var(--studio-font-secondary);}.stacked-field>select,.stacked-field>input,.stacked-field>.combobox{inline-size:100%;}.stack{display:flex;flex-direction:column;gap:var(--studio-space-2);}.btn{display:inline-flex;align-items:center;justify-content:center;gap:var(--studio-space-1);min-height:var(--studio-control-height);padding-block:0;padding-inline:var(--studio-space-4);border:none;border-radius:var(--studio-radius-button);font:inherit;font-weight:var(--studio-weight-medium);line-height:1;text-decoration:none;white-space:nowrap;cursor:pointer;transition:background-color 0.15s ease-out;}.btn:disabled{opacity:0.5;cursor:not-allowed;}.btn-compact{min-height:var(--studio-control-height-compact);padding-block:0;padding-inline:var(--studio-space-3);}.btn-primary{background:var(--studio-btn-accent-bg);color:var(--studio-btn-accent-text);}.btn-primary:hover:not(:disabled){background:var(--studio-btn-accent-bg-hover);}.btn-secondary{background:var(--studio-btn-tonal-bg);color:var(--studio-btn-tonal-text);}.btn-secondary:hover:not(:disabled){background:var(--studio-btn-tonal-bg-hover);}.btn-text{background:transparent;color:var(--studio-btn-tonal-text);padding-block:0;padding-inline:var(--studio-space-3);}.btn-text:hover:not(:disabled){background:var(--studio-btn-plain-hover);}.btn-danger{background:var(--studio-danger-tonal-bg);color:var(--studio-danger-tonal-text);}.btn-danger:hover:not(:disabled){filter:brightness(0.95);}.btn-danger-filled{background:var(--studio-danger-loud-bg);color:var(--studio-danger-loud-text);}.btn-icon{display:inline-flex;align-items:center;justify-content:center;inline-size:var(--studio-control-height);block-size:var(--studio-control-height);padding:0;border:none;border-radius:50%;background:transparent;color:inherit;font:inherit;cursor:pointer;}.btn-icon:disabled{opacity:0.4;cursor:not-allowed;}.btn-icon:hover:not(:disabled){background:var(--studio-hover);}.btn-icon.danger{color:var(--studio-error);}.btn-icon svg{inline-size:20px;block-size:20px;fill:currentColor;}.quick-action-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:var(--studio-space-2);padding-block-end:var(--studio-space-3);border-block-end:1px solid var(--studio-divider);}.quick-action-grid:last-child{padding-block-end:0;border-block-end:none;}.quick-action-btn{justify-content:flex-start;gap:var(--studio-space-2);min-height:var(--studio-control-height);padding-block:var(--studio-space-2);padding-inline:var(--studio-space-3);border-radius:var(--studio-radius-control);white-space:normal;text-align:start;line-height:var(--studio-line-height-condensed);}.quick-action-btn svg{inline-size:18px;block-size:18px;fill:currentColor;flex-shrink:0;}.combobox{position:relative;display:flex;flex-direction:column;min-inline-size:0;}.combobox-input-wrap{position:relative;display:flex;align-items:center;inline-size:100%;}.combobox-input-wrap>input[role="combobox"]{inline-size:100%;padding-inline-end:calc(var(--studio-control-height-compact) + var(--studio-space-2));}.combobox-clear{position:absolute;inset-inline-end:var(--studio-space-1);display:inline-flex;align-items:center;justify-content:center;inline-size:var(--studio-control-height-compact);block-size:var(--studio-control-height-compact);padding:0;border:none;border-radius:50%;background:transparent;color:var(--studio-text-secondary);font:inherit;cursor:pointer;}.combobox-clear:hover{background:var(--studio-hover);color:var(--studio-text);}.combobox-listbox{position:absolute;inset-block-start:calc(100% + var(--studio-space-1));inset-inline:0;z-index:45;max-height:280px;margin:0;padding:var(--studio-space-1);list-style:none;overflow-y:auto;border:1px solid var(--studio-divider);border-radius:var(--studio-radius-control);background:var(--studio-popup-bg);box-shadow:var(--studio-overlay-shadow);}.combobox-option{display:flex;align-items:center;justify-content:space-between;gap:var(--studio-space-2);min-height:var(--studio-control-height);padding-block:var(--studio-space-1);padding-inline:var(--studio-space-2);border-radius:var(--studio-radius-field);cursor:pointer;}.combobox-option:hover,.combobox-option.active{background:var(--studio-hover);}.combobox-option[aria-selected="true"]{background:var(--studio-nav-active-bg);color:var(--studio-nav-active-text);}.combobox-option-main{display:flex;flex-direction:column;min-inline-size:0;flex:1;}.combobox-option-title{font-weight:var(--studio-weight-medium);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}.combobox-option-id{color:var(--studio-text-secondary);font-family:var(--studio-font-code);font-size:var(--studio-font-caption);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}.combobox-option-chips{display:inline-flex;align-items:center;flex-wrap:wrap;gap:var(--studio-space-1);flex-shrink:0;}.combobox-empty,.combobox-footer{padding-block:var(--studio-space-2);padding-inline:var(--studio-space-2);color:var(--studio-text-secondary);font-size:var(--studio-font-caption);}.combobox-footer{border-block-start:1px solid var(--studio-divider);}.sortable-list{display:flex;flex-direction:column;gap:var(--studio-space-2);}.sortable-row{display:flex;align-items:center;gap:var(--studio-space-2);padding-block:var(--studio-space-2);padding-inline:var(--studio-space-3);border:1px solid var(--studio-divider);border-radius:var(--studio-radius-control);background:var(--studio-input-bg);transition:border-color 0.12s ease,opacity 0.12s ease,background-color 0.12s ease;}.sortable-row.dragging,.pill.dragging{opacity:0.65;border-color:var(--studio-primary);box-shadow:var(--studio-handoff-ring);}.sortable-row.drag-over-before{border-block-start:2px solid var(--studio-primary);}.sortable-row.drag-over-after{border-block-end:2px solid var(--studio-primary);}.pill.drag-over-before{box-shadow:inset 2px 0 0 var(--studio-primary);}.pill.drag-over-after{box-shadow:inset -2px 0 0 var(--studio-primary);}.drag-handle{display:inline-flex;align-items:center;justify-content:center;min-inline-size:var(--studio-control-height-compact);min-block-size:var(--studio-control-height-compact);padding:0;border:none;border-radius:var(--studio-radius-field);background:transparent;color:var(--studio-text-secondary);font:inherit;line-height:1;cursor:grab;touch-action:none;user-select:none;flex-shrink:0;}.drag-handle:hover{background:var(--studio-hover);color:var(--studio-text);}.drag-handle:active{cursor:grabbing;}.sortable-row-content{flex:1;min-inline-size:0;}.sortable-row-actions{display:inline-flex;align-items:center;gap:var(--studio-space-1);flex-shrink:0;}`;
__latterExp(__exports, { CONTROL_STYLES: () => CONTROL_STYLES });
//# sourceURL=latter-studio/src/styles/controls.ts
});
__latterDef("src/styles/data.ts", (__exports, __req) => {
const { css } = __req("src/lib/lit.ts");
/**
 * Key-value lists, data tables, WCAG 2.2 AA chips, >= 32px pills, BLE signal bars,
 * wallpaper gallery, camera previews, logs, & alerts (`D-061`, `D-064`).
 */
const DATA_STYLES = css`.kv-list{display:flex;flex-direction:column;gap:0;}.kv-row{display:flex;align-items:center;justify-content:space-between;gap:var(--studio-space-3);min-height:var(--studio-control-height);padding-block:var(--studio-space-1);padding-inline:0;}.kv-row>span:first-child{color:var(--studio-text-secondary);}.kv-row>strong,.kv-value{font-weight:var(--studio-weight-medium);font-variant-numeric:tabular-nums;text-align:end;}button.kv-row{inline-size:100%;border:none;border-radius:var(--studio-radius-control);background:transparent;color:inherit;font:inherit;text-align:start;cursor:pointer;}button.kv-row:hover{background:var(--studio-hover);}button.kv-row>strong::after{content:" ›";color:var(--studio-text-secondary);font-weight:var(--studio-weight-regular);}:host(:dir(rtl)) button.kv-row>strong::after{content:" ‹";}.table-wrap{inline-size:100%;overflow-x:auto;border:1px solid var(--studio-divider);border-radius:var(--studio-radius-control);}table.data-table{inline-size:100%;border-collapse:collapse;text-align:start;}table.data-table th{padding:0;border-block-end:1px solid var(--studio-divider);white-space:nowrap;}.sort-btn{inline-size:100%;padding:var(--studio-space-3);border:none;background:transparent;color:var(--studio-text-secondary);font:inherit;font-size:var(--studio-font-caption);font-weight:var(--studio-weight-medium);text-align:start;cursor:pointer;}.sort-btn:hover{color:var(--studio-text);}th[aria-sort="ascending"] .sort-btn,th[aria-sort="descending"] .sort-btn{color:var(--studio-primary);}table.data-table td{padding:var(--studio-space-3);border-block-end:1px solid var(--studio-divider);white-space:nowrap;}table.data-table tbody tr:last-child td{border-block-end:none;}table.data-table tbody tr{cursor:pointer;}table.data-table tbody tr:hover,table.data-table tbody tr:focus-visible{background:var(--studio-hover);}td.col-name{font-weight:var(--studio-weight-medium);}table.data-table a{color:inherit;text-decoration:none;}table.data-table a:hover{text-decoration:underline;}td.col-open{color:var(--studio-text-secondary);text-align:end;}.chip{display:inline-flex;align-items:center;gap:var(--studio-space-1);min-height:22px;padding-block:0;padding-inline:var(--studio-space-2);border-radius:var(--studio-radius-pill);background:var(--studio-input-bg);color:var(--studio-text-secondary);font-size:var(--studio-font-caption);font-weight:var(--studio-weight-medium);white-space:nowrap;font-variant-numeric:tabular-nums;}.chip-primary{background:var(--studio-chip-primary-bg);color:var(--studio-chip-primary-text);}.chip-success{background:var(--studio-chip-success-bg);color:var(--studio-chip-success-text);}.chip-warning{background:var(--studio-chip-warning-bg);color:var(--studio-chip-warning-text);}.chip-error{background:var(--studio-chip-danger-bg);color:var(--studio-chip-danger-text);}.status-dot{display:inline-block;inline-size:8px;block-size:8px;margin-inline-end:var(--studio-space-2);border-radius:50%;background:var(--studio-text-disabled);}.chip>.status-dot{margin-inline-end:var(--studio-space-1);}.status-dot.online{background:var(--studio-success);}.status-dot.update{background:var(--studio-warning);}.status-tiles{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:var(--studio-space-2);}@container (max-width:260px){.status-tiles{grid-template-columns:minmax(0,1fr);}}.status-tile{display:flex;flex-direction:column;align-items:stretch;gap:var(--studio-space-1);padding:var(--studio-space-3);border:1px solid var(--studio-divider);border-radius:var(--studio-radius-control);background:var(--studio-input-bg);color:inherit;font:inherit;text-align:start;}button.status-tile{cursor:pointer;transition:background-color 0.15s ease-out,border-color 0.15s ease-out;}button.status-tile:hover{background:var(--studio-hover);border-color:var(--studio-primary);}button.status-tile:focus-visible{outline:2px solid var(--studio-primary);outline-offset:2px;}.status-tile-head{display:flex;align-items:center;gap:var(--studio-space-2);color:var(--studio-text-secondary);font-size:var(--studio-font-caption);font-weight:var(--studio-weight-medium);line-height:var(--studio-line-height-condensed);}.status-tile-head svg{inline-size:16px;block-size:16px;fill:currentColor;flex-shrink:0;}.status-tile-value{margin-block-start:var(--studio-space-1);font-size:var(--studio-font-section);font-weight:var(--studio-weight-medium);line-height:var(--studio-line-height-condensed);font-variant-numeric:tabular-nums;overflow-wrap:anywhere;}.status-tile-meta{color:var(--studio-text-secondary);font-size:var(--studio-font-secondary);line-height:var(--studio-line-height-condensed);}.status-tile>.signal-track{margin-block-start:var(--studio-space-1);}@container (max-width:420px){.status-tile{gap:0;padding-block:var(--studio-space-2);padding-inline:var(--studio-space-3);}.status-tile-head{gap:var(--studio-space-1);}.status-tile-value{margin-block-start:var(--studio-space-1);font-size:var(--studio-font-body);}.status-tile-meta{margin-block-start:var(--studio-space-1);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}}.overview-box{display:flex;flex-direction:column;align-items:stretch;gap:var(--studio-space-2);inline-size:100%;padding-block:var(--studio-space-3);padding-inline:var(--studio-space-4);border:1px solid var(--studio-divider);border-radius:var(--studio-radius-control);background:var(--studio-input-bg);color:inherit;font:inherit;text-align:start;}button.overview-box{cursor:pointer;transition:background-color 0.15s ease-out,border-color 0.15s ease-out;}button.overview-box:hover{background:var(--studio-hover);border-color:var(--studio-primary);}.overview-box-head{display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:var(--studio-space-2);}.overview-box-title{display:inline-flex;align-items:center;gap:var(--studio-space-2);font-size:var(--studio-font-body);font-weight:var(--studio-weight-medium);line-height:var(--studio-line-height-condensed);}.overview-box-title svg{inline-size:18px;block-size:18px;fill:currentColor;color:var(--studio-text-secondary);flex-shrink:0;}.overview-box-end{display:inline-flex;align-items:center;flex-wrap:wrap;gap:var(--studio-space-2);}.overview-box-chevron{color:var(--studio-text-secondary);font-weight:var(--studio-weight-regular);}.overview-box-meta{color:var(--studio-text-secondary);font-size:var(--studio-font-secondary);line-height:var(--studio-line-height-condensed);}.overview-chips{display:flex;align-items:center;flex-wrap:wrap;gap:var(--studio-space-1);}.swatch-strip{display:inline-flex;align-items:center;flex-wrap:wrap;gap:var(--studio-space-1);}.swatch.swatch-sm{inline-size:14px;block-size:14px;}.pill-list{display:flex;flex-wrap:wrap;gap:var(--studio-space-2);}.pill{display:inline-flex;align-items:center;gap:2px;min-height:var(--studio-control-height-compact);padding-block:0;padding-inline:var(--studio-space-1);border:1px solid var(--studio-divider);border-radius:var(--studio-radius-pill);background:var(--studio-input-bg);color:var(--studio-text-secondary);font:inherit;font-size:var(--studio-font-secondary);font-weight:var(--studio-weight-medium);}.pill.enabled{border-color:var(--studio-primary);background:var(--studio-chip-primary-bg);color:var(--studio-chip-primary-text);}.pill-move{display:inline-flex;align-items:center;justify-content:center;min-inline-size:var(--studio-control-height-compact);min-block-size:var(--studio-control-height-compact);padding:0;border:none;border-radius:var(--studio-radius-pill);background:transparent;color:inherit;font:inherit;cursor:pointer;}.pill-move:hover:not(:disabled){background:var(--studio-hover);color:var(--studio-primary);}.pill-move:disabled{opacity:0.4;cursor:not-allowed;}.pill-toggle{display:inline-flex;align-items:center;justify-content:center;min-inline-size:var(--studio-control-height-compact);min-block-size:var(--studio-control-height-compact);padding-block:0;padding-inline:var(--studio-space-2);border:none;border-radius:var(--studio-radius-pill);background:transparent;color:inherit;font:inherit;cursor:pointer;}.pill-toggle:disabled{opacity:0.5;cursor:not-allowed;}.pill .drag-handle{border-radius:var(--studio-radius-pill);color:inherit;}.swatch{display:inline-block;inline-size:20px;block-size:20px;border-radius:50%;border:1px solid var(--studio-divider);background:var(--swatch-color,var(--studio-primary));flex-shrink:0;}#card-ble-calibration{scroll-margin-top:calc(var(--studio-header-height) + var(--studio-space-4));}.calibrate-target-box{display:flex;flex-direction:column;gap:var(--studio-space-3);padding:var(--studio-space-3);border:1px solid var(--studio-divider);border-radius:var(--studio-radius-control);background:var(--studio-input-bg);transition:border-color 0.2s ease,background-color 0.2s ease,box-shadow 0.2s ease;}.calibrate-target-box.handoff-active{border-color:var(--studio-primary);box-shadow:var(--studio-handoff-ring);background:var(--studio-primary-tint);}.calibrate-handoff-banner{display:flex;align-items:center;justify-content:space-between;gap:var(--studio-space-2);font-weight:var(--studio-weight-medium);}.signal-row{display:flex;flex-direction:column;gap:var(--studio-space-2);padding:var(--studio-space-3);border:1px solid var(--studio-divider);border-radius:var(--studio-radius-control);background:var(--studio-input-bg);}.signal-row.winner{border-color:var(--studio-primary);}.proxy-trim-details{padding-block-start:var(--studio-space-2);}.proxy-trim-details>summary{color:var(--studio-text-secondary);font-size:var(--studio-font-secondary);}.proxy-trim-details[open]>summary,.proxy-trim-details>summary:hover{color:var(--studio-text);}.proxy-trim-body{display:flex;flex-direction:column;gap:var(--studio-space-2);padding-block-start:var(--studio-space-2);}.signal-row-head{display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:var(--studio-space-2);}.signal-row-title{display:flex;align-items:center;flex-wrap:wrap;gap:var(--studio-space-2);}.signal-meta{color:var(--studio-text-secondary);font-size:var(--studio-font-secondary);}.signal-track,.upload-progress{block-size:6px;border-radius:var(--studio-radius-pill);background:var(--studio-surface-alt);overflow:hidden;}.signal-fill{inline-size:var(--signal-pct,0%);block-size:100%;background:var(--studio-primary);transition:inline-size 0.25s ease,width 0.25s ease;}.signal-fill.low{background:var(--studio-error);}.upload-progress-fill{inline-size:var(--upload-pct,0%);block-size:100%;background:var(--studio-primary);transition:inline-size 0.15s ease,width 0.15s ease;}.wp-upload-trigger{display:inline-flex;align-items:center;}.wp-upload-status{display:flex;align-items:center;justify-content:space-between;gap:var(--studio-space-2);font-size:var(--studio-font-secondary);color:var(--studio-text-secondary);}.wp-gallery{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:var(--studio-space-3);}.wp-card{display:flex;flex-direction:column;align-items:center;gap:var(--studio-space-2);padding:var(--studio-space-3);border:1px solid var(--studio-divider);border-radius:var(--studio-radius-control);background:var(--studio-input-bg);text-align:center;}.wp-gallery>.empty-state{grid-column:1 / -1;}.wp-card.active{border-color:var(--studio-primary);background:var(--studio-primary-tint);}.wp-thumb-btn{padding:0;border:none;background:transparent;border-radius:var(--studio-radius-control);cursor:pointer;line-height:0;}.wp-thumb-btn.circle{border-radius:50%;}.wp-thumb-btn:hover .wp-thumb{border-color:var(--studio-primary);}.wp-thumb-btn:focus-visible{outline:2px solid var(--studio-primary);outline-offset:2px;}.wp-thumb{inline-size:104px;block-size:104px;object-fit:cover;background:var(--studio-media-bg);border:1px solid var(--studio-divider);}.wp-thumb.circle{border-radius:50%;}.wp-thumb.square{border-radius:var(--studio-radius-control);}.wp-title{font-size:var(--studio-font-secondary);font-weight:var(--studio-weight-medium);overflow-wrap:anywhere;}.wp-actions{display:flex;align-items:center;justify-content:center;flex-wrap:wrap;gap:var(--studio-space-1);margin-block-start:auto;inline-size:100%;}.btn-icon.wp-star-btn{inline-size:var(--studio-control-height-compact);block-size:var(--studio-control-height-compact);}.btn-icon.wp-star-btn:hover{color:var(--studio-warning);background:var(--studio-warning-tint);}.btn-icon.wp-star-btn.starred{color:var(--studio-warning);}.cam-preview{display:flex;flex-direction:column;gap:var(--studio-space-2);padding:var(--studio-space-3);border:1px solid var(--studio-divider);border-radius:var(--studio-radius-control);background:var(--studio-input-bg);}.cam-preview img{inline-size:100%;max-inline-size:360px;aspect-ratio:16 / 9;object-fit:cover;border-radius:var(--studio-radius-control);background:var(--studio-media-bg);}.log-output{max-block-size:380px;margin:0;padding:var(--studio-space-3);overflow:auto;border:1px solid var(--studio-divider);border-radius:var(--studio-radius-control);background:var(--studio-input-bg);white-space:pre-wrap;}.empty-state{padding-block:var(--studio-space-3);padding-inline:0;color:var(--studio-text-secondary);}.loading-state{display:flex;align-items:center;gap:var(--studio-space-3);padding-block:var(--studio-space-5);padding-inline:0;color:var(--studio-text-secondary);}.loading-state::before{content:"";inline-size:20px;block-size:20px;border:2px solid var(--studio-divider);border-block-start-color:var(--studio-primary);border-radius:50%;animation:studio-spin 0.8s linear infinite;}.studio-root:not(.is-loading) #studio-loading{display:none;}@keyframes studio-spin{to{transform:rotate(360deg);}}.alert{display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:var(--studio-space-3);padding-block:var(--studio-space-2);padding-inline:var(--studio-space-4);border-radius:var(--studio-radius-field);background:var(--studio-info-tint);}.alert-error{background:var(--studio-error-tint);}.alert-warning{background:var(--studio-warning-tint);}.alert-body{display:flex;flex-direction:column;gap:var(--studio-space-1);min-inline-size:0;}.alert-list{margin:0;padding-inline-start:var(--studio-space-5);}.toast{position:fixed;inset-inline-start:50%;inset-block-end:var(--studio-space-5);transform:translateX(-50%);z-index:50;max-inline-size:min(560px,calc(100vw - 32px));padding-block:var(--studio-space-3);padding-inline:var(--studio-space-4);border-radius:var(--studio-radius-field);background:var(--studio-toast-bg);color:var(--studio-toast-text);box-shadow:var(--studio-overlay-shadow);}.toast.error{background:var(--studio-danger-loud-bg);color:var(--studio-danger-loud-text);}.offscreen,.sr-only{position:fixed;inset-block-start:0;inset-inline-start:0;inline-size:1px;block-size:1px;padding:0;margin:0;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:none;opacity:0;pointer-events:none;}`;
__latterExp(__exports, { DATA_STYLES: () => DATA_STYLES });
//# sourceURL=latter-studio/src/styles/data.ts
});
__latterDef("src/styles/dialogs.ts", (__exports, __req) => {
const { css } = __req("src/lib/lit.ts");
/**
 * Native `<dialog>` modals, confirmation modal (`Q5`), non-truncating `.dock-row`,
 * shortcut/MDI picker grids, and HSV color wheel (`D-053`, `D-064`).
 */
const DIALOG_STYLES = css`dialog.studio-dialog{inline-size:min(460px,calc(100vw - 32px));max-block-size:calc(100vh - 32px);max-block-size:calc(100dvh - 32px);padding:var(--studio-space-5);border:none;border-radius:var(--studio-radius-dialog);background:var(--studio-surface);color:var(--studio-text);box-shadow:var(--studio-overlay-shadow);overflow-y:auto;}dialog.studio-dialog::backdrop{background:var(--studio-scrim);}dialog.studio-dialog.confirm-dialog{inline-size:min(480px,calc(100vw - 32px));}.dialog-body{display:flex;flex-direction:column;gap:var(--studio-space-3);}.dialog-header-row{display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:var(--studio-space-2);}.dialog-title{font-size:var(--studio-font-card-title);font-weight:var(--studio-weight-regular);line-height:var(--studio-line-height-condensed);}.dialog-text{color:var(--studio-text-secondary);}.dialog-actions{display:flex;align-items:center;justify-content:flex-end;flex-wrap:wrap;gap:var(--studio-space-2);margin-block-start:var(--studio-space-2);}.dialog-actions.with-secondary{justify-content:space-between;}.dialog-actions-end{display:inline-flex;align-items:center;flex-wrap:wrap;gap:var(--studio-space-2);margin-inline-start:auto;}dialog.studio-dialog.shortcut-dialog{inline-size:min(560px,calc(100vw - 32px));}.shortcut-item-row,.dock-row{display:flex;align-items:center;gap:var(--studio-space-2);padding-block:var(--studio-space-2);padding-inline:var(--studio-space-3);border:1px solid var(--studio-divider);border-radius:var(--studio-radius-control);background:var(--studio-input-bg);}.dock-row{flex-wrap:wrap;}.dock-row .shortcut-item-info{flex:1 1 180px;}.dock-row .shortcut-item-title,.dock-row .shortcut-item-meta{white-space:normal;overflow-wrap:anywhere;}.shortcut-item-row.shortcut-item-locked,.dock-row.shortcut-item-locked{border-style:dashed;background:transparent;}.shortcut-item-row.shortcut-item-locked .shortcut-icon-badge,.shortcut-item-row.shortcut-item-hidden .shortcut-icon-badge,.dock-row.shortcut-item-locked .shortcut-icon-badge,.dock-row.shortcut-item-hidden .shortcut-icon-badge{background:var(--studio-surface-alt);color:var(--studio-text-secondary);}.shortcut-icon-badge{display:inline-flex;align-items:center;justify-content:center;inline-size:var(--studio-control-height-compact);block-size:var(--studio-control-height-compact);border-radius:var(--studio-radius-pill);background:var(--studio-chip-primary-bg);color:var(--studio-chip-primary-text);flex-shrink:0;}.shortcut-item-info{display:flex;flex-direction:column;gap:var(--studio-space-1);min-inline-size:0;flex:1;}.shortcut-item-title{font-weight:var(--studio-weight-medium);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}.shortcut-item-meta{font-size:var(--studio-font-secondary);color:var(--studio-text-secondary);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}.shortcut-page-group{display:flex;flex-direction:column;gap:var(--studio-space-2);padding:var(--studio-space-3);border:1px solid var(--studio-divider);border-radius:var(--studio-radius-control);background:var(--studio-surface-alt);}.shortcut-page-header{display:flex;align-items:center;justify-content:space-between;font-size:var(--studio-font-secondary);font-weight:var(--studio-weight-medium);color:var(--studio-text-secondary);}.shortcut-toolbar{display:flex;align-items:center;flex-wrap:wrap;gap:var(--studio-space-2);}.shortcut-icon-row{display:flex;align-items:center;gap:var(--studio-space-2);}.shortcut-icon-row input[type="text"]{flex:1;min-inline-size:0;}.mdi-picker-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(40px,1fr));gap:var(--studio-space-1);max-block-size:168px;overflow-y:auto;padding:var(--studio-space-2);border:1px solid var(--studio-divider);border-radius:var(--studio-radius-control);background:var(--studio-input-bg);}.mdi-picker-btn{display:inline-flex;align-items:center;justify-content:center;block-size:var(--studio-control-height);border:1px solid transparent;border-radius:var(--studio-radius-control);background:transparent;color:var(--studio-text);cursor:pointer;}.mdi-picker-btn:hover{background:var(--studio-hover);}.mdi-picker-btn.selected{background:var(--studio-chip-primary-bg);border-color:var(--studio-primary);color:var(--studio-chip-primary-text);}.color-wheel{display:flex;justify-content:center;}.color-wheel canvas{border-radius:50%;cursor:crosshair;touch-action:none;}.color-hex-row{display:flex;align-items:center;justify-content:center;gap:var(--studio-space-2);}.color-hex-row input[type="text"]{inline-size:120px;font-family:var(--studio-font-code);text-align:center;}.color-hex-row input[type="color"]{inline-size:var(--studio-control-height);block-size:var(--studio-control-height);padding:0;border:1px solid var(--studio-divider);border-radius:var(--studio-radius-control);background:none;cursor:pointer;}`;
__latterExp(__exports, { DIALOG_STYLES: () => DIALOG_STYLES });
//# sourceURL=latter-studio/src/styles/dialogs.ts
});
__latterDef("src/styles/layout.ts", (__exports, __req) => {
const { css } = __req("src/lib/lit.ts");
/**
 * Title bar, two-pane RTL-safe sidebar shell, navigation badges, & two-column layout (`D-014`).
 */
const LAYOUT_STYLES = css`header.latter-top-titlebar{display:flex;align-items:center;justify-content:space-between;gap:var(--studio-space-3);height:var(--studio-header-height);padding-block:0;padding-inline:var(--studio-space-3);background:var(--studio-header-bg);color:var(--studio-header-text);border-block-end:var(--studio-header-border);position:sticky;inset-block-start:0;z-index:30;}.titlebar-brand{display:flex;align-items:center;gap:var(--studio-space-3);font-size:var(--studio-font-title);font-weight:var(--studio-weight-regular);user-select:none;}.titlebar-brand .ha-menu-btn{color:var(--studio-header-icon);display:none;}:host([narrow]) .titlebar-brand .ha-menu-btn{display:inline-flex;}.titlebar-title{padding-inline-start:var(--studio-space-3);}:host([narrow]) .titlebar-title{padding-inline-start:0;}.titlebar-actions{display:flex;align-items:center;gap:var(--studio-space-2);}.app-shell{display:grid;grid-template-columns:var(--studio-sidebar-width) minmax(0,1fr);min-height:calc(100vh - var(--studio-header-height));min-height:calc(100dvh - var(--studio-header-height));}aside.sidebar{background:var(--studio-sidebar-bg);border-inline-end:1px solid var(--studio-divider);display:flex;flex-direction:column;gap:var(--studio-space-2);padding-block:var(--studio-space-4);padding-inline:var(--studio-space-3);position:sticky;inset-block-start:var(--studio-header-height);height:calc(100vh - var(--studio-header-height));height:calc(100dvh - var(--studio-header-height));overflow-y:auto;}.scope-tabs{display:grid;grid-template-columns:1fr 1fr;gap:var(--studio-space-1);padding:var(--studio-space-1);background:var(--studio-input-bg);border:1px solid var(--studio-divider);border-radius:var(--studio-radius-control);}.scope-tab{min-height:var(--studio-control-height-compact);border:none;border-radius:var(--studio-radius-control);background:transparent;color:var(--studio-text-secondary);font:inherit;font-weight:var(--studio-weight-medium);cursor:pointer;}.scope-tab.active{background:var(--studio-btn-tonal-bg);color:var(--studio-btn-tonal-text);}.nav-list{display:flex;flex-direction:column;gap:var(--studio-space-1);}.nav-btn{display:flex;align-items:center;justify-content:space-between;gap:var(--studio-space-2);width:100%;min-height:var(--studio-control-height);padding-block:0;padding-inline:var(--studio-space-3);border:none;border-radius:var(--studio-radius-control);background:transparent;color:var(--studio-text);font:inherit;font-weight:var(--studio-weight-medium);text-align:start;text-decoration:none;white-space:nowrap;cursor:pointer;}.nav-btn:hover{background:var(--studio-hover);}.nav-btn.active{background:var(--studio-nav-active-bg);color:var(--studio-nav-active-text);}.nav-btn.nav-back-btn{color:var(--studio-text-secondary);}.nav-device-title{padding-block:var(--studio-space-2);padding-inline:var(--studio-space-3);border-block-start:1px solid var(--studio-divider);border-block-end:1px solid var(--studio-divider);font-size:var(--studio-font-section);font-weight:var(--studio-weight-medium);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}#nav-scope-device .nav-btn:not(.nav-back-btn){padding-inline-start:var(--studio-space-4);}.nav-badge{min-inline-size:20px;padding-block:0;padding-inline:var(--studio-space-2);border-radius:var(--studio-radius-pill);background:var(--studio-input-bg);color:var(--studio-text-secondary);font-size:var(--studio-font-caption);font-weight:var(--studio-weight-medium);text-align:center;font-variant-numeric:tabular-nums;}.main-area{min-inline-size:0;}.content-wrap{max-inline-size:1140px;margin-block:0;margin-inline:auto;padding:var(--studio-space-5);display:flex;flex-direction:column;gap:var(--studio-space-4);container-type:inline-size;container-name:studio-content;}.content-wrap>section{display:flex;flex-direction:column;gap:var(--studio-space-4);}.page-title{display:flex;align-items:baseline;flex-wrap:wrap;gap:var(--studio-space-2);font-size:var(--studio-font-title);font-weight:var(--studio-weight-regular);}.page-subtitle{color:var(--studio-text-secondary);font-weight:var(--studio-weight-regular);}.is-loading .content-wrap>section{display:none !important;}.columns{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:var(--studio-space-4);align-items:start;}.column{display:flex;flex-direction:column;gap:var(--studio-space-4);min-inline-size:0;}@container studio-content (max-width:760px){.columns{grid-template-columns:minmax(0,1fr);}}`;
__latterExp(__exports, { LAYOUT_STYLES: () => LAYOUT_STYLES });
//# sourceURL=latter-studio/src/styles/layout.ts
});
__latterDef("src/styles/narrow.ts", (__exports, __req) => {
const { css } = __req("src/lib/lit.ts");
/**
 * Container queries & mobile breakpoints, including horizontal `.nav-list` scroll fade mask.
 */
const NARROW_STYLES = css`@container (max-width:520px){.settings-row{grid-template-columns:minmax(0,1fr);}.settings-row + .settings-row{border-block-start:1px solid var(--studio-divider);}.settings-row-control{justify-content:flex-start;}.settings-row-control select,.settings-row-control .combobox,.settings-row-control input[type="text"],.settings-row-control input[type="search"],.settings-row-control input[type="password"]{inline-size:100%;}}@container (max-width:360px){.quick-action-grid{grid-template-columns:minmax(0,1fr);}}@media (max-width:860px){.titlebar-brand .ha-menu-btn{display:inline-flex;}.titlebar-title{padding-inline-start:0;}.app-shell{grid-template-columns:1fr;grid-template-rows:auto 1fr;}aside.sidebar{align-self:start;position:sticky;inset-block-start:var(--studio-header-height);z-index:25;block-size:auto;padding-block:var(--studio-space-2);padding-inline:var(--studio-space-3);border-inline-end:none;border-block-end:1px solid var(--studio-divider);}.nav-device-title{display:none;}.nav-list{flex-direction:row;overflow-x:auto;scrollbar-width:none;padding-inline:var(--studio-space-1);-webkit-mask-image:var(--studio-nav-scroll-mask);mask-image:var(--studio-nav-scroll-mask);}.nav-list::-webkit-scrollbar{display:none;}.nav-btn{inline-size:auto;border:1px solid var(--studio-divider);border-radius:var(--studio-radius-pill);}#nav-scope-device .nav-btn:not(.nav-back-btn){padding-inline-start:var(--studio-space-3);}.content-wrap{padding-block:var(--studio-space-4) var(--studio-space-5);padding-inline:var(--studio-space-3);}.settings-row{grid-template-columns:minmax(0,1fr);}.settings-row + .settings-row{border-block-start:1px solid var(--studio-divider);}.settings-row-control{justify-content:flex-start;}.settings-row-control select,.settings-row-control .combobox,.settings-row-control input[type="text"],.settings-row-control input[type="search"],.settings-row-control input[type="password"]{inline-size:100%;}}@media (max-width:480px){.list-row{flex-wrap:wrap;}.list-row-head{flex-wrap:wrap;}.list-row-main{grid-template-columns:minmax(0,1fr);inline-size:100%;}}`;
__latterExp(__exports, { NARROW_STYLES: () => NARROW_STYLES });
//# sourceURL=latter-studio/src/styles/narrow.ts
});
__latterDef("src/styles/tokens.ts", (__exports, __req) => {
const { css } = __req("src/lib/lit.ts");
const { BASE_STYLES } = __req("src/styles/base.ts");
const { CARD_STYLES } = __req("src/styles/cards.ts");
const { CONTROL_STYLES } = __req("src/styles/controls.ts");
const { DATA_STYLES } = __req("src/styles/data.ts");
const { DIALOG_STYLES } = __req("src/styles/dialogs.ts");
const { LAYOUT_STYLES } = __req("src/styles/layout.ts");
const { NARROW_STYLES } = __req("src/styles/narrow.ts");
/**
 * Composed Latter Studio Design System Stylesheet (`STUDIO_STYLES`), re-exporting
 * modular stylesheet slices (`base`, `layout`, `cards`, `controls`, `data`, `dialogs`, `narrow`).
 */
const STUDIO_STYLES = css`${BASE_STYLES}${LAYOUT_STYLES}${CARD_STYLES}${CONTROL_STYLES}${DATA_STYLES}${DIALOG_STYLES}${NARROW_STYLES}`;
__latterExp(__exports, { BASE_STYLES: () => BASE_STYLES, CARD_STYLES: () => CARD_STYLES, CONTROL_STYLES: () => CONTROL_STYLES, DATA_STYLES: () => DATA_STYLES, DIALOG_STYLES: () => DIALOG_STYLES, LAYOUT_STYLES: () => LAYOUT_STYLES, NARROW_STYLES: () => NARROW_STYLES, STUDIO_STYLES: () => STUDIO_STYLES });
//# sourceURL=latter-studio/src/styles/tokens.ts
});
__latterDef("src/views/device-overview-view.ts", (__exports, __req) => {
const { isDeviceTime24h, renderCard, renderNativeControlRow, renderQuickActionGrid, renderSelectRow, renderSettingsRow, renderSvgIcon } = __req("src/components/controls.ts");
const { DEFAULT_ALARMS_SUMMARY } = __req("src/constants.ts");
const { formatHaEntityState } = __req("src/i18n/index.ts");
const { html, nothing } = __req("src/lib/lit.ts");
const { defaultLocaleTimeFormat, entityLabel, fmtDistance, fmtNumber, fmtPercent, formatClockHhMm, issueMessage, rssiToPercent } = __req("src/utils/format.ts");
/**
 * Device Overview View (`dashboard`, `D-003`, `D-029`, `D-030`, `D-048`, `D-066`, `F-01`):
 * - Shared `renderDeviceOfflineBanner`, `renderDeviceEntityRow` (`formatHaEntityState`), and `defaultLocaleTimeFormat`
 * - Column 1: High-level Status card (`caps.has_battery` true unknowns & real `update.*` Firmware gating)
 *   + Quick actions (`forceDisabled` offline gating, separated `.btn-danger` Restart row, `#btn-open-in-ha`)
 * - Column 2: Assignments, Timers & alarms (1 Hz client countdown from `timer_ends_at` / `stopwatch_started_at`),
 *   and spillover Sensors & controls.
 */
const DEV_ICON_AREA =
  "M12,6.5A2.5,2.5 0 0,1 14.5,9A2.5,2.5 0 0,1 12,11.5A2.5,2.5 0 0,1 9.5,9A2.5,2.5 0 0,1 12,6.5M12,2A7,7 0 0,1 19,9C19,14.25 12,22 12,22C12,22 5,14.25 5,9A7,7 0 0,1 12,2M12,4A5,5 0 0,0 7,9C7,10 7,12 12,18.71C17,12 17,10 17,9A5,5 0 0,0 12,4Z";
const DEV_ICON_BATTERY =
  "M16,20H8V6H16M16.67,4H15V2H9V4H7.33A1.33,1.33 0 0,0 6,5.33V20.67C6,21.4 6.6,22 7.33,22H16.67A1.33,1.33 0 0,0 18,20.67V5.33C18,4.6 17.4,4 16.67,4Z";
const DEV_ICON_PLUG =
  "M16,7V3H14V7H10V3H8V7H8C7,7 6,8 6,9V14.5L9.5,18V21H14.5V18L18,14.5V9C18,8 17,7 16,7M16,13.67L12.5,17.17V19H11.5V17.17L8,13.67V9H16V13.67Z";
const DEV_ICON_RADAR =
  "M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12C22,10.84 21.79,9.69 21.39,8.61L19.79,10.21C19.93,10.8 20,11.4 20,12A8,8 0 0,1 12,20A8,8 0 0,1 4,12A8,8 0 0,1 12,4C12.6,4 13.2,4.07 13.79,4.21L15.4,2.6C14.31,2.21 13.16,2 12,2M19,2A2,2 0 0,0 17,4A2,2 0 0,0 19,6A2,2 0 0,0 21,4A2,2 0 0,0 19,2M12,6A6,6 0 0,0 6,12A6,6 0 0,0 12,18A6,6 0 0,0 18,12H16A4,4 0 0,1 12,16A4,4 0 0,1 8,12A4,4 0 0,1 12,8V6M12,10A2,2 0 0,0 10,12A2,2 0 0,0 12,14A2,2 0 0,0 14,12A2,2 0 0,0 12,10Z";
const DEV_ICON_WIFI =
  "M12,21L15.6,16.2C14.6,15.45 13.35,15 12,15C10.65,15 9.4,15.45 8.4,16.2L12,21M12,3C7.95,3 4.21,4.34 1.2,6.6L3,9C5.5,7.12 8.62,6 12,6C15.38,6 18.5,7.12 21,9L22.8,6.6C19.79,4.34 16.05,3 12,3M12,9C9.3,9 6.81,9.89 4.8,11.4L6.6,13.8C8.1,12.67 9.97,12 12,12C14.03,12 15.9,12.67 17.4,13.8L19.2,11.4C17.19,9.89 14.7,9 12,9Z";
const DEV_ICON_BLUETOOTH =
  "M14.88,16.29L13,18.17V14.41M13,5.83L14.88,7.71L13,9.58M17.71,7.71L12,2H11V9.58L6.41,5L5,6.41L10.59,12L5,17.58L6.41,19L11,14.41V22H12L17.71,16.29L13.41,12L17.71,7.71Z";
const DEV_ICON_CHIP =
  "M17,17H7V7H17M21,11V9H19V7C19,5.89 18.1,5 17,5H15V3H13V5H11V3H9V5H7C5.89,5 5,5.89 5,7V9H3V11H5V13H3V15H5V17A2,2 0 0,0 7,19H9V21H11V19H13V21H15V19H17A2,2 0 0,0 19,17V15H21V13H19V11M15,15H9V9H15V15Z";
const DEV_ICON_TAG =
  "M21.41,11.58L12.41,2.58C12.05,2.22 11.55,2 11,2H4C2.9,2 2,2.9 2,4V11C2,11.55 2.22,12.05 2.59,12.42L11.59,21.42C11.95,21.78 12.45,22 13,22C13.55,22 14.05,21.78 14.41,14.41L21.41,14.41C21.78,14.05 22,13.55 22,13C22,12.45 21.77,11.94 21.41,11.58M13,20.01L4,11V4H11V3.99L20,12.99L13,20.01M6.5,5A1.5,1.5 0 0,1 8,6.5A1.5,1.5 0 0,1 6.5,8A1.5,1.5 0 0,1 5,6.5A1.5,1.5 0 0,1 6.5,5Z";
/**
 * Shared calm offline / sleeping banner rendered at the top of Device views (`Q8` / `E-04`).
 */
function renderDeviceOfflineBanner(store) {
  const data = store.state;
  const cfg = data?.config || {};
  if (cfg.kind === "ble_tag") return nothing;
  const curDevEntry =
    (data?.system_devices || []).find((d) => d.subentry_id === store.activeSubentryId) ||
    (data?.system_devices || []).find((d) => d.is_current);
  if (curDevEntry?.is_online !== false) return nothing;
  const sleepExpected = Boolean(data?.live?.is_ble_sleep_expected);
  const titleKey = sleepExpected
    ? "offline.device_sleeping_title"
    : "offline.device_banner_title";
  return html`<div
    id="device-offline-banner"
    role="region"
    aria-label=${store.t(titleKey)}
    class="alert offline-banner"
  >
    <div class="offline-banner-body">
      <strong>${store.t(titleKey)}</strong>
      <span>${store.t("offline.device_banner_body")}</span>
    </div>
    <span class="chip">
      ${sleepExpected ? store.t("status.sleeping") : store.t("status.offline")}
    </span>
  </div>`;
}
/**
 * Formats non-pref Home Assistant entity `select` options and sensor states via `formatHaEntityState` (`D-13`),
 * while delegating preference-backed, switch, number, button, and update controls to `renderNativeControlRow`.
 */
function renderDeviceEntityRow(
  store,
  item,
) {
  if (
    item.pref_key ||
    item.domain === "switch" ||
    item.domain === "number" ||
    item.domain === "button" ||
    item.domain === "update"
  ) {
    return renderNativeControlRow(store, item);
  }
  const label = entityLabel(item.name || item.entity_id);
  const st = String(item.state ?? "");
  const unavailable = st === "unavailable" || st === "unknown";
  if (item.domain === "select") {
    const opts = item.options || [];
    const onChange = (ev) => {
      void store.entity.espSelect(item.entity_id, (ev.currentTarget).value);
    };
    return renderSettingsRow({
      label,
      control: html`<select aria-label=${label} ?disabled=${unavailable} .value=${st} @change=${onChange}>
        ${opts.map(
          (opt) =>
            html`<option value=${opt} ?selected=${opt === st}>
              ${formatHaEntityState(store.hass, item.entity_id, opt)}
            </option>`,
        )}
      </select>`,
    });
  }
  const displayVal = unavailable
    ? store.t("common.unknown")
    : item.unit && Number.isFinite(Number(st))
      ? `${fmtNumber(Number(st), store.hass)} ${item.unit}`
      : formatHaEntityState(store.hass, item.entity_id, st);
  return html`<div class="kv-row">
    <span>${label}</span>
    <strong>${displayVal}</strong>
  </div>`;
}
function rssiQualityLabel(store, rssi) {
  if (rssi === null || !Number.isFinite(rssi)) return store.t("signal.no_reading");
  if (rssi >= -60) return store.t("signal.excellent");
  if (rssi >= -70) return store.t("signal.good");
  if (rssi >= -80) return store.t("signal.fair");
  return store.t("signal.weak");
}
function canonicalActionCommand(item) {
  if (item.device_command) return item.device_command;
  if (item.device_class === "identify") return "find_my";
  if (item.device_class === "restart") return "restart";
  const tail = (item.key || item.entity_id.split(".", 2)[1] || "").toLowerCase();
  if (tail === "find_my" || tail.endsWith("_find_my_device") || tail.endsWith("_find_my")) {
    return "find_my";
  }
  if (
    tail === "trigger_va" ||
    tail.endsWith("_trigger_voice_assistant") ||
    tail.endsWith("_trigger_va")
  ) {
    return "trigger_va";
  }
  if (tail === "activate_screensaver" || tail.endsWith("_activate_screensaver")) {
    return "activate_screensaver";
  }
  if (tail === "hibernate" || tail.endsWith("_hibernate_device") || tail.endsWith("_hibernate")) {
    return "hibernate";
  }
  if (tail === "restart" || tail.endsWith("_restart_device") || tail.endsWith("_restart")) {
    return "restart";
  }
  return "";
}
function localizedQuickActionLabel(
  store,
  cmd,
  fallback,
) {
  switch (cmd) {
    case "find_my":
      return store.t("dev_overview.qa_find_my");
    case "trigger_va":
      return store.t("dev_overview.qa_trigger_va");
    case "activate_screensaver":
      return store.t("dev_overview.qa_activate_screensaver");
    case "restart":
      return store.t("dev_overview.qa_restart");
    default:
      return entityLabel(fallback);
  }
}
const DEFAULT_ALARM_SLOTS = [
  { time: "07:00", enabled: false, recurrence: 1 },
  { time: "08:30", enabled: false, recurrence: 2 },
  { time: "09:00", enabled: false, recurrence: 2 },
];
function parseAlarmsSummary(raw) {
  const text = String(raw || DEFAULT_ALARMS_SUMMARY).trim();
  const parts = text.split(";");
  const slots = [];
  for (let i = 0; i < 3; i++) {
    const fallback = DEFAULT_ALARM_SLOTS[i];
    const seg = (parts[i] || "").trim();
    const m = /^(\d{1,2}):(\d{2})\|([01])\|([0-3])$/.exec(seg);
    if (!m) {
      slots.push({ ...fallback });
      continue;
    }
    const hh = Number(m[1]);
    const mm = Number(m[2]);
    if (hh < 0 || hh > 23 || mm < 0 || mm > 59) {
      slots.push({ ...fallback });
      continue;
    }
    slots.push({
      time: `${String(hh).padStart(2, "0")}:${String(mm).padStart(2, "0")}`,
      enabled: m[3] === "1",
      recurrence: Number(m[4]),
    });
  }
  return [slots[0], slots[1], slots[2]];
}
function serializeAlarmsSummary(slots) {
  return slots
    .slice(0, 3)
    .map((s) => `${s.time}|${s.enabled ? 1 : 0}|${s.recurrence}`)
    .join(";");
}
function formatClockDuration(rawSec) {
  const sec = Math.max(0, Math.floor(Number(rawSec) || 0));
  const hh = Math.floor(sec / 3600);
  const mm = Math.floor((sec % 3600) / 60);
  const ss = sec % 60;
  if (hh > 0) {
    return `${String(hh).padStart(2, "0")}:${String(mm).padStart(2, "0")}:${String(ss).padStart(2, "0")}`;
  }
  return `${String(mm).padStart(2, "0")}:${String(ss).padStart(2, "0")}`;
}
function renderDeviceOverviewView(store) {
  const data = store.state;
  const cfg = data?.config || {};
  const live = data?.live || {};
  const caps = data?.capabilities || {};
  const links = data?.links || {};
  const esp = data?.esphome;
  const isBleOnly = cfg.kind === "ble_tag";
  const curDevEntry =
    (data?.system_devices || []).find((d) => d.subentry_id === store.activeSubentryId) ||
    (data?.system_devices || []).find((d) => d.is_current);
  const isOffline = !isBleOnly && curDevEntry?.is_online === false;
  const deviceIssues = (data?.issues || []).filter(
    (i) => i.subentry_id && i.subentry_id === store.activeSubentryId,
  );
  const hasErrorIssue = deviceIssues.some(
    (i) => i.severity === "error" || i.severity === "critical",
  );
  // Live Status calculations (strict `D-003` unknowns)
  const winRow = (curDevEntry?.ble_survey_rows || []).find((r) => r.is_winner);
  const hasBattery = Boolean(caps.has_battery || curDevEntry?.has_battery);
  const hasBatteryReading =
    !isBleOnly &&
    hasBattery &&
    curDevEntry?.battery_level !== null &&
    curDevEntry?.battery_level !== undefined &&
    Number.isFinite(Number(curDevEntry.battery_level));
  const batPct = hasBatteryReading
    ? Math.max(0, Math.min(100, Math.round(Number(curDevEntry?.battery_level))))
    : 0;
  const batSignalStyle = `--signal-pct:${batPct}%`;
  const batMeta = curDevEntry?.is_charging
    ? store.t("status.charging")
    : curDevEntry?.is_usb_connected
      ? store.t("status.plugged_in")
      : hasBatteryReading
        ? store.t("status.on_battery")
        : store.t("dev_overview.waiting_for_reading");
  let rssiVal = null;
  if (!isBleOnly && curDevEntry?.wifi_rssi !== null && curDevEntry?.wifi_rssi !== undefined) {
    rssiVal = Number(curDevEntry.wifi_rssi);
  } else if (
    isBleOnly &&
    winRow &&
    winRow.effective_rssi !== null &&
    winRow.effective_rssi !== undefined
  ) {
    rssiVal = Number(winRow.effective_rssi);
  }
  const hasRssi = rssiVal !== null && Number.isFinite(rssiVal);
  const rssiText = hasRssi
    ? `${fmtNumber(rssiVal, store.hass, 0)} dBm`
    : store.t("common.unknown");
  const rssiPct = hasRssi ? rssiToPercent(rssiVal) : 0;
  const wifiSignalStyle = `--signal-pct:${rssiPct}%`;
  const hasAssignedArea = Boolean(curDevEntry?.has_assigned_area);
  const areaText = hasAssignedArea
    ? curDevEntry?.area_label || live.active_area_name || store.t("common.unknown")
    : live.active_area_name || store.t("common.unknown");
  const effBleCat = String(cfg.effective_ble_category || curDevEntry?.ble_category || "ble_tag");
  const rawBleCat = String(cfg.ble_category || "auto").trim().toLowerCase();
  const curBleCat = rawBleCat === "phone" || rawBleCat === "ble_tag" ? rawBleCat : "auto";
  const txStatus = isBleOnly ? live.ble_transmitter_status : null;
  const txStateText = String(txStatus?.state || "").trim();
  const showTxOffBanner =
    Boolean(txStatus) && Boolean(txStateText) && txStateText.toLowerCase() !== "transmitting";
  const distSuffix =
    live.ble_closest_proxy &&
    winRow &&
    winRow.distance_m !== null &&
    winRow.distance_m !== undefined
      ? ` (~${fmtDistance(winRow.distance_m, store.hass, winRow.distance_ft)})`
      : "";
  const showProxyMeta = Boolean(
    (isBleOnly || (caps.has_ble_beacon && cfg.native_ble_tracking)) && live.ble_closest_proxy,
  );
  const areaMetaBase = isBleOnly
    ? effBleCat === "phone"
      ? store.t("status.phone")
      : store.t("status.ble_tag")
    : hasAssignedArea
      ? store.t("status.stationary")
      : store.t("status.roaming");
  const areaMeta = showProxyMeta
    ? `${areaMetaBase} • ${live.ble_closest_proxy}${distSuffix}`
    : areaMetaBase;
  const rawSw = String(live.device_sw_version || esp?.device?.sw_version || "").replace(
    /^v/i,
    "",
  );
  const fwValue = rawSw ? `v${rawSw}` : store.t("common.unknown");
  const allUpdateEntities = (esp?.sections || []).flatMap((s) =>
    (s.items || []).filter((it) => it.domain === "update"),
  );
  const fwEntityId = String(
    live.fw_update_entity || allUpdateEntities[0]?.entity_id || "",
  ).trim();
  const fwEntityItem = fwEntityId
    ? allUpdateEntities.find((it) => it.entity_id === fwEntityId)
    : allUpdateEntities[0];
  const fwEntityState = String(
    fwEntityItem?.state ?? (fwEntityId ? store.hass?.states?.[fwEntityId]?.state : "") ?? "",
  ).trim();
  const hasAvailableUpdateEntity = Boolean(
    fwEntityId && fwEntityState && fwEntityState !== "unavailable" && fwEntityState !== "unknown",
  );
  const fwMeta = live.fw_update_available
    ? store.t("status.update")
    : hasAvailableUpdateEntity
      ? store.t("status.up_to_date")
      : store.t("common.unknown");
  let statusChipClass = "chip";
  let statusDotClass = "status-dot";
  let statusLabel = store.t("common.unknown");
  if (isBleOnly) {
    if (curDevEntry?.status_code === "online" || Boolean(curDevEntry?.is_online) || Boolean(winRow)) {
      statusChipClass = "chip chip-success";
      statusDotClass = "status-dot online";
      statusLabel = store.t("status.online");
    } else if (curDevEntry?.status_code === "scanning") {
      statusLabel = store.t("status.scanning");
    } else if (curDevEntry?.status_code === "away") {
      statusLabel = store.t("status.away");
    } else if (curDevEntry?.status_label) {
      statusLabel = curDevEntry.status_label;
    }
  } else if (curDevEntry?.is_online && live.fw_update_available) {
    statusChipClass = "chip chip-warning";
    statusDotClass = "status-dot update";
    statusLabel = store.t("status.update");
  } else if (curDevEntry?.is_online) {
    statusChipClass = "chip chip-success";
    statusDotClass = "status-dot online";
    statusLabel = store.t("status.online");
  } else if (curDevEntry?.is_online === false) {
    statusLabel = live.is_ble_sleep_expected
      ? store.t("status.sleeping")
      : store.t("status.offline");
  }
  // Canonical `data?.quick_actions` + deduplicated ESPHome action buttons (`C-19`, `R-8`)
  const sectionActionItems = store.entity
    .getSectionItems("actions")
    .concat(store.entity.getSectionItems("overview"));
  const sectionButtons = sectionActionItems.filter((it) => it.domain === "button");
  const synthesizedButtons = (data?.quick_actions || []).map((qa) => {
    const cmd = qa.device_command || qa.key;
    return {
      entity_id: `cmd:${qa.key}`,
      domain: "button",
      name: localizedQuickActionLabel(store, cmd, qa.label),
      state: qa.state,
      key: qa.key,
      device_command: qa.device_command,
      device_class:
        qa.device_class ||
        (cmd === "find_my" ? "identify" : cmd === "restart" ? "restart" : undefined),
    };
  });
  const synthesizedCmdSet = new Set(
    synthesizedButtons.map((sb) => canonicalActionCommand(sb)).filter(Boolean),
  );
  const extraSectionButtons = sectionButtons.filter((b) => {
    const cmd = canonicalActionCommand(b);
    return !cmd || !synthesizedCmdSet.has(cmd);
  });
  const allQuickActionButtons = synthesizedButtons.concat(extraSectionButtons);
  const harmlessQuickButtons = allQuickActionButtons.filter(
    (b) => canonicalActionCommand(b) !== "restart",
  );
  const restartButton =
    allQuickActionButtons.find((b) => canonicalActionCommand(b) === "restart") || null;
  const otherQuickItemsRaw = sectionActionItems.filter((it) => it.domain !== "button");
  if (
    data?.speaker_volume &&
    !otherQuickItemsRaw.some((it) => it.entity_id === data.speaker_volume?.entity_id)
  ) {
    otherQuickItemsRaw.push(data.speaker_volume);
  }
  const otherQuickItems = isOffline
    ? otherQuickItemsRaw.map((it) => ({ ...it, state: "unavailable" }))
    : otherQuickItemsRaw;
  const hasQuickControls =
    harmlessQuickButtons.length > 0 || otherQuickItems.length > 0 || Boolean(restartButton);
  const showQuickActionsCard = !isBleOnly;
  const otherSensorItems = store.entity.getSectionItems("other");
  const groups = data?.device_groups || [];
  const rawGroupId = String(cfg.device_group || "custom").trim() || "custom";
  const curGroupId =
    rawGroupId === "custom" || groups.some((g) => g.id === rawGroupId) ? rawGroupId : "custom";
  const remoteGroups = data?.system_config?.remote_groups || [];
  const curRemoteMode =
    String(cfg.device_remote_group || curDevEntry?.device_remote_group || "area_auto").trim() ||
    "area_auto";
  let remoteSummary = store.t("dev_overview.remote_follow_area");
  if (curRemoteMode === "all") {
    remoteSummary = store.t("dev_overview.remote_all_system");
  } else if (curRemoteMode.startsWith("group:")) {
    const gid = curRemoteMode.slice(6);
    remoteSummary = remoteGroups.find((g) => g.id === gid)?.name || gid;
  }
  const alarmsSummaryPref = store.entity.getPref("alarms_summary");
  const alarmSlots = parseAlarmsSummary(
    alarmsSummaryPref?.value ?? cfg.alarms_summary ?? DEFAULT_ALARMS_SUMMARY,
  );
  const updateAlarmSlot = (
    idx,
    patch,
    focusId,
  ) => {
    const next = [
      { ...alarmSlots[0] },
      { ...alarmSlots[1] },
      { ...alarmSlots[2] },
    ];
    const merged = { ...next[idx], ...patch };
    if (!/^\d{2}:\d{2}$/.test(merged.time)) {
      return;
    }
    next[idx] = merged;
    store.entity.stageDeviceSetting("alarms_summary", serializeAlarmsSummary(next), focusId);
  };
  // Live 1 Hz client countdown / stopwatch elapsed from `timer_ends_at` / `stopwatch_started_at` (`F-01`, `B-17`)
  const nowMs = Number.isFinite(store.liveClockNowMs) ? store.liveClockNowMs : Date.now();
  const timerEndsMs = live.timer_ends_at ? Date.parse(live.timer_ends_at) : Number.NaN;
  const liveTimerRemainingSec =
    live.timer_running && Number.isFinite(timerEndsMs)
      ? Math.max(0, Math.ceil((timerEndsMs - nowMs) / 1000))
      : Math.max(0, Math.round(Number(live.timer_remaining_sec || 0)));
  const stopwatchStartedMs = live.stopwatch_started_at
    ? Date.parse(live.stopwatch_started_at)
    : Number.NaN;
  const liveStopwatchElapsedSec =
    live.stopwatch_running && Number.isFinite(stopwatchStartedMs)
      ? Math.max(0, Math.floor((nowMs - stopwatchStartedMs) / 1000))
      : Math.max(0, Math.round(Number(live.stopwatch_elapsed_sec || 0)));
  const timerActive = Boolean(live.timer_running || live.timer_paused);
  const stopwatchActive = Boolean(live.stopwatch_running || live.stopwatch_paused);
  const alarmRinging = Boolean(live.alarm_ringing);
  const enabledAlarmSlots = alarmSlots
    .filter((s) => s.enabled)
    .sort((a, b) => a.time.localeCompare(b.time));
  const is24h = isDeviceTime24h(store);
  const alarmsSummaryLabel =
    enabledAlarmSlots.length > 0
      ? store.t("dev_overview.alarms_enabled_summary", {
          count: fmtNumber(enabledAlarmSlots.length, store.hass, 0),
          nextTime: formatClockHhMm(enabledAlarmSlots[0].time, is24h),
        })
      : store.t("common.all_off");
  const alarmsSummaryChipClass = enabledAlarmSlots.length > 0 ? "chip chip-primary" : "chip";
  const alarmRecurrenceChoices = [
    { value: 0, label: store.t("dev_overview.alarm_rec_daily") },
    { value: 1, label: store.t("dev_overview.alarm_rec_weekdays") },
    { value: 2, label: store.t("dev_overview.alarm_rec_weekends") },
    { value: 3, label: store.t("dev_overview.alarm_rec_once") },
  ];
  const powerTileBody = hasBattery
    ? html`<div class="status-tile-head">
          ${renderSvgIcon(DEV_ICON_BATTERY)}
          <span>${store.t("dev_overview.tile_battery")}</span>
        </div>
        <strong class="status-tile-value">
          ${hasBatteryReading
            ? fmtPercent(curDevEntry?.battery_level, store.hass)
            : store.t("common.unknown")}
        </strong>
        <span class="status-tile-meta">${batMeta}</span>
        ${hasBatteryReading
          ? html`<div class="signal-track" aria-hidden="true">
              <div
                class="signal-fill${batPct <= 20 && !curDevEntry?.is_charging ? " low" : ""}"
                style=${batSignalStyle}
              ></div>
            </div>`
          : nothing}`
    : html`<div class="status-tile-head">
          ${renderSvgIcon(DEV_ICON_PLUG)}
          <span>${store.t("dev_overview.tile_power")}</span>
        </div>
        <strong class="status-tile-value">${store.t("status.plugged_in")}</strong>
        <span class="status-tile-meta">
          ${caps.has_power
            ? store.t("status.sleep_wake_active")
            : store.t("status.always_on")}
        </span>`;
  const hasOpenInHa = Boolean(links.esphome_device_id || links.latter_device_id);
  const onTriggerRestart = () => {
    if (!restartButton) return;
    const toastMsg = store.t("sync.restarting_device");
    if (restartButton.device_command) {
      void store.entity.runDeviceAction(restartButton.device_command, toastMsg);
    } else {
      void store.entity.espAction(restartButton.entity_id, "press", undefined, toastMsg);
    }
  };
  return html`<section id="view-dashboard" class="stack">
    ${renderDeviceOfflineBanner(store)}

    ${deviceIssues.length
      ? html`<div
          role="region"
          aria-label=${store.t("status.needs_attention")}
          class="alert ${hasErrorIssue ? "alert-error" : "alert-warning"}"
        >
          <div class="alert-body">
            <strong>${store.t("status.needs_attention")}</strong>
            <ul class="alert-list">
              ${deviceIssues.map((iss) => html`<li>${issueMessage(iss, store.hass)}</li>`)}
            </ul>
          </div>
          <button
            type="button"
            @click=${() => store.openHaPage("/config/repairs")}
            class="btn btn-secondary btn-compact"
          >
            ${store.t("action.open_repairs")}
          </button>
        </div>`
      : nothing}

    ${showTxOffBanner
      ? html`<div
          id="ble-transmitter-off-banner"
          role="region"
          aria-label=${store.t("offline.ble_tx_off_title", { state: txStateText })}
          class="alert alert-warning"
        >
          <div class="alert-body">
            <strong>${store.t("offline.ble_tx_off_title", { state: txStateText })}</strong>
            <span>${store.t("offline.ble_tx_off_body")}</span>
          </div>
        </div>`
      : nothing}

    <div class="columns">
      <div class="column">
        ${renderCard({
          id: "card-device-status",
          heading: html`<h3 class="card-title">${store.t("card.status")}</h3>`,
          headerActions: html`<span id="st-status-chip" class=${statusChipClass}>
            <span class=${statusDotClass} aria-hidden="true"></span>${statusLabel}
          </span>`,
          contentClass: "stack",
          body: html`<div class="status-tiles">
            <button
              type="button"
              @click=${() => store.switchView("presence")}
              class="status-tile"
            >
              <div class="status-tile-head">
                ${renderSvgIcon(DEV_ICON_AREA)}
                <span id="st-area-label">
                  ${hasAssignedArea
                    ? store.t("dev_overview.tile_area")
                    : store.t("dev_overview.tile_current_area")}
                </span>
              </div>
              <strong class="status-tile-value">${areaText}</strong>
              <span class="status-tile-meta">${areaMeta}</span>
            </button>

            ${isBleOnly
              ? html`<button
                  type="button"
                  @click=${() => store.switchView("presence")}
                  class="status-tile"
                >
                  <div class="status-tile-head">
                    ${renderSvgIcon(DEV_ICON_RADAR)}
                    <span>${store.t("dev_overview.tile_closest_proxy")}</span>
                  </div>
                  <strong class="status-tile-value">
                    ${live.ble_closest_proxy || store.t("common.unknown")}
                  </strong>
                  <span class="status-tile-meta">
                    ${winRow && winRow.distance_m !== null && winRow.distance_m !== undefined
                      ? `~${fmtDistance(winRow.distance_m, store.hass, winRow.distance_ft)}`
                      : store.t("dev_overview.ble_presence_meta")}
                  </span>
                </button>`
              : store.deviceHasView("power")
                ? html`<button
                    type="button"
                    @click=${() => store.switchView("power")}
                    class="status-tile"
                  >
                    ${powerTileBody}
                  </button>`
                : html`<div class="status-tile">${powerTileBody}</div>`}

            <button
              type="button"
              @click=${() =>
                isBleOnly
                  ? store.switchView("presence")
                  : store.openDeviceSection("tools", "card-device-diagnostics")}
              class="status-tile"
            >
              <div class="status-tile-head">
                ${renderSvgIcon(isBleOnly ? DEV_ICON_BLUETOOTH : DEV_ICON_WIFI)}
                <span id="st-wifi-label">
                  ${isBleOnly
                    ? store.t("dev_overview.tile_ble_signal")
                    : store.t("dev_overview.tile_wifi_signal")}
                </span>
              </div>
              <strong class="status-tile-value">${rssiText}</strong>
              <span class="status-tile-meta">${rssiQualityLabel(store, rssiVal)}</span>
              ${hasRssi
                ? html`<div class="signal-track" aria-hidden="true">
                    <div
                      class="signal-fill${rssiVal !== null && rssiVal < -80 ? " low" : ""}"
                      style=${wifiSignalStyle}
                    ></div>
                  </div>`
                : nothing}
            </button>

            ${isBleOnly
              ? html`<button
                  type="button"
                  @click=${() => store.openDeviceSection("presence", "card-ble-identity")}
                  class="status-tile"
                >
                  <div class="status-tile-head">
                    ${renderSvgIcon(DEV_ICON_TAG)}
                    <span>${store.t("dev_overview.tile_ble_target")}</span>
                  </div>
                  <strong class="status-tile-value">
                    <code>${cfg.ble_target_address || store.t("common.unknown")}</code>
                  </strong>
                  <span class="status-tile-meta">
                    ${store.t("dev_overview.ble_address_meta")}
                  </span>
                </button>`
              : html`<button
                  type="button"
                  @click=${() => store.openDeviceSection("tools", "card-device-diagnostics")}
                  class="status-tile"
                >
                  <div class="status-tile-head">
                    ${renderSvgIcon(DEV_ICON_CHIP)}
                    <span>${store.t("dev_overview.tile_firmware")}</span>
                  </div>
                  <strong class="status-tile-value">${fwValue}</strong>
                  <span class="status-tile-meta">${fwMeta}</span>
                </button>`}
          </div>`,
          footerActions:
            isBleOnly && hasOpenInHa
              ? html`<button
                  type="button"
                  id="btn-open-in-ha"
                  @click=${() => store.openDeviceInHa(true)}
                  class="btn btn-text"
                >
                  ${store.t("action.open_in_ha")}
                </button>`
              : nothing,
        })}

        ${showQuickActionsCard
          ? renderCard({
              id: "card-device-quick-actions",
              title: store.t("card.quick_actions"),
              contentClass: "settings-list",
              body: hasQuickControls
                ? html`${renderQuickActionGrid(store, harmlessQuickButtons, isOffline)}
                    ${otherQuickItems.map((it) => renderDeviceEntityRow(store, it))}
                    ${restartButton
                      ? renderSettingsRow({
                          id: "row-restart-device",
                          label: store.t("dev_overview.restart_device"),
                          description: store.t("dev_overview.restart_device_desc"),
                          control: html`<button
                            type="button"
                            id="btn-restart-device"
                            data-entity-id=${restartButton.entity_id}
                            ?disabled=${isOffline ||
                            String(restartButton.state ?? "") === "unavailable"}
                            @click=${onTriggerRestart}
                            class="btn btn-danger btn-compact"
                          >
                            ${store.t("dev_overview.restart_btn")}
                          </button>`,
                        })
                      : nothing}`
                : html`<p class="empty-state">${store.t("dev_overview.empty_quick_actions")}</p>`,
              footerActions: hasOpenInHa
                ? html`<button
                    type="button"
                    id="btn-open-in-ha"
                    @click=${() => store.openDeviceInHa()}
                    class="btn btn-text"
                  >
                    ${store.t("action.open_in_ha")}
                  </button>`
                : nothing,
            })
          : nothing}
      </div>

      <div class="column">
        ${renderCard({
          id: "card-device-assignments",
          title: store.t("card.assignments"),
          contentClass: "settings-list",
          body: html`${!isBleOnly
              ? renderSettingsRow({
                  label: store.t("dev_overview.device_group_label"),
                  forId: "cfg-device_group",
                  description:
                    curGroupId === "custom"
                      ? store.t("dev_overview.device_group_custom_desc")
                      : store.t("dev_overview.device_group_preset_desc"),
                  control: html`<select
                      id="cfg-device_group"
                      .value=${curGroupId}
                      @change=${(ev) =>
                        store.entity.stageDeviceSetting(
                          "device_group",
                          (ev.currentTarget).value,
                          "cfg-device_group",
                        )}
                    >
                      <option value="custom" ?selected=${curGroupId === "custom"}>
                        ${store.t("common.custom")}
                      </option>
                      ${groups.map(
                        (g) =>
                          html`<option value=${g.id} ?selected=${g.id === curGroupId}>
                            ${g.name}
                          </option>`,
                      )}
                    </select>
                    ${curGroupId === "custom"
                      ? html`<button
                          type="button"
                          id="btn-save-custom-group"
                          @click=${() => store.groups.openSaveGroupModal()}
                          class="btn btn-secondary btn-compact"
                        >
                          ${store.t("action.save_custom_group")}
                        </button>`
                      : nothing}
                    <button
                      type="button"
                      id="btn-manage-groups"
                      @click=${() => store.openManageGroups(curGroupId)}
                      class="btn btn-text btn-compact"
                    >
                      ${store.t("action.manage_groups")}
                    </button>`,
                })
              : renderSettingsRow({
                  label: store.t("dev_overview.device_category_label"),
                  forId: "cfg-ble_category",
                  description: store.t("dev_overview.device_category_desc"),
                  control: html`<select
                    id="cfg-ble_category"
                    .value=${curBleCat}
                    @change=${(ev) =>
                      store.entity.stageDeviceSetting(
                        "ble_category",
                        (ev.currentTarget).value,
                        "cfg-ble_category",
                      )}
                  >
                    <option value="auto" ?selected=${curBleCat === "auto"}>
                      ${store.t("dev_overview.auto_category_option", {
                        category:
                          effBleCat === "phone"
                            ? store.t("status.phone")
                            : store.t("status.ble_tag"),
                      })}
                    </option>
                    <option value="phone" ?selected=${curBleCat === "phone"}>
                      ${store.t("status.phone")}
                    </option>
                    <option value="ble_tag" ?selected=${curBleCat === "ble_tag"}>
                      ${store.t("status.ble_tag")}
                    </option>
                  </select>`,
                })}
            ${renderSelectRow({
              id: "cfg-assigned_person",
              label: store.t("dev_overview.assigned_person_label"),
              description: store.t("dev_overview.assigned_person_desc"),
              value: cfg.assigned_person,
              choices: data?.catalog?.persons,
              emptyOptionLabel: store.t("dev_overview.unassigned_option"),
              onChange: (val) =>
                store.entity.stageDeviceSetting(
                  "assigned_person",
                  val,
                  "cfg-assigned_person",
                ),
            })}
            ${!isBleOnly && caps.has_display
              ? renderSettingsRow({
                  label: store.t("dev_overview.remote_group_label"),
                  description: store.t("dev_overview.remote_group_desc"),
                  control: html`<span class="chip">${remoteSummary}</span>
                    <button
                      type="button"
                      id="btn-configure-remote-group"
                      @click=${() => store.entity.openAppConfigModal("remote")}
                      class="btn btn-text btn-compact"
                    >
                      ${store.t("action.configure")}
                    </button>`,
                })
              : nothing}`,
        })}

        ${!isBleOnly && caps.has_display
          ? renderCard({
              id: "card-device-timers-alarms",
              title: store.t("card.timers_alarms"),
              body: html`${alarmRinging
                  ? html`<div id="overview-ringing-alert" role="alert" class="alert alert-warning">
                      <span>${store.t("dev_overview.ringing_alert_text")}</span>
                      <button
                        type="button"
                        id="btn-dismiss-ringing"
                        @click=${() =>
                          void store.entity.runDeviceAction(
                            "dismiss_ringing",
                            store.t("dev_overview.dismissed_ringing_toast"),
                          )}
                        class="btn btn-secondary btn-compact"
                      >
                        ${store.t("action.dismiss")}
                      </button>
                    </div>`
                  : nothing}
                <div class="settings-list">
                  ${renderSettingsRow({
                    id: "overview-active-timer",
                    label: store.t("dev_overview.active_timer_label"),
                    description: timerActive
                      ? undefined
                      : store.t("dev_overview.no_active_timer"),
                    control: timerActive
                      ? html`<span class="chip ${live.timer_running ? "chip-primary" : ""}">
                            ${live.timer_running
                              ? store.t("dev_overview.running")
                              : store.t("dev_overview.paused")}
                          </span>
                          <strong class="kv-value">
                            ${formatClockDuration(liveTimerRemainingSec)}
                          </strong>
                          <button
                            type="button"
                            id="btn-cancel-timer"
                            ?disabled=${isOffline}
                            @click=${() =>
                              void store.entity.runDeviceAction(
                                "cancel_timer",
                                store.t("dev_overview.cancelled_timer_toast"),
                              )}
                            class="btn btn-secondary btn-compact"
                          >
                            ${store.t("dev_overview.cancel_timer")}
                          </button>`
                      : html`<span class="kv-value">${store.t("common.unknown")}</span>`,
                  })}
                  ${renderSettingsRow({
                    id: "overview-stopwatch",
                    label: store.t("dev_overview.stopwatch_label"),
                    description: stopwatchActive
                      ? undefined
                      : store.t("dev_overview.not_running"),
                    control: stopwatchActive
                      ? html`<span class="chip ${live.stopwatch_running ? "chip-primary" : ""}">
                            ${live.stopwatch_running
                              ? store.t("dev_overview.running")
                              : store.t("dev_overview.paused")}
                          </span>
                          <strong class="kv-value">
                            ${formatClockDuration(liveStopwatchElapsedSec)}
                          </strong>
                          <button
                            type="button"
                            id="btn-reset-stopwatch"
                            ?disabled=${isOffline}
                            @click=${() =>
                              void store.entity.runDeviceAction(
                                "reset_stopwatch",
                                store.t("dev_overview.reset_stopwatch_toast"),
                              )}
                            class="btn btn-secondary btn-compact"
                          >
                            ${store.t("dev_overview.reset_stopwatch")}
                          </button>`
                      : html`<span class="kv-value">${store.t("common.unknown")}</span>`,
                  })}
                  <details
                    id="overview-alarms-drawer"
                    class="sub-collapsible summary-row"
                    ?open=${store.overviewAlarmsOpen}
                    @toggle=${(ev) => {
                      store.overviewAlarmsOpen = (ev.currentTarget).open;
                    }}
                  >
                    <summary>
                      <span class="row-label">${store.t("dev_overview.alarms_label")}</span>
                      <span class="summary-row-end">
                        <span id="overview-alarms-chip" class=${alarmsSummaryChipClass}>
                          ${alarmsSummaryLabel}
                        </span>
                        <span class="summary-chevron" aria-hidden="true">▾</span>
                      </span>
                    </summary>
                    <div id="overview-alarms" class="card-content stack">
                      <p class="row-description">${store.t("dev_overview.alarms_desc")}</p>
                      <div
                        class="stack"
                        role="group"
                        aria-label=${store.t("dev_overview.alarms_group_aria")}
                      >
                        ${([0, 1, 2]).map((idx) => {
                          const slot = alarmSlots[idx];
                          const timeId = `cfg-alarm_${idx + 1}_time`;
                          const recId = `cfg-alarm_${idx + 1}_recurrence`;
                          const enId = `cfg-alarm_${idx + 1}_enabled`;
                          return html`<div class="list-row">
                            <div class="list-row-main">
                              <div class="stacked-field">
                                <label for=${timeId}>
                                  ${store.t("dev_overview.alarm_time_label", { index: idx + 1 })}
                                </label>
                                <input
                                  type="time"
                                  id=${timeId}
                                  step="60"
                                  .value=${slot.time}
                                  @change=${(ev) => {
                                    const val = (ev.currentTarget).value;
                                    if (val) {
                                      updateAlarmSlot(idx, { time: val.slice(0, 5) }, timeId);
                                    }
                                  }}
                                />
                              </div>
                              <div class="stacked-field">
                                <label for=${recId}>
                                  ${store.t("dev_overview.alarm_schedule_label", {
                                    index: idx + 1,
                                  })}
                                </label>
                                <select
                                  id=${recId}
                                  .value=${String(slot.recurrence)}
                                  @change=${(ev) =>
                                    updateAlarmSlot(
                                      idx,
                                      {
                                        recurrence: Number(
                                          (ev.currentTarget).value,
                                        ),
                                      },
                                      recId,
                                    )}
                                >
                                  ${alarmRecurrenceChoices.map(
                                    (opt) =>
                                      html`<option
                                        value=${String(opt.value)}
                                        ?selected=${opt.value === slot.recurrence}
                                      >
                                        ${opt.label}
                                      </option>`,
                                  )}
                                </select>
                              </div>
                            </div>
                            <label for=${enId} class="inline-switch">
                              <span>${store.t("common.enabled")}</span>
                              <input
                                type="checkbox"
                                id=${enId}
                                .checked=${slot.enabled}
                                @change=${(ev) =>
                                  updateAlarmSlot(
                                    idx,
                                    { enabled: (ev.currentTarget).checked },
                                    enId,
                                  )}
                                role="switch"
                                class="switch"
                              />
                            </label>
                          </div>`;
                        })}
                      </div>
                    </div>
                  </details>
                </div>`,
            })
          : nothing}

        ${otherSensorItems.length
          ? renderCard({
              title: store.t("card.sensors_controls"),
              contentClass: "settings-list",
              body: otherSensorItems.map((it) => renderDeviceEntityRow(store, it)),
            })
          : nothing}
      </div>
    </div>
  </section>`;
}
__latterExp(__exports, { defaultLocaleTimeFormat: () => defaultLocaleTimeFormat, renderDeviceOfflineBanner: () => renderDeviceOfflineBanner, renderDeviceEntityRow: () => renderDeviceEntityRow, renderDeviceOverviewView: () => renderDeviceOverviewView });
//# sourceURL=latter-studio/src/views/device-overview-view.ts
});
__latterDef("src/views/device-audio-view.ts", (__exports, __req) => {
const { renderCard, renderPrefControlRow, renderRangeRow, renderSelectRow, renderSwitchRow } = __req("src/components/controls.ts");
const { html, nothing } = __req("src/lib/lit.ts");
const { renderDeviceEntityRow, renderDeviceOfflineBanner } = __req("src/views/device-overview-view.ts");
/**
 * Device Audio View (`audio_voice`, `D-008`, `D-031`, `D-036`, `D-066`, `Q7`, `Q8`):
 * - Column 1: Voice assistant & wake word (hides `Voice Follows Me` & delay when `native_ble_tracking` is Off).
 * - Column 2: Sound & playback (keeps `area_handoff` visible in both Static and BLE modes per `D-008`,
 *   using unified `store.tPrefLabel("area_handoff")` matching System Groups).
 */
function renderDeviceAudioView(store) {
  const data = store.state;
  const cfg = data?.config || {};
  const caps = data?.capabilities || {};
  const live = data?.live || {};
  const wwModePref = store.entity.getPref("wake_word_mode");
  const wwDisabled = wwModePref ? String(wwModePref.value) === "Disabled" : false;
  const wakeScreenPref = store.entity.getPref("wake_screen_on_assist");
  const voiceItems = store.entity.getSectionItems("voice");
  const voicePrimary = voiceItems.filter((it) => {
    if (it.domain === "assist_satellite") return false;
    const k = it.key || it.pref_key || (it.entity_id ? it.entity_id.split(".").pop() || "" : "");
    if (k === "va_visual_profile" || k.endsWith("_visual_profile")) return false;
    if (k === "wake_word_mode" || k.endsWith("_wake_word_mode")) return false;
    if (k === "wake_screen_on_assist" || k.endsWith("_wake_screen_on_assist")) return false;
    if (k.startsWith("ww_sens_") || k.includes("_ww_sens_")) return false;
    if (
      wwDisabled &&
      (it.key === "wake_word" ||
        it.key === "wake_word_n" ||
        k.endsWith("_wake_word") ||
        k.endsWith("_wake_word_n"))
    ) {
      return false;
    }
    return true;
  });
  const sensitivityPrefs = wwDisabled
    ? []
    : store.entity.getPrefs([
        "ww_sens_okay_nabu",
        "ww_sens_hey_luna",
        "ww_sens_hey_jarvis",
        "ww_sens_hey_mycroft",
        "ww_sens_alexa",
      ]);
  const soundPrefs = store.entity.getPrefs([
    "alert_volume",
    "volume_step_size",
    "game_sound_effects",
  ]);
  const soundItems = store.entity.getSectionItems("sound").filter((it) => !it.pref_key);
  // Hide `Voice Follows Me` & dwell delay when `native_ble_tracking` is Off (Static mode, `Q8` / `E-13`)
  const showVoiceFollowsMe =
    Boolean(cfg.native_ble_tracking) && caps.is_roaming_device !== false;
  const dwellSeconds = Number(cfg.area_follow_dwell_s ?? 10);
  const autoMaEntity = cfg.device_slug ? `media_player.${cfg.device_slug}` : "";
  const savedMa = String(cfg.ma_player_entity || "").trim();
  const maUnmatched = live.ma_link_matched === false;
  const hasCustomMaOverride = Boolean(savedMa && savedMa !== autoMaEntity);
  const showMaOverrideRow = maUnmatched || hasCustomMaOverride;
  const maTargetName = autoMaEntity || store.t("dev_audio.ma_player_fallback_target");
  const maDescription = maUnmatched
    ? store.t("dev_audio.ma_player_unmatched_desc", { entity: maTargetName })
    : store.t("dev_audio.ma_player_manual_desc", { entity: maTargetName });
  const speakerChoices = data?.catalog?.ma_speakers;
  return html`<section id="view-audio_voice">
    ${renderDeviceOfflineBanner(store)}

    <div class="columns">
      <div class="column">
        ${renderCard({
          heading: html`<h3 class="card-title">${store.t("dev_audio.card_voice_wake")}</h3>`,
          contentClass: "settings-list",
          body: html`${wwModePref ? renderPrefControlRow(store, wwModePref) : nothing}
            ${voicePrimary.map((it) => renderDeviceEntityRow(store, it))}
            ${wakeScreenPref ? renderPrefControlRow(store, wakeScreenPref) : nothing}
            ${showVoiceFollowsMe
              ? html`${renderSwitchRow({
                    rowId: "row-sync-device-area",
                    id: "cfg-sync_device_area",
                    label: store.tPrefLabel("sync_device_area"),
                    description: store.t("dev_audio.vfm_desc"),
                    checked: Boolean(cfg.sync_device_area),
                    onChange: (checked) =>
                      store.entity.stageDeviceSetting(
                        "sync_device_area",
                        checked,
                        "cfg-sync_device_area",
                      ),
                  })}
                  ${renderRangeRow({
                    rowId: "row-area-follow-dwell",
                    id: "cfg-area_follow_dwell_s",
                    label: store.t("dev_audio.vfm_delay_label"),
                    ariaLabel: store.t("dev_audio.vfm_delay_label"),
                    description: store.t("dev_audio.vfm_delay_desc"),
                    value: dwellSeconds,
                    min: 3,
                    max: 60,
                    step: 1,
                    unit: "s",
                    hass: store.hass,
                    onCommit: (val) =>
                      store.entity.stageDeviceSetting(
                        "area_follow_dwell_s",
                        val || 10,
                        "cfg-area_follow_dwell_s",
                      ),
                  })}`
              : nothing}
            ${sensitivityPrefs.length
              ? html`<details class="sub-collapsible">
                  <summary>${store.t("dev_audio.ww_sensitivity_summary")}</summary>
                  <div class="card-content settings-list">
                    ${sensitivityPrefs.map((p) => renderPrefControlRow(store, p))}
                  </div>
                </details>`
              : nothing}`,
        })}
      </div>

      <div class="column">
        ${renderCard({
          heading: html`<h3 class="card-title">
            ${store.t("dev_audio.card_sound_playback")}
          </h3>`,
          contentClass: "settings-list",
          body: html`${renderSelectRow({
              id: "cfg-default_speaker",
              label: store.t("dev_audio.default_speaker_label"),
              description: store.t("dev_audio.default_speaker_desc"),
              value: cfg.default_speaker,
              choices: speakerChoices,
              emptyOptionLabel: store.t("dev_audio.default_speaker_auto"),
              onChange: (val) =>
                store.entity.stageDeviceSetting("default_speaker", val, "cfg-default_speaker"),
            })}
            ${showMaOverrideRow
              ? renderSelectRow({
                  rowId: "row-ma-player-entity",
                  id: "cfg-ma_player_entity",
                  label: store.t("dev_audio.ma_player_label"),
                  description: maDescription,
                  descId: "desc-ma-player-entity",
                  value: savedMa,
                  choices: data?.catalog?.ma_players,
                  emptyOptionLabel: store.t("dev_audio.ma_player_auto"),
                  onChange: (val) =>
                    store.entity.stageDeviceSetting(
                      "ma_player_entity",
                      val,
                      "cfg-ma_player_entity",
                    ),
                })
              : nothing}
            ${renderSwitchRow({
              id: "cfg-area_handoff",
              label: store.tPrefLabel("area_handoff"),
              description: store.t("dev_audio.area_handoff_desc"),
              checked: Boolean(cfg.area_handoff),
              onChange: (checked) =>
                store.entity.stageDeviceSetting("area_handoff", checked, "cfg-area_handoff"),
            })}
            ${soundPrefs.map((p) => renderPrefControlRow(store, p))}
            ${soundItems.map((it) => renderDeviceEntityRow(store, it))}`,
        })}
      </div>
    </div>
  </section>`;
}
__latterExp(__exports, { renderDeviceAudioView: () => renderDeviceAudioView });
//# sourceURL=latter-studio/src/views/device-audio-view.ts
});
__latterDef("src/components/wallpaper-gallery.ts", (__exports, __req) => {
const { html, nothing, repeat } = __req("src/lib/lit.ts");
const { fmtNumber } = __req("src/utils/format.ts");
const { renderTrashIconButton } = __req("src/components/controls.ts");
/**
 * Wallpaper Gallery & Multipart XHR Upload Component (Device & System scopes, `D-25`, `Q5`, `Q9a`).
 */
function renderStarIcon(filled) {
  if (filled) {
    return html`<svg viewBox="0 0 24 24" aria-hidden="true">
      <path
        d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.62L12 2 9.19 8.62 2 9.24l5.45 4.73L5.82 21 12 17.27Z"
      />
    </svg>`;
  }
  return html`<svg viewBox="0 0 24 24" aria-hidden="true">
    <path
      d="M12 15.39l-3.76 2.27.99-4.28-3.32-2.88 4.38-.38L12 6.09l1.71 4.03 4.38.38-3.32 2.88.99 4.28L12 15.39M22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.45 4.73L5.82 21 12 17.27 18.18 21l-1.64-7.03L22 9.24Z"
    />
  </svg>`;
}
function renderWallpaperGalleryItems(
  store,
  scope,
  items,
  displayShape,
) {
  if (!items.length) {
    return html`<p class="empty-state">${store.t("wp_gallery.empty")}</p>`;
  }
  const shapeClass = displayShape === "circle" ? "circle" : "square";
  return html`${repeat(
    items,
    (wp, idx) => `${wp.id}::${idx}`,
    (wp) => {
      const label = wp.name || wp.id;
      const isActive = Boolean(wp.active);
      const isFav = Boolean(wp.favorite);
      const canDelete = Boolean(wp.deletable ?? wp.kind === "upload");
      const thumbSrc = wp.thumb_url || wp.preview_url || "";
      const activeCls = isActive ? "wp-card active" : "wp-card";
      const onUse = () => {
        void store.entity.selectWallpaperSource(wp.id);
      };
      const onFav = () => {
        void store.entity.toggleWallpaperFav(wp.id);
      };
      const onDel = () => {
        store.entity.requestDeleteWallpaper(wp.id, label);
      };
      const clickableThumb = scope === "device" && !isActive;
      const thumbImg = thumbSrc
        ? html`<img
            src=${thumbSrc}
            alt=${clickableThumb ? "" : label}
            loading="lazy"
            class="wp-thumb ${shapeClass}"
          />`
        : html`<div class="wp-thumb ${shapeClass}" aria-hidden="true"></div>`;
      return html`<div class=${activeCls}>
        ${clickableThumb
          ? html`<button
              type="button"
              tabindex="-1"
              aria-hidden="true"
              @click=${onUse}
              class="wp-thumb-btn ${shapeClass}"
            >
              ${thumbImg}
            </button>`
          : thumbImg}
        <div class="wp-title">${label}</div>
        <div class="wp-actions">
          ${scope === "device"
            ? html`${isActive
                  ? html`<span class="chip chip-primary">${store.t("common.active")}</span>`
                  : html`<button
                      type="button"
                      aria-label=${store.t("wp_gallery.use_aria", { name: label })}
                      @click=${onUse}
                      class="btn btn-secondary btn-compact"
                    >
                      ${store.t("action.use")}
                    </button>`}
                <button
                  type="button"
                  aria-label=${isFav
                    ? store.t("wp_gallery.star_remove_aria", { name: label })
                    : store.t("wp_gallery.star_add_aria", { name: label })}
                  aria-pressed=${String(isFav)}
                  title=${isFav
                    ? store.t("wp_gallery.star_active_title")
                    : store.t("wp_gallery.star_inactive_title")}
                  @click=${onFav}
                  class="btn-icon wp-star-btn${isFav ? " starred" : ""}"
                >
                  ${renderStarIcon(isFav)}
                </button>
                ${canDelete
                  ? renderTrashIconButton(
                      store.t("wp_gallery.delete_aria", { name: label }),
                      onDel,
                    )
                  : nothing}`
            : canDelete
              ? html`<span class="chip chip-primary">${store.t("wp_gallery.uploaded")}</span>
                  ${renderTrashIconButton(
                    store.t("wp_gallery.delete_aria", { name: label }),
                    onDel,
                  )}`
              : html`<span class="chip">${store.t("wp_gallery.builtin")}</span>`}
        </div>
      </div>`;
    },
  )}`;
}
function renderWallpaperUploadTrigger(
  store,
  scope,
) {
  const isUploadingThisScope = store.uploadBusy && store.uploadScope === scope;
  const inputId = scope === "device" ? "input-upload-wp" : "input-upload-sys-wp";
  const btnId = scope === "device" ? "btn-upload-wp" : "btn-upload-sys-wp";
  const onFilePick = (ev) => {
    const input = ev.currentTarget;
    const f = input.files && input.files[0] ? input.files[0] : null;
    if (scope === "device") {
      store.selectedDeviceWallpaperFile = f;
    } else {
      store.selectedSystemWallpaperFile = f;
    }
    if (f) {
      void store.entity.uploadWallpaper(scope);
    } else {
      store.host.requestUpdate();
    }
  };
  const onTriggerPick = (ev) => {
    const btn = ev.currentTarget;
    const fileInput = btn?.parentElement?.querySelector("input[type='file']")
            ;
    fileInput?.click();
  };
  return html`<span class="wp-upload-trigger">
    <input
      type="file"
      id=${inputId}
      accept="image/*"
      aria-label=${store.t("wp_gallery.file_aria")}
      @change=${onFilePick}
      class="offscreen"
    />
    <button
      type="button"
      id=${btnId}
      ?disabled=${store.uploadBusy}
      @click=${onTriggerPick}
      class="btn btn-secondary btn-compact"
    >
      ${isUploadingThisScope ? store.t("wp_gallery.uploading") : store.t("wp_gallery.upload_photo")}
    </button>
  </span>`;
}
function renderWallpaperUploadProgress(
  store,
  scope,
) {
  const isUploadingThisScope = store.uploadBusy && store.uploadScope === scope;
  if (!isUploadingThisScope) return nothing;
  const pctStyle = `--upload-pct:${store.uploadPercent}%`;
  return html`<div class="stack">
    <div class="wp-upload-status">
      <span>${store.t("wp_gallery.uploading_photo")}</span>
      <span class="chip chip-primary">${fmtNumber(store.uploadPercent, store.hass, 0)}%</span>
    </div>
    <div
      role="progressbar"
      aria-label=${store.t("wp_gallery.upload_progress_aria")}
      aria-valuenow=${String(store.uploadPercent)}
      aria-valuemin="0"
      aria-valuemax="100"
      class="upload-progress"
    >
      <div class="upload-progress-fill" style=${pctStyle}></div>
    </div>
  </div>`;
}
__latterExp(__exports, { renderWallpaperGalleryItems: () => renderWallpaperGalleryItems, renderWallpaperUploadTrigger: () => renderWallpaperUploadTrigger, renderWallpaperUploadProgress: () => renderWallpaperUploadProgress });
//# sourceURL=latter-studio/src/components/wallpaper-gallery.ts
});
__latterDef("src/views/device-display-view.ts", (__exports, __req) => {
const { renderCard, renderPrefControlRow, renderSettingsRow } = __req("src/components/controls.ts");
const { renderWallpaperGalleryItems, renderWallpaperUploadProgress, renderWallpaperUploadTrigger } = __req("src/components/wallpaper-gallery.ts");
const { WALLPAPER_ROTATION_OPTIONS } = __req("src/constants.ts");
const { html, nothing } = __req("src/lib/lit.ts");
const { defaultThemeHex, entityLabel, fmtNumber, isValidHexColor } = __req("src/utils/format.ts");
const { renderDeviceOfflineBanner } = __req("src/views/device-overview-view.ts");
/**
 * Device Display View (`display`, `D-027`, `D-029`, `D-034`, `D-036`, `D-069`):
 * Hardware & OS surface aesthetics across screens:
 * - Column 1: Screensaver, Voice assistant, & Brightness.
 * - Column 2: Colors (`isValidHexColor` validation) & Wallpapers (with Home weather-background hint).
 */
function rotationLabel(store, minutes, fallback) {
  const key = `dev_display.rot_${minutes}`;
  const translated = store.t(key);
  return translated === key ? fallback : translated;
}
function renderDeviceDisplayView(store) {
  const data = store.state;
  const cfg = data?.config || {};
  const palettes = (data?.system_config?.custom_palettes || []).filter((p) =>
    isValidHexColor(p.hex),
  );
  const curDevEntry =
    (data?.system_devices || []).find((d) => d.subentry_id === store.activeSubentryId) ||
    (data?.system_devices || []).find((d) => d.is_current);
  const isOffline = curDevEntry?.is_online === false;
  // Screensaver card
  const screensaverPrefs = store.entity.getPrefs([
    "docked_screensaver",
    "screensaver_style",
    "docked_idle_timeout",
  ]);
  const activateScreensaverBtn = store.entity
    .getSectionItems("actions")
    .find(
      (it) =>
        it.domain === "button" &&
        (it.device_command === "activate_screensaver" ||
          it.key === "activate_screensaver" ||
          it.entity_id?.endsWith("_activate_screensaver")),
    );
  // Voice assistant card
  const voiceVisualPref = store.entity.getPref("va_visual_profile");
  const bedtimeActive = Boolean(
    store.entity.getPref("bedtime_active")?.value ?? cfg.bedtime_active,
  );
  // Brightness card
  const autoBrtPref = store.entity.getPref("auto_brightness_mode");
  const autoBrtState = String(autoBrtPref?.value ?? "").trim();
  const autoBrtOff = autoBrtState === "Disabled" || autoBrtState === "off";
  const autoBrtTimeSchedule = autoBrtState === "Time Schedule";
  const brightnessPrefs = store.entity.getPrefs([
    "auto_brightness_mode",
    "manual_brightness",
    "day_brightness",
    "night_brightness",
    "day_start_hour",
    "night_start_hour",
  ]);
  const visibleBrightnessPrefs = brightnessPrefs.filter((p) => {
    if (autoBrtPref) {
      if (autoBrtOff && (p.key === "day_brightness" || p.key === "night_brightness")) {
        return false;
      }
      if (!autoBrtOff && p.key === "manual_brightness") {
        return false;
      }
      if (!autoBrtTimeSchedule && (p.key === "day_start_hour" || p.key === "night_start_hour")) {
        return false;
      }
    }
    return true;
  });
  // Column 2: Colors card (`isValidHexColor` validation, `A-07`)
  const colorProfilePref = store.entity.getPref("color_profile");
  const rawThemeHex = defaultThemeHex(store.host);
  const safeThemeHex = isValidHexColor(rawThemeHex)
    ? rawThemeHex.toUpperCase()
    : defaultThemeHex(null);
  const curHex = isValidHexColor(cfg.device_custom_color)
    ? String(cfg.device_custom_color).toUpperCase()
    : safeThemeHex;
  const swatchStyle = `--swatch-color:${curHex}`;
  // Column 2: Wallpapers + cross-tab Home weather-background hint (`D-069`)
  const weatherBgRaw =
    store.entity.getPref("weather_background")?.value ?? cfg.weather_background;
  const weatherBgOn =
    weatherBgRaw !== undefined && weatherBgRaw !== null
      ? typeof weatherBgRaw === "string"
        ? !["", "0", "false", "off", "disabled"].includes(weatherBgRaw.trim().toLowerCase())
        : Boolean(weatherBgRaw)
      : true;
  const homeScreenRaw =
    store.entity.getPref("home_screen_enabled")?.value ?? cfg.home_screen_enabled;
  const homeScreenEnabled = homeScreenRaw !== false;
  const curCycle = Number(cfg.wallpaper_cycle_minutes || 0);
  const wallpapers = data?.wallpapers || [];
  const activeWp = wallpapers.find((wp) => Boolean(wp.active)) || null;
  const hasActiveWallpaper = Boolean(activeWp);
  const isRotating = curCycle > 0;
  const starredCount = wallpapers.filter((wp) => Boolean(wp.favorite)).length;
  const allStarred = wallpapers.length > 0 && starredCount === wallpapers.length;
  let wpStatusBase;
  if (isRotating) {
    if (activeWp) {
      if (starredCount === 1) {
        wpStatusBase = store.t("dev_display.wp_rotating_named_starred_one", {
          name: activeWp.name,
        });
      } else if (starredCount > 1) {
        wpStatusBase = store.t("dev_display.wp_rotating_named_starred_many", {
          name: activeWp.name,
          count: fmtNumber(starredCount, store.hass, 0),
        });
      } else {
        wpStatusBase = store.t("dev_display.wp_rotating_named_all", {
          name: activeWp.name,
          count: fmtNumber(wallpapers.length, store.hass, 0),
        });
      }
    } else if (starredCount === 1) {
      wpStatusBase = store.t("dev_display.wp_rotating_starred_one");
    } else if (starredCount > 1) {
      wpStatusBase = store.t("dev_display.wp_rotating_starred_many", {
        count: fmtNumber(starredCount, store.hass, 0),
      });
    } else {
      wpStatusBase = store.t("dev_display.wp_rotating_all", {
        count: fmtNumber(wallpapers.length, store.hass, 0),
      });
    }
  } else if (hasActiveWallpaper) {
    wpStatusBase = store.t("dev_display.wp_static_named", {
      name: activeWp?.name || store.t("common.active"),
    });
  } else {
    wpStatusBase = store.t("dev_display.wp_off");
  }
  const wpStatusText =
    (isRotating || hasActiveWallpaper) && homeScreenEnabled && weatherBgOn
      ? `${wpStatusBase} ${store.t("dev_display.wp_weather_bg_note")}`
      : wpStatusBase;
  const wpRotationHint =
    starredCount === 0
      ? store.t("dev_display.wp_hint_none")
      : starredCount === 1
        ? store.t("dev_display.wp_hint_one")
        : store.t("dev_display.wp_hint_many", {
            starred: fmtNumber(starredCount, store.hass, 0),
            total: fmtNumber(wallpapers.length, store.hass, 0),
          });
  return html`<section id="view-display">
    ${renderDeviceOfflineBanner(store)}

    <div class="columns">
      <div class="column">
        ${screensaverPrefs.length || activateScreensaverBtn
          ? renderCard({
              heading: html`<h3 class="card-title">${store.t("card.screensaver")}</h3>`,
              contentClass: "settings-list",
              body: html`${screensaverPrefs.map((p) => renderPrefControlRow(store, p))}
                ${activateScreensaverBtn
                  ? renderSettingsRow({
                      label: entityLabel(
                        activateScreensaverBtn.name || activateScreensaverBtn.entity_id,
                      ),
                      description: store.t("dev_display.screensaver_preview_desc"),
                      control: html`<button
                        type="button"
                        ?disabled=${isOffline ||
                        String(activateScreensaverBtn.state ?? "") === "unavailable"}
                        @click=${() => {
                          const btnLabel = entityLabel(
                            activateScreensaverBtn.name || activateScreensaverBtn.entity_id,
                          );
                          const toastMsg = store.t("sync.triggered_action", {
                            label: btnLabel,
                          });
                          if (activateScreensaverBtn.device_command) {
                            void store.entity.runDeviceAction(
                              activateScreensaverBtn.device_command,
                              toastMsg,
                            );
                          } else {
                            void store.entity.espAction(
                              activateScreensaverBtn.entity_id,
                              "press",
                              undefined,
                              toastMsg,
                            );
                          }
                        }}
                        class="btn btn-secondary btn-compact"
                      >
                        ${store.t("dev_display.preview_btn")}
                      </button>`,
                    })
                  : nothing}`,
            })
          : nothing}

        ${voiceVisualPref
          ? renderCard({
              heading: html`<h3 class="card-title">
                ${store.t("dev_display.card_voice_assistant")}
              </h3>`,
              contentClass: "settings-list",
              body: renderPrefControlRow(store, voiceVisualPref),
            })
          : nothing}

        ${visibleBrightnessPrefs.length
          ? renderCard({
              id: "card-brightness",
              heading: html`<h3 class="card-title">${store.t("card.brightness")}</h3>`,
              subtitle: bedtimeActive
                ? store.t("dev_display.bedtime_brightness_override_note")
                : undefined,
              contentClass: "settings-list",
              body: visibleBrightnessPrefs.map((p) => renderPrefControlRow(store, p)),
            })
          : nothing}
      </div>

      <div class="column">
        ${renderCard({
          heading: html`<h3 class="card-title">${store.t("card.colors")}</h3>`,
          contentClass: "settings-list",
          body: html`${colorProfilePref ? renderPrefControlRow(store, colorProfilePref) : nothing}
            ${renderSettingsRow({
              label: store.t("dev_display.custom_color_label"),
              forId: "dev-custom-palette-select",
              description: store.t("dev_display.custom_color_desc"),
              control: html`<span class="swatch" style=${swatchStyle} aria-hidden="true"></span>
                <select
                  id="dev-custom-palette-select"
                  .value=${curHex}
                  @change=${(ev) => {
                    const val = (ev.currentTarget).value;
                    if (isValidHexColor(val)) {
                      store.entity.applyDeviceCustomColor(val, true);
                    }
                  }}
                >
                  ${!palettes.length
                    ? html`<option value=${curHex} selected>
                        ${store.t("dev_display.current_color_option", { hex: curHex })}
                      </option>`
                    : html`
                        ${!palettes.some((p) => p.hex.toUpperCase() === curHex)
                          ? html`<option value=${curHex} selected>
                              ${store.t("dev_display.current_color_option", { hex: curHex })}
                            </option>`
                          : nothing}
                        ${palettes.map((p) => {
                          const h = p.hex.toUpperCase();
                          return html`<option value=${h} ?selected=${h === curHex}>
                            ${p.name || h} (${h})
                          </option>`;
                        })}
                      `}
                </select>
                <button
                  type="button"
                  @click=${() => store.tools.openColorWheelModal("device")}
                  class="btn btn-secondary btn-compact"
                >
                  ${store.t("dev_display.add_color_btn")}
                </button>`,
            })}`,
        })}

        ${renderCard({
          heading: html`<h3 class="card-title">${store.t("card.wallpapers")}</h3>`,
          subtitle: store.t("dev_display.wallpapers_subtitle"),
          headerActions: renderWallpaperUploadTrigger(store, "device"),
          contentClass: "stack",
          body: html`${renderWallpaperUploadProgress(store, "device")}
            <div class="settings-list">
              ${renderSettingsRow({
                id: "wp-status-row",
                label: store.t("dev_display.active_wallpaper_label"),
                description: wpStatusText,
                control: isRotating
                  ? html`<button
                        type="button"
                        id="btn-stop-wp-rotation"
                        @click=${() => void store.entity.setWallpaperRotation(0)}
                        class="btn btn-secondary btn-compact"
                      >
                        ${store.t("dev_display.stop_rotation")}
                      </button>
                      <button
                        type="button"
                        id="btn-turn-off-wp"
                        @click=${() => void store.entity.selectWallpaperSource("")}
                        class="btn btn-secondary btn-compact"
                      >
                        ${store.t("dev_display.turn_off_wallpaper")}
                      </button>`
                  : hasActiveWallpaper
                    ? html`${wallpapers.length >= 2
                          ? html`<button
                              type="button"
                              id="btn-enable-wp-rotation"
                              @click=${() => void store.entity.setWallpaperRotation(15)}
                              class="btn btn-secondary btn-compact"
                            >
                              ${store.t("dev_display.enable_rotation")}
                            </button>`
                          : nothing}
                        <button
                          type="button"
                          id="btn-turn-off-wp"
                          @click=${() => void store.entity.selectWallpaperSource("")}
                          class="btn btn-secondary btn-compact"
                        >
                          ${store.t("dev_display.turn_off_wallpaper")}
                        </button>`
                    : wallpapers.length >= 2
                      ? html`<button
                          type="button"
                          id="btn-enable-wp-rotation"
                          @click=${() => void store.entity.setWallpaperRotation(15)}
                          class="btn btn-primary btn-compact"
                        >
                          ${store.t("dev_display.enable_rotation")}
                        </button>`
                      : nothing,
              })}
              ${renderSettingsRow({
                id: "wp-rotation-row",
                label: store.t("dev_display.rotation_interval_label"),
                forId: "cfg-wallpaper_cycle_minutes",
                description: wpRotationHint,
                control: html`<select
                    id="cfg-wallpaper_cycle_minutes"
                    aria-label=${store.t("dev_display.rotation_interval_aria")}
                    .value=${String(curCycle)}
                    @change=${(ev) =>
                      void store.entity.setWallpaperRotation(
                        Number((ev.currentTarget).value) || 0,
                      )}
                  >
                    ${WALLPAPER_ROTATION_OPTIONS.map(
                      (opt) =>
                        html`<option value=${String(opt.value)} ?selected=${opt.value === curCycle}>
                          ${rotationLabel(store, opt.value, opt.label)}
                        </option>`,
                    )}
                  </select>
                  ${wallpapers.length > 0 && !allStarred
                    ? html`<button
                        type="button"
                        id="btn-star-all-wp"
                        @click=${() =>
                          void store.entity.setAllWallpaperFavorites(
                            wallpapers.map((w) => w.id),
                          )}
                        class="btn btn-text btn-compact"
                      >
                        ${store.t("dev_display.star_all")}
                      </button>`
                    : nothing}
                  ${starredCount > 0
                    ? html`<button
                        type="button"
                        id="btn-clear-stars-wp"
                        @click=${() => void store.entity.setAllWallpaperFavorites([])}
                        class="btn btn-text btn-compact"
                      >
                        ${store.t("dev_display.clear_stars")}
                      </button>`
                    : nothing}`,
              })}
            </div>
            <div class="wp-gallery">
              ${renderWallpaperGalleryItems(
                store,
                "device",
                wallpapers,
                String(cfg.display_shape || "square"),
              )}
            </div>`,
        })}
      </div>
    </div>
  </section>`;
}
__latterExp(__exports, { renderDeviceDisplayView: () => renderDeviceDisplayView });
//# sourceURL=latter-studio/src/views/device-display-view.ts
});
__latterDef("src/views/device-interface-view.ts", (__exports, __req) => {
const { renderCard, renderPillList, renderSelectRow, renderSettingsRow, renderSortableList, renderSwitchRow, renderTrashIconButton } = __req("src/components/controls.ts");
const { ACTIVITY_SOURCES_CATALOG, HOME_CLOCK_TAP_OPTIONS, HOME_DATE_TAP_OPTIONS, MAX_DOCK_ITEMS, NATIVE_DOCK_APP_TOKENS, NATIVE_DOCK_CONFIG_APP_MAP, RETURN_TO_HOME_TIMEOUT_OPTIONS, SHORTCUT_ROUTES_CATALOG, START_SCREEN_CONFIG_APP_MAP, START_SCREEN_OPTIONS, TOOLS_ITEMS_CATALOG } = __req("src/constants.ts");
const { html, nothing, repeat } = __req("src/lib/lit.ts");
const { ROUTE_PREVIEW_ICONS, shortcutActionLabel } = __req("src/mdi-catalog.ts");
const { isCatalogItemSupported } = __req("src/state/store.ts");
const { fmtNumber, hassFirstWeekday } = __req("src/utils/format.ts");
const { defaultLocaleTimeFormat, renderDeviceOfflineBanner } = __req("src/views/device-overview-view.ts");
/**
 * Device Interface View (`interface`, `D-026`, `D-035`, `D-047`, `D-053`, `D-064`, `D-069`, `U4`):
 * - Column 1: Home screen (`home_screen_enabled`, `start_screen` + inline `Configure`, `time_format`,
 *   `home_clock_tap_action` + conditional `clock_face`, `home_date_tap_action`, `return_to_home_timeout`,
 *   `wake_greeting`, `weather_background` + conditional `home_sun`/`home_moon` pills, `activity_card`,
 *   & sortable `renderPillList` for `activity_sources`).
 * - Column 2: App Dock (`renderSortableList` with `≡` drag handle + focus-preserving `↑`/`↓` and
 *   non-truncating `.dock-row` layout, `requestResetDockItems` confirmation, and Hidden from dock) —
 *   omitted cleanly when `home_screen_enabled === false` (`D-069`).
 */
const IFACE_UTC_ZONES = new Set([
  "UTC",
  "Etc/UTC",
  "GMT",
  "Etc/GMT",
  "Etc/GMT+0",
  "Etc/GMT-0",
  "Etc/GMT0",
]);
const IFACE_IANA_PATTERN = /^[A-Za-z0-9_+-]+(?:\/[A-Za-z0-9_+-]+)+$/;
function countConfiguredWorldClocks(raw) {
  let count = 0;
  const seen = new Set();
  for (const part of String(raw ?? "").split(";")) {
    const rec = part.trim();
    if (!rec) continue;
    const pipeIdx = rec.indexOf("|");
    if (pipeIdx < 0) continue;
    const rawLbl = rec.slice(0, pipeIdx).trim();
    const iana = rec.slice(pipeIdx + 1).trim();
    if (!iana || IFACE_UTC_ZONES.has(iana) || !IFACE_IANA_PATTERN.test(iana)) {
      continue;
    }
    const key = `${rawLbl.toLowerCase()}|${iana}`;
    if (seen.has(key)) continue;
    seen.add(key);
    count += 1;
    if (count >= 4) break;
  }
  return count;
}
function isNativeDockRouteItem(item) {
  return (
    item.kind === "route" &&
    NATIVE_DOCK_APP_TOKENS.includes(item.target) &&
    !item.label &&
    !item.icon
  );
}
function activitySourceLabel(store, token, fallback) {
  const key = `dev_interface.activity_src_${token}`;
  const translated = store.t(key);
  return translated === key ? fallback : translated;
}
function renderDeviceInterfaceView(store) {
  const data = store.state;
  const cfg = data?.config || {};
  const caps = data?.capabilities || {};
  const remoteGroups = data?.system_config?.remote_groups || [];
  const homeScreenEnabledPref = store.entity.getPref("home_screen_enabled");
  const homeScreenEnabled = homeScreenEnabledPref
    ? Boolean(homeScreenEnabledPref.value)
    : cfg.home_screen_enabled !== false;
  const startScreenPref = store.entity.getPref("start_screen");
  const rawStartOptions =
    startScreenPref?.options && startScreenPref.options.length > 0
      ? startScreenPref.options
      : START_SCREEN_OPTIONS;
  const visibleStartOptions = (
    homeScreenEnabled ? rawStartOptions : rawStartOptions.filter((opt) => opt !== "Home")
  ).map((opt) => ({ value: opt, label: store.tPrefOption("start_screen", opt) }));
  const rawStartValue = String(
    startScreenPref?.value ?? cfg.start_screen ?? (homeScreenEnabled ? "Home" : "Time App"),
  );
  const startScreenValue =
    !homeScreenEnabled && rawStartValue === "Home" ? "Time App" : rawStartValue;
  const startScreenConfigApp = !homeScreenEnabled
    ? START_SCREEN_CONFIG_APP_MAP[startScreenValue] || null
    : null;
  const homeClockTapPref = store.entity.getPref("home_clock_tap_action");
  const homeClockTapOptions = (
    homeClockTapPref?.options && homeClockTapPref.options.length > 0
      ? homeClockTapPref.options
      : HOME_CLOCK_TAP_OPTIONS
  ).map((opt) => ({
    value: opt,
    label: store.tPrefOption("home_clock_tap_action", opt),
  }));
  const homeClockTapValue = String(
    homeClockTapPref?.value ?? cfg.home_clock_tap_action ?? "Time App",
  );
  const homeDateTapPref = store.entity.getPref("home_date_tap_action");
  const homeDateTapOptions = (
    homeDateTapPref?.options && homeDateTapPref.options.length > 0
      ? homeDateTapPref.options
      : HOME_DATE_TAP_OPTIONS
  ).map((opt) => ({
    value: opt,
    label: store.tPrefOption("home_date_tap_action", opt),
  }));
  const homeDateTapValue = String(
    homeDateTapPref?.value ?? cfg.home_date_tap_action ?? "Overview",
  );
  const returnTimeoutPref = store.entity.getPref("return_to_home_timeout");
  const rawReturnTimeoutOptions = (
    returnTimeoutPref?.options && returnTimeoutPref.options.length > 0
      ? returnTimeoutPref.options
      : RETURN_TO_HOME_TIMEOUT_OPTIONS
  ).map((opt) => ({
    value: opt,
    label: store.tPrefOption("return_to_home_timeout", opt),
  }));
  const returnTimeoutValue = String(
    returnTimeoutPref?.value ?? cfg.return_to_home_timeout ?? "2 min",
  );
  const activityCardOn = cfg.activity_card !== false;
  const enabledSourceTokens = store.entity.getEnabledActivitySources();
  const enabledSourceSet = new Set(enabledSourceTokens);
  const activitySpecMap = new Map(ACTIVITY_SOURCES_CATALOG.map((c) => [c.token, c]));
  const activityPillItems = [
    ...enabledSourceTokens
      .map((tok) => activitySpecMap.get(tok))
      .filter((c) =>
        Boolean(c && isCatalogItemSupported(c, caps)),
      )
      .map((c) => ({
        token: c.token,
        label: activitySourceLabel(store, c.token, c.label),
        enabled: true,
      })),
    ...ACTIVITY_SOURCES_CATALOG.filter(
      (c) => !enabledSourceSet.has(c.token) && isCatalogItemSupported(c, caps),
    ).map((c) => ({
      token: c.token,
      label: activitySourceLabel(store, c.token, c.label),
      enabled: false,
    })),
  ];
  const dockItems = store.entity.getDockItems();
  const pinnedItems = store.entity.getPinnedItems();
  const enabledHomeCats = store.entity.getEnabledHomeCategories();
  const enabledAreaCats = store.entity.getEnabledAreaCategories();
  const enabledTools = store.entity.getEnabledToolsItems();
  const toolSpecMap = new Map(TOOLS_ITEMS_CATALOG.map((t) => [t.token, t]));
  const visibleToolsCount = enabledTools.filter((tok) => {
    const spec = toolSpecMap.get(tok);
    return spec ? isCatalogItemSupported(spec, caps) : true;
  }).length;
  const enabledGames = store.entity.getEnabledGamesItems();
  const curDevEntry = (data?.system_devices || []).find(
    (d) => d.subentry_id === store.activeSubentryId,
  );
  const curRemoteMode =
    String(cfg.device_remote_group || curDevEntry?.device_remote_group || "area_auto").trim() ||
    "area_auto";
  const albumArtPref = store.entity.getPref("album_art_style");
  const albumArtRaw = String(albumArtPref?.value ?? cfg.album_art_style ?? "Full Screen");
  const albumArtVal = store.tPrefOption("album_art_style", albumArtRaw);
  const albumSortPref = store.entity.getPref("album_sort_order");
  const albumSortRaw = String(albumSortPref?.value ?? cfg.album_sort_order ?? "Alphabetical");
  const albumSortVal = store.tPrefOption("album_sort_order", albumSortRaw);
  const showUtcClockPref = store.entity.getPref("show_utc_clock");
  const showUtcClock = showUtcClockPref
    ? Boolean(showUtcClockPref.value)
    : Boolean(cfg.show_utc_clock);
  const worldClocksPref = store.entity.getPref("world_clocks");
  const worldClockCount = countConfiguredWorldClocks(
    worldClocksPref?.value ?? cfg.world_clocks ?? "",
  );
  const clockFacePref = store.entity.getPref("clock_face");
  const clockFaceSpec = store.entity.getPrefSpec("clock_face");
  const rawClockFaceOpts =
    clockFacePref?.options && clockFacePref.options.length > 0
      ? clockFacePref.options
      : clockFaceSpec?.options || [];
  const filteredClockFaceOpts =
    caps.is_round === false
      ? rawClockFaceOpts.filter((opt) => opt !== "Modern Analog")
      : rawClockFaceOpts;
  const clockFaceRaw = String(clockFacePref?.value ?? cfg.clock_face ?? "Minimal Digital");
  const resolvedClockFaceValue =
    filteredClockFaceOpts.length > 0 && !filteredClockFaceOpts.includes(clockFaceRaw)
      ? filteredClockFaceOpts[0]
      : clockFaceRaw;
  const clockFaceOptions = filteredClockFaceOpts.map((opt) => ({
    value: opt,
    label: store.tPrefOption("clock_face", opt),
  }));
  const clockFaceVal = store.tPrefOption("clock_face", resolvedClockFaceValue);
  // Default unset `time_format` from `hass.locale?.time_format` (`D-14`)
  const timeFormatPref = store.entity.getPref("time_format");
  const timeFormatSpec = store.entity.getPrefSpec("time_format");
  const rawTimeFormatOpts =
    timeFormatPref?.options && timeFormatPref.options.length > 0
      ? timeFormatPref.options
      : timeFormatSpec?.options || [];
  const rawTimeFormatVal = timeFormatPref?.value ?? cfg.time_format;
  const effectiveTimeFormat =
    rawTimeFormatVal !== undefined &&
    rawTimeFormatVal !== null &&
    String(rawTimeFormatVal).trim() !== ""
      ? String(rawTimeFormatVal)
      : defaultLocaleTimeFormat(store.hass);
  const resolvedTimeFormatValue =
    rawTimeFormatOpts.length > 0 && !rawTimeFormatOpts.includes(effectiveTimeFormat)
      ? rawTimeFormatOpts[0]
      : effectiveTimeFormat;
  const timeFormatOptions = rawTimeFormatOpts.map((opt) => ({
    value: opt,
    label: store.tPrefOption("time_format", opt),
  }));
  const shortTimeFormat = resolvedTimeFormatValue.startsWith("24")
    ? store.t("dev_interface.clock_24h")
    : store.t("dev_interface.clock_12h");
  // Home screen appearance controls consolidated into Home screen (`D-069`)
  const wakeGreetingPref = store.entity.getPref("wake_greeting");
  const wakeGreetingRaw = wakeGreetingPref?.value ?? cfg.wake_greeting;
  const wakeGreetingOn =
    wakeGreetingRaw !== undefined && wakeGreetingRaw !== null
      ? typeof wakeGreetingRaw === "string"
        ? !["", "0", "false", "off", "disabled"].includes(wakeGreetingRaw.trim().toLowerCase())
        : Boolean(wakeGreetingRaw)
      : true;
  const weatherBgPref = store.entity.getPref("weather_background");
  const weatherBgRaw = weatherBgPref?.value ?? cfg.weather_background;
  const weatherBgOn =
    weatherBgRaw !== undefined && weatherBgRaw !== null
      ? typeof weatherBgRaw === "string"
        ? !["", "0", "false", "off", "disabled"].includes(weatherBgRaw.trim().toLowerCase())
        : Boolean(weatherBgRaw)
      : true;
  const celestialPillItems = (["home_sun", "home_moon"]).map((key) => {
    const pref = store.entity.getPref(key);
    const rawVal = pref?.value ?? cfg[key];
    const enabled =
      rawVal !== undefined && rawVal !== null
        ? typeof rawVal === "string"
          ? !["", "0", "false", "off", "disabled"].includes(rawVal.trim().toLowerCase())
          : Boolean(rawVal)
        : true;
    return {
      token: key,
      label: store.tPrefLabel(key, pref?.label),
      enabled,
    };
  });
  const renderInlineClockFaceRow = () =>
    clockFaceOptions.length > 0
      ? renderSelectRow({
          id: "cfg-clock_face",
          label: store.tPrefLabel("clock_face"),
          description: store.t("dev_interface.clock_face_desc"),
          value: resolvedClockFaceValue,
          rawOptions: clockFaceOptions,
          onChange: (val) => {
            store.entity.stageDeviceSetting("clock_face", val, "cfg-clock_face");
          },
        })
      : nothing;
  const calLookaheadPref = store.entity.getPref("calendar_lookahead_days");
  const rawLookahead = Number(calLookaheadPref?.value ?? cfg.calendar_lookahead_days ?? 30);
  const calLookaheadDays =
    rawLookahead <= 10 ? 7 : rawLookahead <= 21 ? 14 : rawLookahead <= 45 ? 30 : 60;
  const calWeekStartPref = store.entity.getPref("calendar_week_start");
  const rawWeekStartVal = calWeekStartPref?.value ?? cfg.calendar_week_start;
  const effectiveWeekStart =
    rawWeekStartVal !== undefined &&
    rawWeekStartVal !== null &&
    String(rawWeekStartVal).trim() !== ""
      ? String(rawWeekStartVal)
      : hassFirstWeekday(store.hass);
  const calWeekStart = store.tPrefOption(
    "calendar_week_start",
    effectiveWeekStart === "Monday" ? "Monday" : "Sunday",
  );
  const describeNativeDockApp = (routeToken) => {
    switch (routeToken) {
      case "app:pinned": {
        if (pinnedItems.length === 0) {
          return store.t("dev_interface.pinned_empty_meta");
        }
        const pages = Math.ceil(pinnedItems.length / 6);
        return store.t("dev_interface.pinned_count_meta", {
          count: fmtNumber(pinnedItems.length, store.hass, 0),
          shortcutWord:
            pinnedItems.length === 1
              ? store.t("dev_interface.word_shortcut_one")
              : store.t("dev_interface.word_shortcut_many"),
          pages: fmtNumber(pages, store.hass, 0),
          pageWord:
            pages === 1
              ? store.t("dev_interface.word_page_one")
              : store.t("dev_interface.word_page_many"),
        });
      }
      case "app:music":
        return store.t("dev_interface.music_meta", {
          art: albumArtVal,
          albums: albumSortVal,
        });
      case "app:home_hub":
        return enabledHomeCats.length === 1
          ? store.t("dev_interface.categories_enabled_one")
          : store.t("dev_interface.categories_enabled_many", {
              count: fmtNumber(enabledHomeCats.length, store.hass, 0),
            });
      case "app:area":
        return enabledAreaCats.length === 1
          ? store.t("dev_interface.categories_enabled_one")
          : store.t("dev_interface.categories_enabled_many", {
              count: fmtNumber(enabledAreaCats.length, store.hass, 0),
            });
      case "app:remote": {
        if (curRemoteMode === "all") return store.t("dev_interface.remote_all");
        if (curRemoteMode.startsWith("group:")) {
          const gid = curRemoteMode.slice(6);
          return remoteGroups.find((g) => g.id === gid)?.name || gid;
        }
        return store.t("dev_interface.remote_follow_area");
      }
      case "app:weather":
        return store.t("dev_interface.weather_meta");
      case "app:time":
        if (showUtcClock && worldClockCount > 0) {
          return worldClockCount === 1
            ? store.t("dev_interface.time_utc_world_one")
            : store.t("dev_interface.time_utc_world_many", {
                count: fmtNumber(worldClockCount, store.hass, 0),
              });
        }
        if (worldClockCount > 0) {
          return worldClockCount === 1
            ? store.t("dev_interface.time_world_one")
            : store.t("dev_interface.time_world_many", {
                count: fmtNumber(worldClockCount, store.hass, 0),
              });
        }
        return showUtcClock
          ? store.t("dev_interface.time_local_utc")
          : store.t("dev_interface.time_local");
      case "app:clock":
        return `${clockFaceVal} • ${shortTimeFormat}`;
      case "app:calendar":
        return store.t("dev_interface.calendar_meta", {
          days: fmtNumber(calLookaheadDays, store.hass, 0),
          weekday: calWeekStart,
        });
      case "app:tools":
        return visibleToolsCount === 1
          ? store.t("dev_interface.tools_enabled_one")
          : store.t("dev_interface.tools_enabled_many", {
              count: fmtNumber(visibleToolsCount, store.hass, 0),
            });
      case "app:games":
        return enabledGames.length === 1
          ? store.t("dev_interface.games_enabled_one")
          : store.t("dev_interface.games_enabled_many", {
              count: fmtNumber(enabledGames.length, store.hass, 0),
            });
      default:
        return routeToken;
    }
  };
  const shortcutEntityMap = new Map(
    (data?.catalog?.shortcut_entities || []).map((e) => [e.id, e]),
  );
  const routeSpecMap = new Map(SHORTCUT_ROUTES_CATALOG.map((r) => [r.token, r]));
  const activeNativeSet = new Set(
    dockItems.filter((it) => isNativeDockRouteItem(it)).map((it) => it.target),
  );
  const hiddenNativeApps = NATIVE_DOCK_APP_TOKENS.filter((tok) => !activeNativeSet.has(tok));
  // Stable index-independent keys so `renderSortableList` preserves focus across keyboard `↑`/`↓` moves
  const dockItemKeys = (() => {
    const counts = new Map();
    return dockItems.map((it) => {
      const base = isNativeDockRouteItem(it)
        ? `native:${it.target}`
        : `custom:${it.kind}:${it.target}:${it.action}:${it.label}:${it.icon}`;
      const occ = (counts.get(base) || 0) + 1;
      counts.set(base, occ);
      return occ === 1 ? base : `${base}#${occ}`;
    });
  })();
  const resolveDockItemPresentation = (
    item,
  ) => {
    if (isNativeDockRouteItem(item)) {
      const spec = routeSpecMap.get(item.target);
      return {
        title: spec?.label || item.target,
        meta: describeNativeDockApp(item.target),
        icon: ROUTE_PREVIEW_ICONS[item.target] || "mdi:apps",
      };
    }
    if (item.kind === "route") {
      const spec = routeSpecMap.get(item.target);
      const title = item.label || spec?.label || item.target;
      const targetDesc = spec ? `${spec.group} • ${spec.label}` : item.target;
      return {
        title,
        meta: store.t("dev_interface.custom_route_meta", { target: targetDesc }),
        icon: item.icon || ROUTE_PREVIEW_ICONS[item.target] || "mdi:apps",
      };
    }
    const ent = shortcutEntityMap.get(item.target);
    const dom = item.target.split(".", 1)[0] || "";
    const actLbl = shortcutActionLabel(dom, item.action);
    const title = item.label || ent?.name || item.target;
    const meta = item.confirm
      ? store.t("dev_interface.custom_entity_confirm_meta", {
          action: actLbl,
          target: item.target,
        })
      : store.t("dev_interface.custom_entity_tap_meta", {
          action: actLbl,
          target: item.target,
        });
    return {
      title,
      meta,
      icon: item.icon || ent?.icon || "mdi:flash",
    };
  };
  return html`<section id="view-interface">
    ${renderDeviceOfflineBanner(store)}

    <div class="columns">
      <div class="column">
        ${renderCard({
          id: "card-home-screen",
          heading: html`<h3 class="card-title">${store.t("card.home_screen")}</h3>`,
          contentClass: "settings-list",
          body: html`${renderSwitchRow({
              id: "cfg-home_screen_enabled",
              label: store.tPrefLabel("home_screen_enabled"),
              description: store.t("dev_interface.enable_home_desc"),
              checked: homeScreenEnabled,
              onChange: (checked) => {
                store.entity.stageDeviceSetting(
                  "home_screen_enabled",
                  checked,
                  "cfg-home_screen_enabled",
                );
              },
            })}
            ${renderSettingsRow({
              label: store.tPrefLabel("start_screen"),
              forId: "cfg-start_screen",
              description: homeScreenEnabled
                ? store.t("dev_interface.start_screen_multi_desc")
                : store.t("dev_interface.start_screen_single_desc"),
              control: html`<select
                  id="cfg-start_screen"
                  .value=${startScreenValue}
                  @change=${(ev) => {
                    store.entity.stageDeviceSetting(
                      "start_screen",
                      (ev.currentTarget).value,
                      "cfg-start_screen",
                    );
                  }}
                >
                  ${visibleStartOptions.map(
                    (o) =>
                      html`<option value=${o.value} ?selected=${o.value === startScreenValue}>
                        ${o.label}
                      </option>`,
                  )}
                </select>
                ${startScreenConfigApp
                  ? html`<button
                      type="button"
                      id="btn-configure-start-screen"
                      @click=${() => store.entity.openAppConfigModal(startScreenConfigApp)}
                      class="btn btn-secondary btn-compact"
                    >
                      ${store.t("action.configure")}
                    </button>`
                  : nothing}`,
            })}
            ${timeFormatOptions.length > 0
              ? renderSelectRow({
                  id: "cfg-time_format",
                  label: store.tPrefLabel("time_format"),
                  description: store.t("dev_interface.time_format_desc"),
                  value: resolvedTimeFormatValue,
                  rawOptions: timeFormatOptions,
                  onChange: (val) => {
                    store.entity.stageDeviceSetting("time_format", val, "cfg-time_format");
                  },
                })
              : nothing}
            ${!homeScreenEnabled && startScreenValue === "Clock Face"
              ? renderInlineClockFaceRow()
              : nothing}
            ${homeScreenEnabled
              ? html`${renderSelectRow({
                    id: "cfg-home_clock_tap_action",
                    label: store.tPrefLabel("home_clock_tap_action"),
                    description: store.t("dev_interface.home_clock_tap_desc"),
                    value: homeClockTapValue,
                    rawOptions: homeClockTapOptions,
                    onChange: (val) => {
                      store.entity.stageDeviceSetting(
                        "home_clock_tap_action",
                        val,
                        "cfg-home_clock_tap_action",
                      );
                    },
                  })}
                  ${homeClockTapValue === "Clock Face" || startScreenValue === "Clock Face"
                    ? renderInlineClockFaceRow()
                    : nothing}
                  ${renderSelectRow({
                    id: "cfg-home_date_tap_action",
                    label: store.tPrefLabel("home_date_tap_action"),
                    description: store.t("dev_interface.home_date_tap_desc"),
                    value: homeDateTapValue,
                    rawOptions: homeDateTapOptions,
                    onChange: (val) => {
                      store.entity.stageDeviceSetting(
                        "home_date_tap_action",
                        val,
                        "cfg-home_date_tap_action",
                      );
                    },
                  })}
                  ${renderSelectRow({
                    id: "cfg-return_to_home_timeout",
                    label: store.tPrefLabel("return_to_home_timeout"),
                    description: store.t("dev_interface.return_timeout_desc"),
                    value: returnTimeoutValue,
                    rawOptions: rawReturnTimeoutOptions,
                    onChange: (val) => {
                      store.entity.stageDeviceSetting(
                        "return_to_home_timeout",
                        val,
                        "cfg-return_to_home_timeout",
                      );
                    },
                  })}
                  ${renderSwitchRow({
                    id: "cfg-wake_greeting",
                    label: store.tPrefLabel("wake_greeting"),
                    description: store.t("dev_interface.wake_greeting_desc"),
                    checked: wakeGreetingOn,
                    onChange: (checked) => {
                      store.entity.stageDeviceSetting(
                        "wake_greeting",
                        checked,
                        "cfg-wake_greeting",
                      );
                    },
                  })}
                  ${renderSwitchRow({
                    id: "cfg-weather_background",
                    label: store.tPrefLabel("weather_background"),
                    description: store.t("dev_interface.weather_bg_desc"),
                    checked: weatherBgOn,
                    onChange: (checked) => {
                      store.entity.stageDeviceSetting(
                        "weather_background",
                        checked,
                        "cfg-weather_background",
                      );
                    },
                  })}
                  ${weatherBgOn
                    ? renderSettingsRow({
                        id: "weather-celestial-bodies",
                        label: store.t("dev_interface.sun_moon_label"),
                        description: store.t("dev_interface.sun_moon_desc"),
                        control: renderPillList({
                          id: "weather-celestial-pills",
                          ariaLabel: store.t("dev_interface.sun_moon_label"),
                          items: celestialPillItems,
                          onToggle: (token, nextEnabled) => {
                            store.entity.stageDeviceSetting(token, nextEnabled);
                          },
                          overlay: store.localeOverlay,
                        }),
                      })
                    : nothing}
                  ${renderSwitchRow({
                    id: "cfg-activity_card",
                    label: store.tPrefLabel("activity_card"),
                    description: store.t("dev_interface.activity_card_desc"),
                    checked: activityCardOn,
                    onChange: (checked) =>
                      store.entity.stageDeviceSetting(
                        "activity_card",
                        checked,
                        "cfg-activity_card",
                      ),
                  })}
                  ${activityCardOn
                    ? renderSettingsRow({
                        id: "activity-sources",
                        label: store.tPrefLabel("activity_sources"),
                        description: store.t("dev_interface.activity_sources_desc"),
                        stacked: true,
                        control: renderPillList({
                          id: "activity-sources-pills",
                          ariaLabel: store.tPrefLabel("activity_sources"),
                          items: activityPillItems,
                          onToggle: (token, nextEnabled) => {
                            store.entity.toggleActivitySource(token, nextEnabled);
                          },
                          onReorder: (fromIdx, toIdx) => {
                            store.entity.reorderActivitySources(fromIdx, toIdx);
                          },
                          overlay: store.localeOverlay,
                        }),
                      })
                    : nothing}`
              : nothing}`,
        })}
      </div>

      <div class="column">
        ${homeScreenEnabled
          ? renderCard({
              id: "card-app-dock",
              heading: html`<h3 class="card-title">${store.t("card.app_dock")}</h3>`,
              contentClass: "stack",
              body: html`<p class="row-description">
                  ${store.t("dev_interface.app_dock_desc")}
                </p>
                <div id="dock-shortcuts-container" class="stack">
                  ${renderSortableList({
                    id: "dock-shortcuts-list",
                    ariaLabel: store.t("dev_interface.active_dock_aria"),
                    items: dockItems,
                    rowClass: "dock-row",
                    getKey: (_item, idx) => dockItemKeys[idx],
                    getLabel: (item) => resolveDockItemPresentation(item).title,
                    onReorder: (fromIdx, toIdx) => {
                      store.entity.reorderShortcutItems("dock_items", fromIdx, toIdx);
                    },
                    renderContent: (item) => {
                      const info = resolveDockItemPresentation(item);
                      return html`<div class="input-action-row">
                        <span class="shortcut-icon-badge" aria-hidden="true">
                          <ha-icon .icon=${info.icon}></ha-icon>
                        </span>
                        <div class="shortcut-item-info">
                          <span class="shortcut-item-title">${info.title}</span>
                          <span class="shortcut-item-meta">${info.meta}</span>
                        </div>
                      </div>`;
                    },
                    renderActions: (item, idx) => {
                      const info = resolveDockItemPresentation(item);
                      if (isNativeDockRouteItem(item)) {
                        const configApp = NATIVE_DOCK_CONFIG_APP_MAP[item.target];
                        return html`${configApp
                            ? html`<button
                                type="button"
                                aria-label=${store.t("action.configure_item", {
                                  item: info.title,
                                })}
                                @click=${() => store.entity.openAppConfigModal(configApp)}
                                class="btn btn-secondary btn-compact"
                              >
                                ${store.t("action.configure")}
                              </button>`
                            : nothing}
                          <input
                            type="checkbox"
                            role="switch"
                            aria-label=${store.t("dev_interface.show_on_dock_aria", {
                              title: info.title,
                            })}
                            .checked=${true}
                            @change=${(ev) =>
                              store.entity.toggleNativeDockApp(
                                item.target,
                                (ev.currentTarget).checked,
                              )}
                            class="switch"
                          />`;
                      }
                      return html`<button
                          type="button"
                          aria-label=${store.t("action.edit_item", { item: info.title })}
                          @click=${() => store.entity.openShortcutModal("dock_items", idx)}
                          class="btn btn-secondary btn-compact"
                        >
                          ${store.t("action.edit")}
                        </button>
                        ${renderTrashIconButton(
                          store.t("action.remove_item", { item: info.title }),
                          () => store.entity.removeShortcutItem("dock_items", idx),
                        )}`;
                    },
                    overlay: store.localeOverlay,
                  })}
                  <div class="dock-row shortcut-item-locked">
                    <span class="shortcut-icon-badge" aria-hidden="true">
                      <ha-icon .icon=${"mdi:cog"}></ha-icon>
                    </span>
                    <div class="shortcut-item-info">
                      <span class="shortcut-item-title">
                        ${store.t("dev_interface.settings_title")}
                      </span>
                      <span class="shortcut-item-meta">
                        ${store.t("dev_interface.settings_locked_meta")}
                      </span>
                    </div>
                  </div>
                </div>
                <div class="shortcut-toolbar">
                  <button
                    type="button"
                    id="btn-add-dock-item"
                    ?disabled=${dockItems.length >= MAX_DOCK_ITEMS}
                    @click=${() => store.entity.openShortcutModal("dock_items", null)}
                    class="btn btn-secondary"
                  >
                    ${store.t("action.add_custom_shortcut")}
                  </button>
                  <button
                    type="button"
                    id="btn-reset-dock-items"
                    @click=${() => store.entity.requestResetDockItems()}
                    class="btn btn-text"
                  >
                    ${store.t("action.reset_default_dock")}
                  </button>
                </div>
                ${hiddenNativeApps.length > 0
                  ? html`<div
                      id="dock-hidden-native-apps"
                      class="stack"
                      role="group"
                      aria-label=${store.t("dev_interface.hidden_from_dock")}
                    >
                      <div class="subsection-title">
                        ${store.t("dev_interface.hidden_from_dock")}
                      </div>
                      ${repeat(
                        hiddenNativeApps,
                        (tok) => tok,
                        (tok) => {
                          const spec = routeSpecMap.get(tok);
                          const displayTitle = spec?.label || tok;
                          const iconSlug = ROUTE_PREVIEW_ICONS[tok] || "mdi:apps";
                          const configApp = NATIVE_DOCK_CONFIG_APP_MAP[tok];
                          return html`<div class="dock-row shortcut-item-hidden">
                            <span class="shortcut-icon-badge" aria-hidden="true">
                              <ha-icon .icon=${iconSlug}></ha-icon>
                            </span>
                            <div class="shortcut-item-info">
                              <span class="shortcut-item-title">${displayTitle}</span>
                              <span class="shortcut-item-meta">${describeNativeDockApp(tok)}</span>
                            </div>
                            ${configApp
                              ? html`<button
                                  type="button"
                                  aria-label=${store.t("action.configure_item", {
                                    item: displayTitle,
                                  })}
                                  @click=${() => store.entity.openAppConfigModal(configApp)}
                                  class="btn btn-secondary btn-compact"
                                >
                                  ${store.t("action.configure")}
                                </button>`
                              : nothing}
                            <input
                              type="checkbox"
                              role="switch"
                              aria-label=${store.t("dev_interface.show_on_dock_aria", {
                                title: displayTitle,
                              })}
                              ?disabled=${dockItems.length >= MAX_DOCK_ITEMS}
                              .checked=${false}
                              @change=${(ev) =>
                                store.entity.toggleNativeDockApp(
                                  tok,
                                  (ev.currentTarget).checked,
                                )}
                              class="switch"
                            />
                          </div>`;
                        },
                      )}
                    </div>`
                  : nothing}`,
            })
          : nothing}
      </div>
    </div>
  </section>`;
}
__latterExp(__exports, { renderDeviceInterfaceView: () => renderDeviceInterfaceView });
//# sourceURL=latter-studio/src/views/device-interface-view.ts
});
__latterDef("src/views/device-power-view.ts", (__exports, __req) => {
const { renderCard, renderPrefControlRow } = __req("src/components/controls.ts");
const { html, nothing } = __req("src/lib/lit.ts");
const { renderDeviceEntityRow, renderDeviceOfflineBanner } = __req("src/views/device-overview-view.ts");
/**
 * Device Power View (`power`, `D-014`, `D-027`, `D-036`, `D-066`, `D-068`):
 * Sleep & wake controls, Bedtime mode, and Power & battery telemetry.
 */
const SCREENSAVER_KEYS = new Set([
  "docked_screensaver",
  "screensaver_style",
  "docked_idle_timeout",
]);
const BEDTIME_KEYS = new Set([
  "bedtime_active",
  "bedtime_display",
  "bedtime_brightness",
  "bedtime_schedule",
  "bedtime_start_hour",
  "bedtime_end_hour",
  "bedtime_mode",
]);
function renderDevicePowerView(store) {
  const sleepPrefs = store.entity
    .getPrefs([
      "tap_to_wake",
      "pickup_to_wake",
      "battery_screen_timeout",
      "battery_hibernate_timeout",
      "hold_crown_power_off",
    ])
    .filter((p) => !SCREENSAVER_KEYS.has(p.key));
  const bedtimeAllPrefs = store.entity.getPrefs([
    "bedtime_active",
    "bedtime_display",
    "bedtime_brightness",
    "bedtime_schedule",
    "bedtime_start_hour",
    "bedtime_end_hour",
  ]);
  const bedtimeScheduleOn = Boolean(
    bedtimeAllPrefs.find((p) => p.key === "bedtime_schedule")?.value,
  );
  const bedtimePrefs = bedtimeAllPrefs.filter(
    (p) =>
      bedtimeScheduleOn ||
      (p.key !== "bedtime_start_hour" && p.key !== "bedtime_end_hour"),
  );
  const sleepPrefKeys = new Set(sleepPrefs.map((p) => p.key));
  const sleepEntities = store.entity.getSectionItems("sleep").filter((it) => {
    if (it.pref_key) return false;
    const k = it.key || (it.entity_id ? it.entity_id.split(".").pop() || "" : "");
    if (SCREENSAVER_KEYS.has(k) || Array.from(SCREENSAVER_KEYS).some((sk) => k.endsWith(sk))) {
      return false;
    }
    if (BEDTIME_KEYS.has(k) || Array.from(BEDTIME_KEYS).some((bk) => k.endsWith(bk))) {
      return false;
    }
    if (sleepPrefKeys.has(k) || Array.from(sleepPrefKeys).some((pk) => k.endsWith(pk))) {
      return false;
    }
    return true;
  });
  const batteryItems = store.entity.getSectionItems("battery");
  const sleepItems = [...sleepPrefs, ...sleepEntities];
  const allEmpty = !sleepItems.length && !bedtimePrefs.length && !batteryItems.length;
  return html`<section id="view-power">
    ${renderDeviceOfflineBanner(store)}

    <div class="columns">
      <div class="column">
        ${sleepItems.length
          ? html`<div class="card" data-entity-card>
              <div class="card-header">
                <h3 class="card-title">${store.t("dev_power.card_sleep_wake")}</h3>
              </div>
              <div class="card-content settings-list">
                ${sleepPrefs.map((p) => renderPrefControlRow(store, p))}
                ${sleepEntities.map((it) => renderDeviceEntityRow(store, it))}
              </div>
            </div>`
          : allEmpty
            ? renderCard({
                title: store.t("dev_power.card_power_battery"),
                body: html`<p class="empty-state">${store.t("dev_power.empty")}</p>`,
              })
            : nothing}
      </div>
      <div class="column">
        ${bedtimePrefs.length
          ? renderCard({
              id: "card-bedtime-mode",
              title: store.t("dev_power.card_bedtime"),
              subtitle: store.t("dev_power.card_bedtime_subtitle"),
              contentClass: "settings-list",
              body: html`${bedtimePrefs.map((p) => renderPrefControlRow(store, p))}`,
            })
          : nothing}
        ${batteryItems.length
          ? html`<div class="card" data-entity-card>
              <div class="card-header">
                <h3 class="card-title">${store.t("dev_power.card_power_battery")}</h3>
              </div>
              <div class="card-content settings-list">
                ${batteryItems.map((it) => renderDeviceEntityRow(store, it))}
              </div>
            </div>`
          : nothing}
      </div>
    </div>
  </section>`;
}
__latterExp(__exports, { renderDevicePowerView: () => renderDevicePowerView });
//# sourceURL=latter-studio/src/views/device-power-view.ts
});
__latterDef("src/views/device-presence-view.ts", (__exports, __req) => {
const { renderCard, renderPrefControlRow, renderSelectRow, renderSwitchRow } = __req("src/components/controls.ts");
const { focusSafe, html, nothing } = __req("src/lib/lit.ts");
const { fmtNumber } = __req("src/utils/format.ts");
const { renderDeviceEntityRow, renderDeviceOfflineBanner } = __req("src/views/device-overview-view.ts");
/**
 * Device BLE & Area Presence View (`presence`, `D-003`, `D-032`, `D-036`, `D-066`, `Q8`):
 * Static Assigned Area vs. BLE Roaming, Fallback Area, and BLE identity (hidden when Static).
 */
function renderDevicePresenceView(store) {
  const data = store.state;
  const cfg = data?.config || {};
  const isBleOnly = cfg.kind === "ble_tag";
  const bleTracking = isBleOnly || Boolean(cfg.native_ble_tracking);
  // Strict `D-003` unknown gating: never substitute a fake `-59 dBm` reading when unknown (`E-03`)
  const rawDetectedRef = data?.live?.ble_detected_ref_power;
  const hasDetectedRefPower =
    rawDetectedRef !== null &&
    rawDetectedRef !== undefined &&
    Number.isFinite(Number(rawDetectedRef));
  const refPowerPlaceholder = hasDetectedRefPower
    ? store.t("dev_presence.ref_power_placeholder_detected", {
        dbm: fmtNumber(Number(rawDetectedRef), store.hass, 0),
      })
    : store.t("common.auto");
  const refPowerValue =
    cfg.ble_ref_power !== null && cfg.ble_ref_power !== undefined
      ? String(cfg.ble_ref_power)
      : "";
  const txStatus = isBleOnly ? data?.live?.ble_transmitter_status : null;
  const txPowerRaw = String(txStatus?.tx_power || "").trim();
  const advModeRaw = String(txStatus?.advertise_mode || "").trim();
  const txPowerNorm = txPowerRaw.toLowerCase().replace(/[^a-z]/g, "");
  const advModeNorm = advModeRaw.toLowerCase().replace(/[^a-z]/g, "");
  const showCompanionPowerTip =
    Boolean(txStatus) &&
    (txPowerNorm === "ultralow" || txPowerNorm === "low" || advModeNorm === "lowpower");
  const bleBeaconPref = store.entity.getPref("ble_beacon_mode");
  const bleAreaItems = store.entity
    .getSectionItems("area")
    .filter((it) => !it.pref_key && it.key !== "ble_beacon_mode");
  return html`<section id="view-presence">
    ${renderDeviceOfflineBanner(store)}

    <div class="columns">
      <div class="column">
        ${renderCard({
          title: store.t("dev_presence.card_area_tracking"),
          contentClass: "settings-list",
          body: html`${!isBleOnly
              ? renderSwitchRow({
                  id: "cfg-native_ble_tracking",
                  label: store.t("dev_presence.track_ble_label"),
                  description: store.t("dev_presence.track_ble_desc"),
                  checked: Boolean(cfg.native_ble_tracking),
                  onChange: (checked) =>
                    store.entity.stageDeviceSetting(
                      "native_ble_tracking",
                      checked,
                      "cfg-native_ble_tracking",
                    ),
                })
              : nothing}
            ${bleTracking
              ? html`${!isBleOnly
                    ? renderSwitchRow({
                        id: "cfg-ble_auto_switch",
                        label: store.tPrefLabel("ble_auto_switch"),
                        description: store.t("dev_presence.auto_switch_desc"),
                        checked: Boolean(cfg.ble_auto_switch),
                        onChange: (checked) =>
                          store.entity.stageDeviceSetting(
                            "ble_auto_switch",
                            checked,
                            "cfg-ble_auto_switch",
                          ),
                      })
                    : nothing}
                  ${renderSelectRow({
                    id: "cfg-default_area",
                    label: store.t("dev_presence.fallback_area_label"),
                    description: store.t("dev_presence.fallback_area_desc"),
                    value: cfg.default_area,
                    choices: data?.catalog?.areas,
                    emptyOptionLabel: store.t("dev_presence.fallback_area_auto"),
                    onChange: (val) =>
                      store.entity.stageDeviceSetting(
                        "default_area",
                        val,
                        "cfg-default_area",
                      ),
                  })}
                  ${bleBeaconPref ? renderPrefControlRow(store, bleBeaconPref) : nothing}
                  ${bleAreaItems.map((it) => renderDeviceEntityRow(store, it))}`
              : renderSelectRow({
                  id: "cfg-default_area",
                  label: store.t("dev_presence.assigned_area_label"),
                  description: store.t("dev_presence.assigned_area_desc"),
                  value: cfg.default_area,
                  choices: data?.catalog?.areas,
                  emptyOptionLabel: store.t("dev_overview.unassigned_option"),
                  onChange: (val) =>
                    store.entity.stageDeviceSetting("default_area", val, "cfg-default_area"),
                })}`,
        })}
      </div>

      <div class="column">
        ${bleTracking
          ? renderCard({
              id: "card-ble-identity",
              handoffActive: store.isHandoffTarget("card-ble-identity"),
              title: store.t("dev_presence.card_ble_identity"),
              contentClass: "stack",
              body: html`<div class="stacked-field">
                  <label for="cfg-ble_target_address">
                    ${store.t("dev_presence.target_addr_label")}
                  </label>
                  <input
                    type="text"
                    id="cfg-ble_target_address"
                    placeholder=${store.t("dev_presence.target_addr_placeholder")}
                    .value=${focusSafe(String(cfg.ble_target_address || ""))}
                    @change=${(ev) =>
                      store.entity.stageDeviceSetting(
                        "ble_target_address",
                        (ev.currentTarget).value.trim(),
                        "cfg-ble_target_address",
                      )}
                  />
                  <span class="help-text">${store.t("dev_presence.target_addr_help")}</span>
                </div>
                <div class="stacked-field">
                  <label for="cfg-ble_ref_power">
                    ${store.t("dev_presence.ref_power_label")}
                  </label>
                  <input
                    type="number"
                    id="cfg-ble_ref_power"
                    min="-90"
                    max="-30"
                    step="1"
                    placeholder=${refPowerPlaceholder}
                    .value=${focusSafe(refPowerValue)}
                    @change=${(ev) => {
                      const raw = (ev.currentTarget).value.trim();
                      if (raw === "") {
                        store.entity.stageDeviceSetting(
                          "ble_ref_power",
                          null,
                          "cfg-ble_ref_power",
                        );
                        return;
                      }
                      const num = Number(raw);
                      if (Number.isFinite(num)) {
                        store.entity.stageDeviceSetting(
                          "ble_ref_power",
                          Math.round(num),
                          "cfg-ble_ref_power",
                        );
                      }
                    }}
                  />
                  <span class="help-text">${store.t("dev_presence.ref_power_help")}</span>
                </div>
                ${showCompanionPowerTip
                  ? html`<div id="ble-companion-power-tip" class="alert">
                      <div class="alert-body">
                        <strong>${store.t("dev_presence.companion_low_title")}</strong>
                        <span>
                          ${store.t("dev_presence.companion_low_body", {
                            txPower:
                              txPowerRaw || store.t("dev_presence.companion_default_power"),
                            modeSuffix: advModeRaw
                              ? store.t("dev_presence.companion_mode_suffix", {
                                  mode: advModeRaw,
                                })
                              : "",
                            refSuffix: hasDetectedRefPower
                              ? store.t("dev_presence.companion_ref_suffix", {
                                  dbm: fmtNumber(Number(rawDetectedRef), store.hass, 0),
                                })
                              : "",
                          })}
                        </span>
                      </div>
                    </div>`
                  : nothing}
                ${!isBleOnly
                  ? html`<div class="stacked-field">
                      <label for="cfg-ble_beacon_uuid">
                        ${store.t("dev_presence.ibeacon_uuid_label")}
                      </label>
                      <input
                        type="text"
                        id="cfg-ble_beacon_uuid"
                        placeholder=${store.t("dev_presence.ibeacon_uuid_placeholder")}
                        .value=${focusSafe(String(cfg.ble_beacon_uuid || ""))}
                        @change=${(ev) =>
                          store.entity.stageDeviceSetting(
                            "ble_beacon_uuid",
                            (ev.currentTarget).value.trim(),
                            "cfg-ble_beacon_uuid",
                          )}
                      />
                    </div>`
                  : nothing}`,
            })
          : nothing}
      </div>
    </div>
  </section>`;
}
__latterExp(__exports, { renderDevicePresenceView: () => renderDevicePresenceView });
//# sourceURL=latter-studio/src/views/device-presence-view.ts
});
__latterDef("src/views/device-tools-view.ts", (__exports, __req) => {
const { renderCard, renderPrefControlRow, renderSelectRow, renderSettingsRow } = __req("src/components/controls.ts");
const { SECURITY_PIN_POLICY_OPTIONS } = __req("src/constants.ts");
const { t } = __req("src/i18n/index.ts");
const { focusSafe, html, nothing } = __req("src/lib/lit.ts");
const { fmtNumber } = __req("src/utils/format.ts");
const { renderDeviceEntityRow, renderDeviceOfflineBanner } = __req("src/views/device-overview-view.ts");
/**
 * Device Tools View (`tools`, `D-027`, `D-064`, `D-066`, `Q5`, `Q8`, `Q12`):
 * - Column 1: Diagnostics + collapsed Developer & telemetry drawer + `Open in Home Assistant`.
 * - Column 2: Perimeter security policy + write-only PIN (`focusSafe` + `requestClearSecurityPin`),
 *   Replace hardware (lossless Home Assistant Reconfigure + `Download backup`), & Danger zone.
 */
const INTERACTIVE_ENTITY_DOMAINS = new Set([
  "update",
  "button",
  "switch",
  "select",
  "number",
]);
function isValidTelemetryState(val) {
  const s = String(val ?? "").trim();
  return s !== "" && s !== "unknown" && s !== "unavailable";
}
const INTERNAL_NETWORK_BLOB_KEYS = new Set([
  "rpc_outbox",
  "hardware_manifest",
  "link_report",
]);
function isInternalNetworkBlobEntity(it) {
  if (it.key && INTERNAL_NETWORK_BLOB_KEYS.has(it.key)) return true;
  return Array.from(INTERNAL_NETWORK_BLOB_KEYS).some((k) => it.entity_id.endsWith(`_${k}`));
}
const SUMMARY_DUPLICATE_KEYS = new Set([
  "wifi_signal",
  "ip_address",
  "mac_address",
  "firmware_version",
  "latter_sdk",
  "sdk_rev",
]);
function isSummaryDuplicateNetworkEntity(it) {
  if (it.key && SUMMARY_DUPLICATE_KEYS.has(it.key)) return true;
  return Array.from(SUMMARY_DUPLICATE_KEYS).some((k) => it.entity_id.endsWith(`_${k}`));
}
function formatTelemetryDuration(totalSec) {
  if (!Number.isFinite(totalSec) || totalSec < 0) return "—";
  const secs = Math.round(totalSec);
  if (secs < 60) return `${secs}s`;
  const mins = Math.floor(secs / 60);
  if (mins < 60) {
    const remSec = secs % 60;
    return remSec > 0 ? `${mins}m ${remSec}s` : `${mins}m`;
  }
  const hours = Math.floor(mins / 60);
  if (hours < 24) {
    const remMin = mins % 60;
    return remMin > 0 ? `${hours}h ${remMin}m` : `${hours}h`;
  }
  const days = Math.floor(hours / 24);
  const remHr = hours % 24;
  return remHr > 0 ? `${days}d ${remHr}h` : `${days}d`;
}
function parseDeviceLinkReportRows(
  rawState,
  hass,
  overlay,
) {
  if (!isValidTelemetryState(rawState)) return [];
  const kv = new Map();
  for (const tok of rawState.trim().split(/\s+/)) {
    const eq = tok.indexOf("=");
    if (eq > 0 && eq < tok.length - 1) {
      kv.set(tok.slice(0, eq), tok.slice(eq + 1));
    }
  }
  if (!kv.size) return [];
  const rows = [];
  const upRaw = kv.get("up");
  if (upRaw !== undefined && Number.isFinite(Number(upRaw))) {
    rows.push({
      label: t("dev_tools.telem_uptime", undefined, overlay),
      value: formatTelemetryDuration(Number(upRaw)),
    });
  }
  const rstRaw = kv.get("rst");
  if (rstRaw) {
    rows.push({
      label: t("dev_tools.telem_last_reset", undefined, overlay),
      value: rstRaw,
      code: true,
    });
  }
  const discRaw = kv.get("disc");
  if (discRaw !== undefined && Number.isFinite(Number(discRaw))) {
    const btoNum = Number(kv.get("bto") ?? 0);
    const btoSuffix =
      Number.isFinite(btoNum) && btoNum > 0
        ? t(
            "dev_tools.telem_beacon_timeouts",
            { count: fmtNumber(btoNum, hass, 0) },
            overlay,
          )
        : "";
    rows.push({
      label: t("dev_tools.telem_wifi_disc", undefined, overlay),
      value: `${fmtNumber(Number(discRaw), hass, 0)}${btoSuffix}`,
    });
  }
  const rssiRaw = kv.get("rssi");
  if (rssiRaw && rssiRaw !== "na" && rssiRaw.includes("/")) {
    const [avgStr, minStr] = rssiRaw.split("/", 2);
    if (Number.isFinite(Number(avgStr)) && Number.isFinite(Number(minStr))) {
      rows.push({
        label: t("dev_tools.telem_wifi_avg_min", undefined, overlay),
        value: `${fmtNumber(Number(avgStr), hass, 0)} / ${fmtNumber(Number(minStr), hass, 0)} dBm`,
      });
    }
  }
  const haRaw = kv.get("ha");
  if (haRaw !== undefined && Number.isFinite(Number(haRaw))) {
    const gapNum = Number(kv.get("gap") ?? 0);
    const gapSuffix =
      Number.isFinite(gapNum) && gapNum > 0
        ? t("dev_tools.telem_max_gap", { duration: formatTelemetryDuration(gapNum) }, overlay)
        : "";
    rows.push({
      label: t("dev_tools.telem_ha_sessions", undefined, overlay),
      value: `${fmtNumber(Number(haRaw), hass, 0)}${gapSuffix}`,
    });
  }
  const slpRaw = kv.get("slp");
  if (slpRaw !== undefined && Number.isFinite(Number(slpRaw))) {
    const lsNum = Number(kv.get("ls") ?? 0);
    const lsSuffix =
      Number.isFinite(lsNum) && lsNum > 0
        ? t("dev_tools.telem_cycles", { count: fmtNumber(lsNum, hass, 0) }, overlay)
        : "";
    rows.push({
      label: t("dev_tools.telem_light_sleep", undefined, overlay),
      value: `${fmtNumber(Number(slpRaw), hass, 1)}%${lsSuffix}`,
    });
  }
  const nvsRaw = kv.get("nvs");
  if (nvsRaw && nvsRaw.includes("/")) {
    const parts = nvsRaw.split("/");
    if (parts.length >= 3 && parts.every((p) => Number.isFinite(Number(p)))) {
      rows.push({
        label: t("dev_tools.telem_nvs_writes", undefined, overlay),
        value: t(
          "dev_tools.telem_nvs_value",
          {
            writes: fmtNumber(Number(parts[0]), hass, 0),
            erases: fmtNumber(Number(parts[1]), hass, 0),
            maxMs: fmtNumber(Number(parts[2]), hass, 0),
          },
          overlay,
        ),
      });
    }
  }
  return rows;
}
function parseDeviceHardwareManifestRows(
  rawState,
  hass,
  overlay,
) {
  if (!isValidTelemetryState(rawState)) return [];
  const trimmed = rawState.trim();
  if (!trimmed.startsWith("{")) return [];
  let parsed;
  try {
    const obj = JSON.parse(trimmed);
    if (!obj || typeof obj !== "object" || Array.isArray(obj)) return [];
    parsed = obj;
  } catch {
    return [];
  }
  const rows = [];
  const board = typeof parsed.board === "string" ? parsed.board.trim() : "";
  if (board) {
    rows.push({
      label: t("dev_tools.telem_board", undefined, overlay),
      value: board,
      code: true,
    });
  }
  const chip = typeof parsed.chip === "string" ? parsed.chip.trim() : "";
  const psramMb = Number(parsed.psram_mb ?? 0);
  if (chip) {
    const psramSuffix =
      Number.isFinite(psramMb) && psramMb > 0
        ? t("dev_tools.telem_psram_suffix", { mb: fmtNumber(psramMb, hass, 0) }, overlay)
        : "";
    rows.push({
      label: t("dev_tools.telem_processor", undefined, overlay),
      value: `${chip}${psramSuffix}`,
    });
  }
  const hasDisplay = Number(parsed.display ?? 0) === 1 && parsed.shape !== "none";
  if (parsed.display !== undefined) {
    if (!hasDisplay) {
      rows.push({
        label: t("dev_tools.telem_display_panel", undefined, overlay),
        value: t("dev_tools.telem_headless", undefined, overlay),
      });
    } else {
      const w = Number(parsed.w ?? 0);
      const h = Number(parsed.h ?? 0);
      const shape = typeof parsed.shape === "string" ? parsed.shape.trim() : "";
      const panelTech =
        parsed.ips === 1 ? "IPS" : parsed.ips === 0 ? "AMOLED" : "";
      if (w > 0 && h > 0) {
        const parts = [`${w}×${h}`, shape, panelTech].filter(Boolean);
        rows.push({
          label: t("dev_tools.telem_display_panel", undefined, overlay),
          value: parts.join(" "),
        });
      }
    }
  }
  const traits = [];
  if (Number(parsed.touch) === 1) traits.push(t("dev_tools.trait_touch", undefined, overlay));
  if (Number(parsed.mic) === 1) traits.push(t("dev_tools.trait_mic", undefined, overlay));
  if (Number(parsed.spk) === 1) traits.push(t("dev_tools.trait_speaker", undefined, overlay));
  if (Number(parsed.mic) !== 1 && Number(parsed.spk) !== 1 && Number(parsed.audio) === 1) {
    traits.push(t("dev_tools.trait_audio", undefined, overlay));
  }
  if (Number(parsed.imu) === 1) traits.push(t("dev_tools.trait_imu", undefined, overlay));
  if (Number(parsed.battery) === 1) {
    traits.push(t("dev_tools.trait_battery", undefined, overlay));
  }
  if (Number(parsed.wearable) === 1) {
    traits.push(t("dev_tools.trait_wearable", undefined, overlay));
  }
  if (Number(parsed.stationary) === 1) {
    traits.push(t("dev_tools.trait_stationary", undefined, overlay));
  }
  if (traits.length) {
    rows.push({
      label: t("dev_tools.telem_traits", undefined, overlay),
      value: traits.join(", "),
    });
  }
  return rows;
}
function renderDeviceToolsView(store) {
  const data = store.state;
  const cfg = data?.config || {};
  const live = data?.live || {};
  const links = data?.links || {};
  const esp = data?.esphome;
  const isBleOnly = cfg.kind === "ble_tag";
  const curDevEntry =
    (data?.system_devices || []).find((d) => d.subentry_id === store.activeSubentryId) ||
    (data?.system_devices || []).find((d) => d.is_current);
  const networkItems = store.entity.getSectionItems("network");
  const developerItems = store.entity.getSectionItems("developer");
  const networkControlItems = networkItems.filter((it) =>
    INTERACTIVE_ENTITY_DOMAINS.has(it.domain),
  );
  const extraNetworkSensorItems = networkItems.filter(
    (it) =>
      !INTERACTIVE_ENTITY_DOMAINS.has(it.domain) &&
      !isInternalNetworkBlobEntity(it) &&
      !isSummaryDuplicateNetworkEntity(it),
  );
  const findNetworkState = (key) => {
    const match = networkItems.find(
      (it) => it.key === key || it.entity_id.endsWith(`_${key}`),
    );
    return isValidTelemetryState(match?.state) ? String(match?.state).trim() : "";
  };
  const winRow = (curDevEntry?.ble_survey_rows || []).find((r) => r.is_winner);
  let signalText = store.t("common.unknown");
  if (!isBleOnly) {
    if (curDevEntry?.wifi_rssi !== null && curDevEntry?.wifi_rssi !== undefined) {
      signalText = `${fmtNumber(curDevEntry.wifi_rssi, store.hass, 0)} dBm`;
    } else {
      const rawWifi = findNetworkState("wifi_signal");
      if (rawWifi) {
        signalText = Number.isFinite(Number(rawWifi))
          ? `${fmtNumber(Number(rawWifi), store.hass, 0)} dBm`
          : rawWifi;
      }
    }
  } else if (winRow && winRow.effective_rssi !== null) {
    signalText = `${fmtNumber(winRow.effective_rssi, store.hass, 0)} dBm`;
  }
  const rawSw = String(
    live.device_sw_version || esp?.device?.sw_version || findNetworkState("firmware_version") || "",
  ).replace(/^v/i, "");
  const fwVersionText = rawSw ? `v${rawSw}` : store.t("common.unknown");
  const modelText = curDevEntry?.model_label || esp?.device?.model || store.t("common.unknown");
  const ipStr = curDevEntry?.ip_address || findNetworkState("ip_address") || "";
  const macStr = esp?.device?.mac || findNetworkState("mac_address") || "";
  const weatherSimPref = store.entity.getPref("weather_sim_condition");
  const devControlItems = developerItems.filter(
    (it) =>
      INTERACTIVE_ENTITY_DOMAINS.has(it.domain) &&
      !it.pref_key &&
      it.key !== "weather_sim_condition",
  );
  const devSensorItems = developerItems.filter(
    (it) => !INTERACTIVE_ENTITY_DOMAINS.has(it.domain),
  );
  const linkReportEntity = networkItems.find(
    (it) => it.key === "link_report" || it.entity_id.endsWith("_link_report"),
  );
  const manifestEntity = networkItems.find(
    (it) => it.key === "hardware_manifest" || it.entity_id.endsWith("_hardware_manifest"),
  );
  const linkRows = parseDeviceLinkReportRows(
    linkReportEntity?.state,
    store.hass,
    store.localeOverlay,
  );
  const manifestRows = parseDeviceHardwareManifestRows(
    manifestEntity?.state,
    store.hass,
    store.localeOverlay,
  );
  const hasDeveloperDrawer =
    !isBleOnly &&
    Boolean(
      weatherSimPref ||
        devControlItems.length ||
        devSensorItems.length ||
        linkRows.length ||
        manifestRows.length,
    );
  const curPinPolicy = String(cfg.security_pin_policy || "auto");
  const effectivePinPolicyLabel = store.tPrefOption(
    "security_pin_policy",
    live.effective_security_pin_policy || curPinPolicy,
  );
  const localizedPinPolicyOptions = SECURITY_PIN_POLICY_OPTIONS.map((opt) => ({
    value: opt.value,
    label: store.tPrefOption("security_pin_policy", opt.value),
  }));
  const hasPin = store.hasConfiguredSecurityPin;
  const hasOpenInHa = Boolean(links.esphome_device_id || links.latter_device_id);
  return html`<section id="view-tools">
    ${renderDeviceOfflineBanner(store)}

    <div class="columns">
      <div class="column">
        ${renderCard({
          id: "card-device-diagnostics",
          handoffActive: store.isHandoffTarget("card-device-diagnostics"),
          heading: html`<h3 class="card-title">${store.t("card.diagnostics")}</h3>`,
          contentClass: "stack",
          body: html`${networkControlItems.length
              ? html`<div class="settings-list">
                  ${networkControlItems.map((it) => renderDeviceEntityRow(store, it))}
                </div>`
              : nothing}
            <div class="kv-list">
              ${isBleOnly
                ? html`<div class="kv-row">
                      <span>${store.t("dev_tools.ble_signal")}</span>
                      <strong>${signalText}</strong>
                    </div>
                    <div class="kv-row">
                      <span>${store.t("dev_tools.ble_target")}</span>
                      <strong>
                        ${cfg.ble_target_address
                          ? html`<code>${cfg.ble_target_address}</code>`
                          : store.t("common.unknown")}
                      </strong>
                    </div>`
                : html`<div class="kv-row">
                      <span>${store.t("dev_tools.model")}</span>
                      <strong>${modelText}</strong>
                    </div>
                    <div class="kv-row">
                      <span>${store.t("dev_tools.esphome_node")}</span>
                      <strong>
                        <code id="diag-node-name">
                          ${cfg.device_slug || store.t("common.unknown")}
                        </code>
                      </strong>
                    </div>
                    <div class="kv-row">
                      <span>${store.t("dev_tools.firmware_version")}</span>
                      <strong>${fwVersionText}</strong>
                    </div>
                    <div class="kv-row">
                      <span>${store.t("dev_tools.latter_sdk")}</span>
                      <strong id="diag-sdk-rev">
                        ${live.sdk_rev || store.t("common.unknown")}
                      </strong>
                    </div>
                    <div class="kv-row">
                      <span>${store.t("dev_tools.wifi_signal")}</span>
                      <strong>${signalText}</strong>
                    </div>
                    <div class="kv-row">
                      <span>${store.t("dev_tools.ip_address")}</span>
                      <strong>
                        ${ipStr ? html`<code>${ipStr}</code>` : store.t("common.unknown")}
                      </strong>
                    </div>
                    ${macStr
                      ? html`<div class="kv-row">
                          <span>${store.t("dev_tools.mac_address")}</span>
                          <strong><code>${macStr}</code></strong>
                        </div>`
                      : nothing}
                    ${extraNetworkSensorItems.map((it) => renderDeviceEntityRow(store, it))}`}
            </div>
            <div class="settings-list">
              ${links.latter_device_id || links.entry_id
                ? renderSettingsRow({
                    id: "row-diagnostics",
                    label: store.t("dev_tools.diagnostics_file_label"),
                    description: store.t("dev_tools.diagnostics_file_desc"),
                    control: html`<button
                      type="button"
                      @click=${() => void store.tools.downloadDeviceDiagnostics()}
                      class="btn btn-secondary btn-compact"
                    >
                      ${store.t("action.download_diagnostics")}
                    </button>`,
                  })
                : nothing}
              ${isBleOnly
                ? renderSettingsRow({
                    label: store.t("dev_tools.backup_row_label"),
                    description: store.t("dev_tools.backup_row_desc"),
                    control: html`<button
                      type="button"
                      @click=${() => void store.tools.exportBackup(store.activeSubentryId)}
                      class="btn btn-secondary btn-compact"
                    >
                      ${store.t("action.download_backup")}
                    </button>`,
                  })
                : nothing}
            </div>
            ${hasDeveloperDrawer
              ? html`<details class="sub-collapsible">
                  <summary>${store.t("card.developer_telemetry")}</summary>
                  <div class="card-content">
                    ${weatherSimPref || devControlItems.length
                      ? html`<div class="settings-list">
                          ${weatherSimPref ? renderPrefControlRow(store, weatherSimPref) : nothing}
                          ${devControlItems.map((it) => renderDeviceEntityRow(store, it))}
                        </div>`
                      : nothing}
                    ${devSensorItems.length || linkRows.length || manifestRows.length
                      ? html`<div class="kv-list">
                          ${devSensorItems.map((it) => renderDeviceEntityRow(store, it))}
                          ${[...linkRows, ...manifestRows].map(
                            (row) => html`<div class="kv-row">
                              <span>${row.label}</span>
                              <strong>
                                ${row.code ? html`<code>${row.value}</code>` : row.value}
                              </strong>
                            </div>`,
                          )}
                        </div>`
                      : nothing}
                  </div>
                </details>`
              : nothing}`,
          footerActions: hasOpenInHa
            ? html`<button
                type="button"
                id="btn-tools-open-in-ha"
                @click=${() => store.openDeviceInHa(isBleOnly)}
                class="btn btn-text"
              >
                ${store.t("action.open_in_ha")}
              </button>`
            : nothing,
        })}
      </div>

      <div class="column">
        ${!isBleOnly
          ? html`${renderCard({
                id: "card-device-security",
                title: store.t("card.perimeter_security"),
                subtitle: store.t("dev_tools.perimeter_subtitle"),
                contentClass: "settings-list",
                body: html`${renderSelectRow({
                    id: "cfg-security_pin_policy",
                    label: store.tPrefLabel("security_pin_policy"),
                    description: html`${store.t("dev_tools.pin_policy_desc_prefix")}
                      <strong>${effectivePinPolicyLabel}</strong>.`,
                    value: curPinPolicy,
                    rawOptions: localizedPinPolicyOptions,
                    onChange: (val) =>
                      store.entity.stageDeviceSetting(
                        "security_pin_policy",
                        val,
                        "cfg-security_pin_policy",
                      ),
                  })}
                  ${renderSettingsRow({
                    label: store.t("dev_tools.security_pin_label"),
                    description: store.t("dev_tools.security_pin_desc"),
                    stacked: true,
                    control: html`<div class="input-action-row">
                      <span class="chip ${hasPin ? "chip-success" : ""}">
                        ${hasPin
                          ? store.t("status.pin_configured")
                          : store.t("status.pin_not_set")}
                      </span>
                      <input
                        type="password"
                        id="dev-security-pin-input"
                        inputmode="numeric"
                        pattern="[0-9]*"
                        autocomplete="new-password"
                        aria-label=${store.t("dev_tools.pin_input_aria")}
                        placeholder=${hasPin
                          ? store.t("dev_tools.pin_placeholder_replace")
                          : store.t("dev_tools.pin_placeholder_new")}
                        .value=${focusSafe(store.devicePinDraft)}
                        @input=${(ev) => {
                          store.devicePinDraft = (ev.currentTarget).value;
                          store.host.requestUpdate();
                        }}
                      />
                      <button
                        type="button"
                        ?disabled=${store.pinBusy || !store.devicePinDraft.trim()}
                        @click=${() => void store.tools.saveSecurityPin("device")}
                        class="btn btn-primary btn-compact"
                      >
                        ${store.t("dev_tools.save_pin")}
                      </button>
                      ${hasPin
                        ? html`<button
                            type="button"
                            ?disabled=${store.pinBusy}
                            @click=${() => store.tools.requestClearSecurityPin("device")}
                            class="btn btn-danger btn-compact"
                          >
                            ${store.t("dev_tools.clear_pin")}
                          </button>`
                        : nothing}
                    </div>`,
                  })}`,
              })}
              ${renderCard({
                id: "card-replace-hardware",
                heading: html`<h3 class="card-title">${store.t("card.replace_hardware")}</h3>`,
                contentClass: "stack",
                body: html`<p class="row-description">
                    ${store.t("card.replace_hardware_body")}
                  </p>
                  <div class="input-action-row">
                    <button
                      type="button"
                      id="btn-reconfigure-hardware"
                      @click=${() => store.openDeviceInHa(true)}
                      class="btn btn-secondary"
                    >
                      ${store.t("dev_tools.reconfigure_in_ha")}
                    </button>
                    <button
                      type="button"
                      id="btn-download-device-backup"
                      @click=${() => void store.tools.exportBackup(store.activeSubentryId)}
                      class="btn btn-text"
                    >
                      ${store.t("action.download_backup")}
                    </button>
                  </div>`,
              })}`
          : nothing}

        ${renderCard({
          heading: html`<h3 class="card-title">${store.t("card.danger_zone")}</h3>`,
          danger: true,
          contentClass: "settings-list",
          body: html`${renderSettingsRow({
              label: store.t("dev_tools.reset_defaults_label"),
              description: store.t("dev_tools.reset_defaults_desc"),
              control: html`<button
                type="button"
                @click=${() => store.tools.openResetDeviceModal()}
                class="btn btn-danger"
              >
                ${store.t("dev_tools.reset_defaults_label")}
              </button>`,
            })}
            ${renderSettingsRow({
              label: store.t("dev_tools.remove_device_label"),
              description: store.t("dev_tools.remove_device_desc"),
              control: html`<button
                type="button"
                @click=${() =>
                  store.tools.openRemoveDeviceModal(
                    store.activeSubentryId,
                    data?.title || cfg.device_slug || store.t("devices.col_device"),
                  )}
                class="btn btn-danger"
              >
                ${store.t("dev_tools.remove_device_label")}
              </button>`,
            })}`,
        })}
      </div>
    </div>
  </section>`;
}
__latterExp(__exports, { parseDeviceLinkReportRows: () => parseDeviceLinkReportRows, parseDeviceHardwareManifestRows: () => parseDeviceHardwareManifestRows, renderDeviceToolsView: () => renderDeviceToolsView });
//# sourceURL=latter-studio/src/views/device-tools-view.ts
});
__latterDef("src/views/devices-discovered-view.ts", (__exports, __req) => {
const { renderCard, renderSettingsRow } = __req("src/components/controls.ts");
const { focusSafe, html, nothing, repeat } = __req("src/lib/lit.ts");
const { entityLabel, fmtNumber } = __req("src/utils/format.ts");
/**
 * Discovered Devices View (`discovered_devices`, `D-041`, `D-066`, `Q12`):
 * Two stacked full-width onboarding cards:
 * 1. `Latter Devices` — Unbound ESPHome Devices running Latter firmware ready for adoption or ignore,
 *    plus collapsible `Ignored (N)` restore drawer and Web Installer / Getting started empty-state links.
 * 2. `Bluetooth devices` — Filterable (`c.is_tracker`), sortable, and pausable BLE trackers, phones,
 *    and named advertisements with unique keyed DOM identity.
 */
const WEB_INSTALLER_URL = "https://slampton.github.io/esphome-latter-core/";
const GETTING_STARTED_URL =
  "https://github.com/slampton/ha-latter/blob/main/docs/getting-started.md";
function candidateTitle(store, c) {
  return c.title || c.target_address || store.t("status.ble_tag");
}
function compareBleCandidates(
  store,
  a,
  b,
  sortMode,
) {
  const aTitle = candidateTitle(store, a);
  const bTitle = candidateTitle(store, b);
  const aAddr = a.target_address || "";
  const bAddr = b.target_address || "";
  if (sortMode === "rssi") {
    const aHas = a.rssi !== null && a.rssi !== undefined;
    const bHas = b.rssi !== null && b.rssi !== undefined;
    if (aHas !== bHas) return aHas ? -1 : 1;
    if (aHas && bHas && a.rssi !== b.rssi) return Number(b.rssi) - Number(a.rssi);
  } else if (sortMode === "area") {
    const aArea = String(a.area_name || "").trim();
    const bArea = String(b.area_name || "").trim();
    if (Boolean(aArea) !== Boolean(bArea)) return aArea ? -1 : 1;
    if (aArea && bArea) {
      const areaCmp = aArea.localeCompare(bArea, undefined, { sensitivity: "base" });
      if (areaCmp !== 0) return areaCmp;
    }
  }
  const nameCmp = aTitle.localeCompare(bTitle, undefined, { sensitivity: "base" });
  if (nameCmp !== 0) return nameCmp;
  return aAddr.localeCompare(bAddr);
}
function renderDevicesDiscoveredView(store) {
  const data = store.state;
  const latterCandidates = data?.discovered_latter_devices || [];
  const ignoredLatter = data?.ignored_latter_devices || [];
  const isPaused = Boolean(store.discoveredBlePaused);
  const bleCandidates =
    isPaused && Array.isArray(store.discoveredBleFrozenSnapshot)
      ? store.discoveredBleFrozenSnapshot
      : data?.discovered_ble_devices || [];
  const groups = data?.device_groups || [];
  const persons = data?.catalog?.persons || [];
  const groupNameMap = new Map();
  for (const g of groups) {
    if (g && g.id) {
      groupNameMap.set(g.id, g.name || entityLabel(g.id.replace(/_/g, " ")));
    }
  }
  const kindFilter = store.discoveredBleKindFilter || "all";
  const sortMode = store.discoveredBleSort || "name";
  const query = (store.discoveredBleSearch || "").trim().toLowerCase();
  const filteredBle = bleCandidates
    .filter((c) => {
      if (kindFilter === "tracker" && !c.is_tracker) return false;
      if (kindFilter === "named" && c.is_tracker) return false;
      if (!query) return true;
      const haystack = [c.title, c.target_address, c.kind, c.area_name]
        .filter(Boolean)
        .join(" ")
        .toLowerCase();
      return haystack.includes(query);
    })
    .slice()
    .sort((a, b) => compareBleCandidates(store, a, b, sortMode));
  const latterDraftGroups = store.discoveredLatterGroupDrafts;
  const latterDraftPersons = store.discoveredLatterPersonDrafts;
  const bleDraftPersons = store.discoveredBlePersonDrafts;
  return html`<section id="view-discovered_devices">
    ${renderCard({
      id: "card-discovered-latter",
      handoffActive: store.isHandoffTarget("card-discovered-latter"),
      title: store.t("discovered.latter_devices"),
      headerActions: html`<button
        type="button"
        @click=${() => store.openHaPage("/config/integrations/integration/latter")}
        class="btn btn-secondary"
      >
        ${store.t("action.open_integration")}
      </button>`,
      contentClass: "stack",
      body: html`<div id="latter-adopt-table-box" class="settings-list">
          ${latterCandidates.length
            ? repeat(
                latterCandidates,
                (d, idx) => `${d.esphome_device_id || d.node_name}::${idx}`,
                (d) => {
                  const title =
                    d.title || d.node_name || store.t("discovered.default_latter_title");
                  const defGrpName =
                    groupNameMap.get(d.default_group) ||
                    entityLabel((d.default_group || "custom").replace(/_/g, " "));
                  const meta = [
                    d.model_label || store.t("discovered.default_latter_model"),
                  ];
                  if (d.node_name) {
                    meta.push(store.t("discovered.meta_node", { node: d.node_name }));
                  }
                  if (d.area_name) {
                    meta.push(store.t("discovered.meta_area", { area: d.area_name }));
                  }
                  const curGrp = latterDraftGroups.get(d.esphome_device_id) || "auto";
                  const curPerson = latterDraftPersons.get(d.esphome_device_id) || "";
                  return renderSettingsRow({
                    label: title,
                    description: meta.join(" • "),
                    control: html`<select
                        aria-label=${store.t("discovered.group_select_aria", { title })}
                        .value=${curGrp}
                        @change=${(ev) => {
                          latterDraftGroups.set(
                            d.esphome_device_id,
                            (ev.currentTarget).value || "auto",
                          );
                          store.host.requestUpdate();
                        }}
                      >
                        <option value="auto" ?selected=${curGrp === "auto"}>
                          ${store.t("discovered.auto_group_option", { group: defGrpName })}
                        </option>
                        <option value="custom" ?selected=${curGrp === "custom"}>
                          ${store.t("common.custom")}
                        </option>
                        ${groups.map(
                          (g) =>
                            html`<option value=${g.id} ?selected=${curGrp === g.id}>
                              ${g.name}
                            </option>`,
                        )}
                      </select>
                      <select
                        aria-label=${store.t("discovered.person_select_aria", { title })}
                        .value=${curPerson}
                        @change=${(ev) => {
                          latterDraftPersons.set(
                            d.esphome_device_id,
                            (ev.currentTarget).value || "",
                          );
                          store.host.requestUpdate();
                        }}
                      >
                        <option value="" ?selected=${!curPerson}>
                          ${store.t("common.no_person")}
                        </option>
                        ${persons.map(
                          (p) =>
                            html`<option value=${p.id} ?selected=${curPerson === p.id}>
                              ${p.name}
                            </option>`,
                        )}
                      </select>
                      <button
                        type="button"
                        @click=${() =>
                          void store.tools.adoptLatterDevice(
                            d.esphome_device_id,
                            title,
                            latterDraftGroups.get(d.esphome_device_id) || "auto",
                            latterDraftPersons.get(d.esphome_device_id) || "",
                          )}
                        class="btn btn-primary btn-compact"
                      >
                        ${store.t("action.adopt")}
                      </button>
                      <button
                        type="button"
                        aria-label=${store.t("discovered.ignore_aria", { title })}
                        @click=${() =>
                          void store.tools.ignoreDiscoveredDevice(d.esphome_device_id, title)}
                        class="btn btn-text btn-compact"
                      >
                        ${store.t("action.ignore")}
                      </button>`,
                  });
                },
              )
            : html`<div class="stack">
                <p class="empty-state">${store.t("discovered.empty_latter")}</p>
                <div class="input-action-row">
                  <a
                    href=${WEB_INSTALLER_URL}
                    target="_blank"
                    rel="noopener noreferrer"
                    class="btn btn-secondary btn-compact"
                  >
                    ${store.t("discovered.web_installer")}
                  </a>
                  <a
                    href=${GETTING_STARTED_URL}
                    target="_blank"
                    rel="noopener noreferrer"
                    class="btn btn-text btn-compact"
                  >
                    ${store.t("discovered.getting_started")}
                  </a>
                </div>
              </div>`}
        </div>
        ${ignoredLatter.length > 0
          ? html`<details
              id="discovered-ignored-drawer"
              class="sub-collapsible summary-row"
              ?open=${store.discoveredIgnoredOpen}
              @toggle=${(ev) => {
                store.discoveredIgnoredOpen = (ev.currentTarget).open;
              }}
            >
              <summary>
                <span class="row-label">
                  ${store.t("discovered.ignored_count", {
                    count: fmtNumber(ignoredLatter.length, store.hass, 0),
                  })}
                </span>
                <span class="summary-row-end">
                  <span class="summary-chevron" aria-hidden="true">▾</span>
                </span>
              </summary>
              <div class="card-content settings-list">
                ${repeat(
                  ignoredLatter,
                  (d, idx) => `ignored::${d.esphome_device_id || d.node_name}::${idx}`,
                  (d) => {
                    const title =
                      d.title || d.node_name || store.t("discovered.default_latter_title");
                    const meta = [
                      d.model_label || store.t("discovered.default_latter_model"),
                    ];
                    if (d.node_name) {
                      meta.push(store.t("discovered.meta_node", { node: d.node_name }));
                    }
                    if (d.area_name) {
                      meta.push(store.t("discovered.meta_area", { area: d.area_name }));
                    }
                    return renderSettingsRow({
                      label: title,
                      description: meta.join(" • "),
                      control: html`<button
                        type="button"
                        aria-label=${store.t("discovered.restore_aria", { title })}
                        @click=${() =>
                          void store.tools.unignoreDiscoveredDevice(d.esphome_device_id, title)}
                        class="btn btn-secondary btn-compact"
                      >
                        ${store.t("action.unignore")}
                      </button>`,
                    });
                  },
                )}
              </div>
            </details>`
          : nothing}`,
    })}

    ${renderCard({
      id: "card-discovered-ble",
      handoffActive: store.isHandoffTarget("card-discovered-ble"),
      title: store.t("discovered.bluetooth_devices"),
      headerActions: html`<input
          type="search"
          id="discovered-ble-search"
          aria-label=${store.t("discovered.search_ble_aria")}
          placeholder=${store.t("discovered.search_ble_placeholder")}
          .value=${focusSafe(store.discoveredBleSearch)}
          @input=${(ev) => {
            store.discoveredBleSearch = (ev.currentTarget).value;
            store.host.requestUpdate();
          }}
        />
        <select
          id="discovered-ble-filter"
          aria-label=${store.t("discovered.filter_ble_aria")}
          .value=${kindFilter}
          @change=${(ev) => {
            const val = (ev.currentTarget).value;
            store.discoveredBleKindFilter =
              val === "tracker" || val === "named" ? val : "all";
            store.host.requestUpdate();
          }}
        >
          <option value="all" ?selected=${kindFilter === "all"}>
            ${store.t("discovered.all_ble")}
          </option>
          <option value="tracker" ?selected=${kindFilter === "tracker"}>
            ${store.t("discovered.phones_trackers")}
          </option>
          <option value="named" ?selected=${kindFilter === "named"}>
            ${store.t("discovered.named_ble")}
          </option>
        </select>
        <select
          id="discovered-ble-sort"
          aria-label=${store.t("discovered.sort_ble_aria")}
          .value=${sortMode}
          @change=${(ev) => {
            const val = (ev.currentTarget).value;
            store.discoveredBleSort =
              val === "rssi" || val === "area" ? val : "name";
            store.host.requestUpdate();
          }}
        >
          <option value="name" ?selected=${sortMode === "name"}>
            ${store.t("discovered.sort_name")}
          </option>
          <option value="rssi" ?selected=${sortMode === "rssi"}>
            ${store.t("discovered.sort_rssi")}
          </option>
          <option value="area" ?selected=${sortMode === "area"}>
            ${store.t("discovered.sort_area")}
          </option>
        </select>
        <button
          type="button"
          id="btn-pause-discovered-ble"
          aria-pressed=${String(isPaused)}
          @click=${() => store.toggleDiscoveredBlePause()}
          class="btn btn-secondary"
        >
          ${isPaused ? store.t("discovered.resume_list") : store.t("discovered.pause_list")}
        </button>
        <button
          type="button"
          @click=${() => store.tools.openAddBleModal()}
          class="btn btn-primary"
        >
          ${store.t("action.add_ble_tag")}
        </button>`,
      contentClass: "settings-list",
      body: html`<div id="ble-adopt-table-box" class="settings-list">
        ${isPaused
          ? html`<p class="help-text">
              ${store.t("discovered.paused_hint", {
                count: fmtNumber(filteredBle.length, store.hass, 0),
              })}
            </p>`
          : nothing}
        ${filteredBle.length
          ? repeat(
              filteredBle,
              (c, idx) =>
                `${(c.target_address || candidateTitle(store, c)).toLowerCase()}::${idx}`,
              (c) => {
                const title = candidateTitle(store, c);
                const addr = c.target_address || "";
                const addrKey = (addr || title).toLowerCase();
                const curPerson = bleDraftPersons.get(addrKey) || "";
                const kindLabel = c.kind || store.t("discovered.default_ble_kind");
                const showAddr =
                  Boolean(addr) && !kindLabel.toLowerCase().includes(addr.toLowerCase());
                const meta = [kindLabel, ...(showAddr ? [addr] : [])];
                if (c.rssi !== null && c.rssi !== undefined) {
                  meta.push(`${fmtNumber(c.rssi, store.hass, 0)} dBm`);
                }
                if (c.area_name) {
                  meta.push(store.t("discovered.meta_nearest_area", { area: c.area_name }));
                }
                return renderSettingsRow({
                  label: title,
                  description: meta.join(" • "),
                  control: html`<select
                      aria-label=${store.t("discovered.person_select_aria", { title })}
                      .value=${curPerson}
                      @change=${(ev) => {
                        bleDraftPersons.set(
                          addrKey,
                          (ev.currentTarget).value || "",
                        );
                        store.host.requestUpdate();
                      }}
                    >
                      <option value="" ?selected=${!curPerson}>
                        ${store.t("common.no_person")}
                      </option>
                      ${persons.map(
                        (p) =>
                          html`<option value=${p.id} ?selected=${curPerson === p.id}>
                            ${p.name}
                          </option>`,
                      )}
                    </select>
                    <button
                      type="button"
                      @click=${() =>
                        void store.tools.quickAdoptBleCandidate(
                          title,
                          addr,
                          bleDraftPersons.get(addrKey) || "",
                        )}
                      class="btn btn-secondary btn-compact"
                    >
                      ${store.t("action.adopt")}
                    </button>`,
                });
              },
            )
          : html`<p class="empty-state">
              ${bleCandidates.length
                ? store.t("discovered.empty_ble_filtered")
                : store.t("discovered.empty_ble_none")}
            </p>`}
      </div>`,
    })}
  </section>`;
}
__latterExp(__exports, { renderDevicesDiscoveredView: () => renderDevicesDiscoveredView });
//# sourceURL=latter-studio/src/views/devices-discovered-view.ts
});
__latterDef("src/views/devices-list-view.ts", (__exports, __req) => {
const { renderCard, renderSortHeader } = __req("src/components/controls.ts");
const { html, nothing, repeat } = __req("src/lib/lit.ts");
const { entityLabel } = __req("src/utils/format.ts");
/**
 * Managed Devices View (`select_device_prompt`, `D-041`, `D-048`, `D-061`, `D-066`):
 * - Sentence-case `store.t(...)` labels with `Inventory` card heading when filter is `"all"` (`R-8`).
 * - Typed `d.status_code` filtering, sorting, and status dot classes (`D-15`).
 * - Semantic `<a href="/latter/devices/<id>">` Device link in `.col-name` (`D-10`) + humanized `d.model_label` (`Q12`).
 * - Actionable 0-Device onboarding CTAs (`E-10`).
 */
function effectiveStatusCode(d) {
  if (d.status_code) return d.status_code;
  const lbl = String(d.status_label || "").trim().toLowerCase();
  if (lbl.includes("update")) return "update";
  if (lbl === "away") return "away";
  if (lbl === "scanning") return "scanning";
  if (lbl === "online" || d.is_online) return "online";
  return "offline";
}
function statusRankByCode(code) {
  if (code === "update") return 1;
  if (code === "offline" || code === "away" || code === "scanning") return 2;
  return 3;
}
function localizedStatusLabel(store, d, code) {
  switch (code) {
    case "online":
      return store.t("status.online");
    case "update":
      return store.t("status.update");
    case "away":
      return store.t("status.away");
    case "scanning":
      return store.t("status.scanning");
    case "offline":
      return d.status_label && d.status_label.toLowerCase() === "sleeping"
        ? store.t("status.sleeping")
        : store.t("status.offline");
    default:
      return d.status_label || store.t("common.unknown");
  }
}
function renderDevicesListView(store) {
  const allDevices = store.state?.system_devices || [];
  const groups = store.state?.device_groups || [];
  const rawCat = store.deviceCategoryFilter || "all";
  const hasPhones = allDevices.some((d) => d.kind === "ble_tag" && d.ble_category === "phone");
  const hasBleTags = allDevices.some((d) => d.kind === "ble_tag" && d.ble_category !== "phone");
  const hasAssignedPeople = allDevices.some((d) => Boolean(d.assigned_person));
  const hasUpdates = allDevices.some((d) => effectiveStatusCode(d) === "update");
  const hasCustomGroup = allDevices.some(
    (d) => d.kind !== "ble_tag" && (!d.device_group || d.device_group === "custom"),
  );
  const baseCategories = [
    { id: "all", label: store.t("devices.all") },
    { id: "online", label: store.t("devices.online") },
    { id: "roaming", label: store.t("devices.roaming") },
    { id: "stationary", label: store.t("devices.stationary") },
  ];
  if (rawCat === "native") {
    baseCategories.push({ id: "native", label: store.t("devices.latter_displays") });
  }
  if (rawCat === "ble_tracked") {
    baseCategories.push({ id: "ble_tracked", label: store.t("devices.ble_tracked") });
  }
  if (hasPhones || rawCat === "phone") {
    baseCategories.push({ id: "phone", label: store.t("devices.phones") });
  }
  if (hasBleTags || rawCat === "ble_tag") {
    baseCategories.push({ id: "ble_tag", label: store.t("devices.ble_tags") });
  }
  if (hasAssignedPeople || rawCat === "assigned_person") {
    baseCategories.push({ id: "assigned_person", label: store.t("devices.assigned_person") });
  }
  if (hasUpdates || rawCat === "updates") {
    baseCategories.push({ id: "updates", label: store.t("devices.updates_available") });
  }
  for (const g of groups) {
    if (!g || !g.id || g.id === "custom") continue;
    const grpFilterId = `group:${g.id}`;
    const hasMembers = allDevices.some((d) => d.kind !== "ble_tag" && d.device_group === g.id);
    if (hasMembers || rawCat === grpFilterId) {
      baseCategories.push({
        id: grpFilterId,
        label: store.t("devices.group_prefix", { name: entityLabel(g.name) }),
      });
    }
  }
  if (hasCustomGroup || rawCat === "group:custom") {
    baseCategories.push({
      id: "group:custom",
      label: store.t("devices.group_prefix", { name: store.t("common.custom") }),
    });
  }
  const activeCategory = baseCategories.find((o) => o.id === rawCat) || baseCategories[0];
  const cat = activeCategory.id;
  const cardHeadingTitle =
    cat === "all" ? store.t("devices.inventory_heading") : activeCategory.label;
  const filtered = allDevices.filter((d) => {
    const isBleTag = d.kind === "ble_tag";
    const isRoaming = isBleTag || Boolean(d.is_roaming);
    if (cat === "online") return Boolean(d.is_online);
    if (cat === "native") return Boolean(d.is_latter_native);
    if (cat === "ble_tracked") return Boolean(d.ble_tracked);
    if (cat === "assigned_person") return Boolean(d.assigned_person);
    if (cat === "roaming") return isRoaming;
    if (cat === "stationary") return !isRoaming;
    if (cat === "phone") return isBleTag && d.ble_category === "phone";
    if (cat === "ble_tag") return isBleTag && d.ble_category !== "phone";
    if (cat === "updates") return effectiveStatusCode(d) === "update";
    if (cat === "group:custom") {
      return !isBleTag && (!d.device_group || d.device_group === "custom");
    }
    if (cat.startsWith("group:")) return !isBleTag && d.device_group === cat.slice(6);
    return true;
  });
  filtered.sort((a, b) => {
    let cmp = 0;
    if (store.deviceSortField === "status") {
      cmp = statusRankByCode(effectiveStatusCode(a)) - statusRankByCode(effectiveStatusCode(b));
      if (cmp === 0) cmp = (a.title || "").localeCompare(b.title || "");
    } else if (store.deviceSortField === "model") {
      cmp = (a.model_label || "").localeCompare(b.model_label || "");
    } else if (store.deviceSortField === "area") {
      cmp = (a.area_label || "").localeCompare(b.area_label || "");
    } else if (store.deviceSortField === "group") {
      cmp = (a.device_group_name || "").localeCompare(b.device_group_name || "");
    } else {
      cmp = (a.title || "").localeCompare(b.title || "");
    }
    return store.deviceSortAsc ? cmp : -cmp;
  });
  return html`<section id="view-select_device_prompt">
    ${renderCard({
      title: cardHeadingTitle,
      headerActions: allDevices.length
        ? html`<select
            id="device-category-filter"
            aria-label=${store.t("devices.filter_aria")}
            .value=${cat}
            @change=${(ev) => {
              store.deviceCategoryFilter = (ev.currentTarget).value || "all";
              store.host.requestUpdate();
            }}
          >
            ${baseCategories.map(
              (o) => html`<option value=${o.id} ?selected=${o.id === cat}>${o.label}</option>`,
            )}
          </select>`
        : nothing,
      footerActions: !allDevices.length
        ? html`<button
              type="button"
              @click=${() => store.openDiscoveredDevices()}
              class="btn btn-primary"
            >
              ${store.t("devices.open_discovered")}
            </button>
            <button
              type="button"
              @click=${() => store.tools.openAddBleModal()}
              class="btn btn-secondary"
            >
              ${store.t("action.add_ble_tag")}
            </button>
            <button
              type="button"
              @click=${() => store.openSystemSection("area_tracking")}
              class="btn btn-text"
            >
              ${store.t("devices.open_area_presence")}
            </button>`
        : nothing,
      body: filtered.length
        ? html`<div class="table-wrap">
            <table class="data-table">
              <thead>
                <tr>
                  ${renderSortHeader(store, "title", store.t("devices.col_device"))}
                  ${renderSortHeader(store, "model", store.t("devices.col_model"))}
                  ${renderSortHeader(store, "area", store.t("devices.col_area"))}
                  ${renderSortHeader(store, "group", store.t("devices.col_group"))}
                  ${renderSortHeader(store, "status", store.t("devices.col_status"))}
                  <th><span class="sort-btn" aria-hidden="true"></span></th>
                </tr>
              </thead>
              <tbody>
                ${repeat(
                  filtered,
                  (d) => d.subentry_id,
                  (d) => {
                    const code = effectiveStatusCode(d);
                    const st = localizedStatusLabel(store, d, code);
                    const dotCls = code === "update" ? "update" : code === "online" ? "online" : "";
                    const grpCell =
                      d.kind === "ble_tag"
                        ? d.ble_category === "phone"
                          ? store.t("devices.phones")
                          : store.t("devices.ble_tags")
                        : d.device_group === "custom"
                          ? store.t("common.custom")
                          : d.device_group_name || store.t("common.unknown");
                    const href = `/latter/devices/${encodeURIComponent(d.subentry_id)}`;
                    const onLinkClick = (ev) => {
                      if (
                        ev.defaultPrevented ||
                        ev.button !== 0 ||
                        ev.metaKey ||
                        ev.ctrlKey ||
                        ev.shiftKey ||
                        ev.altKey
                      ) {
                        return;
                      }
                      ev.preventDefault();
                      ev.stopPropagation();
                      void store.switchSystemDevice(d.subentry_id);
                    };
                    const onRowClick = (ev) => {
                      const target = ev.target;
                      if (target?.closest?.("a, button, input, select")) return;
                      void store.switchSystemDevice(d.subentry_id);
                    };
                    return html`<tr @click=${onRowClick}>
                      <td class="col-name">
                        <a href=${href} @click=${onLinkClick}>${d.title}</a>
                      </td>
                      <td>${d.model_label || store.t("common.unknown")}</td>
                      <td>${d.area_label || store.t("common.unknown")}</td>
                      <td>${grpCell}</td>
                      <td><span class="status-dot ${dotCls}" aria-hidden="true"></span>${st}</td>
                      <td class="col-open" aria-hidden="true">›</td>
                    </tr>`;
                  },
                )}
              </tbody>
            </table>
          </div>`
        : allDevices.length
          ? html`<p class="empty-state">${store.t("devices.empty_filtered")}</p>`
          : html`<div class="stack">
              <strong>${store.t("devices.empty_zero_title")}</strong>
              <p class="empty-state">${store.t("devices.empty_zero_body")}</p>
            </div>`,
    })}
  </section>`;
}
__latterExp(__exports, { renderDevicesListView: () => renderDevicesListView });
//# sourceURL=latter-studio/src/views/devices-list-view.ts
});
__latterDef("src/views/groups/batch-controls.ts", (__exports, __req) => {
const { renderCard, renderHourSelectControl, renderRangeControl, renderSettingsRow } = __req("src/components/controls.ts");
const { html, nothing } = __req("src/lib/lit.ts");
const { defaultLocaleTimeFormat, entityLabel, fmtNumber, isValidHexColor } = __req("src/utils/format.ts");
/**
 * Staged Batch Controls Card (`system_sync` Column 2, `D-050`, `D-055`, `D-064` / `Q6`).
 * - Stages edits in `store.groups.batchDraft` & `Mixed`-safe `store.groups.batchPillDrafts`
 * - Action bar with **Apply to N Devices** (`requestApplyBatchDraft`) + **Reset** (`resetBatchDraft`)
 *   and automatic `Custom` detachment note when grouped Devices are targeted
 */
const BATCH_CATEGORY_META
   = [
  { id: "display", labelKey: "batch.cat_display" },
  { id: "interface", labelKey: "batch.cat_interface" },
  { id: "audio", labelKey: "batch.cat_audio" },
  { id: "power", labelKey: "batch.cat_power" },
  { id: "presence", labelKey: "batch.cat_presence" },
  { id: "security", labelKey: "batch.cat_security" },
];
function renderBatchControlRow(
  store,
  fc,
) {
  const targets = store.groups.filteredControlTargets(fc);
  if (!targets.length) return nothing;
  const eff = store.groups.getEffectiveBatchValue(fc);
  const { value: curState, mixed, staged } = eff;
  const prefKey = fc.pref_key || "";
  const label = prefKey
    ? store.tPrefLabel(prefKey, entityLabel(fc.name))
    : entityLabel(fc.name);
  const secTitle = entityLabel(fc.section_title || fc.section);
  const baseDesc =
    targets.length === 1
      ? store.t("batch.row_meta_one", { section: secTitle })
      : store.t("batch.row_meta_many", {
          section: secTitle,
          count: fmtNumber(targets.length, store.hass, 0),
        });
  const desc = mixed ? `${baseDesc} • ${store.t("batch.mixed_hint")}` : baseDesc;
  const optLabels = fc.option_labels || {};
  const statusBadge = staged
    ? html`<span class="chip chip-primary">${store.t("batch.staged_badge")}</span>`
    : mixed
      ? html`<span class="chip chip-warning">${store.t("batch.mixed_badge")}</span>`
      : nothing;
  let control;
  if (fc.domain === "select" && fc.options && fc.options.length) {
    const selectValue = mixed && !staged ? "__mixed__" : curState;
    control = html`${statusBadge}
      <select
        aria-label=${label}
        .value=${selectValue}
        @change=${(ev) => {
          const val = (ev.currentTarget).value;
          if (val !== "__mixed__") {
            store.groups.stageBatchEntityControl(fc, { option: val });
          }
        }}
      >
        ${mixed && !staged
          ? html`<option value="__mixed__" selected disabled>
              ${store.t("batch.mixed_badge")}
            </option>`
          : nothing}
        ${fc.options.map((opt) => {
          const optText =
            optLabels[opt] || (prefKey ? store.tPrefOption(prefKey, opt) : opt);
          return html`<option
            value=${opt}
            ?selected=${!(mixed && !staged) && opt === curState}
          >
            ${optText}
          </option>`;
        })}
      </select>`;
  } else if (fc.domain === "switch") {
    const checked = !mixed && curState === "on";
    control = html`${statusBadge}
      <input
        type="checkbox"
        role="switch"
        aria-label=${label}
        .checked=${checked}
        @change=${(ev) =>
          store.groups.stageBatchEntityControl(fc, {
            action: (ev.currentTarget).checked ? "turn_on" : "turn_off",
          })}
        class="switch"
      />`;
  } else if (fc.domain === "number") {
    const min = fc.min ?? 0;
    const max = fc.max ?? 100;
    const step = fc.step ?? 1;
    const numVal = Number.isFinite(Number(curState)) ? Number(curState) : min;
    control =
      fc.unit === ":00"
        ? html`${statusBadge}
            ${renderHourSelectControl({
              ariaLabel: label,
              value: numVal,
              is24h: defaultLocaleTimeFormat(store.hass).startsWith("24"),
              hass: store.hass,
              mixed: mixed && !staged,
              mixedLabel: store.t("batch.mixed_badge"),
              onCommit: (raw) => store.groups.stageBatchEntityControl(fc, { level: raw }),
            })}`
        : html`${statusBadge}
            ${renderRangeControl({
              ariaLabel: label,
              value: numVal,
              min,
              max,
              step,
              unit: fc.unit,
              is24h: defaultLocaleTimeFormat(store.hass).startsWith("24"),
              hass: store.hass,
              onCommit: (raw) => store.groups.stageBatchEntityControl(fc, { level: raw }),
            })}`;
  } else if (fc.domain === "color") {
    const hexVal = isValidHexColor(curState) ? curState.toUpperCase() : "#3898FF";
    control = html`${statusBadge}
      <input
        type="color"
        aria-label=${label}
        .value=${hexVal}
        @change=${(ev) =>
          store.groups.stageBatchColor(fc, (ev.currentTarget).value)}
      />
      <span class="chip">${mixed && !staged ? store.t("batch.mixed_badge") : hexVal}</span>`;
  } else if (fc.domain === "pills" && fc.options && fc.options.length) {
    const pillStates = store.groups.getEffectiveBatchPillStates(fc);
    const hasAnyStaged = pillStates.some((p) => p.staged);
    const hasAnyMixed = pillStates.some((p) => p.state === "mixed");
    const pillBadge = hasAnyStaged
      ? html`<span class="chip chip-primary">${store.t("batch.staged_badge")}</span>`
      : hasAnyMixed
        ? html`<span class="chip chip-warning">${store.t("batch.mixed_badge")}</span>`
        : nothing;
    control = html`<div role="group" aria-label=${label} class="pill-list">
      ${pillBadge}
      ${pillStates.map((pill) => {
        const isOn = pill.state === "on";
        const isMixed = pill.state === "mixed";
        const pillText = isMixed
          ? store.t("batch.mixed_pill_suffix", { label: pill.label })
          : pill.label;
        return html`<span class="pill ${isOn ? "enabled" : ""}">
          <button
            type="button"
            aria-pressed=${isMixed ? "mixed" : isOn ? "true" : "false"}
            @click=${() => store.groups.stageBatchPillToggle(fc, pill.token)}
            class="pill-toggle"
          >
            ${pillText}
          </button>
        </span>`;
      })}
    </div>`;
  } else {
    control = html`${statusBadge}
      <span class="chip">${mixed ? store.t("batch.mixed_badge") : curState}</span>`;
  }
  return renderSettingsRow({
    label,
    description: desc,
    stacked: fc.domain === "pills",
    control,
  });
}
function requestBatchListPush(
  store,
  sourceSubentryId,
  latterDevices,
  matchingCount,
  selectedTargetName,
  copyKeys,
  listLabel,
) {
  if (matchingCount <= 1) {
    void store.groups.applyBatchCopyFromDevice(sourceSubentryId, copyKeys);
    return;
  }
  const srcDev = latterDevices.find((d) => d.subentry_id === sourceSubentryId);
  const devTitle = srcDev?.title || sourceSubentryId;
  store.openConfirm({
    kind: "batch_copy_list",
    title: store.t("batch.confirm_push_list_title", {
      listLabel,
      target: selectedTargetName,
    }),
    consequence: store.t("batch.confirm_push_list_body", {
      listLabel,
      device: devTitle,
    }),
    confirmLabel: store.t("batch.confirm_push_list_confirm"),
    danger: false,
    blastRadiusCount: matchingCount,
    onConfirm: async() => {
      await store.groups.applyBatchCopyFromDevice(sourceSubentryId, copyKeys);
    },
  });
}
function renderBatchControlsCard(
  store,
  groups,
  latterDevices,
  systemControls,
) {
  const validTargetFilters = new Set ([
    "all",
    "online",
    "roaming",
    "stationary",
    "group:custom",
    ...groups.map((g) => `group:${g.id}`),
  ]);
  const activeFilter = validTargetFilters.has(store.batchTargetFilter || "all")
    ? store.batchTargetFilter || "all"
    : "all";
  const activeCat = store.batchCategoryFilter || "all";
  const selectedTargetName =
    activeFilter === "all"
      ? store.t("batch.all_latter_devices")
      : activeFilter === "online"
        ? store.t("batch.online_devices")
        : activeFilter === "roaming"
          ? store.t("batch.roaming_devices")
          : activeFilter === "stationary"
            ? store.t("batch.stationary_devices")
            : activeFilter === "group:custom"
              ? store.t("common.custom")
              : groups.find((g) => `group:${g.id}` === activeFilter)?.name ||
                activeFilter.replace(/^group:/, "");
  const matchingDevs = store.groups.matchingBatchDevices();
  const batchCopySrc =
    store.batchCopySourceSubentryId ||
    store.activeSubentryId ||
    latterDevices[0]?.subentry_id ||
    "";
  const draftCount = store.groups.batchDraftCount;
  const hasDraft = store.groups.hasBatchDraft;
  const detachCount = store.groups.previewBatchDetachmentCount();
  const applyLabel =
    matchingDevs.length === 1
      ? store.t("batch.apply_to_one")
      : store.t("batch.apply_to_n", { count: fmtNumber(matchingDevs.length, store.hass, 0) });
  const renderBatchCopyListsSection = () => {
    if (!latterDevices.length || !matchingDevs.some((d) => d.has_display !== false)) {
      return nothing;
    }
    return html`<div class="settings-list">
      <div class="subsection-title">${store.t("batch.copy_lists_title")}</div>
      ${renderSettingsRow({
        label: store.t("batch.template_device"),
        description: store.t("batch.template_device_desc", { target: selectedTargetName }),
        control: html`<select
          id="batch-copy-source"
          aria-label=${store.t("batch.template_device_aria")}
          .value=${batchCopySrc}
          @change=${(ev) => {
            store.batchCopySourceSubentryId = (ev.currentTarget).value;
            store.host.requestUpdate();
          }}
        >
          ${latterDevices.map(
            (d) =>
              html`<option value=${d.subentry_id} ?selected=${d.subentry_id === batchCopySrc}>
                ${d.title}
              </option>`,
          )}
        </select>`,
      })}
      <div class="input-action-row">
        <button
          type="button"
          @click=${() =>
            requestBatchListPush(
              store,
              batchCopySrc,
              latterDevices,
              matchingDevs.length,
              selectedTargetName,
              ["dock_items"],
              store.t("card.app_dock"),
            )}
          class="btn btn-secondary btn-compact"
        >
          ${store.t("batch.push_dock")}
        </button>
        <button
          type="button"
          @click=${() =>
            requestBatchListPush(
              store,
              batchCopySrc,
              latterDevices,
              matchingDevs.length,
              selectedTargetName,
              ["pinned_items"],
              store.t("dialogs.pinned_label"),
            )}
          class="btn btn-secondary btn-compact"
        >
          ${store.t("batch.push_pinned")}
        </button>
        <button
          type="button"
          @click=${() =>
            requestBatchListPush(
              store,
              batchCopySrc,
              latterDevices,
              matchingDevs.length,
              selectedTargetName,
              ["world_clocks"],
              store.t("dialogs.world_clocks_label"),
            )}
          class="btn btn-secondary btn-compact"
        >
          ${store.t("batch.push_clocks")}
        </button>
      </div>
    </div>`;
  };
  return renderCard({
    id: "card-batch-controls",
    title: store.t("batch.title"),
    subtitle: store.t("batch.subtitle"),
    headerActions: html`${hasDraft
        ? html`<span class="chip chip-primary">
            ${store.t("batch.staged_count", { count: fmtNumber(draftCount, store.hass, 0) })}
          </span>`
        : nothing}
      <select
        id="batch-target-filter"
        aria-label=${store.t("batch.target_filter_aria")}
        .value=${activeFilter}
        @change=${(ev) =>
          store.groups.setBatchTargetFilter((ev.currentTarget).value || "all")}
      >
        <option value="all" ?selected=${activeFilter === "all"}>
          ${store.t("batch.all_latter_devices")}
        </option>
        <option value="online" ?selected=${activeFilter === "online"}>
          ${store.t("batch.online_devices")}
        </option>
        <option value="roaming" ?selected=${activeFilter === "roaming"}>
          ${store.t("batch.roaming_devices")}
        </option>
        <option value="stationary" ?selected=${activeFilter === "stationary"}>
          ${store.t("batch.stationary_devices")}
        </option>
        ${groups.map(
          (g) =>
            html`<option
              value=${`group:${g.id}`}
              ?selected=${activeFilter === `group:${g.id}`}
            >
              ${g.name}
            </option>`,
        )}
        <option value="group:custom" ?selected=${activeFilter === "group:custom"}>
          ${store.t("common.custom")}
        </option>
      </select>
      <select
        id="batch-cat-filter"
        aria-label=${store.t("batch.category_filter_aria")}
        .value=${activeCat}
        @change=${(ev) => {
          store.batchCategoryFilter = (ev.currentTarget).value || "all";
          store.host.requestUpdate();
        }}
      >
        <option value="all" ?selected=${activeCat === "all"}>
          ${store.t("batch.all_categories")}
        </option>
        ${BATCH_CATEGORY_META.map(
          (cat) =>
            html`<option value=${cat.id} ?selected=${activeCat === cat.id}>
              ${store.t(cat.labelKey)}
            </option>`,
        )}
      </select>`,
    contentClass: "stack",
    body: !matchingDevs.length
      ? html`<p class="empty-state">
          ${activeFilter === "all"
            ? store.t("batch.empty_all")
            : store.t("batch.empty_target", { target: selectedTargetName })}
        </p>`
      : html`<div class="help-text">
            ${store.t("batch.target_summary", {
              count: fmtNumber(matchingDevs.length, store.hass, 0),
              names: matchingDevs.map((d) => d.title).join(", "),
            })}
          </div>

          ${hasDraft && detachCount > 0
            ? html`<div role="status" class="alert alert-warning">
                <div class="alert-body">
                  <span>
                    ${detachCount === 1
                      ? store.t("batch.detachment_note_one")
                      : store.t("batch.detachment_note_many", {
                          count: fmtNumber(detachCount, store.hass, 0),
                        })}
                  </span>
                </div>
              </div>`
            : nothing}

          <div id="system-controls-list" class="stack">
            ${activeCat === "all"
              ? BATCH_CATEGORY_META.map((cat) => {
                  const rows = systemControls
                    .filter((fc) => fc.section === cat.id)
                    .map((fc) => renderBatchControlRow(store, fc))
                    .filter((row) => row !== nothing);
                  const copyBlock =
                    cat.id === "interface" ? renderBatchCopyListsSection() : nothing;
                  if (!rows.length && copyBlock === nothing) return nothing;
                  return html`<details
                    ?open=${store.openBatchCategories.has(cat.id)}
                    @toggle=${(ev) => {
                      if (ev.target !== ev.currentTarget) return;
                      const isOpen = (ev.currentTarget).open;
                      if (isOpen) store.openBatchCategories.add(cat.id);
                      else store.openBatchCategories.delete(cat.id);
                    }}
                    class="sub-collapsible"
                  >
                    <summary>${store.t(cat.labelKey)}</summary>
                    <div class="card-content stack">
                      ${rows.length ? html`<div class="settings-list">${rows}</div>` : nothing}
                      ${copyBlock}
                    </div>
                  </details>`;
                })
              : (() => {
                  const rows = systemControls
                    .filter((fc) => fc.section === activeCat)
                    .map((fc) => renderBatchControlRow(store, fc))
                    .filter((row) => row !== nothing);
                  const copyBlock =
                    activeCat === "interface" ? renderBatchCopyListsSection() : nothing;
                  if (!rows.length && copyBlock === nothing) {
                    return html`<p class="empty-state">${store.t("batch.empty_category")}</p>`;
                  }
                  return html`${rows.length
                    ? html`<div class="settings-list">${rows}</div>`
                    : nothing}
                  ${copyBlock}`;
                })()}
          </div>`,
    footerActions: matchingDevs.length
      ? html`<button
            type="button"
            id="btn-batch-reset"
            ?disabled=${!hasDraft || store.groups.batchBusy}
            @click=${() => store.groups.resetBatchDraft()}
            class="btn btn-secondary"
          >
            ${store.t("batch.reset_staged")}
          </button>
          <button
            type="button"
            id="btn-batch-apply"
            ?disabled=${!hasDraft || store.groups.batchBusy}
            @click=${() => store.groups.requestApplyBatchDraft()}
            class="btn btn-primary"
          >
            ${applyLabel}
          </button>`
      : nothing,
  });
}
__latterExp(__exports, { renderBatchControlsCard: () => renderBatchControlsCard });
//# sourceURL=latter-studio/src/views/groups/batch-controls.ts
});
__latterDef("src/views/groups/group-baseline-drawer.ts", (__exports, __req) => {
const { renderHourSelectRow, renderRangeRow, renderSettingsRow, renderSwitchRow } = __req("src/components/controls.ts");
const { ACTIVITY_SOURCES_CATALOG, AREA_CATEGORIES_CATALOG, CALENDAR_LOOKAHEAD_OPTIONS, DEFAULT_ACTIVITY_SOURCES, DEFAULT_AREA_CATEGORIES, DEFAULT_GAMES_ITEMS, DEFAULT_HOME_CATEGORIES, DEFAULT_TOOLS_ITEMS, GAMES_ITEMS_CATALOG, HOME_CATEGORIES_CATALOG, SECURITY_PIN_POLICY_OPTIONS, TOOLS_ITEMS_CATALOG, WALLPAPER_ROTATION_OPTIONS } = __req("src/constants.ts");
const { html, nothing } = __req("src/lib/lit.ts");
const { isCatalogItemSupported } = __req("src/state/store.ts");
const { defaultLocaleTimeFormat, fmtNumber, isValidHexColor } = __req("src/utils/format.ts");
/**
 * Group Baseline Drawer (`system_sync` Column 1, `D-048`, `D-050`, `D-063`, `D-064`).
 * - Zero hardcoded option arrays (`A-12`): reads options/bounds/defaults from `store.entity.getPrefSpec(key)`
 * - Localizes labels/options via `store.tPrefLabel` & `store.tPrefOption`
 * - Trait-gates group baseline rows (`E-14`) via single `isCatalogItemSupported` (`A-14`)
 * - Confirms `copyDeviceToGroupBaseline` (`Q5`)
 */
function deriveGroupCapabilities(
  group,
  members,
) {
  if (group.id === "pocket_carry") {
    return {
      has_display: true,
      is_round: true,
      has_imu: true,
      has_battery: true,
      has_ble_beacon: true,
      has_voice: true,
      has_audio: true,
      is_roaming_device: true,
    };
  }
  if (group.id === "handhelds" || group.id === "wearables") {
    return {
      has_display: true,
      is_round: false,
      has_imu: true,
      has_battery: true,
      has_ble_beacon: true,
      has_voice: true,
      has_audio: true,
      is_roaming_device: true,
    };
  }
  if (group.id === "wall_panels") {
    return {
      has_display: true,
      is_round: false,
      has_imu: false,
      has_battery: false,
      has_ble_beacon: true,
      has_voice: true,
      has_audio: true,
      is_roaming_device: false,
    };
  }
  if (members.length > 0) {
    return {
      has_display: members.some((m) => m.has_display !== false),
      has_battery: members.some((m) => m.has_battery !== false),
      has_ble_beacon: members.some((m) => m.has_ble !== false),
      is_roaming_device: members.some((m) => m.is_roaming !== false),
    };
  }
  return {};
}
function renderSpecSelect(
  store,
  group,
  key,
  currentVal,
  caps,
) {
  const spec = store.entity.getPrefSpec(key);
  if (!spec || !isCatalogItemSupported(spec, caps)) {
    return nothing;
  }
  const options = spec.options || [];
  if (options.length === 0) return nothing;
  const fallbackVal = String(spec.default ?? options[0]);
  const cur =
    typeof currentVal === "string" && options.includes(currentVal)
      ? currentVal
      : fallbackVal;
  const label = store.tPrefLabel(key, spec.label);
  return renderSettingsRow({
    label,
    control: html`<select
      aria-label=${store.t("groups.for_group_aria", { label, group: group.name })}
      .value=${cur}
      @change=${(ev) =>
        void store.groups.updateGroupBaseline(group.id, {
          [key]: (ev.currentTarget).value,
        })}
    >
      ${options.map(
        (opt) => html`<option value=${opt} ?selected=${opt === cur}>
          ${store.tPrefOption(key, opt)}
        </option>`,
      )}
    </select>`,
  });
}
function renderSpecSwitch(
  store,
  group,
  key,
  currentVal,
  caps,
  extraGate = true,
) {
  if (!extraGate) return nothing;
  const spec = store.entity.getPrefSpec(key);
  if (spec && !isCatalogItemSupported(spec, caps)) {
    return nothing;
  }
  const defaultBool = spec ? Boolean(spec.default) : true;
  const checked =
    currentVal !== undefined && currentVal !== null ? Boolean(currentVal) : defaultBool;
  const label = store.tPrefLabel(key, spec?.label);
  return renderSwitchRow({
    label,
    ariaLabel: store.t("groups.for_group_aria", { label, group: group.name }),
    checked,
    onChange: (next) =>
      void store.groups.updateGroupBaseline(group.id, { [key]: next }),
  });
}
function renderSpecRange(
  store,
  group,
  key,
  currentVal,
  caps,
  fallbackBounds,
) {
  const spec = store.entity.getPrefSpec(key);
  if (spec && !isCatalogItemSupported(spec, caps)) {
    return nothing;
  }
  const min = spec?.min ?? fallbackBounds?.min ?? 0;
  const max = spec?.max ?? fallbackBounds?.max ?? 100;
  const step = spec?.step ?? fallbackBounds?.step ?? 1;
  const unit = spec?.unit ?? fallbackBounds?.unit ?? "";
  const defNum = Number(spec?.default ?? fallbackBounds?.defaultVal ?? min);
  const numVal = Number.isFinite(Number(currentVal)) ? Number(currentVal) : defNum;
  const label = store.tPrefLabel(key, spec?.label);
  return renderRangeRow({
    label,
    ariaLabel: store.t("groups.for_group_aria", { label, group: group.name }),
    value: numVal,
    min,
    max,
    step,
    unit,
    is24h: defaultLocaleTimeFormat(store.hass).startsWith("24"),
    hass: store.hass,
    onCommit: (nextVal) =>
      void store.groups.updateGroupBaseline(group.id, { [key]: nextVal }),
  });
}
function renderSpecHourSelect(
  store,
  group,
  key,
  currentVal,
  caps,
) {
  const spec = store.entity.getPrefSpec(key);
  if (spec && !isCatalogItemSupported(spec, caps)) {
    return nothing;
  }
  const defNum = Number(spec?.default ?? 0);
  const numVal = Number.isFinite(Number(currentVal)) ? Number(currentVal) : defNum;
  const label = store.tPrefLabel(key, spec?.label);
  return renderHourSelectRow({
    label,
    ariaLabel: store.t("groups.for_group_aria", { label, group: group.name }),
    value: numVal,
    is24h: defaultLocaleTimeFormat(store.hass).startsWith("24"),
    hass: store.hass,
    onCommit: (nextHour) =>
      void store.groups.updateGroupBaseline(group.id, { [key]: nextHour }),
  });
}
function renderBaselineLabeledSelect(
  store,
  group,
  key,
  currentVal,
  options,
  defaultVal,
  asNumber = false,
) {
  const curStr =
    currentVal !== undefined && currentVal !== null ? String(currentVal) : defaultVal;
  const cur = options.some((o) => o.value === curStr) ? curStr : defaultVal;
  const label = store.tPrefLabel(key);
  return renderSettingsRow({
    label,
    control: html`<select
      aria-label=${store.t("groups.for_group_aria", { label, group: group.name })}
      .value=${cur}
      @change=${(ev) => {
        const raw = (ev.currentTarget).value;
        const val = asNumber ? Number(raw) || 0 : raw;
        void store.groups.updateGroupBaseline(group.id, { [key]: val });
      }}
    >
      ${options.map(
        (opt) =>
          html`<option value=${opt.value} ?selected=${opt.value === cur}>
            ${opt.label}
          </option>`,
      )}
    </select>`,
  });
}
function renderBaselinePills(
  store,
  group,
  key,
  currentVal,
  catalog,
  defaultCsv,
  minRequired,
  caps,
) {
  const supportedCatalog = catalog.filter((c) => isCatalogItemSupported(c, caps));
  const csvStr = typeof currentVal === "string" ? currentVal : defaultCsv;
  const activeSet = new Set(
    csvStr
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean),
  );
  const label = store.tPrefLabel(key);
  const toggleTok = (tok) => {
    const next = new Set(activeSet);
    if (next.has(tok)) {
      if (next.size <= minRequired) {
        const noun =
          key === "tools_items"
            ? "tool"
            : key === "games_items"
              ? "game"
              : "category";
        store.showToast(store.t("common.keep_one_enabled", { noun }), true);
        return;
      }
      next.delete(tok);
    } else {
      next.add(tok);
    }
    const ordered = catalog.map((c) => c.token).filter((t) => next.has(t));
    void store.groups.updateGroupBaseline(group.id, { [key]: ordered.join(",") });
  };
  return renderSettingsRow({
    label,
    stacked: true,
    control: html`<div
      role="group"
      aria-label=${store.t("groups.for_group_aria", { label, group: group.name })}
      class="pill-list"
    >
      ${supportedCatalog.map((item) => {
        const on = activeSet.has(item.token);
        return html`<span class="pill ${on ? "enabled" : ""}">
          <button
            type="button"
            aria-pressed=${on ? "true" : "false"}
            @click=${() => toggleTok(item.token)}
            class="pill-toggle"
          >
            ${item.label}
          </button>
        </span>`;
      })}
    </div>`,
  });
}
function requestCopyDeviceIntoGroup(
  store,
  group,
  memberCount,
  sourceSubentryId,
  latterDevices,
  copyKeys,
  listLabel,
) {
  const srcDev = latterDevices.find((d) => d.subentry_id === sourceSubentryId);
  const devName = srcDev?.title || sourceSubentryId;
  store.openConfirm({
    kind: "copy_group_baseline",
    title: store.t("groups.confirm_copy_title", { group: group.name }),
    consequence: listLabel
      ? store.t("groups.confirm_copy_list_body", {
          listLabel,
          device: devName,
          group: group.name,
        })
      : store.t("groups.confirm_copy_body", {
          group: group.name,
          device: devName,
        }),
    confirmLabel: store.t("groups.confirm_copy_confirm"),
    danger: false,
    blastRadiusCount: memberCount > 0 ? memberCount : null,
    onConfirm: async() => {
      await store.groups.copyDeviceToGroupBaseline(group.id, sourceSubentryId, copyKeys);
    },
  });
}
function renderGroupBaselineDrawer(
  store,
  group,
  members,
  latterDevices,
) {
  const gid = group.id;
  const cfg = group.device_config || {};
  const caps = deriveGroupCapabilities(group, members);
  const includeDisplay = Boolean(group.include_display);
  const includeInterface = Boolean(group.include_interface);
  const autoBrt = String(cfg.auto_brightness_mode || "Sun Synchronized");
  const wwMode = String(cfg.wake_word_mode || "Docked Only");
  const bleOn = Boolean(cfg.native_ble_tracking);
  const autoSw = cfg.ble_auto_switch !== undefined ? Boolean(cfg.ble_auto_switch) : bleOn;
  const vfm = Boolean(cfg.sync_device_area);
  const handoff = Boolean(cfg.area_handoff);
  const pinPolicy = String(cfg.security_pin_policy || "auto");
  const colorProfile = String(cfg.color_profile || "Steel Blue");
  const rawCustomHex =
    typeof cfg.device_custom_color === "string" ? cfg.device_custom_color : null;
  const customHex = isValidHexColor(rawCustomHex)
    ? String(rawCustomHex).toUpperCase()
    : "#3898FF";
  const copySrc =
    store.groupCopySourceDrafts.get(gid) ||
    store.activeSubentryId ||
    latterDevices[0]?.subentry_id ||
    "";
  const sysWallpapers = store.state?.system_wallpapers || [];
  const wallpaperOptions = [
    { value: "", label: store.t("groups.wallpaper_none") },
    ...sysWallpapers.map((wp) => ({ value: wp.id, label: wp.name || wp.id })),
  ];
  const rotationOptions = WALLPAPER_ROTATION_OPTIONS.map(
    (o) => ({ value: String(o.value), label: o.label }),
  );
  const lookaheadOptions = CALENDAR_LOOKAHEAD_OPTIONS.map(
    (o) => ({ value: String(o.value), label: o.label }),
  );
  const remoteGroups = store.state?.system_config?.remote_groups || [];
  const remoteScopeOptions = [
    { value: "area_auto", label: store.t("groups.remote_match_area") },
    ...remoteGroups.map((rg) => ({
      value: `group:${rg.id}`,
      label: store.t("groups.remote_group_prefix", { name: rg.name }),
    })),
    { value: "all", label: store.t("groups.remote_all_system") },
  ];
  const dockCount = Array.isArray(cfg.dock_items) ? cfg.dock_items.length : 7;
  const pinnedCount = Array.isArray(cfg.pinned_items) ? cfg.pinned_items.length : 0;
  const worldClocksStr = typeof cfg.world_clocks === "string" ? cfg.world_clocks.trim() : "";
  const clockCount = worldClocksStr ? worldClocksStr.split(";").filter(Boolean).length : 0;
  return html`<details
    ?open=${store.openGroupIds.has(gid)}
    @toggle=${(ev) => {
      if (ev.target !== ev.currentTarget) return;
      const isOpen = (ev.currentTarget).open;
      if (isOpen) store.openGroupIds.add(gid);
      else store.openGroupIds.delete(gid);
    }}
    class="sub-collapsible"
  >
    <summary>${store.t("groups.baseline_settings")}</summary>
    <div class="card-content stack">
      <div class="settings-list">
        ${renderSwitchRow({
          label: store.t("groups.include_display"),
          description: store.t("groups.include_display_desc"),
          ariaLabel: store.t("groups.for_group_aria", {
            label: store.t("groups.include_display"),
            group: group.name,
          }),
          checked: includeDisplay,
          onChange: (checked) =>
            void store.groups.updateGroupScope(gid, { include_display: checked }),
        })}
        ${renderSwitchRow({
          label: store.t("groups.include_interface"),
          description: store.t("groups.include_interface_desc"),
          ariaLabel: store.t("groups.for_group_aria", {
            label: store.t("groups.include_interface"),
            group: group.name,
          }),
          checked: includeInterface,
          onChange: (checked) =>
            void store.groups.updateGroupScope(gid, { include_interface: checked }),
        })}
      </div>

      <details class="sub-collapsible" open>
        <summary>${store.t("groups.section_power_brightness")}</summary>
        <div class="card-content settings-list">
          ${renderSpecSelect(store, group, "tap_to_wake", cfg.tap_to_wake, caps)}
          ${renderSpecSelect(store, group, "pickup_to_wake", cfg.pickup_to_wake, caps)}
          ${renderSpecSelect(
            store,
            group,
            "battery_screen_timeout",
            cfg.battery_screen_timeout,
            caps,
          )}
          ${renderSpecSelect(
            store,
            group,
            "battery_hibernate_timeout",
            cfg.battery_hibernate_timeout,
            caps,
          )}
          ${renderSpecSwitch(store, group, "docked_screensaver", cfg.docked_screensaver, caps)}
          ${caps.has_battery !== false || cfg.docked_screensaver !== false
            ? renderSpecSelect(store, group, "docked_idle_timeout", cfg.docked_idle_timeout, caps)
            : nothing}
          ${renderSpecSwitch(
            store,
            group,
            "hold_crown_power_off",
            cfg.hold_crown_power_off,
            caps,
            caps.has_battery !== false,
          )}
          ${renderSpecSelect(
            store,
            group,
            "auto_brightness_mode",
            cfg.auto_brightness_mode,
            caps,
          )}
          ${autoBrt === "Disabled"
            ? renderSpecRange(store, group, "manual_brightness", cfg.manual_brightness, caps)
            : html`${renderSpecRange(store, group, "day_brightness", cfg.day_brightness, caps)}
                ${renderSpecRange(
                  store,
                  group,
                  "night_brightness",
                  cfg.night_brightness,
                  caps,
                )}`}
          ${autoBrt === "Time Schedule"
            ? html`${renderSpecHourSelect(store, group, "day_start_hour", cfg.day_start_hour, caps)}
                ${renderSpecHourSelect(store, group, "night_start_hour", cfg.night_start_hour, caps)}`
            : nothing}
          ${renderSpecSelect(store, group, "bedtime_display", cfg.bedtime_display, caps)}
          ${renderSpecRange(store, group, "bedtime_brightness", cfg.bedtime_brightness, caps)}
          ${renderSpecSwitch(store, group, "bedtime_schedule", cfg.bedtime_schedule, caps)}
          ${Boolean(cfg.bedtime_schedule)
            ? html`${renderSpecHourSelect(
                  store,
                  group,
                  "bedtime_start_hour",
                  cfg.bedtime_start_hour,
                  caps,
                )}
                ${renderSpecHourSelect(
                  store,
                  group,
                  "bedtime_end_hour",
                  cfg.bedtime_end_hour,
                  caps,
                )}`
            : nothing}
        </div>
      </details>

      <details class="sub-collapsible">
        <summary>${store.t("groups.section_audio_voice")}</summary>
        <div class="card-content settings-list">
          ${renderSpecSelect(store, group, "wake_word_mode", cfg.wake_word_mode, caps)}
          ${wwMode !== "Disabled"
            ? html`${renderSpecSelect(
                  store,
                  group,
                  "ww_sens_okay_nabu",
                  cfg.ww_sens_okay_nabu,
                  caps,
                )}
                ${renderSpecSelect(
                  store,
                  group,
                  "ww_sens_hey_luna",
                  cfg.ww_sens_hey_luna,
                  caps,
                )}
                ${renderSpecSelect(
                  store,
                  group,
                  "ww_sens_hey_jarvis",
                  cfg.ww_sens_hey_jarvis,
                  caps,
                )}
                ${renderSpecSelect(
                  store,
                  group,
                  "ww_sens_hey_mycroft",
                  cfg.ww_sens_hey_mycroft,
                  caps,
                )}
                ${renderSpecSelect(store, group, "ww_sens_alexa", cfg.ww_sens_alexa, caps)}`
            : nothing}
          ${renderSpecSwitch(
            store,
            group,
            "wake_screen_on_assist",
            cfg.wake_screen_on_assist,
            caps,
          )}
          ${renderSpecRange(store, group, "alert_volume", cfg.alert_volume, caps)}
          ${renderSpecRange(store, group, "volume_step_size", cfg.volume_step_size, caps)}
          ${renderSpecSwitch(store, group, "game_sound_effects", cfg.game_sound_effects, caps)}
          ${bleOn && caps.is_roaming_device !== false
            ? html`${renderSwitchRow({
                  label: store.tPrefLabel("sync_device_area"),
                  ariaLabel: store.t("groups.for_group_aria", {
                    label: store.tPrefLabel("sync_device_area"),
                    group: group.name,
                  }),
                  checked: vfm,
                  onChange: (checked) =>
                    void store.groups.updateGroupBaseline(gid, { sync_device_area: checked }),
                })}
                ${vfm
                  ? renderSpecRange(
                      store,
                      group,
                      "area_follow_dwell_s",
                      cfg.area_follow_dwell_s,
                      caps,
                      { min: 3, max: 60, step: 1, unit: "s", defaultVal: 10 },
                    )
                  : nothing}`
            : nothing}
          ${renderSwitchRow({
            label: store.tPrefLabel("area_handoff"),
            ariaLabel: store.t("groups.for_group_aria", {
              label: store.tPrefLabel("area_handoff"),
              group: group.name,
            }),
            checked: handoff,
            onChange: (checked) =>
              void store.groups.updateGroupBaseline(gid, { area_handoff: checked }),
          })}
        </div>
      </details>

      <details class="sub-collapsible">
        <summary>${store.t("groups.section_presence_security")}</summary>
        <div class="card-content settings-list">
          ${renderSwitchRow({
            label: store.tPrefLabel("native_ble_tracking"),
            ariaLabel: store.t("groups.for_group_aria", {
              label: store.tPrefLabel("native_ble_tracking"),
              group: group.name,
            }),
            checked: bleOn,
            onChange: (checked) =>
              void store.groups.updateGroupBaseline(gid, { native_ble_tracking: checked }),
          })}
          ${bleOn
            ? html`${renderSwitchRow({
                  label: store.tPrefLabel("ble_auto_switch"),
                  ariaLabel: store.t("groups.for_group_aria", {
                    label: store.tPrefLabel("ble_auto_switch"),
                    group: group.name,
                  }),
                  checked: autoSw,
                  onChange: (checked) =>
                    void store.groups.updateGroupBaseline(gid, { ble_auto_switch: checked }),
                })}
                ${renderSpecSelect(store, group, "ble_beacon_mode", cfg.ble_beacon_mode, caps)}`
            : nothing}
          ${renderBaselineLabeledSelect(
            store,
            group,
            "security_pin_policy",
            pinPolicy,
            SECURITY_PIN_POLICY_OPTIONS.map((opt) => ({
              value: opt.value,
              label: store.tPrefOption("security_pin_policy", opt.value),
            })),
            "auto",
          )}
        </div>
      </details>

      ${includeDisplay && caps.has_display !== false
        ? html`<details class="sub-collapsible" open>
            <summary>${store.t("groups.section_display")}</summary>
            <div class="card-content settings-list">
              ${renderBaselineLabeledSelect(
                store,
                group,
                "wallpaper_source",
                cfg.wallpaper_source,
                wallpaperOptions,
                "",
              )}
              ${renderBaselineLabeledSelect(
                store,
                group,
                "wallpaper_cycle_minutes",
                cfg.wallpaper_cycle_minutes,
                rotationOptions,
                "0",
                true,
              )}
              ${renderSpecSelect(store, group, "screensaver_style", cfg.screensaver_style, caps)}
              ${renderSpecSelect(store, group, "color_profile", cfg.color_profile, caps)}
              ${colorProfile === "Custom"
                ? renderSettingsRow({
                    label: store.tPrefLabel("device_custom_color"),
                    control: html`<input
                        type="color"
                        aria-label=${store.t("groups.for_group_aria", {
                          label: store.tPrefLabel("device_custom_color"),
                          group: group.name,
                        })}
                        .value=${customHex}
                        @change=${(ev) => {
                          const raw = (ev.currentTarget).value.toUpperCase();
                          if (isValidHexColor(raw)) {
                            void store.groups.updateGroupBaseline(gid, {
                              device_custom_color: raw,
                            });
                          }
                        }}
                      />
                      <span class="chip">${customHex}</span>`,
                  })
                : nothing}
              ${renderSpecSelect(store, group, "va_visual_profile", cfg.va_visual_profile, caps)}
            </div>
          </details>`
        : nothing}

      ${includeInterface && caps.has_display !== false
        ? html`<details class="sub-collapsible" open>
            <summary>${store.t("groups.section_interface")}</summary>
            <div class="card-content settings-list">
              ${renderSpecSwitch(
                store,
                group,
                "home_screen_enabled",
                cfg.home_screen_enabled,
                caps,
              )}
              ${renderSpecSelect(store, group, "start_screen", cfg.start_screen, caps)}
              ${renderSpecSelect(store, group, "time_format", cfg.time_format, caps)}
              ${renderSpecSelect(
                store,
                group,
                "home_clock_tap_action",
                cfg.home_clock_tap_action,
                caps,
              )}
              ${renderSpecSelect(store, group, "clock_face", cfg.clock_face, caps)}
              ${renderSpecSelect(
                store,
                group,
                "home_date_tap_action",
                cfg.home_date_tap_action,
                caps,
              )}
              ${renderSpecSelect(
                store,
                group,
                "return_to_home_timeout",
                cfg.return_to_home_timeout,
                caps,
              )}
              ${renderSpecSwitch(store, group, "wake_greeting", cfg.wake_greeting, caps)}
              ${renderSpecSwitch(
                store,
                group,
                "weather_background",
                cfg.weather_background,
                caps,
              )}
              ${renderSpecSwitch(store, group, "home_sun", cfg.home_sun, caps)}
              ${renderSpecSwitch(store, group, "home_moon", cfg.home_moon, caps)}
              ${renderSwitchRow({
                label: store.tPrefLabel("activity_card"),
                ariaLabel: store.t("groups.for_group_aria", {
                  label: store.tPrefLabel("activity_card"),
                  group: group.name,
                }),
                checked: cfg.activity_card !== false,
                onChange: (checked) =>
                  void store.groups.updateGroupBaseline(gid, { activity_card: checked }),
              })}
              ${renderBaselinePills(
                store,
                group,
                "activity_sources",
                cfg.activity_sources,
                ACTIVITY_SOURCES_CATALOG,
                DEFAULT_ACTIVITY_SOURCES,
                0,
                caps,
              )}
              ${renderBaselinePills(
                store,
                group,
                "home_categories",
                cfg.home_categories,
                HOME_CATEGORIES_CATALOG,
                DEFAULT_HOME_CATEGORIES,
                1,
                caps,
              )}
              ${renderBaselinePills(
                store,
                group,
                "area_categories",
                cfg.area_categories,
                AREA_CATEGORIES_CATALOG,
                DEFAULT_AREA_CATEGORIES,
                1,
                caps,
              )}
              ${renderBaselinePills(
                store,
                group,
                "tools_items",
                cfg.tools_items,
                TOOLS_ITEMS_CATALOG,
                DEFAULT_TOOLS_ITEMS,
                1,
                caps,
              )}
              ${renderBaselinePills(
                store,
                group,
                "games_items",
                cfg.games_items,
                GAMES_ITEMS_CATALOG,
                DEFAULT_GAMES_ITEMS,
                1,
                caps,
              )}
              ${renderBaselineLabeledSelect(
                store,
                group,
                "device_remote_group",
                cfg.device_remote_group,
                remoteScopeOptions,
                "area_auto",
              )}
              ${renderSpecSwitch(store, group, "show_utc_clock", cfg.show_utc_clock, caps)}
              ${renderBaselineLabeledSelect(
                store,
                group,
                "calendar_lookahead_days",
                cfg.calendar_lookahead_days ?? 30,
                lookaheadOptions,
                "30",
                true,
              )}
              ${renderSpecSelect(
                store,
                group,
                "calendar_week_start",
                cfg.calendar_week_start,
                caps,
              )}
              ${renderSpecSelect(store, group, "album_art_style", cfg.album_art_style, caps)}
              ${renderSpecSelect(
                store,
                group,
                "music_overlay_style",
                cfg.music_overlay_style,
                caps,
              )}
              ${renderSpecSelect(store, group, "album_sort_order", cfg.album_sort_order, caps)}
              ${renderSpecSelect(
                store,
                group,
                "artist_album_sort_order",
                cfg.artist_album_sort_order,
                caps,
              )}
              ${renderSpecSelect(
                store,
                group,
                "podcast_sort_order",
                cfg.podcast_sort_order,
                caps,
              )}
              ${latterDevices.length
                ? html`${renderSettingsRow({
                      label: store.t("card.app_dock"),
                      description:
                        dockCount === 1
                          ? store.t("groups.dock_baseline_desc_one")
                          : store.t("groups.dock_baseline_desc_many", {
                              count: fmtNumber(dockCount, store.hass, 0),
                            }),
                      control: html`<button
                        type="button"
                        @click=${() =>
                          requestCopyDeviceIntoGroup(
                            store,
                            group,
                            members.length,
                            copySrc,
                            latterDevices,
                            ["dock_items"],
                            store.t("card.app_dock"),
                          )}
                        class="btn btn-secondary btn-compact"
                      >
                        ${store.t("groups.copy_dock")}
                      </button>`,
                    })}
                    ${renderSettingsRow({
                      label: store.t("dialogs.pinned_label"),
                      description:
                        pinnedCount === 1
                          ? store.t("groups.pinned_baseline_desc_one")
                          : store.t("groups.pinned_baseline_desc_many", {
                              count: fmtNumber(pinnedCount, store.hass, 0),
                            }),
                      control: html`<button
                        type="button"
                        @click=${() =>
                          requestCopyDeviceIntoGroup(
                            store,
                            group,
                            members.length,
                            copySrc,
                            latterDevices,
                            ["pinned_items"],
                            store.t("dialogs.pinned_label"),
                          )}
                        class="btn btn-secondary btn-compact"
                      >
                        ${store.t("groups.copy_pinned")}
                      </button>`,
                    })}
                    ${renderSettingsRow({
                      label: store.t("dialogs.world_clocks_label"),
                      description:
                        clockCount === 1
                          ? store.t("groups.clocks_baseline_desc_one")
                          : store.t("groups.clocks_baseline_desc_many", {
                              count: fmtNumber(clockCount, store.hass, 0),
                            }),
                      control: html`<button
                        type="button"
                        @click=${() =>
                          requestCopyDeviceIntoGroup(
                            store,
                            group,
                            members.length,
                            copySrc,
                            latterDevices,
                            ["world_clocks"],
                            store.t("dialogs.world_clocks_label"),
                          )}
                        class="btn btn-secondary btn-compact"
                      >
                        ${store.t("groups.copy_clocks")}
                      </button>`,
                    })}`
                : nothing}
            </div>
          </details>`
        : nothing}

      ${latterDevices.length
        ? html`<div class="settings-list">
            <div class="subsection-title">${store.t("groups.copy_from_device")}</div>
            ${renderSettingsRow({
              label: store.t("groups.source_device"),
              description: store.t("groups.source_device_desc"),
              control: html`<select
                  aria-label=${store.t("groups.copy_into_aria", { name: group.name })}
                  .value=${copySrc}
                  @change=${(ev) => {
                    store.groupCopySourceDrafts.set(
                      gid,
                      (ev.currentTarget).value,
                    );
                    store.host.requestUpdate();
                  }}
                >
                  ${latterDevices.map(
                    (d) =>
                      html`<option value=${d.subentry_id} ?selected=${d.subentry_id === copySrc}>
                        ${d.title}
                      </option>`,
                  )}
                </select>
                <button
                  type="button"
                  @click=${() =>
                    requestCopyDeviceIntoGroup(
                      store,
                      group,
                      members.length,
                      copySrc,
                      latterDevices,
                    )}
                  class="btn btn-secondary btn-compact"
                >
                  ${store.t("groups.copy_settings")}
                </button>`,
            })}
          </div>`
        : nothing}
    </div>
  </details>`;
}
__latterExp(__exports, { renderGroupBaselineDrawer: () => renderGroupBaselineDrawer });
//# sourceURL=latter-studio/src/views/groups/group-baseline-drawer.ts
});
__latterDef("src/views/system-groups-view.ts", (__exports, __req) => {
const { renderCard, renderTrashIconButton } = __req("src/components/controls.ts");
const { DEFAULT_DEVICE_GROUP_IDS } = __req("src/constants.ts");
const { focusSafe, html, nothing, repeat } = __req("src/lib/lit.ts");
const { fmtNumber } = __req("src/utils/format.ts");
const { renderBatchControlsCard } = __req("src/views/groups/batch-controls.ts");
const { renderGroupBaselineDrawer } = __req("src/views/groups/group-baseline-drawer.ts");
/**
 * System Device Groups & Staged Batch Controls View (`system_sync`, `D-048`, `D-050`, `D-055`, `D-064`).
 * - Column 1: Non-stuttering `Group presets & custom groups` card (`R-8`) with on-demand creation form,
 *   enclosed group containers (`requestDeleteDeviceGroup` confirmation), and read-only
 *   `Custom (individual settings)` summary container (`Q6`).
 * - Column 2: Staged `Batch controls` (`batch-controls.ts`) behind **Apply to N Devices** & **Reset**.
 */
function renderSystemGroupsView(store) {
  const data = store.state;
  const allDevices = data?.system_devices || [];
  const latterDevices = allDevices.filter((d) => d.kind !== "ble_tag");
  const groups = data?.device_groups || [];
  const systemControls = data?.system_controls || [];
  const customMembers = latterDevices.filter(
    (d) => !d.device_group || d.device_group === "custom",
  );
  return html`<section id="view-system_sync">
    <div class="columns">
      <div class="column">
        ${renderCard({
          id: "card-device-groups",
          title: store.t("groups.card_title"),
          subtitle: store.t("groups.card_subtitle"),
          headerActions: !store.newGroupFormOpen
            ? html`<button
                type="button"
                id="btn-open-create-group"
                @click=${() => store.groups.toggleNewGroupForm(true)}
                class="btn btn-secondary btn-compact"
              >
                ${store.t("groups.create_group")}
              </button>`
            : nothing,
          contentClass: "stack",
          body: html`${store.newGroupFormOpen
              ? html`<div id="create-group-form" class="list-block">
                  <div class="list-row-main">
                    <div class="stacked-field">
                      <label for="new-group-name">${store.t("groups.group_name")}</label>
                      <input
                        type="text"
                        id="new-group-name"
                        placeholder=${store.t("groups.group_name_placeholder")}
                        .value=${focusSafe(store.newGroupName)}
                        @input=${(ev) => {
                          store.newGroupName = (ev.currentTarget).value;
                        }}
                      />
                    </div>
                    <div class="stacked-field">
                      <label for="new-group-desc">
                        ${store.t("groups.description_optional")}
                      </label>
                      <input
                        type="text"
                        id="new-group-desc"
                        placeholder=${store.t("groups.description_placeholder")}
                        .value=${focusSafe(store.newGroupDesc)}
                        @input=${(ev) => {
                          store.newGroupDesc = (ev.currentTarget).value;
                        }}
                      />
                    </div>
                  </div>
                  <div class="pill-list">
                    <span class="pill ${store.newGroupIncludeDisplay ? "enabled" : ""}">
                      <button
                        type="button"
                        aria-pressed=${store.newGroupIncludeDisplay ? "true" : "false"}
                        @click=${() => {
                          store.newGroupIncludeDisplay = !store.newGroupIncludeDisplay;
                          store.host.requestUpdate();
                        }}
                        class="pill-toggle"
                      >
                        ${store.t("groups.include_display")}
                      </button>
                    </span>
                    <span class="pill ${store.newGroupIncludeInterface ? "enabled" : ""}">
                      <button
                        type="button"
                        aria-pressed=${store.newGroupIncludeInterface ? "true" : "false"}
                        @click=${() => {
                          store.newGroupIncludeInterface = !store.newGroupIncludeInterface;
                          store.host.requestUpdate();
                        }}
                        class="pill-toggle"
                      >
                        ${store.t("groups.include_interface")}
                      </button>
                    </span>
                  </div>
                  <div class="input-action-row">
                    <select
                      id="new-group-source"
                      aria-label=${store.t("groups.copy_from_aria")}
                      .value=${store.newGroupSourceSubentryId}
                      @change=${(ev) => {
                        store.newGroupSourceSubentryId = (
                          ev.currentTarget
                        ).value;
                      }}
                    >
                      <option value="" ?selected=${!store.newGroupSourceSubentryId}>
                        ${store.t("groups.start_from_defaults")}
                      </option>
                      ${latterDevices.map(
                        (d) =>
                          html`<option
                            value=${d.subentry_id}
                            ?selected=${d.subentry_id === store.newGroupSourceSubentryId}
                          >
                            ${store.t("groups.copy_from_prefix", { title: d.title })}
                          </option>`,
                      )}
                    </select>
                    <button
                      type="button"
                      id="btn-cancel-create-group"
                      @click=${() => store.groups.toggleNewGroupForm(false)}
                      class="btn btn-secondary"
                    >
                      ${store.t("action.cancel")}
                    </button>
                    <button
                      type="button"
                      id="btn-create-device-group"
                      @click=${() => void store.groups.createDeviceGroup()}
                      class="btn btn-primary"
                    >
                      ${store.t("groups.create_group")}
                    </button>
                  </div>
                </div>`
              : nothing}

            <div id="device-groups-list" class="stack">
              ${groups.length
                ? repeat(
                    groups,
                    (g) => g.id,
                    (g) => {
                      const members = latterDevices.filter((d) => d.device_group === g.id);
                      const isDefault =
                        DEFAULT_DEVICE_GROUP_IDS.has(g.id) || Boolean(g.builtin);
                      const metaParts = [
                        g.description || "",
                        members.length
                          ? store.t("groups.devices_list_meta", {
                              names: members.map((m) => m.title).join(", "),
                            })
                          : store.t("groups.no_devices_assigned"),
                      ].filter(Boolean);
                      const groupBoxId = `group-box-${g.id}`;
                      const isGroupHandoff = store.isHandoffTarget(groupBoxId);
                      return html`<div
                        id=${groupBoxId}
                        class="area-presence-box${isGroupHandoff ? " handoff-active" : ""}"
                      >
                        <div class="area-box-head">
                          <div class="area-box-heading">
                            <h4 class="area-box-title">${g.name}</h4>
                            <span class="chip ${members.length ? "chip-primary" : ""}">
                              ${members.length === 1
                                ? store.t("groups.members_one")
                                : store.t("groups.members_many", {
                                    count: fmtNumber(members.length, store.hass, 0),
                                  })}
                            </span>
                            ${g.include_display
                              ? html`<span class="chip">
                                  ${store.t("groups.scope_display_chip")}
                                </span>`
                              : nothing}
                            ${g.include_interface
                              ? html`<span class="chip">
                                  ${store.t("groups.scope_interface_chip")}
                                </span>`
                              : nothing}
                          </div>
                          <div class="area-box-actions">
                            ${members.length
                              ? html`<button
                                  type="button"
                                  @click=${() => store.openDevicesWithCategory(`group:${g.id}`)}
                                  class="btn btn-text btn-compact"
                                >
                                  ${store.t("groups.view_devices")}
                                </button>`
                              : nothing}
                            ${isDefault
                              ? html`<button
                                  type="button"
                                  id="btn-reset-group-${g.id}"
                                  @click=${() =>
                                    store.groups.requestResetDeviceGroup(
                                      g.id,
                                      g.name,
                                      members.length,
                                    )}
                                  class="btn btn-text btn-compact"
                                >
                                  ${store.t("groups.reset_preset")}
                                </button>`
                              : renderTrashIconButton(
                                  store.t("groups.delete_group_aria", { name: g.name }),
                                  () =>
                                    store.groups.requestDeleteDeviceGroup(
                                      g.id,
                                      g.name,
                                      members.length,
                                    ),
                                )}
                          </div>
                        </div>

                        <div class="area-box-meta">${metaParts.join(" • ")}</div>

                        ${renderGroupBaselineDrawer(store, g, members, latterDevices)}
                      </div>`;
                    },
                  )
                : html`<p class="empty-state">${store.t("groups.empty_groups")}</p>`}

              <div id="group-box-custom" class="area-presence-box">
                <div class="area-box-head">
                  <div class="area-box-heading">
                    <h4 class="area-box-title">${store.t("groups.custom_summary_title")}</h4>
                    <span class="chip ${customMembers.length ? "chip-primary" : ""}">
                      ${customMembers.length === 1
                        ? store.t("groups.members_one")
                        : store.t("groups.members_many", {
                            count: fmtNumber(customMembers.length, store.hass, 0),
                          })}
                    </span>
                  </div>
                  <div class="area-box-actions">
                    ${customMembers.length > 0
                      ? html`<button
                          type="button"
                          id="btn-view-custom-devices"
                          @click=${() => store.openDevicesWithCategory("group:custom")}
                          class="btn btn-text btn-compact"
                        >
                          ${store.t("groups.view_devices")}
                        </button>`
                      : nothing}
                  </div>
                </div>
                <div class="area-box-meta">${store.t("groups.custom_summary_desc")}</div>
              </div>
            </div>`,
        })}
      </div>

      <div class="column">
        ${renderBatchControlsCard(store, groups, latterDevices, systemControls)}
      </div>
    </div>
  </section>`;
}
__latterExp(__exports, { renderSystemGroupsView: () => renderSystemGroupsView });
//# sourceURL=latter-studio/src/views/system-groups-view.ts
});
__latterDef("src/views/system-overview-view.ts", (__exports, __req) => {
const { renderCard, renderSvgIcon } = __req("src/components/controls.ts");
const { html, nothing } = __req("src/lib/lit.ts");
const { fmtNumber, issueMessage, isValidHexColor } = __req("src/utils/format.ts");
/**
 * System Overview View (`system_overview`, `D-003`, `D-004`, `D-051`, `D-061`, `D-066`):
 * - Conditional top region for active Home Assistant Repairs (`role="region"` + heading, `D-21`)
 *   and unbound Discovered Latter hardware.
 * - Column 1: High-level Status card (`D-003` release meta, `D-004` People & roaming) +
 *   Area deployment (`area_id` matching `E-21`).
 * - Column 2: System capabilities (dynamic group names `E-25`, `"colors & wallpapers"` `E-22`,
 *   `isValidHexColor` swatch guard `A-07`).
 */
const SYS_ICON_DEVICES =
  "M4,6H20V16H4M20,18A2,2 0 0,0 22,16V6C22,4.89 21.1,4 20,4H4C2.89,4 2,4.89 2,6V16A2,2 0 0,0 4,18H0V20H24V18H20Z";
const SYS_ICON_AREAS =
  "M12,6.5A2.5,2.5 0 0,1 14.5,9A2.5,2.5 0 0,1 12,11.5A2.5,2.5 0 0,1 9.5,9A2.5,2.5 0 0,1 12,6.5M12,2A7,7 0 0,1 19,9C19,14.25 12,22 12,22C12,22 5,14.25 5,9A7,7 0 0,1 12,2M12,4A5,5 0 0,0 7,9C7,10 7,12 12,18.71C17,12 17,10 17,9A5,5 0 0,0 12,4Z";
const SYS_ICON_ROAMING =
  "M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12C22,10.84 21.79,9.69 21.39,8.61L19.79,10.21C19.93,10.8 20,11.4 20,12A8,8 0 0,1 12,20A8,8 0 0,1 4,12A8,8 0 0,1 12,4C12.6,4 13.2,4.07 13.79,4.21L15.4,2.6C14.31,2.21 13.16,2 12,2M19,2A2,2 0 0,0 17,4A2,2 0 0,0 19,6A2,2 0 0,0 21,4A2,2 0 0,0 19,2M12,6A6,6 0 0,0 6,12A6,6 0 0,0 12,18A6,6 0 0,0 18,12H16A4,4 0 0,1 12,16A4,4 0 0,1 8,12A4,4 0 0,1 12,8V6M12,10A2,2 0 0,0 10,12A2,2 0 0,0 12,14A2,2 0 0,0 14,12A2,2 0 0,0 12,10Z";
const SYS_ICON_RELEASE =
  "M17,17H7V7H17M21,11V9H19V7C19,5.89 18.1,5 17,5H15V3H13V5H11V3H9V5H7C5.89,5 5,5.89 5,7V9H3V11H5V13H3V15H5V17A2,2 0 0,0 7,19H9V21H11V19H13V21H15V19H17A2,2 0 0,0 19,17V15H21V13H19V11M15,15H9V9H15V15Z";
const SYS_ICON_HOME =
  "M12,3L2,12H5V20H19V12H22L12,3M12,8.75A2.25,2.25 0 0,1 14.25,11A2.25,2.25 0 0,1 12,13.25A2.25,2.25 0 0,1 9.75,11A2.25,2.25 0 0,1 12,8.75M12,15C13.5,15 16.5,15.75 16.5,17.25V18H7.5V17.25C7.5,15.75 10.5,15 12,15Z";
const SYS_ICON_CAMERA =
  "M17,10.5V7A1,1 0 0,0 16,6H4A1,1 0 0,0 3,7V17A1,1 0 0,0 4,18H16A1,1 0 0,0 17,17V13.5L21,17.5V6.5L17,10.5Z";
const SYS_ICON_REMOTE =
  "M9,2A2,2 0 0,0 7,4V20A2,2 0 0,0 9,22H15A2,2 0 0,0 17,20V4A2,2 0 0,0 15,2H9M12,6A3,3 0 0,1 15,9A3,3 0 0,1 12,12A3,3 0 0,1 9,9A3,3 0 0,1 12,6M12,8A1,1 0 0,0 11,9A1,1 0 0,0 12,10A1,1 0 0,0 13,9A1,1 0 0,0 12,8M10,15H14V17H10V15M10,18H14V20H10V18Z";
const SYS_ICON_GROUPS =
  "M3,3H11V11H3V3M13,3H21V11H13V3M3,13H11V21H3V13M13,13H21V21H13V13M5,5V9H9V5H5M15,5V9H19V5H15M5,15V19H9V15H5M15,15V19H19V15H15Z";
const SYS_ICON_PALETTE =
  "M17.5,12A1.5,1.5 0 0,1 16,10.5A1.5,1.5 0 0,1 17.5,9A1.5,1.5 0 0,1 19,10.5A1.5,1.5 0 0,1 17.5,12M14.5,8A1.5,1.5 0 0,1 13,6.5A1.5,1.5 0 0,1 14.5,5A1.5,1.5 0 0,1 16,6.5A1.5,1.5 0 0,1 14.5,8M9.5,8A1.5,1.5 0 0,1 8,6.5A1.5,1.5 0 0,1 9.5,5A1.5,1.5 0 0,1 11,6.5A1.5,1.5 0 0,1 9.5,8M6.5,12A1.5,1.5 0 0,1 5,10.5A1.5,1.5 0 0,1 6.5,9A1.5,1.5 0 0,1 8,10.5A1.5,1.5 0 0,1 6.5,12M12,3A9,9 0 0,0 3,12A9,9 0 0,0 12,21A1.5,1.5 0 0,0 13.5,19.5C13.5,19.11 13.35,18.76 13.11,18.5C12.88,18.23 12.73,17.88 12.73,17.5A1.5,1.5 0 0,1 14.23,16H16A5,5 0 0,0 21,11C21,6.58 16.97,3 12,3Z";
const SYS_ICON_SHIELD =
  "M12,1L3,5V11C3,16.55 6.84,21.74 12,23C17.16,21.74 21,16.55 21,11V5L12,1M12,7C13.4,7 14.8,8.1 14.8,9.5V11C15.4,11 16,11.6 16,12.3V15.8C16,16.4 15.4,17 14.7,17H9.2C8.6,17 8,16.4 8,15.7V12.2C8,11.6 8.6,11 9.2,11V9.5C9.2,8.1 10.6,7 12,7M12,8.2C11.2,8.2 10.5,8.7 10.5,9.5V11H13.5V9.5C13.5,8.7 12.8,8.2 12,8.2Z";
function renderSystemOverviewView(store) {
  const data = store.state;
  const allDevices = data?.system_devices || [];
  const issues = data?.issues || [];
  const discoveredLatter = data?.discovered_latter_devices || [];
  const groups = data?.device_groups || [];
  const sysCfg = data?.system_config;
  const presenceRows = data?.live?.area_presence_grid || [];
  const signatures = data?.ble_area_signatures || [];
  const totalCount = allDevices.length;
  const onlineCount = allDevices.filter((d) => d.is_online).length;
  const offlineCount = Math.max(0, totalCount - onlineCount);
  const displayCount = allDevices.filter((d) => d.kind !== "ble_tag" && d.has_display).length;
  const phoneCount = allDevices.filter(
    (d) => d.kind === "ble_tag" && d.ble_category === "phone",
  ).length;
  const bleTagOnlyCount = allDevices.filter(
    (d) => d.kind === "ble_tag" && d.ble_category !== "phone",
  ).length;
  const audioOnlyCount = allDevices.filter((d) => d.kind !== "ble_tag" && !d.has_display).length;
  const bleTrackedCount = allDevices.filter((d) => d.ble_tracked || d.kind === "ble_tag").length;
  const assignedPeopleCount = allDevices.filter((d) => Boolean(d.assigned_person)).length;
  const updatesCount = Math.max(
    allDevices.filter((d) => d.status_code === "update" || d.status_label === "Update available")
      .length,
    Number(data?.update_check?.available || 0),
  );
  const hasVerifiedUpToDate = Boolean(data?.update_check && data.update_check.checked > 0);
  const verText = data?.version
    ? `v${String(data.version).replace(/^v/i, "")}`
    : store.t("common.unknown");
  const bleProxyCount = Number(data?.ble_proxy_count ?? 0);
  const hasErrorIssue = issues.some((i) => i.severity === "error" || i.severity === "critical");
  let sysChipClass = "chip";
  let sysDotClass = "status-dot";
  let sysStatusLabel = store.t("sys_overview.no_devices");
  if (issues.length > 0) {
    sysChipClass = hasErrorIssue ? "chip chip-error" : "chip chip-warning";
    sysDotClass = "status-dot update";
    sysStatusLabel =
      issues.length === 1
        ? store.t("sys_overview.issues_one")
        : store.t("sys_overview.issues_many", { count: fmtNumber(issues.length, store.hass, 0) });
  } else if (totalCount > 0 && updatesCount > 0) {
    sysChipClass = "chip chip-warning";
    sysDotClass = "status-dot update";
    sysStatusLabel =
      updatesCount === 1
        ? store.t("sys_overview.updates_one")
        : store.t("sys_overview.updates_many", {
            count: fmtNumber(updatesCount, store.hass, 0),
          });
  } else if (totalCount > 0 && offlineCount === 0) {
    sysChipClass = "chip chip-success";
    sysDotClass = "status-dot online";
    sysStatusLabel = store.t("sys_overview.all_online");
  } else if (totalCount > 0 && onlineCount > 0) {
    sysDotClass = "status-dot online";
    sysStatusLabel = store.t("sys_overview.online_ratio", {
      online: fmtNumber(onlineCount, store.hass, 0),
      total: fmtNumber(totalCount, store.hass, 0),
    });
  } else if (totalCount > 0) {
    sysStatusLabel = store.t("status.offline");
  }
  const onlinePct = totalCount > 0 ? Math.round((onlineCount / totalCount) * 100) : 0;
  const onlineSigStyle = `--signal-pct:${onlinePct}%`;
  const devMetaParts = [];
  if (totalCount === 0) {
    devMetaParts.push(store.t("sys_overview.ready_to_onboard"));
  } else {
    devMetaParts.push(
      displayCount === 1
        ? store.t("sys_overview.displays_one")
        : store.t("sys_overview.displays_many", {
            count: fmtNumber(displayCount, store.hass, 0),
          }),
    );
    if (phoneCount > 0) {
      devMetaParts.push(
        phoneCount === 1
          ? store.t("sys_overview.phones_one")
          : store.t("sys_overview.phones_many", { count: fmtNumber(phoneCount, store.hass, 0) }),
      );
    }
    if (bleTagOnlyCount > 0) {
      devMetaParts.push(
        bleTagOnlyCount === 1
          ? store.t("sys_overview.ble_tags_one")
          : store.t("sys_overview.ble_tags_many", {
              count: fmtNumber(bleTagOnlyCount, store.hass, 0),
            }),
      );
    } else if (phoneCount === 0 && audioOnlyCount > 0) {
      devMetaParts.push(
        store.t("sys_overview.audio_count", { count: fmtNumber(audioOnlyCount, store.hass, 0) }),
      );
    }
  }
  // Build unified Area Deployment map matching Areas strictly by `area_id` (E-21)
  const sigByArea = new Map();
  for (const sig of signatures) {
    if (sig.area_id) sigByArea.set(sig.area_id, sig);
  }
  const rowByArea = new Map();
  for (const row of presenceRows) {
    if (row.area_id) rowByArea.set(row.area_id, row);
  }
  const remoteGroups = sysCfg?.remote_groups || [];
  const allAreaIds = [];
  const seenAreaIds = new Set();
  for (const row of presenceRows) {
    if (row.area_id && !seenAreaIds.has(row.area_id)) {
      seenAreaIds.add(row.area_id);
      allAreaIds.push(row.area_id);
    }
  }
  for (const sig of signatures) {
    if (sig.area_id && !seenAreaIds.has(sig.area_id)) {
      seenAreaIds.add(sig.area_id);
      allAreaIds.push(sig.area_id);
    }
  }
  for (const catArea of data?.catalog?.areas || []) {
    if (catArea.id && !seenAreaIds.has(catArea.id)) {
      seenAreaIds.add(catArea.id);
      allAreaIds.push(catArea.id);
    }
  }
  const areaEntries = allAreaIds.map((areaId) => {
    const row = rowByArea.get(areaId);
    const sig = sigByArea.get(areaId);
    const catArea = (data?.catalog?.areas || []).find((a) => a.id === areaId);
    const areaName = row?.area_name || sig?.area_name || catArea?.name || areaId;
    const stationedTitles = allDevices
      .filter((d) => d.has_assigned_area && d.area_id === areaId)
      .map((d) => d.title);
    const roamingHereTitles = allDevices
      .filter((d) => !d.has_assigned_area && d.is_online && d.area_id === areaId)
      .map((d) => d.title);
    const areaRemoteCount = remoteGroups
      .filter((rg) => rg.area_id === areaId)
      .reduce((acc, rg) => acc + (rg.remotes || []).filter(Boolean).length, 0);
    const hasBleProxy = sig
      ? Boolean(sig.has_ble_proxy)
      : Boolean(row?.winning_rssi !== null && row?.winning_rssi !== undefined);
    const hasSignature = Boolean(sig?.has_signature);
    const activeSensorCount = (row?.active_sensors || []).length;
    const sensorCount = Math.max((row?.fusion_sensors || []).length, activeSensorCount);
    const isOccupied = Boolean(row?.is_occupied);
    const occupants = row?.occupant_names || [];
    const isDeployed =
      isOccupied ||
      stationedTitles.length > 0 ||
      roamingHereTitles.length > 0 ||
      hasSignature ||
      hasBleProxy ||
      areaRemoteCount > 0 ||
      sensorCount > 0;
    return {
      areaId,
      areaName,
      floorLabel: String(row?.floor_name || "").trim(),
      isOccupied,
      occupants,
      hasBleProxy,
      hasSignature,
      scannerCount: Number(sig?.scanner_count || 0),
      stationedTitles,
      roamingHereTitles,
      remoteCount: areaRemoteCount,
      sensorCount,
      activeSensorCount,
      isDeployed,
    };
  });
  areaEntries.sort((a, b) => {
    if (a.isOccupied !== b.isOccupied) return a.isOccupied ? -1 : 1;
    const aDev = a.stationedTitles.length + a.roamingHereTitles.length;
    const bDev = b.stationedTitles.length + b.roamingHereTitles.length;
    if (aDev > 0 !== bDev > 0) return aDev > 0 ? -1 : 1;
    return a.areaName.localeCompare(b.areaName, undefined, { sensitivity: "base" });
  });
  const totalAreas = areaEntries.length;
  const occupiedAreasCount = areaEntries.filter((a) => a.isOccupied).length;
  const deployedAreas = areaEntries.filter((a) => a.isDeployed);
  const shownAreas = deployedAreas.length > 0 ? deployedAreas : areaEntries.slice(0, 6);
  const unconfiguredAreaCount =
    deployedAreas.length > 0
      ? Math.max(0, totalAreas - deployedAreas.length)
      : Math.max(0, totalAreas - shownAreas.length);
  const roamingDevices = allDevices.filter(
    (d) => !d.has_assigned_area && (d.is_roaming || d.kind === "ble_tag"),
  );
  const roamingOnlineCount = roamingDevices.filter((d) => d.is_online).length;
  // System Capabilities metrics
  const thermCount = (sysCfg?.thermostat_entities || []).filter((s) =>
    Boolean(String(s || "").trim()),
  ).length;
  const lockCount = (sysCfg?.lock_entities || []).filter((s) =>
    Boolean(String(s || "").trim()),
  ).length;
  const garageCount = (sysCfg?.garage_entities || []).filter((s) =>
    Boolean(String(s || "").trim()),
  ).length;
  const vacCount = (sysCfg?.vacuum_entities || []).filter((s) =>
    Boolean(String(s || "").trim()),
  ).length;
  const wholeHomeStatuses = [
    {
      label: store.t("sys_overview.hub_weather"),
      configured: Boolean(String(sysCfg?.weather_entity || "").trim()),
    },
    {
      label: store.t("sys_overview.hub_alarm"),
      configured: Boolean(String(sysCfg?.alarm_entity || "").trim()),
    },
    {
      label:
        thermCount > 1
          ? store.t("sys_overview.hub_zones", { count: fmtNumber(thermCount, store.hass, 0) })
          : store.t("sys_overview.hub_thermostat"),
      configured: thermCount > 0,
    },
    {
      label:
        lockCount > 1
          ? store.t("sys_overview.hub_locks", { count: fmtNumber(lockCount, store.hass, 0) })
          : store.t("sys_overview.hub_lock"),
      configured: lockCount > 0,
    },
    {
      label:
        garageCount > 1
          ? store.t("sys_overview.hub_garages", { count: fmtNumber(garageCount, store.hass, 0) })
          : store.t("sys_overview.hub_garage"),
      configured: garageCount > 0,
    },
    {
      label:
        vacCount > 1
          ? store.t("sys_overview.hub_vacuums", { count: fmtNumber(vacCount, store.hass, 0) })
          : store.t("sys_overview.hub_vacuum"),
      configured: vacCount > 0,
    },
  ];
  const wholeHomeActiveCount = wholeHomeStatuses.filter((s) => s.configured).length;
  const camerasCount = (sysCfg?.camera_entities || []).filter(Boolean).length;
  const doorbellsCount = (data?.doorbells || []).filter((b) => Boolean(b.ring_entity)).length;
  const calendarsCount = (sysCfg?.calendar_entities || []).filter(Boolean).length;
  const remotesCount = (sysCfg?.remotes_list || []).filter(Boolean).length;
  const remoteGroupsCount = remoteGroups.length;
  const volCount = (sysCfg?.volume_overrides || []).length;
  const validPalettes = (sysCfg?.custom_palettes || []).filter((p) => isValidHexColor(p.hex));
  const colorsCount = validPalettes.length;
  const wallpapers = data?.system_wallpapers || [];
  const wallpapersCount = wallpapers.length;
  const uploadedWallpapersCount = wallpapers.filter(
    (w) => w.kind === "upload" || w.deletable,
  ).length;
  const presetWallpapersCount = Math.max(0, wallpapersCount - uploadedWallpapersCount);
  const hasSystemPin = Boolean(data?.has_security_pin);
  const latterHardwareDevices = allDevices.filter((d) => d.kind !== "ble_tag");
  const populatedGroupChips = [];
  for (const g of groups) {
    if (!g?.id || g.id === "custom") continue;
    const cnt = latterHardwareDevices.filter((d) => d.device_group === g.id).length;
    if (cnt > 0 || latterHardwareDevices.length === 0) {
      populatedGroupChips.push({
        label:
          latterHardwareDevices.length > 0
            ? `${g.name}: ${fmtNumber(cnt, store.hass, 0)}`
            : g.name,
        active: cnt > 0,
      });
    }
  }
  const customGroupCount = latterHardwareDevices.filter(
    (d) => !d.device_group || d.device_group === "custom",
  ).length;
  if (customGroupCount > 0) {
    populatedGroupChips.push({
      label: store.t("sys_overview.custom_group_chip", {
        count: fmtNumber(customGroupCount, store.hass, 0),
      }),
      active: true,
    });
  }
  const configuredGroupNames = groups
    .filter((g) => Boolean(g?.name) && g.id !== "custom")
    .map((g) => g.name);
  const discoveredPreviewNames =
    discoveredLatter
      .slice(0, 3)
      .map((d) => d.title || d.node_name)
      .join(", ") + (discoveredLatter.length > 3 ? "…" : "");
  return html`<section id="view-system_overview" class="stack">
    ${issues.length
      ? html`<div
          id="sys-issues-banner"
          role="region"
          aria-labelledby="sys-issues-heading"
          class="alert ${hasErrorIssue ? "alert-error" : "alert-warning"}"
        >
          <div class="alert-body">
            <h2 id="sys-issues-heading" class="row-label">
              ${store.t("status.needs_attention")}
            </h2>
            <ul class="alert-list">
              ${issues.map(
                (iss) => html`<li>
                  <strong>${iss.device_title || store.t("shell.title")}:</strong>
                  ${issueMessage(iss, store.hass)}
                  ${iss.subentry_id
                    ? html`<button
                        type="button"
                        @click=${() => void store.switchSystemDevice(String(iss.subentry_id))}
                        class="btn btn-text btn-compact"
                      >
                        ${store.t("sys_overview.open_device")}
                      </button>`
                    : nothing}
                </li>`,
              )}
            </ul>
          </div>
          <button
            type="button"
            @click=${() => store.openHaPage("/config/repairs")}
            class="btn btn-secondary btn-compact"
          >
            ${store.t("action.open_repairs")}
          </button>
        </div>`
      : nothing}

    ${discoveredLatter.length
      ? html`<div id="sys-discovered-banner" class="alert">
          <div class="alert-body">
            <strong>${store.t("sys_overview.discovered_banner_title")}</strong>
            <p class="row-description">
              ${discoveredLatter.length === 1
                ? store.t("sys_overview.discovered_banner_one", { names: discoveredPreviewNames })
                : store.t("sys_overview.discovered_banner_many", {
                    count: fmtNumber(discoveredLatter.length, store.hass, 0),
                    names: discoveredPreviewNames,
                  })}
            </p>
          </div>
          <button
            type="button"
            @click=${() => store.openDiscoveredDevices("card-discovered-latter")}
            class="btn btn-secondary btn-compact"
          >
            ${store.t("sys_overview.open_discovered")}
          </button>
        </div>`
      : nothing}

    <div class="columns">
      <div class="column">
        ${renderCard({
          id: "card-system-status",
          title: store.t("card.status"),
          headerActions: html`<span id="sys-status-chip" class=${sysChipClass}>
            <span class=${sysDotClass} aria-hidden="true"></span>${sysStatusLabel}
          </span>`,
          contentClass: "stack",
          body: html`<div class="status-tiles">
            <button
              type="button"
              id="sys-tile-devices"
              @click=${() => store.openDevicesWithCategory("all")}
              class="status-tile"
            >
              <div class="status-tile-head">
                ${renderSvgIcon(SYS_ICON_DEVICES)}
                <span>${store.t("sys_overview.tile_devices")}</span>
              </div>
              <strong class="status-tile-value">
                ${totalCount > 0
                  ? store.t("sys_overview.online_ratio", {
                      online: fmtNumber(onlineCount, store.hass, 0),
                      total: fmtNumber(totalCount, store.hass, 0),
                    })
                  : store.t("sys_overview.zero_devices")}
              </strong>
              <span class="status-tile-meta">${devMetaParts.join(" • ")}</span>
              ${totalCount > 0
                ? html`<div class="signal-track" aria-hidden="true">
                    <div
                      class="signal-fill${onlineCount === 0 ? " low" : ""}"
                      style=${onlineSigStyle}
                    ></div>
                  </div>`
                : nothing}
            </button>

            <button
              type="button"
              id="sys-tile-areas"
              @click=${() => store.openSystemSection("area_tracking")}
              class="status-tile"
            >
              <div class="status-tile-head">
                ${renderSvgIcon(SYS_ICON_AREAS)}
                <span>${store.t("sys_overview.tile_areas")}</span>
              </div>
              <strong class="status-tile-value">
                ${totalAreas > 0
                  ? store.t("sys_overview.occupied_count", {
                      count: fmtNumber(occupiedAreasCount, store.hass, 0),
                    })
                  : store.t("common.unknown")}
              </strong>
              <span class="status-tile-meta">
                ${totalAreas > 0
                  ? store.t("sys_overview.areas_proxies_meta", {
                      areas:
                        totalAreas === 1
                          ? store.t("sys_overview.areas_one")
                          : store.t("sys_overview.areas_many", {
                              count: fmtNumber(totalAreas, store.hass, 0),
                            }),
                      proxies:
                        bleProxyCount === 1
                          ? store.t("sys_overview.proxies_one")
                          : store.t("sys_overview.proxies_many", {
                              count: fmtNumber(bleProxyCount, store.hass, 0),
                            }),
                    })
                  : store.t("sys_overview.no_areas")}
              </span>
            </button>

            <button
              type="button"
              id="sys-tile-roaming"
              @click=${() =>
                store.openDevicesWithCategory(
                  assignedPeopleCount > 0
                    ? "assigned_person"
                    : bleTrackedCount > 0
                      ? "ble_tracked"
                      : "roaming",
                )}
              class="status-tile"
            >
              <div class="status-tile-head">
                ${renderSvgIcon(SYS_ICON_ROAMING)}
                <span>${store.t("sys_overview.tile_people_roaming")}</span>
              </div>
              <strong class="status-tile-value">
                ${assignedPeopleCount === 1
                  ? store.t("sys_overview.people_assigned_one")
                  : store.t("sys_overview.people_assigned_many", {
                      count: fmtNumber(assignedPeopleCount, store.hass, 0),
                    })}
              </strong>
              <span class="status-tile-meta">
                ${store.t("sys_overview.ble_tracked_meta", {
                  count: fmtNumber(bleTrackedCount, store.hass, 0),
                })}
              </span>
            </button>

            <button
              type="button"
              id="sys-tile-release"
              @click=${() =>
                updatesCount > 0
                  ? store.openDevicesWithCategory("updates")
                  : store.openSystemSection("system_tools", "card-support-diagnostics")}
              class="status-tile"
            >
              <div class="status-tile-head">
                ${renderSvgIcon(SYS_ICON_RELEASE)}
                <span>${store.t("sys_overview.tile_release")}</span>
              </div>
              <strong class="status-tile-value">${verText}</strong>
              <span class="status-tile-meta">
                ${updatesCount > 0
                  ? updatesCount === 1
                    ? store.t("sys_overview.fw_updates_one")
                    : store.t("sys_overview.fw_updates_many", {
                        count: fmtNumber(updatesCount, store.hass, 0),
                      })
                  : hasVerifiedUpToDate
                    ? store.t("status.up_to_date")
                    : store.t("common.unknown")}
              </span>
            </button>
          </div>`,
          footerActions: html`<button
              type="button"
              @click=${() => store.openHaPage("/config/repairs")}
              class="btn btn-text"
            >
              ${store.t("action.open_repairs")}
            </button>
            <button
              type="button"
              @click=${() => void store.tools.checkSystemUpdates()}
              class="btn btn-text"
            >
              ${store.t("sys_overview.check_fw_updates")}
            </button>`,
        })}

        ${renderCard({
          id: "card-area-deployment",
          title: store.t("card.area_deployment"),
          subtitle: store.t("sys_overview.area_deployment_subtitle"),
          headerActions: html`<button
            type="button"
            @click=${() => store.openSystemSection("area_tracking")}
            class="btn btn-text btn-compact"
          >
            ${store.t("sys_overview.manage_presence")}
          </button>`,
          contentClass: "stack",
          body: html`${roamingDevices.length > 0
              ? html`<button
                  type="button"
                  id="sys-deploy-roaming"
                  @click=${() => store.openDevicesWithCategory("roaming")}
                  class="overview-box"
                >
                  <div class="overview-box-head">
                    <span class="overview-box-title">
                      ${renderSvgIcon(SYS_ICON_ROAMING)}
                      <span>${store.t("sys_overview.roaming_devices")}</span>
                    </span>
                    <span class="overview-box-end">
                      <span class="chip ${roamingOnlineCount > 0 ? "chip-primary" : ""}">
                        ${store.t("sys_overview.roaming_active_ratio", {
                          online: fmtNumber(roamingOnlineCount, store.hass, 0),
                          total: fmtNumber(roamingDevices.length, store.hass, 0),
                        })}
                      </span>
                      <span class="overview-box-chevron" aria-hidden="true">›</span>
                    </span>
                  </div>
                  <span class="overview-box-meta">
                    ${roamingDevices
                      .slice(0, 4)
                      .map((d) =>
                        d.active_area_name && d.is_online
                          ? `${d.title} (${d.active_area_name})`
                          : d.title,
                      )
                      .join(" • ")}${roamingDevices.length > 4
                      ? ` • ${store.t("sys_overview.plus_more", {
                          count: fmtNumber(roamingDevices.length - 4, store.hass, 0),
                        })}`
                      : ""}
                  </span>
                </button>`
              : nothing}
            ${shownAreas.length > 0
              ? shownAreas.map((area) => {
                  const detailParts = [];
                  if (area.stationedTitles.length > 0) {
                    detailParts.push(area.stationedTitles.join(", "));
                  }
                  if (area.roamingHereTitles.length > 0) {
                    detailParts.push(
                      store.t("sys_overview.here_prefix", {
                        names: area.roamingHereTitles.join(", "),
                      }),
                    );
                  } else if (area.occupants.length > 0) {
                    detailParts.push(area.occupants.join(", "));
                  }
                  if (area.remoteCount > 0) {
                    detailParts.push(
                      area.remoteCount === 1
                        ? store.t("sys_overview.remotes_one")
                        : store.t("sys_overview.remotes_many", {
                            count: fmtNumber(area.remoteCount, store.hass, 0),
                          }),
                    );
                  }
                  if (area.activeSensorCount > 0) {
                    detailParts.push(
                      area.activeSensorCount === 1
                        ? store.t("sys_overview.active_sensors_one")
                        : store.t("sys_overview.active_sensors_many", {
                            count: fmtNumber(area.activeSensorCount, store.hass, 0),
                          }),
                    );
                  } else if (area.sensorCount > 0) {
                    detailParts.push(
                      area.sensorCount === 1
                        ? store.t("sys_overview.sensors_one")
                        : store.t("sys_overview.sensors_many", {
                            count: fmtNumber(area.sensorCount, store.hass, 0),
                          }),
                    );
                  }
                  if (!detailParts.length) {
                    detailParts.push(
                      area.isOccupied
                        ? store.t("sys_overview.occupied")
                        : store.t("sys_overview.no_devices_stationed"),
                    );
                  }
                  const needsCoverageHint =
                    !area.hasSignature &&
                    !area.hasBleProxy &&
                    (area.stationedTitles.length > 0 || area.sensorCount > 0);
                  return html`<button
                    type="button"
                    @click=${() => store.openSystemSection("area_tracking", `area-box-${area.areaId}`)}
                    class="overview-box"
                  >
                    <div class="overview-box-head">
                      <span class="overview-box-title">
                        <span>${area.areaName}</span>
                        ${area.floorLabel ? html`<span class="chip">${area.floorLabel}</span>` : nothing}
                      </span>
                      <span class="overview-box-end">
                        ${area.isOccupied
                          ? html`<span class="chip chip-success">
                              ${store.t("sys_overview.occupied")}
                            </span>`
                          : nothing}
                        ${area.hasSignature
                          ? html`<span class="chip chip-primary">
                              ${store.t("sys_overview.signature_count", {
                                count: fmtNumber(area.scannerCount, store.hass, 0),
                              })}
                            </span>`
                          : area.hasBleProxy
                            ? html`<span class="chip">${store.t("sys_overview.ble_proxy")}</span>`
                            : html`<span class="chip ${needsCoverageHint ? "chip-warning" : ""}">
                                ${store.t("sys_overview.no_ble_proxy")}
                              </span>`}
                        <span class="overview-box-chevron" aria-hidden="true">›</span>
                      </span>
                    </div>
                    <span class="overview-box-meta">${detailParts.join(" • ")}</span>
                  </button>`;
                })
              : roamingDevices.length === 0
                ? html`<p class="empty-state">${store.t("sys_overview.empty_deployment")}</p>`
                : nothing}
            ${unconfiguredAreaCount > 0
              ? html`<p class="help-text">
                  ${unconfiguredAreaCount === 1
                    ? store.t("sys_overview.unconfigured_areas_one")
                    : store.t("sys_overview.unconfigured_areas_many", {
                        count: fmtNumber(unconfiguredAreaCount, store.hass, 0),
                      })}
                </p>`
              : nothing}`,
        })}
      </div>

      <div class="column">
        ${renderCard({
          id: "card-system-capabilities",
          title: store.t("card.system_capabilities"),
          subtitle: store.t("sys_overview.capabilities_subtitle"),
          contentClass: "stack",
          body: html`<button
              type="button"
              id="cap-home-hub"
              @click=${() => store.openSystemSection("shared_entities", "card-whole-home")}
              class="overview-box"
            >
              <div class="overview-box-head">
                <span class="overview-box-title">
                  ${renderSvgIcon(SYS_ICON_HOME)}
                  <span>${store.t("card.home_hub_weather")}</span>
                </span>
                <span class="overview-box-end">
                  <span class="chip ${wholeHomeActiveCount > 0 ? "chip-primary" : ""}">
                    ${store.t("sys_overview.active_of_six", {
                      count: fmtNumber(wholeHomeActiveCount, store.hass, 0),
                    })}
                  </span>
                  <span class="overview-box-chevron" aria-hidden="true">›</span>
                </span>
              </div>
              <div class="overview-chips">
                ${wholeHomeStatuses.map(
                  (s) =>
                    html`<span class="chip ${s.configured ? "chip-primary" : ""}">
                      ${s.configured ? `✓ ${s.label}` : s.label}
                    </span>`,
                )}
              </div>
            </button>

            <button
              type="button"
              id="cap-cameras-calendars"
              @click=${() =>
                store.openSystemSection(
                  "shared_entities",
                  camerasCount === 0 && calendarsCount > 0
                    ? "card-calendars"
                    : "card-cameras-doorbell",
                  ["card-cameras-doorbell", "card-calendars"],
                )}
              class="overview-box"
            >
              <div class="overview-box-head">
                <span class="overview-box-title">
                  ${renderSvgIcon(SYS_ICON_CAMERA)}
                  <span>${store.t("sys_overview.cap_cameras_calendars")}</span>
                </span>
                <span class="overview-box-end">
                  <span class="chip ${camerasCount + calendarsCount > 0 ? "chip-primary" : ""}">
                    ${camerasCount + calendarsCount > 0
                      ? store.t("common.active")
                      : store.t("sys_overview.not_set")}
                  </span>
                  <span class="overview-box-chevron" aria-hidden="true">›</span>
                </span>
              </div>
              ${camerasCount + calendarsCount > 0
                ? html`<div class="overview-chips">
                    <span class="chip ${camerasCount > 0 ? "chip-primary" : ""}">
                      ${camerasCount === 1
                        ? store.t("sys_overview.cameras_one")
                        : store.t("sys_overview.cameras_many", {
                            count: fmtNumber(camerasCount, store.hass, 0),
                          })}
                    </span>
                    ${camerasCount > 0
                      ? html`<span class="chip ${doorbellsCount > 0 ? "chip-primary" : ""}">
                          ${doorbellsCount === 1
                            ? store.t("sys_overview.doorbells_one")
                            : store.t("sys_overview.doorbells_many", {
                                count: fmtNumber(doorbellsCount, store.hass, 0),
                              })}
                        </span>`
                      : nothing}
                    <span class="chip ${calendarsCount > 0 ? "chip-primary" : ""}">
                      ${calendarsCount === 1
                        ? store.t("sys_overview.calendars_one")
                        : store.t("sys_overview.calendars_many", {
                            count: fmtNumber(calendarsCount, store.hass, 0),
                          })}
                    </span>
                  </div>`
                : html`<span class="overview-box-meta">
                    ${store.t("sys_overview.cameras_calendars_empty")}
                  </span>`}
            </button>

            <button
              type="button"
              id="cap-media-remotes"
              @click=${() => store.openSystemSection("remotes")}
              class="overview-box"
            >
              <div class="overview-box-head">
                <span class="overview-box-title">
                  ${renderSvgIcon(SYS_ICON_REMOTE)}
                  <span>${store.t("sys_overview.cap_media_remotes")}</span>
                </span>
                <span class="overview-box-end">
                  <span class="chip ${remotesCount + volCount > 0 ? "chip-primary" : ""}">
                    ${remotesCount > 0
                      ? remotesCount === 1
                        ? store.t("sys_overview.remotes_one")
                        : store.t("sys_overview.remotes_many", {
                            count: fmtNumber(remotesCount, store.hass, 0),
                          })
                      : volCount > 0
                        ? store.t("common.active")
                        : store.t("sys_overview.not_set")}
                  </span>
                  <span class="overview-box-chevron" aria-hidden="true">›</span>
                </span>
              </div>
              <span class="overview-box-meta">
                ${remotesCount + remoteGroupsCount + volCount > 0
                  ? store.t("sys_overview.remotes_meta", {
                      groups:
                        remoteGroupsCount === 1
                          ? store.t("sys_overview.area_groups_one")
                          : store.t("sys_overview.area_groups_many", {
                              count: fmtNumber(remoteGroupsCount, store.hass, 0),
                            }),
                      overrides:
                        volCount === 1
                          ? store.t("sys_overview.vol_overrides_one")
                          : store.t("sys_overview.vol_overrides_many", {
                              count: fmtNumber(volCount, store.hass, 0),
                            }),
                    })
                  : store.t("sys_overview.remotes_empty")}
              </span>
            </button>

            <button
              type="button"
              id="cap-device-groups"
              @click=${() => store.openSystemSection("system_sync")}
              class="overview-box"
            >
              <div class="overview-box-head">
                <span class="overview-box-title">
                  ${renderSvgIcon(SYS_ICON_GROUPS)}
                  <span>${store.t("sys_overview.cap_device_groups")}</span>
                </span>
                <span class="overview-box-end">
                  <span class="chip">
                    ${groups.length === 1
                      ? store.t("sys_overview.groups_one")
                      : store.t("sys_overview.groups_many", {
                          count: fmtNumber(groups.length, store.hass, 0),
                        })}
                  </span>
                  <span class="overview-box-chevron" aria-hidden="true">›</span>
                </span>
              </div>
              ${populatedGroupChips.length > 0
                ? html`<div class="overview-chips">
                    ${populatedGroupChips.map(
                      (gc) =>
                        html`<span class="chip ${gc.active ? "chip-primary" : ""}">
                          ${gc.label}
                        </span>`,
                    )}
                  </div>`
                : html`<span class="overview-box-meta">
                    ${configuredGroupNames.length > 0
                      ? store.t("sys_overview.groups_meta_dynamic", {
                          names: configuredGroupNames.join(", "),
                        })
                      : store.t("sys_overview.groups_meta_empty")}
                  </span>`}
            </button>

            <button
              type="button"
              id="cap-colors-wallpapers"
              @click=${() =>
                store.openSystemSection(
                  "shared_entities",
                  colorsCount > 0 ? "card-custom-colors" : "card-system-wallpapers",
                  ["card-custom-colors", "card-system-wallpapers"],
                )}
              class="overview-box"
            >
              <div class="overview-box-head">
                <span class="overview-box-title">
                  ${renderSvgIcon(SYS_ICON_PALETTE)}
                  <span>${store.t("sys_overview.cap_colors_wallpapers")}</span>
                </span>
                <span class="overview-box-end">
                  <span class="chip">
                    ${wallpapersCount === 1
                      ? store.t("sys_overview.wallpapers_one")
                      : store.t("sys_overview.wallpapers_many", {
                          count: fmtNumber(wallpapersCount, store.hass, 0),
                        })}
                  </span>
                  <span class="overview-box-chevron" aria-hidden="true">›</span>
                </span>
              </div>
              ${colorsCount > 0
                ? html`<div class="swatch-strip" aria-hidden="true">
                    ${validPalettes.slice(0, 8).map((p) => {
                      const swStyle = `--swatch-color:${p.hex.toUpperCase()}`;
                      return html`<span class="swatch swatch-sm" style=${swStyle}></span>`;
                    })}
                    ${colorsCount > 8
                      ? html`<span class="chip">
                          +${fmtNumber(colorsCount - 8, store.hass, 0)}
                        </span>`
                      : nothing}
                  </div>`
                : nothing}
              <span class="overview-box-meta">
                ${store.t("sys_overview.colors_wallpapers_meta", {
                  colors:
                    colorsCount === 1
                      ? store.t("sys_overview.custom_colors_one")
                      : store.t("sys_overview.custom_colors_many", {
                          count: fmtNumber(colorsCount, store.hass, 0),
                        }),
                  presets:
                    presetWallpapersCount === 1
                      ? store.t("sys_overview.presets_one")
                      : store.t("sys_overview.presets_many", {
                          count: fmtNumber(presetWallpapersCount, store.hass, 0),
                        }),
                  uploaded:
                    uploadedWallpapersCount > 0
                      ? store.t("sys_overview.uploaded_suffix", {
                          count: fmtNumber(uploadedWallpapersCount, store.hass, 0),
                        })
                      : "",
                })}
              </span>
            </button>

            <button
              type="button"
              id="cap-perimeter-security"
              @click=${() => store.openSystemSection("system_tools", "card-perimeter-security")}
              class="overview-box"
            >
              <div class="overview-box-head">
                <span class="overview-box-title">
                  ${renderSvgIcon(SYS_ICON_SHIELD)}
                  <span>${store.t("card.perimeter_security")}</span>
                </span>
                <span class="overview-box-end">
                  <span class="chip ${hasSystemPin ? "chip-success" : ""}">
                    ${hasSystemPin
                      ? store.t("sys_overview.system_pin_set")
                      : store.t("sys_overview.no_system_pin")}
                  </span>
                  <span class="overview-box-chevron" aria-hidden="true">›</span>
                </span>
              </div>
              <span class="overview-box-meta">
                ${hasSystemPin
                  ? store.t("sys_overview.pin_active_meta")
                  : store.t("sys_overview.pin_unset_meta")}
              </span>
            </button>`,
        })}
      </div>
    </div>
  </section>`;
}
__latterExp(__exports, { renderSystemOverviewView: () => renderSystemOverviewView });
//# sourceURL=latter-studio/src/views/system-overview-view.ts
});
__latterDef("src/views/system-presence-view.ts", (__exports, __req) => {
const { renderCard, renderRangeRow, renderSettingsRow } = __req("src/components/controls.ts");
const { focusSafe, html, nothing, repeat } = __req("src/lib/lit.ts");
const { fmtAgo, fmtDateTime, fmtDistance, fmtNumber, fmtPercent, rssiToPercent } = __req("src/utils/format.ts");
/**
 * System BLE & Area presence view (`area_tracking`, `D-044` / `D-045` / `D-046` / `D-058` / `D-064`):
 * Area presence & sensors, walk-around BLE calibration, and advanced BLE settings.
 */
function renderSystemPresenceView(store) {
  const data = store.state;
  const sysCfg = data?.system_config;
  const presenceRows = data?.live?.area_presence_grid || [];
  const signatures = data?.ble_area_signatures || [];
  const allDevs = data?.system_devices || [];
  const bleDevs = allDevs.filter((d) => d.ble_tracked || d.kind === "ble_tag");
  const activeSurveyDev = store.groups.getActiveSurveyDevice() || bleDevs[0];
  const surveyRows = activeSurveyDev?.ble_survey_rows || [];
  const packetsSeen = activeSurveyDev?.ble_packets_seen ?? 0;
  const fusionModeOptions = [
    { val: "weighted", label: store.t("presence_sys.mode_weighted") },
    { val: "any_or", label: store.t("presence_sys.mode_any_or") },
    { val: "ble_only", label: store.t("presence_sys.mode_ble_only") },
    { val: "ble_and_sensor", label: store.t("presence_sys.mode_both") },
  ];
  const sigByArea = new Map();
  for (const sig of signatures) {
    if (sig.area_id) sigByArea.set(sig.area_id, sig);
  }
  const rowByArea = new Map();
  for (const row of presenceRows) {
    if (row.area_id) rowByArea.set(row.area_id, row);
  }
  const unifiedAreas
     = [];
  for (const row of presenceRows) {
    unifiedAreas.push({
      areaId: row.area_id,
      areaName: row.area_name,
      row,
      sig: sigByArea.get(row.area_id),
    });
  }
  for (const sig of signatures) {
    if (!rowByArea.has(sig.area_id)) {
      unifiedAreas.push({
        areaId: sig.area_id,
        areaName: sig.area_name,
        row: undefined,
        sig,
      });
    }
  }
  unifiedAreas.sort((a, b) =>
    a.areaName.localeCompare(b.areaName, undefined, { sensitivity: "base" }),
  );
  const areaChoices = signatures.length
    ? signatures.map((s) => ({ area_id: s.area_id, area_name: s.area_name }))
    : (data?.catalog?.areas || []).map((a) => ({ area_id: a.id, area_name: a.name }));
  const targetAreaId =
    store.bleCalibrateAreaId && areaChoices.some((a) => a.area_id === store.bleCalibrateAreaId)
      ? store.bleCalibrateAreaId
      : areaChoices[0]?.area_id || "";
  const selectedSig = sigByArea.get(targetAreaId);
  const selectedAreaName =
    selectedSig?.area_name ||
    areaChoices.find((a) => a.area_id === targetAreaId)?.area_name ||
    store.t("presence_sys.this_area");
  const calibrateDescription = !areaChoices.length
    ? store.t("presence_sys.cal_desc_no_areas")
    : selectedSig?.has_signature
      ? store.t("presence_sys.cal_desc_replace", {
          count: fmtNumber(selectedSig.scanner_count, store.hass, 0),
          area: selectedAreaName,
        })
      : selectedSig && !selectedSig.has_ble_proxy
        ? store.t("presence_sys.cal_desc_proxyless", { area: selectedAreaName })
        : store.t("presence_sys.cal_desc_new", { area: selectedAreaName });
  const hasFreshSignal = surveyRows.some(
    (r) => Boolean(r.is_fresh) && r.effective_rssi !== null && r.effective_rssi !== undefined,
  );
  return html`<section id="view-area_tracking">
    <div class="columns">
      <div class="column">
        ${renderCard({
          id: "card-area-presence",
          title: store.t("card.area_presence_sensors"),
          subtitle: store.t("presence_sys.area_card_subtitle"),
          body: html`<div id="area-presence-grid-box" class="stack">
            ${unifiedAreas.length
              ? repeat(
                  unifiedAreas,
                  (item) => item.areaId,
                  ({ areaId, areaName, row, sig }) => {
                    const isOcc = Boolean(row?.is_occupied);
                    const hasConf =
                      row?.confidence_pct !== null &&
                      row?.confidence_pct !== undefined &&
                      Number.isFinite(Number(row.confidence_pct));
                    const confStr = hasConf
                      ? fmtPercent(Number(row?.confidence_pct), store.hass)
                      : store.t("common.unknown");
                    const floorLabel = String(
                      row?.floor_name || row?.floor_id || sig?.floor_id || "",
                    ).trim();
                    const hasBleProxy = sig
                      ? Boolean(sig.has_ble_proxy)
                      : Boolean(
                          (row?.winning_rssi !== null && row?.winning_rssi !== undefined) ||
                            surveyRows.some((sr) => sr.area_id === areaId),
                        );
                    const occList = row?.occupant_names || [];
                    const occNames = occList.length
                      ? occList.join(", ")
                      : isOcc
                        ? store.t("presence_sys.occupied_sensor")
                        : store.t("presence_sys.empty");
                    const parts = [occNames];
                    if (row?.winning_rssi !== null && row?.winning_rssi !== undefined) {
                      const distPart =
                        row.closest_distance_m !== null && row.closest_distance_m !== undefined
                          ? ` (~${fmtDistance(row.closest_distance_m, store.hass, row.closest_distance_ft)})`
                          : "";
                      parts.push(
                        store.t("presence_sys.ble_dbm", {
                          rssi: fmtNumber(row.winning_rssi, store.hass, 0),
                          distance: distPart,
                        }),
                      );
                    }
                    if (row?.match_method === "signature") {
                      parts.push(store.t("presence_sys.signature_match"));
                    }
                    if (row?.active_sensors && row.active_sensors.length) {
                      parts.push(
                        row.active_sensors.length === 1
                          ? store.t("presence_sys.active_sensors_one")
                          : store.t("presence_sys.active_sensors_many", {
                              count: row.active_sensors.length,
                            }),
                      );
                    } else if (row?.available_sensors && row.available_sensors.length) {
                      parts.push(
                        row.available_sensors.length === 1
                          ? store.t("presence_sys.clear_sensors_one")
                          : store.t("presence_sys.clear_sensors_many", {
                              count: row.available_sensors.length,
                            }),
                      );
                    }
                    if (sig?.has_signature && sig.captured_at) {
                      parts.push(
                        store.t("presence_sys.calibrated_meta", {
                          when: fmtDateTime(sig.captured_at, store.hass),
                          samples: fmtNumber(sig.sample_count, store.hass, 0),
                        }),
                      );
                    } else if (!hasBleProxy && !sig?.has_signature) {
                      parts.push(store.t("presence_sys.calibrate_hint"));
                    }
                    const curMode = row?.fusion_mode || "weighted";
                    const threshold = Number(row?.fusion_threshold_pct ?? 50);
                    const chosen = row?.fusion_sensors || [];
                    const choices = row?.fusion_sensor_choices || [];
                    const thresholdId = `fusion-threshold-${areaId}`;
                    const areaBoxId = `area-box-${areaId}`;
                    const isAreaHandoff = store.isHandoffTarget(areaBoxId);
                    return html`<div id=${areaBoxId} class="area-presence-box${isAreaHandoff ? " handoff-active" : ""}">
                      <div class="area-box-head">
                        <h4 class="area-box-title">${areaName}</h4>
                        <div class="area-box-actions">
                          ${sig?.has_signature
                            ? html`<button
                                type="button"
                                @click=${() =>
                                  store.groups.requestClearBleAreaSignature(areaId, areaName)}
                                class="btn btn-text btn-compact"
                              >
                                ${store.t("presence_sys.clear_signature")}
                              </button>`
                            : nothing}
                          ${bleDevs.length > 0
                            ? html`<button
                                type="button"
                                @click=${() => store.groups.selectBleCalibrateArea(areaId, true)}
                                class="btn btn-secondary btn-compact"
                              >
                                ${store.t("presence_sys.calibrate")}
                              </button>`
                            : nothing}
                        </div>
                      </div>

                      <div class="area-box-badges">
                        ${isOcc
                          ? html`<span class="chip chip-success">${store.t("presence_sys.occupied_chip", { confidence: confStr })}</span>`
                          : html`<span class="chip">${store.t("presence_sys.clear_chip")}</span>`}
                        ${floorLabel ? html`<span class="chip">${floorLabel}</span>` : nothing}
                        ${sig?.has_signature
                          ? html`<span class="chip chip-primary">${sig.scanner_count === 1
                              ? store.t("presence_sys.signature_proxies_one")
                              : store.t("presence_sys.signature_proxies_many", {
                                  count: fmtNumber(sig.scanner_count, store.hass, 0),
                                })}</span>`
                          : hasBleProxy
                            ? html`<span class="chip">${store.t("sys_overview.ble_proxy")}</span>`
                            : html`<span class="chip chip-warning">${store.t("sys_overview.no_ble_proxy")}</span>`}
                      </div>

                      <div class="area-box-meta">${parts.join(" • ")}</div>

                      ${renderSettingsRow({
                        label: store.t("presence_sys.presence_mode"),
                        control: html`<select
                          aria-label=${store.t("presence_sys.presence_mode_aria", { area: areaName })}
                          .value=${curMode}
                          @change=${(ev) =>
                            void store.groups.setAreaFusion(areaId, {
                              mode: (ev.currentTarget).value,
                            })}
                        >
                          ${fusionModeOptions.map(
                            (m) =>
                              html`<option value=${m.val} ?selected=${m.val === curMode}>
                                ${m.label}
                              </option>`,
                          )}
                        </select>`,
                      })}

                      <details
                        ?open=${store.openFusionAreas.has(areaId)}
                        @toggle=${(ev) => {
                          const isOpen = (ev.currentTarget).open;
                          if (isOpen) store.openFusionAreas.add(areaId);
                          else store.openFusionAreas.delete(areaId);
                        }}
                        class="sub-collapsible"
                      >
                        <summary>${store.t("presence_sys.sensor_threshold_drawer")}</summary>
                        <div class="card-content settings-list">
                          ${renderRangeRow({
                            id: thresholdId,
                            label: store.t("presence_sys.occupied_at"),
                            ariaLabel: store.t("presence_sys.occupied_at"),
                            description:
                              curMode === "weighted"
                                ? store.t("presence_sys.occupied_at_weighted_desc")
                                : store.t("presence_sys.occupied_at_other_desc"),
                            value: threshold,
                            min: 20,
                            max: 95,
                            step: 5,
                            unit: "%",
                            disabled: curMode !== "weighted",
                            hass: store.hass,
                            onCommit: (nextVal) =>
                              void store.groups.setAreaFusion(areaId, {
                                threshold_pct: nextVal,
                              }),
                          })}
                          ${renderSettingsRow({
                            label: store.t("presence_sys.sensors_that_count"),
                            description: chosen.length
                              ? store.t("presence_sys.sensors_selected_desc", {
                                  selected: chosen.length,
                                  total: choices.length,
                                })
                              : store.t("presence_sys.sensors_all_desc"),
                            stacked: true,
                            control: choices.length
                              ? html`<div
                                  role="group"
                                  aria-label=${store.t("presence_sys.sensors_group_aria", {
                                    area: areaName,
                                  })}
                                  class="pill-list"
                                >
                                  ${choices.map((s) => {
                                    const on = chosen.includes(s.entity_id);
                                    const nextSensors = on
                                      ? chosen.filter((x) => x !== s.entity_id)
                                      : chosen.concat([s.entity_id]);
                                    return html`<span class="pill ${on ? "enabled" : ""}">
                                      <button
                                        type="button"
                                        aria-pressed=${String(on)}
                                        title=${s.entity_id}
                                        @click=${() =>
                                          void store.groups.setAreaFusion(areaId, {
                                            sensors: nextSensors,
                                          })}
                                        class="pill-toggle"
                                      >
                                        ${on ? "✓ " : ""}${s.name}
                                      </button>
                                    </span>`;
                                  })}
                                </div>`
                              : html`<p class="empty-state">
                                  ${store.t("presence_sys.no_area_sensors")}
                                </p>`,
                          })}
                        </div>
                      </details>
                    </div>`;
                  },
                )
              : html`<p class="empty-state">
                  ${store.t("presence_sys.empty_areas")}
                </p>`}
          </div>`,
        })}
      </div>

      <div class="column">
        ${renderCard({
          id: "card-ble-calibration",
          title: store.t("card.ble_calibration"),
          subtitle: store.t("presence_sys.calibration_subtitle"),
          headerActions:
            bleDevs.length > 0
              ? html`<button
                  type="button"
                  id="btn-toggle-ble-stream"
                  @click=${() => store.groups.toggleBleLiveStream(!store.bleLiveStreamActive)}
                  class="btn btn-secondary btn-compact"
                >
                  ${store.bleLiveStreamActive
                    ? store.t("presence_sys.pause_stream")
                    : store.t("presence_sys.resume_stream")}
                </button>`
              : nothing,
          footerActions:
            bleDevs.length === 0
              ? html`<button
                  type="button"
                  @click=${() => store.openDiscoveredDevices("card-discovered-ble")}
                  class="btn btn-secondary"
                >
                  ${store.t("presence_sys.open_discovered")}
                </button>`
              : nothing,
          contentClass: "stack",
          body:
            bleDevs.length === 0
              ? html`<p class="empty-state">
                  ${store.t("presence_sys.empty_ble_devices")}
                </p>`
              : html`<div
                    id="ble-calibrate-target-box"
                    class="calibrate-target-box${store.bleCalibrateHandoffActive ? " handoff-active" : ""}"
                  >
                    ${store.bleCalibrateHandoffActive
                      ? html`<div id="ble-calibrate-handoff-banner" class="calibrate-handoff-banner">
                          <span>${store.t("presence_sys.handoff_ready", {
                            area: selectedAreaName,
                            device:
                              activeSurveyDev?.title || store.t("presence_sys.your_device"),
                          })}</span>
                          <button
                            type="button"
                            @click=${() => {
                              store.bleCalibrateHandoffActive = false;
                              store.host.requestUpdate();
                            }}
                            class="btn btn-text btn-compact"
                          >
                            ${store.t("action.dismiss")}
                          </button>
                        </div>`
                      : nothing}

                    ${renderSettingsRow({
                      forId: "ble-survey-device-picker",
                      label: store.t("presence_sys.carried_device"),
                      description: store.t("presence_sys.carried_device_desc"),
                      control: html`<select
                        id="ble-survey-device-picker"
                        .value=${activeSurveyDev?.subentry_id || ""}
                        @change=${(ev) =>
                          store.groups.selectBleSurveyDevice(
                            (ev.currentTarget).value,
                          )}
                      >
                        ${bleDevs.map(
                          (d) =>
                            html`<option
                              value=${d.subentry_id}
                              ?selected=${d.subentry_id === activeSurveyDev?.subentry_id}
                            >
                              ${d.title} (${d.active_area_name || store.t("common.unassigned")})
                            </option>`,
                        )}
                      </select>`,
                    })}

                    ${hasFreshSignal
                      ? html`<div class="alert">
                          <div class="alert-body">
                            <span>${store.t("presence_sys.live_signal_active")}<strong>${activeSurveyDev?.active_area_name || store.t("common.unassigned")}</strong>${store.t("presence_sys.packets_observed", {
                              count: fmtNumber(packetsSeen, store.hass, 0),
                            })}</span>
                          </div>
                        </div>`
                      : html`<div class="alert alert-warning">
                          <div class="alert-body">
                            <span>${store.t("presence_sys.no_recent_packets_prefix")}<strong>${activeSurveyDev?.title || store.t("presence_sys.this_device")}</strong>${store.t("presence_sys.no_recent_packets_suffix")}</span>
                          </div>
                        </div>`}

                    ${renderSettingsRow({
                      forId: "ble-calibrate-area-select",
                      label: store.t("presence_sys.standing_in_area"),
                      description: calibrateDescription,
                      stacked: true,
                      control: html`<div class="input-action-row">
                        <select
                          id="ble-calibrate-area-select"
                          .value=${targetAreaId}
                          @change=${(ev) =>
                            store.groups.selectBleCalibrateArea(
                              (ev.currentTarget).value,
                            )}
                        >
                          ${areaChoices.length
                            ? areaChoices.map((a) => {
                                const aSig = sigByArea.get(a.area_id);
                                const suffix = aSig?.has_signature
                                  ? store.t("presence_sys.suffix_saved")
                                  : aSig && !aSig.has_ble_proxy
                                    ? store.t("presence_sys.suffix_no_proxy")
                                    : "";
                                return html`<option
                                  value=${a.area_id}
                                  ?selected=${a.area_id === targetAreaId}
                                >
                                  ${a.area_name}${suffix}
                                </option>`;
                              })
                            : html`<option value="">${store.t("presence_sys.no_ha_areas_option")}</option>`}
                        </select>
                        <button
                          id="btn-capture-area-signature"
                          type="button"
                          ?disabled=${!activeSurveyDev || !targetAreaId}
                          @click=${() =>
                            void store.groups.captureBleAreaSignature(targetAreaId)}
                          class="btn btn-primary"
                        >
                          ${store.t("presence_sys.calibrate_area_btn")}
                        </button>
                      </div>`,
                    })}
                  </div>

                  <div class="subsection-title">${store.t("presence_sys.nearby_proxies")}</div>
                  ${surveyRows.length
                    ? repeat(
                        surveyRows,
                        (row, idx) => `${row.area_id}::${row.scanner_source || idx}`,
                        (row) => {
                          const scannerSrc = row.scanner_source || "";
                          const areaTitle =
                            row.area_name || store.t("presence_sys.unassigned_proxy");
                          const scannerBadge =
                            row.scanner_name || scannerSrc || store.t("sys_overview.ble_proxy");
                          const pct = rssiToPercent(row.effective_rssi);
                          const sigStyle = `--signal-pct:${pct}%`;
                          const offVal = Number(row.offset_db || 0);
                          const offTxt = `${offVal >= 0 ? "+" : ""}${fmtNumber(offVal, store.hass, 1)} dB`;
                          const rawTxt =
                            row.raw_rssi !== null && row.raw_rssi !== undefined
                              ? `${fmtNumber(row.raw_rssi, store.hass, 0)} dBm`
                              : store.t("common.unknown");
                          const effTxt =
                            row.effective_rssi !== null && row.effective_rssi !== undefined
                              ? `${fmtNumber(row.effective_rssi, store.hass, 0)} dBm`
                              : store.t("signal.no_reading");
                          const distPart =
                            row.distance_m !== null && row.distance_m !== undefined
                              ? ` • ~${fmtDistance(row.distance_m, store.hass, row.distance_ft)}`
                              : "";
                          const agePart =
                            row.age_seconds !== null && row.age_seconds !== undefined
                              ? ` • ${fmtAgo(row.age_seconds, store.hass)}${row.is_fresh === false ? store.t("presence_sys.stale_suffix") : ""}`
                              : "";
                          const trimPart =
                            Math.abs(offVal) >= 0.1
                              ? store.t("presence_sys.trim_suffix", { offset: offTxt })
                              : "";
                          const metaText = `${effTxt}${distPart}${agePart}${trimPart}`;
                          return html`<div class="signal-row ${row.is_winner ? "winner" : ""}">
                            <div class="signal-row-head">
                              <span class="signal-row-title">
                                <span class="row-label">${areaTitle}</span>
                                <span class="chip">${scannerBadge}</span>
                                ${!row.area_name
                                  ? html`<span class="chip chip-warning">${store.t("presence_sys.assign_area_in_ha")}</span>`
                                  : nothing}
                                ${row.is_winner
                                  ? html`<span class="chip chip-primary">${store.t("presence_sys.active_winner")}</span>`
                                  : nothing}
                              </span>
                              <span class="signal-meta">${metaText}</span>
                            </div>
                            <div class="signal-track">
                              <div class="signal-fill" style=${sigStyle}></div>
                            </div>
                            ${scannerSrc
                              ? html`<details
                                  ?open=${store.openProxyTrims.has(scannerSrc)}
                                  @toggle=${(ev) => {
                                    if ((ev.currentTarget).open) {
                                      store.openProxyTrims.add(scannerSrc);
                                    } else {
                                      store.openProxyTrims.delete(scannerSrc);
                                    }
                                  }}
                                  class="sub-collapsible proxy-trim-details"
                                >
                                  <summary>${store.t("presence_sys.antenna_trim")}</summary>
                                  <div class="proxy-trim-body">
                                    <span class="help-text">${store.t("presence_sys.antenna_trim_help", {
                                      raw: rawTxt,
                                      offset: offTxt,
                                    })}</span>
                                    <div class="input-action-row">
                                      <button
                                        type="button"
                                        @click=${() =>
                                          void store.groups.setBleScannerOffset(
                                            scannerSrc,
                                            offVal - 1,
                                          )}
                                        class="btn btn-secondary btn-compact"
                                      >
                                        ${store.t("presence_sys.minus_one_db")}
                                      </button>
                                      <button
                                        type="button"
                                        @click=${() =>
                                          void store.groups.setBleScannerOffset(
                                            scannerSrc,
                                            offVal + 1,
                                          )}
                                        class="btn btn-secondary btn-compact"
                                      >
                                        ${store.t("presence_sys.plus_one_db")}
                                      </button>
                                      <button
                                        type="button"
                                        @click=${() =>
                                          void store.groups.setBleScannerOffset(scannerSrc, 0)}
                                        class="btn btn-text btn-compact"
                                      >
                                        ${store.t("action.reset")}
                                      </button>
                                    </div>
                                  </div>
                                </details>`
                              : nothing}
                          </div>`;
                        },
                      )
                    : html`<p class="empty-state">
                        ${store.t("presence_sys.empty_survey")}
                      </p>`}`,
        })}

        <details
          id="card-advanced-ble-settings"
          ?open=${store.advancedBleOpen}
          @toggle=${(ev) => {
            store.advancedBleOpen = (ev.currentTarget).open;
          }}
          class="card"
        >
          <summary class="card-header">
            <div class="card-heading">
              <h3 class="card-title">${store.t("card.advanced_ble")}</h3>
              <p class="card-subtitle">
                ${store.t("presence_sys.advanced_subtitle")}
              </p>
            </div>
          </summary>
          <div class="card-content settings-list">
            ${renderSettingsRow({
              forId: "sys-ble_away_timeout_s",
              label: store.t("presence_sys.away_timeout"),
              description: store.t("presence_sys.away_timeout_desc"),
              control: html`<input
                type="number"
                id="sys-ble_away_timeout_s"
                min="30"
                max="900"
                step="15"
                .value=${focusSafe(String(sysCfg?.ble_away_timeout_s ?? 180))}
                @change=${(ev) => {
                  const val = Number((ev.currentTarget).value);
                  if (Number.isFinite(val)) {
                    store.entity.stageSystemSetting(
                      "ble_away_timeout_s",
                      Math.round(val),
                      "sys-ble_away_timeout_s",
                    );
                  }
                }}
              />`,
            })}
            ${renderSettingsRow({
              forId: "sys-ble_max_radius_m",
              label: store.t("presence_sys.max_radius"),
              description: store.t("presence_sys.max_radius_desc"),
              control: html`<input
                type="number"
                id="sys-ble_max_radius_m"
                min="2"
                max="50"
                step="0.5"
                .value=${focusSafe(String(sysCfg?.ble_max_radius_m ?? 12))}
                @change=${(ev) => {
                  const val = Number((ev.currentTarget).value);
                  if (Number.isFinite(val)) {
                    store.entity.stageSystemSetting(
                      "ble_max_radius_m",
                      val,
                      "sys-ble_max_radius_m",
                    );
                  }
                }}
              />`,
            })}
            ${renderSettingsRow({
              forId: "sys-ble_max_velocity_mps",
              label: store.t("presence_sys.max_speed"),
              description: store.t("presence_sys.max_speed_desc"),
              control: html`<input
                type="number"
                id="sys-ble_max_velocity_mps"
                min="0.5"
                max="15"
                step="0.5"
                .value=${focusSafe(String(sysCfg?.ble_max_velocity_mps ?? 3.5))}
                @change=${(ev) => {
                  const val = Number((ev.currentTarget).value);
                  if (Number.isFinite(val)) {
                    store.entity.stageSystemSetting(
                      "ble_max_velocity_mps",
                      val,
                      "sys-ble_max_velocity_mps",
                    );
                  }
                }}
              />`,
            })}
            ${renderSettingsRow({
              forId: "sys-ble_attenuation",
              label: store.t("presence_sys.attenuation"),
              description: store.t("presence_sys.attenuation_desc"),
              control: html`<input
                type="number"
                id="sys-ble_attenuation"
                min="1.5"
                max="4.5"
                step="0.1"
                .value=${focusSafe(String(sysCfg?.ble_attenuation ?? 2.2))}
                @change=${(ev) => {
                  const val = Number((ev.currentTarget).value);
                  if (Number.isFinite(val)) {
                    store.entity.stageSystemSetting(
                      "ble_attenuation",
                      val,
                      "sys-ble_attenuation",
                    );
                  }
                }}
              />`,
            })}
          </div>
        </details>
      </div>
    </div>
  </section>`;
}
__latterExp(__exports, { renderSystemPresenceView: () => renderSystemPresenceView });
//# sourceURL=latter-studio/src/views/system-presence-view.ts
});
__latterDef("src/views/system-remotes-view.ts", (__exports, __req) => {
const { renderCard, renderEntitySlotList, renderSelectOptions, renderTrashIconButton } = __req("src/components/controls.ts");
const { focusSafe, html } = __req("src/lib/lit.ts");
/**
 * System Media & Remotes View (`remotes`, `D-026`, `D-042`, `D-064`):
 * - Remote controls with pointer/keyboard reordering (`reorderStringListRows("remotes_list", ...)`)
 * - Speaker volume overrides & Area-bound Remote control groups (`focusSafe` group names)
 */
function renderSystemRemotesView(store) {
  const data = store.state;
  const sc = data?.system_config;
  const cat = data?.catalog || {};
  const remotes = sc?.remotes_list || [];
  const volOverrides = sc?.volume_overrides || [];
  const remoteGroups = sc?.remote_groups || [];
  const areas = cat.areas || [];
  const speakerChoices = cat.ma_speakers || [];
  const targetChoices = cat.volume_targets || cat.remotes || [];
  const inventoryIds = remotes.filter(Boolean);
  const friendlyRemoteLabel = (entId) => {
    const found = (cat.remotes || []).find((r) => r.id === entId);
    return found ? found.name.split(" (")[0] : entId;
  };
  return html`<section id="view-remotes">
    <div class="columns">
      <div class="column">
        ${renderCard({
          title: store.t("card.remote_controls"),
          subtitle: store.t("remotes.controls_subtitle"),
          headerActions: html`<button
            type="button"
            @click=${() => store.entity.addStringListRow("remotes_list", "", 10)}
            class="btn btn-secondary btn-compact"
          >
            ${store.t("remotes.add_remote")}
          </button>`,
          body: renderEntitySlotList({
            id: "remotes-list",
            items: remotes,
            choices: cat.remotes,
            emptyOptionLabel: store.t("remotes.choose_remote"),
            emptyStateText: store.t("remotes.empty_remotes"),
            selectAriaLabel: store.t("remotes.remote_aria"),
            removeAriaLabel: store.t("remotes.remove_remote"),
            useCombobox: (cat.remotes?.length ?? 0) > 8,
            host: store.host,
            slotLabel: (idx) =>
              idx === 0
                ? store.t("remotes.slot_primary")
                : store.t("remotes.slot_n", { index: idx + 1 }),
            onReorder: (fromIdx, toIdx) =>
              store.entity.reorderStringListRows("remotes_list", fromIdx, toIdx),
            onChange: (idx, val) => store.entity.updateStringListRow("remotes_list", idx, val),
            onRemove: (idx) => store.entity.removeStringListRow("remotes_list", idx),
          }),
        })}

        ${renderCard({
          id: "card-volume-overrides",
          title: store.t("card.volume_overrides"),
          subtitle: store.t("remotes.overrides_subtitle"),
          headerActions: html`<button
            type="button"
            @click=${() => store.entity.addVolumeOverrideRow()}
            class="btn btn-secondary btn-compact"
          >
            ${store.t("remotes.add_override")}
          </button>`,
          body: html`<div id="volume-overrides-list" class="stack">
            ${volOverrides.length
              ? volOverrides.map(
                  (vo, idx) => html`<div class="list-row">
                    <div class="list-row-main">
                      <div class="stacked-field">
                        <span class="field-label">${store.t("remotes.when_playing_on")}</span>
                        <select
                          aria-label=${store.t("remotes.speaker_aria")}
                          .value=${vo.speaker}
                          @change=${(ev) =>
                            store.entity.updateVolumeOverrideRow(
                              idx,
                              "speaker",
                              (ev.currentTarget).value,
                            )}
                        >
                          ${renderSelectOptions(
                            speakerChoices,
                            vo.speaker,
                            store.t("remotes.choose_speaker"),
                          )}
                        </select>
                      </div>
                      <div class="stacked-field">
                        <span class="field-label">${store.t("remotes.change_volume_on")}</span>
                        <select
                          aria-label=${store.t("remotes.volume_target_aria")}
                          .value=${vo.target}
                          @change=${(ev) =>
                            store.entity.updateVolumeOverrideRow(
                              idx,
                              "target",
                              (ev.currentTarget).value,
                            )}
                        >
                          ${renderSelectOptions(
                            targetChoices,
                            vo.target,
                            store.t("remotes.choose_volume_target"),
                          )}
                        </select>
                      </div>
                    </div>
                    ${renderTrashIconButton(store.t("remotes.remove_override_aria"), () =>
                      store.entity.removeVolumeOverrideRow(idx),
                    )}
                  </div>`,
                )
              : html`<p class="empty-state">${store.t("remotes.empty_overrides")}</p>`}
          </div>`,
        })}
      </div>

      <div class="column">
        ${renderCard({
          id: "card-remote-groups",
          handoffActive: store.isHandoffTarget("card-remote-groups"),
          title: store.t("card.remote_groups"),
          subtitle: store.t("remotes.groups_subtitle"),
          headerActions: html`<button
            type="button"
            @click=${() => store.entity.addRemoteGroupRow()}
            class="btn btn-secondary btn-compact"
          >
            ${store.t("remotes.add_group")}
          </button>`,
          body: html`<div id="remote-groups-list" class="stack">
            ${remoteGroups.length
              ? remoteGroups.map((grp, gIdx) => {
                  const selectedRems = Array.isArray(grp.remotes) ? grp.remotes : [];
                  const pool = selectedRems
                    .filter((id) => inventoryIds.includes(id))
                    .concat(inventoryIds.filter((id) => !selectedRems.includes(id)));
                  const nameId = `rg-name-${grp.id}`;
                  const areaId = `rg-area-${grp.id}`;
                  return html`<div class="list-block">
                    <div class="list-row-head">
                      <div class="list-row-main">
                        <div class="stacked-field">
                          <label for=${nameId}>${store.t("remotes.group_name")}</label>
                          <input
                            type="text"
                            id=${nameId}
                            placeholder=${store.t("remotes.group_name_placeholder")}
                            .value=${focusSafe(grp.name || "")}
                            @change=${(ev) =>
                              store.entity.updateRemoteGroupField(
                                grp.id,
                                "name",
                                (ev.currentTarget).value,
                              )}
                          />
                        </div>
                        <div class="stacked-field">
                          <label for=${areaId}>${store.t("remotes.loads_in_area")}</label>
                          <select
                            id=${areaId}
                            aria-label=${store.t("remotes.area_aria")}
                            .value=${grp.area_id || ""}
                            @change=${(ev) =>
                              store.entity.updateRemoteGroupField(
                                grp.id,
                                "area_id",
                                (ev.currentTarget).value,
                              )}
                          >
                            <option value="">${store.t("remotes.no_area_option")}</option>
                            ${areas.map(
                              (a) =>
                                html`<option value=${a.id} ?selected=${a.id === grp.area_id}>
                                  ${a.name}
                                </option>`,
                            )}
                          </select>
                        </div>
                      </div>
                      ${renderTrashIconButton(
                        store.t("remotes.delete_group_aria", { name: grp.name || grp.id }),
                        () => store.entity.removeRemoteGroupRow(grp.id),
                      )}
                    </div>
                    <div class="stacked-field">
                      <span id=${`rg-remotes-${gIdx}`} class="field-label">
                        ${store.t("remotes.group_remotes_label")}
                      </span>
                      <div role="group" aria-labelledby=${`rg-remotes-${gIdx}`} class="pill-list">
                        ${pool.length
                          ? pool.map((entId) => {
                              const pos = selectedRems.indexOf(entId);
                              const isEn = pos >= 0;
                              const lbl = friendlyRemoteLabel(entId);
                              const text = isEn
                                ? pos === 0
                                  ? store.t("remotes.primary_badge", { name: lbl })
                                  : store.t("remotes.numbered_badge", {
                                      index: pos + 1,
                                      name: lbl,
                                    })
                                : store.t("remotes.add_badge", { name: lbl });
                              return html`<span class="pill ${isEn ? "enabled" : ""}">
                                <button
                                  type="button"
                                  aria-pressed=${isEn ? "true" : "false"}
                                  @click=${() => store.entity.toggleRemoteInGroup(grp.id, entId)}
                                  class="pill-toggle"
                                >
                                  ${text}
                                </button>
                              </span>`;
                            })
                          : html`<span class="help-text">
                              ${store.t("remotes.add_remotes_first")}
                            </span>`}
                      </div>
                    </div>
                  </div>`;
                })
              : html`<p class="empty-state">${store.t("remotes.empty_groups")}</p>`}
          </div>`,
        })}
      </div>
    </div>
  </section>`;
}
__latterExp(__exports, { renderSystemRemotesView: () => renderSystemRemotesView });
//# sourceURL=latter-studio/src/views/system-remotes-view.ts
});
__latterDef("src/views/system-shared-view.ts", (__exports, __req) => {
const { renderCard, renderEntityCombobox, renderEntitySlotList, renderSelectOptions, renderSelectRow, renderSettingsRow, renderSortableList, renderSvgIcon, renderTrashIconButton } = __req("src/components/controls.ts");
const { renderWallpaperGalleryItems, renderWallpaperUploadProgress, renderWallpaperUploadTrigger } = __req("src/components/wallpaper-gallery.ts");
const { html, nothing } = __req("src/lib/lit.ts");
const { entityLabel, fmtAgo, fmtNumber, isValidHexColor } = __req("src/utils/format.ts");
/**
 * System Shared Entities View (`shared_entities`, `D-022`, `D-059`, `D-064`, `D-065`):
 * - Home hub & weather (singleton Weather/Alarm + multi-entity sortable domain boxes)
 * - Calendars & Cameras with pointer/keyboard reordering (`reorderStringListRows`) & combobox
 * - On-demand 600 s camera preview signing (`store.entity.previewCamera`, `Q4`)
 * - Custom colors (`isValidHexColor` swatch guard `A-07`) & shared System wallpapers
 */
const ICON_THERMOSTAT =
  "M15,13V5A3,3 0 0,0 9,5V13A5,5 0 1,0 15,13M12,4A1,1 0 0,1 13,5V8H11V5A1,1 0 0,1 12,4Z";
const ICON_LOCK =
  "M12,17A2,2 0 0,0 14,15C14,13.89 13.1,13 12,13A2,2 0 0,0 10,15A2,2 0 0,0 12,17M18,8A2,2 0 0,1 20,10V20A2,2 0 0,1 18,22H6A2,2 0 0,1 4,20V10C4,8.89 4.9,8 6,8H7V6A5,5 0 0,1 12,1A5,5 0 0,1 17,6V8H18M12,3A3,3 0 0,0 9,6V8H15V6A3,3 0 0,0 12,3Z";
const ICON_GARAGE =
  "M19,20H17V11H7V20H5V9L12,5L19,9V20M8,12H16V14H8V12M8,15H16V17H8V15M16,18V20H8V18H16Z";
const ICON_VACUUM =
  "M12,2A10,10 0 0,1 22,12A10,10 0 0,1 12,22A10,10 0 0,1 2,12A10,10 0 0,1 12,2M12,4A8,8 0 0,0 4,12C4,13.38 4.35,14.68 4.97,15.81L18.81,7.82C17.34,5.53 14.84,4 12,4M19.56,9.5L5.72,17.5C7.19,19.62 9.45,21 12,21A8,8 0 0,0 20,13C20,11.75 19.84,10.58 19.56,9.5M12,11A2,2 0 0,1 14,13A2,2 0 0,1 12,15A2,2 0 0,1 10,13A2,2 0 0,1 12,11Z";
function findCatalogChoice(
  choices,
  id,
) {
  const clean = String(id || "").trim();
  if (!clean || !choices) return undefined;
  return choices.find((c) => c.id === clean);
}
function renderSystemSharedView(store) {
  const data = store.state;
  const sc = data?.system_config;
  const cat = data?.catalog || {};
  const cameras = sc?.camera_entities || [];
  const calendars = sc?.calendar_entities || [];
  const palettes = (sc?.custom_palettes || []).filter((p) => isValidHexColor(p.hex));
  const doorbells = data?.doorbells || [];
  const wallpapers = data?.system_wallpapers || [];
  const noiseRed = sc?.doorbell_noise_reduction || "strong";
  const doorbellFilterOptions = [
    { value: "strong", label: store.t("shared.filter_strong") },
    { value: "light", label: store.t("shared.filter_light") },
    { value: "off", label: store.t("shared.filter_off") },
  ];
  const singletonFields
     = [
    { key: "weather_entity", label: store.t("shared.weather_label"), choices: cat.weathers },
    { key: "alarm_entity", label: store.t("shared.security_alarm_label"), choices: cat.alarms },
  ];
  const multiDomainGroups
     = [
    {
      key: "thermostat_entities",
      title: store.t("shared.thermostat_zones"),
      addLabel: store.t("shared.add_zone"),
      emptyPlaceholder: store.t("shared.choose_thermostat"),
      selectAriaLabel: store.t("shared.thermostat_aria"),
      removeAriaLabel: store.t("shared.remove_thermostat"),
      icon: ICON_THERMOSTAT,
      maxItems: 8,
      items: sc?.thermostat_entities || [],
      choices: cat.climates,
    },
    {
      key: "lock_entities",
      title: store.t("shared.door_locks"),
      addLabel: store.t("shared.add_lock"),
      emptyPlaceholder: store.t("shared.choose_lock"),
      selectAriaLabel: store.t("shared.lock_aria"),
      removeAriaLabel: store.t("shared.remove_lock"),
      icon: ICON_LOCK,
      maxItems: 8,
      items: sc?.lock_entities || [],
      choices: cat.locks,
    },
    {
      key: "garage_entities",
      title: store.t("shared.garage_doors"),
      addLabel: store.t("shared.add_garage"),
      emptyPlaceholder: store.t("shared.choose_garage"),
      selectAriaLabel: store.t("shared.garage_aria"),
      removeAriaLabel: store.t("shared.remove_garage"),
      icon: ICON_GARAGE,
      maxItems: 6,
      items: sc?.garage_entities || [],
      choices: cat.garages,
    },
    {
      key: "vacuum_entities",
      title: store.t("shared.robot_vacuums"),
      addLabel: store.t("shared.add_vacuum"),
      emptyPlaceholder: store.t("shared.choose_vacuum"),
      selectAriaLabel: store.t("shared.vacuum_aria"),
      removeAriaLabel: store.t("shared.remove_vacuum"),
      icon: ICON_VACUUM,
      maxItems: 6,
      items: sc?.vacuum_entities || [],
      choices: cat.vacuums,
    },
  ];
  return html`<section id="view-shared_entities">
    <div class="columns">
      <div class="column">
        ${renderCard({
          id: "card-whole-home",
          handoffActive: store.isHandoffTarget("card-whole-home"),
          title: store.t("card.home_hub_weather"),
          subtitle: store.t("shared.home_hub_subtitle"),
          contentClass: "stack",
          body: html`<div class="settings-list">
              ${singletonFields.map((f) => {
                const curVal = String(sc?.[f.key] || "");
                const selectId = `cfg-${f.key}`;
                return renderSettingsRow({
                  label: f.label,
                  forId: selectId,
                  control: html`<select
                    id=${selectId}
                    .value=${curVal}
                    @change=${(ev) =>
                      store.entity.stageSystemSetting(
                        f.key,
                        (ev.currentTarget).value,
                        selectId,
                      )}
                  >
                    ${renderSelectOptions(f.choices, curVal, store.t("common.none_option"))}
                  </select>`,
                });
              })}
            </div>

            ${multiDomainGroups.map((g) => {
              const configuredCount = g.items.filter((s) => Boolean(String(s || "").trim())).length;
              return html`<div id="hub-domain-${g.key}" class="hub-domain-box">
                <div class="hub-domain-head">
                  <span class="hub-domain-title">
                    ${renderSvgIcon(g.icon)}
                    <span>${g.title}</span>
                    ${configuredCount > 0
                      ? html`<span class="chip chip-primary">
                          ${fmtNumber(configuredCount, store.hass, 0)}
                        </span>`
                      : html`<span class="hub-domain-empty">
                          ${store.t("common.none_configured")}
                        </span>`}
                  </span>
                  <button
                    type="button"
                    ?disabled=${g.items.length >= g.maxItems}
                    @click=${() => store.entity.addStringListRow(g.key, "", g.maxItems)}
                    class="btn btn-secondary btn-compact"
                  >
                    ${g.addLabel}
                  </button>
                </div>
                ${g.items.length
                  ? renderSortableList({
                      id: `hub-list-${g.key}`,
                      ariaLabel: g.title,
                      items: g.items,
                      overlay: store.localeOverlay,
                      getKey: (val) => (val ? `ent:${val}` : "empty"),
                      getLabel: (val, idx) => {
                        const meta = findCatalogChoice(g.choices, val);
                        return meta?.name || val || `${g.selectAriaLabel} ${idx + 1}`;
                      },
                      onReorder: (fromIdx, toIdx) =>
                        store.entity.reorderStringListRows(g.key, fromIdx, toIdx),
                      renderContent: (val, idx) => {
                        const meta = findCatalogChoice(g.choices, val);
                        return html`<div class="hub-slot-row">
                          ${(g.choices?.length ?? 0) > 8
                            ? renderEntityCombobox({
                                id: `hub-combo-${g.key}-${idx}`,
                                value: val,
                                options: g.choices,
                                ariaLabel: g.selectAriaLabel,
                                emptyOptionLabel: g.emptyPlaceholder,
                                host: store.host,
                                overlay: store.localeOverlay,
                                onChange: (nextVal) =>
                                  store.entity.updateStringListRow(g.key, idx, nextVal),
                              })
                            : html`<select
                                aria-label=${g.selectAriaLabel}
                                .value=${val}
                                @change=${(ev) =>
                                  store.entity.updateStringListRow(
                                    g.key,
                                    idx,
                                    (ev.currentTarget).value,
                                  )}
                              >
                                ${renderSelectOptions(g.choices, val, g.emptyPlaceholder)}
                              </select>`}
                          ${meta?.area_name
                            ? html`<span class="hub-slot-meta">
                                <span class="chip">${meta.area_name}</span>
                              </span>`
                            : nothing}
                        </div>`;
                      },
                      renderActions: (_val, idx) =>
                        renderTrashIconButton(g.removeAriaLabel, () =>
                          store.entity.removeStringListRow(g.key, idx),
                        ),
                    })
                  : nothing}
              </div>`;
            })}`,
        })}

        ${renderCard({
          id: "card-calendars",
          handoffActive: store.isHandoffTarget("card-calendars"),
          title: store.t("card.calendars"),
          subtitle: store.t("shared.calendars_subtitle"),
          headerActions: html`<button
            type="button"
            @click=${() => store.entity.addStringListRow("calendar_entities", "", 50)}
            class="btn btn-secondary btn-compact"
          >
            ${store.t("shared.add_calendar")}
          </button>`,
          body: renderEntitySlotList({
            id: "calendars-list",
            items: calendars,
            choices: cat.calendars,
            emptyOptionLabel: store.t("shared.choose_calendar"),
            emptyStateText: store.t("shared.empty_calendars"),
            selectAriaLabel: store.t("shared.calendar_aria"),
            removeAriaLabel: store.t("shared.remove_calendar"),
            useCombobox: (cat.calendars?.length ?? 0) > 8,
            host: store.host,
            onReorder: (fromIdx, toIdx) =>
              store.entity.reorderStringListRows("calendar_entities", fromIdx, toIdx),
            onChange: (idx, val) =>
              store.entity.updateStringListRow("calendar_entities", idx, val),
            onRemove: (idx) => store.entity.removeStringListRow("calendar_entities", idx),
          }),
        })}

        ${renderCard({
          id: "card-system-wallpapers",
          handoffActive: store.isHandoffTarget("card-system-wallpapers"),
          title: store.t("card.wallpapers"),
          subtitle: store.t("shared.wallpapers_subtitle"),
          headerActions: renderWallpaperUploadTrigger(store, "system"),
          contentClass: "stack",
          body: html`${renderWallpaperUploadProgress(store, "system")}
            <div class="wp-gallery">
              ${renderWallpaperGalleryItems(store, "system", wallpapers, "square")}
            </div>`,
        })}
      </div>

      <div class="column">
        ${renderCard({
          id: "card-cameras-doorbell",
          handoffActive: store.isHandoffTarget("card-cameras-doorbell"),
          title: store.t("card.cameras_doorbell"),
          subtitle: store.t("shared.cameras_subtitle"),
          headerActions: html`<button
            type="button"
            @click=${() => store.entity.addStringListRow("camera_entities", "", 10)}
            class="btn btn-secondary btn-compact"
          >
            ${store.t("shared.add_camera")}
          </button>`,
          contentClass: "stack",
          body: html`<div class="settings-list">
              ${renderSelectRow({
                id: "cfg-doorbell_noise_reduction",
                label: store.t("shared.doorbell_filter_label"),
                description: store.t("shared.doorbell_filter_desc"),
                value: noiseRed,
                rawOptions: doorbellFilterOptions,
                onChange: (val) =>
                  store.entity.stageSystemSetting(
                    "doorbell_noise_reduction",
                    val,
                    "cfg-doorbell_noise_reduction",
                  ),
              })}
            </div>

            ${renderEntitySlotList({
              id: "cameras-list",
              items: cameras,
              choices: cat.cameras,
              emptyOptionLabel: store.t("shared.choose_camera"),
              emptyStateText: store.t("shared.empty_cameras"),
              selectAriaLabel: store.t("shared.camera_aria"),
              removeAriaLabel: store.t("shared.remove_camera"),
              useCombobox: (cat.cameras?.length ?? 0) > 8,
              host: store.host,
              slotLabel: (idx) =>
                idx === 0
                  ? store.t("shared.camera_slot_primary")
                  : store.t("shared.camera_slot_n", { index: idx + 1 }),
              extraActions: (camId) => html`<button
                type="button"
                ?disabled=${!camId}
                @click=${() => void store.entity.previewCamera(camId)}
                class="btn btn-text btn-compact"
              >
                ${store.t("shared.preview")}
              </button>`,
              onReorder: (fromIdx, toIdx) =>
                store.entity.reorderStringListRows("camera_entities", fromIdx, toIdx),
              onChange: (idx, val) =>
                store.entity.updateStringListRow("camera_entities", idx, val),
              onRemove: (idx) => store.entity.removeStringListRow("camera_entities", idx),
            })}

            ${store.cameraPreviewUrl
              ? html`<div id="cam-preview-box" class="cam-preview">
                  <div class="input-action-row">
                    <span class="field-label">
                      ${store.t("shared.preview_heading", {
                        entity: store.activeCameraPreviewEntity,
                      })}
                    </span>
                    <button
                      type="button"
                      @click=${() =>
                        void store.entity.previewCamera(store.activeCameraPreviewEntity, true)}
                      class="btn btn-secondary btn-compact"
                    >
                      ${store.t("action.refresh")}
                    </button>
                    <button
                      type="button"
                      @click=${() => store.entity.closeCameraPreview()}
                      class="btn btn-text btn-compact"
                    >
                      ${store.t("action.close")}
                    </button>
                  </div>
                  <img
                    id="cam-preview-img"
                    src=${store.cameraPreviewUrl}
                    alt=${store.t("shared.camera_preview_alt")}
                  />
                </div>`
              : nothing}

            ${doorbells.length
              ? html`<div id="doorbell-status" class="stack">
                  <h4 class="subsection-title">${store.t("shared.doorbells_heading")}</h4>
                  <div id="doorbell-status-list" class="kv-list">
                    ${doorbells.map((b) => {
                      let ring = store.t("shared.no_ring_sensor");
                      const ringEnt = b.ring_entity || "";
                      if (ringEnt) {
                        const when = b.ring_at
                          ? fmtAgo((Date.now() - Date.parse(b.ring_at)) / 1000, store.hass)
                          : "";
                        const st = ringEnt.startsWith("event.")
                          ? when
                            ? store.t("shared.last_ring", { when })
                            : store.t("shared.no_ring_yet")
                          : b.ring_state === "on"
                            ? store.t("shared.ringing")
                            : b.ring_state
                              ? when
                                ? store.t("shared.idle_changed", { when })
                                : store.t("shared.idle")
                              : store.t("shared.unavailable");
                        ring = `${b.ring_name || ringEnt}: ${st}`;
                      }
                      const talk = (b.talk || [])
                        .map((entry) => {
                          const stateWord =
                            entry.state === "listening"
                              ? store.t("shared.talk_listening")
                              : entry.state === "talking"
                                ? store.t("shared.talk_talking")
                                : entry.state;
                          return `${entry.device_title} ${stateWord}`;
                        })
                        .join(", ");
                      return html`<div class="kv-row">
                        <span>${entityLabel(b.camera_name || b.camera_entity)}</span>
                        <strong>${ring}${talk ? ` • ${talk}` : ""}</strong>
                      </div>`;
                    })}
                  </div>
                </div>`
              : nothing}`,
        })}

        ${renderCard({
          id: "card-custom-colors",
          handoffActive: store.isHandoffTarget("card-custom-colors"),
          title: store.t("card.custom_colors"),
          subtitle: store.t("shared.colors_subtitle"),
          headerActions: html`<button
            type="button"
            @click=${() => store.tools.openColorWheelModal("system")}
            class="btn btn-secondary btn-compact"
          >
            ${store.t("shared.add_color")}
          </button>`,
          contentClass: "settings-list",
          body: html`<div id="sys-custom-palettes-list" class="settings-list">
            ${palettes.length
              ? palettes.map((p) => {
                  const h = p.hex.toUpperCase();
                  const swStyle = `--swatch-color:${h}`;
                  return renderSettingsRow({
                    labelHtml: html`<span class="row-label">
                      <span class="swatch" style=${swStyle} aria-hidden="true"></span>
                      ${p.name || h}
                    </span>`,
                    description: html`<code>${h}</code>`,
                    control: renderTrashIconButton(
                      store.t("shared.delete_color_aria", { name: p.name || h }),
                      () => store.entity.deleteCustomPalette(h),
                    ),
                  });
                })
              : html`<p class="empty-state">${store.t("shared.empty_colors")}</p>`}
          </div>`,
        })}
      </div>
    </div>
  </section>`;
}
__latterExp(__exports, { renderSystemSharedView: () => renderSystemSharedView });
//# sourceURL=latter-studio/src/views/system-shared-view.ts
});
__latterDef("src/views/system-tools-view.ts", (__exports, __req) => {
const { renderCard, renderSettingsRow } = __req("src/components/controls.ts");
const { STUDIO_REV } = __req("src/constants.ts");
const { focusSafe, html, nothing } = __req("src/lib/lit.ts");
/**
 * System tools view (`system_tools`, `D-020` / `D-040` / `D-064` / `D-066`):
 * Notifications & announcements, doorbell & intercom audio, backup & restore,
 * perimeter security & signing, System & Device logs, and Support & diagnostics.
 */
const DOCS_URL = "https://github.com/slampton/ha-latter";
const ISSUES_URL = "https://github.com/slampton/ha-latter/issues";
function renderSystemToolsView(store) {
  const data = store.state;
  const allDevices = data?.system_devices || [];
  const latterDevices = allDevices.filter((d) => d.kind !== "ble_tag");
  const bleTagCount = allDevices.length - latterDevices.length;
  const configuredCameras = (data?.system_config?.camera_entities || [])
    .map((c) => String(c || "").trim())
    .filter(Boolean);
  const primaryCamera = configuredCameras[0] || "";
  const canTestDoorbell = Boolean(primaryCamera && latterDevices.length > 0);
  const doorbellTestDescription = !primaryCamera
    ? store.t("tools_sys.doorbell_desc_no_cam")
    : !latterDevices.length
      ? store.t("tools_sys.doorbell_desc_no_dev")
      : store.t("tools_sys.doorbell_desc_ready", { camera: primaryCamera });
  const hasSystemPin = Boolean(data?.has_security_pin);
  const isBroadcast = store.announceMode === "broadcast";
  const sysInfo = data?.system_info;
  const haVer = sysInfo?.ha_version || store.hass?.config?.version || store.t("common.unknown");
  const rawIntVer = sysInfo?.integration_version || data?.version || "";
  const intVer = rawIntVer ? `v${rawIntVer}` : store.t("common.unknown");
  const sdkRev = sysInfo?.min_firmware_sdk_rev
    ? String(sysInfo.min_firmware_sdk_rev)
    : store.t("common.unknown");
  const studioRev = `rev ${String(sysInfo?.studio_rev ?? STUDIO_REV)}`;
  const onAnnounceRadioKey = (ev) => {
    const kev = ev;
    if (kev.key !== "ArrowLeft" && kev.key !== "ArrowRight") return;
    kev.preventDefault();
    const nextMode = store.announceMode === "notify" ? "broadcast" : "notify";
    store.announceMode = nextMode;
    store.host.requestUpdate();
    const group = (kev.currentTarget).parentElement;
    const nextBtn = group?.querySelector(
      `[data-mode="${nextMode}"]`,
    );
    nextBtn?.focus();
  };
  return html`<section id="view-system_tools">
    <div class="columns">
      <div class="column">
        ${renderCard({
          id: "card-notifications-announcements",
          title: store.t("card.notifications_announcements"),
          subtitle: store.t("tools_sys.announce_subtitle"),
          contentClass: "stack",
          body: html`<div
              role="radiogroup"
              aria-label=${store.t("tools_sys.announce_mode_aria")}
              class="segmented"
            >
              <button
                type="button"
                data-mode="notify"
                tabindex=${!isBroadcast ? "0" : "-1"}
                aria-checked=${String(!isBroadcast)}
                @click=${() => {
                  store.announceMode = "notify";
                  store.host.requestUpdate();
                }}
                @keydown=${onAnnounceRadioKey}
                role="radio"
              >
                ${store.t("tools_sys.screen_notification")}
              </button>
              <button
                type="button"
                data-mode="broadcast"
                tabindex=${isBroadcast ? "0" : "-1"}
                aria-checked=${String(isBroadcast)}
                @click=${() => {
                  store.announceMode = "broadcast";
                  store.host.requestUpdate();
                }}
                @keydown=${onAnnounceRadioKey}
                role="radio"
              >
                ${store.t("tools_sys.voice_broadcast")}
              </button>
            </div>

            <div class="stacked-field">
              <label for="ann-target">${store.t("tools_sys.target_label")}</label>
              <select
                id="ann-target"
                .value=${store.announceTarget}
                @change=${(ev) => {
                  store.announceTarget = (ev.currentTarget).value || "all";
                  store.host.requestUpdate();
                }}
              >
                <option value="all" ?selected=${store.announceTarget === "all"}>
                  ${store.t("tools_sys.all_displays")}
                </option>
                <option
                  value="occupied_areas"
                  ?selected=${store.announceTarget === "occupied_areas"}
                >
                  ${store.t("tools_sys.occupied_areas_only")}
                </option>
                ${latterDevices.map(
                  (d) =>
                    html`<option
                      value=${d.device_slug}
                      ?selected=${store.announceTarget === d.device_slug}
                    >
                      ${store.t("tools_sys.device_prefix", { title: d.title })}
                    </option>`,
                )}
              </select>
            </div>

            ${!isBroadcast
              ? html`<div class="stacked-field">
                    <label for="ann-title">${store.t("tools_sys.notification_title")}</label>
                    <input
                      type="text"
                      id="ann-title"
                      placeholder=${store.t("tools_sys.notification_title_placeholder")}
                      .value=${focusSafe(store.announceTitle)}
                      @input=${(ev) => {
                        store.announceTitle = (ev.currentTarget).value;
                      }}
                    />
                  </div>
                  <div class="list-row-main">
                    <div class="stacked-field">
                      <label for="ann-priority">${store.t("tools_sys.priority")}</label>
                      <select
                        id="ann-priority"
                        .value=${store.announcePriority}
                        @change=${(ev) => {
                          store.announcePriority = (ev.currentTarget).value
                                        ;
                        }}
                      >
                        <option value="normal">${store.t("tools_sys.priority_normal")}</option>
                        <option value="warning">${store.t("tools_sys.priority_warning")}</option>
                        <option value="critical">${store.t("tools_sys.priority_critical")}</option>
                      </select>
                    </div>
                    <label class="inline-switch">
                      <input
                        type="checkbox"
                        role="switch"
                        .checked=${store.announceIncludeCamera}
                        @change=${(ev) => {
                          store.announceIncludeCamera = (
                            ev.currentTarget
                          ).checked;
                        }}
                        class="switch"
                      />
                      <span>${store.t("tools_sys.include_camera")}</span>
                    </label>
                  </div>`
              : nothing}

            <div class="stacked-field">
              <label for="ann-message">${store.t("tools_sys.message")}</label>
              <textarea
                id="ann-message"
                rows="3"
                placeholder=${store.t("tools_sys.message_placeholder")}
                .value=${focusSafe(store.announceMessage)}
                @input=${(ev) => {
                  store.announceMessage = (ev.currentTarget).value;
                }}
              ></textarea>
            </div>

            <div class="input-action-row">
              <button
                type="button"
                id="btn-send-announcement"
                @click=${() => void store.tools.sendAnnouncement()}
                class="btn btn-primary"
              >
                ${store.t("tools_sys.send_now")}
              </button>
            </div>`,
        })}

        ${renderCard({
          id: "card-doorbell-intercom-audio",
          title: store.t("card.doorbell_intercom_audio"),
          subtitle: store.t("tools_sys.doorbell_subtitle"),
          contentClass: "settings-list",
          body: html`${renderSettingsRow({
              label: store.t("tools_sys.source_device"),
              forId: "doorbell-test-device",
              description: store.t("tools_sys.source_device_desc"),
              control: html`<select
                id="doorbell-test-device"
                ?disabled=${!canTestDoorbell}
                .value=${store.doorbellTestSubentryId}
                @change=${(ev) => {
                  store.doorbellTestSubentryId = (ev.currentTarget).value;
                  store.host.requestUpdate();
                }}
              >
                ${latterDevices.length
                  ? latterDevices.map(
                      (d) =>
                        html`<option
                          value=${d.subentry_id}
                          ?selected=${d.subentry_id === store.doorbellTestSubentryId}
                        >
                          ${d.title}
                        </option>`,
                    )
                  : html`<option value="">${store.t("tools_sys.no_latter_devices")}</option>`}
              </select>`,
            })}
            ${renderSettingsRow({
              id: "row-doorbell-test-reply",
              label: store.t("tools_sys.test_door_reply"),
              forId: "doorbell-test-reply",
              description: doorbellTestDescription,
              stacked: true,
              control: html`<div class="input-action-row">
                <input
                  type="text"
                  id="doorbell-test-reply"
                  maxlength="160"
                  placeholder=${store.t("tools_sys.doorbell_reply_placeholder")}
                  ?disabled=${!canTestDoorbell}
                  .value=${focusSafe(store.doorbellTestReply)}
                  @input=${(ev) => {
                    store.doorbellTestReply = (ev.currentTarget).value;
                  }}
                />
                <button
                  type="button"
                  id="btn-play-door-speaker"
                  ?disabled=${!canTestDoorbell}
                  @click=${() => void store.entity.testDoorbellSpeaker()}
                  class="btn btn-primary btn-compact"
                >
                  ${store.t("tools_sys.play_door_speaker")}
                </button>
                ${!primaryCamera
                  ? html`<button
                      type="button"
                      @click=${() =>
                        store.openSystemSection("shared_entities", "card-cameras-doorbell")}
                      class="btn btn-text btn-compact"
                    >
                      ${store.t("action.open_shared_entities")}
                    </button>`
                  : nothing}
              </div>`,
            })}`,
        })}

        <details
          id="card-system-logs"
          ?open=${store.logsOpen}
          @toggle=${(ev) =>
            store.tools.onToggleLogsDetails((ev.currentTarget).open)}
          class="card"
        >
          <summary class="card-header">
            <div class="card-heading">
              <h3 class="card-title">${store.t("card.system_device_logs")}</h3>
            </div>
          </summary>
          <div class="card-content stack">
            <div class="input-action-row">
              <select
                aria-label=${store.t("tools_sys.logs_filter_aria")}
                .value=${store.logFilter}
                @change=${(ev) => {
                  store.logFilter = (ev.currentTarget).value || "all";
                  store.host.requestUpdate();
                }}
              >
                <option value="all" ?selected=${store.logFilter === "all"}>
                  ${store.t("tools_sys.logs_all")}
                </option>
                <option value="latter" ?selected=${store.logFilter === "latter"}>
                  ${store.t("tools_sys.logs_studio")}
                </option>
                <option value="errors" ?selected=${store.logFilter === "errors"}>
                  ${store.t("tools_sys.logs_errors")}
                </option>
                ${allDevices.map(
                  (d) =>
                    html`<option
                      value=${`device:${d.device_slug}`}
                      ?selected=${store.logFilter === `device:${d.device_slug}`}
                    >
                      ${store.t("tools_sys.device_prefix", { title: d.title })}
                    </option>`,
                )}
              </select>
              <button
                type="button"
                @click=${() => void store.refreshState({ includeLogs: true })}
                class="btn btn-secondary btn-compact"
              >
                ${store.t("tools_sys.refresh_logs")}
              </button>
              <button
                type="button"
                @click=${() => void store.tools.copyLogsToClipboard()}
                class="btn btn-secondary btn-compact"
              >
                ${store.t("tools_sys.copy_logs")}
              </button>
              <button
                type="button"
                id="btn-clear-internal-logs"
                @click=${() => void store.tools.clearInternalLogs()}
                class="btn btn-text btn-compact"
              >
                ${store.t("tools_sys.clear_logs")}
              </button>
              <button
                type="button"
                @click=${() => store.openHaPage("/config/logs")}
                class="btn btn-text btn-compact"
              >
                ${store.t("action.open_ha_logs")}
              </button>
            </div>
            <pre class="log-output">${store.tools.formatVisibleLogs()}</pre>
          </div>
        </details>
      </div>

      <div class="column">
        ${renderCard({
          id: "card-backup-restore",
          handoffActive: store.isHandoffTarget("card-backup-restore"),
          title: store.t("card.backup_restore"),
          subtitle: store.t("tools_sys.backup_subtitle"),
          contentClass: "stack",
          body: html`<div class="stacked-field">
              <label for="bkp-scope-select">${store.t("tools_sys.export_scope")}</label>
              <div class="input-action-row">
                <select
                  id="bkp-scope-select"
                  .value=${store.backupExportScope}
                  @change=${(ev) => {
                    store.backupExportScope = (ev.currentTarget).value;
                    store.host.requestUpdate();
                  }}
                >
                  <option value="system" ?selected=${store.backupExportScope === "system"}>
                    ${store.t("tools_sys.entire_system")}
                  </option>
                  ${allDevices.map(
                    (d) =>
                      html`<option
                        value=${`device:${d.subentry_id}`}
                        ?selected=${store.backupExportScope === `device:${d.subentry_id}`}
                      >
                        ${store.t("tools_sys.device_prefix", { title: d.title })}
                      </option>`,
                  )}
                </select>
                <button
                  type="button"
                  id="btn-download-backup"
                  @click=${() => void store.tools.exportBackup()}
                  class="btn btn-secondary"
                >
                  ${store.t("action.download_backup")}
                </button>
              </div>
            </div>

            <div class="stacked-field">
              <label for="input-restore-backup">${store.t("tools_sys.restore_from_backup")}</label>
              <input
                type="file"
                id="input-restore-backup"
                accept=".json,application/json"
                @change=${(ev) => {
                  const inp = ev.currentTarget;
                  store.selectedBackupFile = inp.files && inp.files[0] ? inp.files[0] : null;
                  store.host.requestUpdate();
                }}
              />
            </div>

            <div class="stacked-field">
              <label for="bkp-restore-device">${store.t("tools_sys.target_device_restore")}</label>
              <select
                id="bkp-restore-device"
                .value=${store.backupRestoreSubentryId}
                @change=${(ev) => {
                  store.backupRestoreSubentryId = (ev.currentTarget).value;
                  store.host.requestUpdate();
                }}
              >
                <option value="">${store.t("tools_sys.auto_system_backup")}</option>
                ${allDevices.map(
                  (d) =>
                    html`<option
                      value=${d.subentry_id}
                      ?selected=${d.subentry_id === store.backupRestoreSubentryId}
                    >
                      ${d.title}
                    </option>`,
                )}
              </select>
            </div>

            <div class="input-action-row">
              <button
                type="button"
                id="btn-restore-backup"
                ?disabled=${!store.selectedBackupFile}
                @click=${() => void store.tools.requestRestoreFromUploadedFile()}
                class="btn btn-primary"
              >
                ${store.t("action.restore_backup")}
              </button>
            </div>`,
        })}

        ${renderCard({
          id: "card-perimeter-security",
          handoffActive: store.isHandoffTarget("card-perimeter-security"),
          title: store.t("card.perimeter_security_signing"),
          contentClass: "settings-list",
          body: html`${renderSettingsRow({
              label: store.t("tools_sys.system_pin_label"),
              description: store.t("tools_sys.system_pin_desc"),
              stacked: true,
              control: html`<div class="input-action-row">
                <span
                  id="sys-security-pin-status"
                  class="chip ${hasSystemPin ? "chip-success" : ""}"
                >
                  ${hasSystemPin
                    ? store.t("status.pin_configured")
                    : store.t("status.pin_not_set")}
                </span>
                <input
                  type="password"
                  id="sys-security-pin-input"
                  inputmode="numeric"
                  pattern="[0-9]*"
                  autocomplete="new-password"
                  aria-label=${store.t("tools_sys.system_pin_aria")}
                  placeholder=${hasSystemPin
                    ? store.t("tools_sys.pin_replace_placeholder")
                    : store.t("tools_sys.pin_digits_placeholder")}
                  .value=${focusSafe(store.systemPinDraft)}
                  @input=${(ev) => {
                    store.systemPinDraft = (ev.currentTarget).value;
                    store.host.requestUpdate();
                  }}
                />
                <button
                  type="button"
                  id="btn-save-security-pin"
                  ?disabled=${store.pinBusy || !store.systemPinDraft.trim()}
                  @click=${() => void store.tools.saveSecurityPin("system")}
                  class="btn btn-primary btn-compact"
                >
                  ${store.t("tools_sys.save_pin")}
                </button>
                ${hasSystemPin
                  ? html`<button
                      type="button"
                      id="btn-clear-security-pin"
                      ?disabled=${store.pinBusy}
                      @click=${() => store.tools.requestClearSecurityPin("system")}
                      class="btn btn-danger btn-compact"
                    >
                      ${store.t("tools_sys.clear_pin")}
                    </button>`
                  : nothing}
              </div>`,
            })}
            ${renderSettingsRow({
              label: store.t("tools_sys.signing_key_label"),
              description: store.t("tools_sys.signing_key_desc"),
              control: html`<button
                type="button"
                id="btn-rotate-signing-key"
                @click=${() => store.tools.requestRotateSigningKey()}
                class="btn btn-secondary btn-compact"
              >
                ${store.t("tools_sys.rotate_signing_key")}
              </button>`,
            })}`,
        })}

        ${renderCard({
          id: "card-support-diagnostics",
          title: store.t("card.support_diagnostics"),
          subtitle: store.t("card.support_subtitle"),
          contentClass: "stack",
          footerActions: html`<a
              href=${DOCS_URL}
              target="_blank"
              rel="noopener noreferrer"
              class="btn btn-text"
            >
              ${store.t("support.documentation")}
            </a>
            <a
              href=${ISSUES_URL}
              target="_blank"
              rel="noopener noreferrer"
              class="btn btn-text"
            >
              ${store.t("support.report_issue")}
            </a>`,
          body: html`<div class="kv-list">
              <div class="kv-row">
                <span>${store.t("support.ha_version")}</span>
                <strong>${haVer}</strong>
              </div>
              <div class="kv-row">
                <span>${store.t("support.integration_version")}</span>
                <strong>${intVer}</strong>
              </div>
              <div class="kv-row">
                <span>${store.t("support.sdk_rev")}</span>
                <strong>${sdkRev}</strong>
              </div>
              <div class="kv-row">
                <span>${store.t("support.studio_rev")}</span>
                <strong>${studioRev}</strong>
              </div>
              <div class="kv-row">
                <span>${store.t("support.managed_devices")}</span>
                <strong>${store.t("support.managed_devices_value", {
                  total: allDevices.length,
                  displays: latterDevices.length,
                  trackers: bleTagCount,
                })}</strong>
              </div>
            </div>
            <div class="input-action-row">
              <button
                type="button"
                id="btn-download-system-diagnostics"
                @click=${() => void store.tools.downloadSystemDiagnostics()}
                class="btn btn-primary"
              >
                ${store.t("support.download_system_diagnostics")}
              </button>
              <button
                type="button"
                id="btn-copy-system-info"
                @click=${() => void store.tools.copySystemInfoSummary()}
                class="btn btn-secondary"
              >
                ${store.t("support.copy_summary")}
              </button>
            </div>`,
        })}
      </div>
    </div>
  </section>`;
}
__latterExp(__exports, { renderSystemToolsView: () => renderSystemToolsView });
//# sourceURL=latter-studio/src/views/system-tools-view.ts
});
__latterDef("src/views/index.ts", (__exports, __req) => {
const { renderDeviceAudioView } = __req("src/views/device-audio-view.ts");
const { renderDeviceDisplayView } = __req("src/views/device-display-view.ts");
const { renderDeviceInterfaceView } = __req("src/views/device-interface-view.ts");
const { renderDeviceOverviewView } = __req("src/views/device-overview-view.ts");
const { renderDevicePowerView } = __req("src/views/device-power-view.ts");
const { renderDevicePresenceView } = __req("src/views/device-presence-view.ts");
const { renderDeviceToolsView } = __req("src/views/device-tools-view.ts");
const { renderDevicesDiscoveredView } = __req("src/views/devices-discovered-view.ts");
const { renderDevicesListView } = __req("src/views/devices-list-view.ts");
const { renderSystemGroupsView } = __req("src/views/system-groups-view.ts");
const { renderSystemOverviewView } = __req("src/views/system-overview-view.ts");
const { renderSystemPresenceView } = __req("src/views/system-presence-view.ts");
const { renderSystemRemotesView } = __req("src/views/system-remotes-view.ts");
const { renderSystemSharedView } = __req("src/views/system-shared-view.ts");
const { renderSystemToolsView } = __req("src/views/system-tools-view.ts");
/**
 * Active-View-Only Router (`D-023`, `D-026`, `E-14`):
 * Renders ONLY the currently active Studio view and gates Device routes via `store.deviceHasView`.
 */
function renderActiveView(store) {
  if (store.currentScope === "system") {
    switch (store.currentViewId) {
      case "shared_entities":
        return renderSystemSharedView(store);
      case "remotes":
        return renderSystemRemotesView(store);
      case "system_sync":
        return renderSystemGroupsView(store);
      case "area_tracking":
        return renderSystemPresenceView(store);
      case "system_tools":
        return renderSystemToolsView(store);
      case "system_overview":
      default:
        return renderSystemOverviewView(store);
    }
  }
  const viewId = store.currentViewId;
  if (viewId === "discovered_devices") {
    return renderDevicesDiscoveredView(store);
  }
  if (!store.deviceSelected || viewId === "select_device_prompt") {
    return renderDevicesListView(store);
  }
  switch (viewId) {
    case "display":
      return store.deviceHasView("display")
        ? renderDeviceDisplayView(store)
        : renderDeviceOverviewView(store);
    case "interface":
      return store.deviceHasView("interface")
        ? renderDeviceInterfaceView(store)
        : renderDeviceOverviewView(store);
    case "audio_voice":
      return store.deviceHasView("audio_voice")
        ? renderDeviceAudioView(store)
        : renderDeviceOverviewView(store);
    case "power":
      return store.deviceHasView("power")
        ? renderDevicePowerView(store)
        : renderDeviceOverviewView(store);
    case "presence":
      return store.deviceHasView("presence")
        ? renderDevicePresenceView(store)
        : renderDeviceOverviewView(store);
    case "tools":
      return store.deviceHasView("tools")
        ? renderDeviceToolsView(store)
        : renderDeviceOverviewView(store);
    case "dashboard":
    default:
      return renderDeviceOverviewView(store);
  }
}
__latterExp(__exports, { renderActiveView: () => renderActiveView });
//# sourceURL=latter-studio/src/views/index.ts
});
__latterDef("src/latter-studio.ts", (__exports, __req) => {
const { renderConfirmDialog, syncDialogElement } = __req("src/components/controls.ts");
const { renderStudioDialogs, syncStudioDialogs } = __req("src/components/dialogs.ts");
const { DEVICE_VIEW_SLUGS, SYSTEM_VIEW_SLUGS } = __req("src/constants.ts");
const { html, LitElement, nothing } = __req("src/lib/lit.ts");
const { StudioStore } = __req("src/state/store.ts");
const { STUDIO_STYLES } = __req("src/styles/tokens.ts");
const { renderActiveView } = __req("src/views/index.ts");
/**
 * `<latter-studio>` Custom Element — Modular TypeScript + Vendored `lit-html` Shell (`D-023`, `D-061`, `D-062`).
 *
 * - Zero `window.*` property bindings; state is owned per element by `StudioStore`.
 * - `_applyRoute()` runs before `super.connectedCallback()` so `hostConnected` subscribes once (`B-01`).
 * - Sidebar `<a href="/latter/...">` links with `aria-current="page"` and SPA click interception (`D-22`).
 * - Promoted `<h1>` `#unified-page-title`, persistent polite/assertive live regions, sticky error toast (`D-01`),
 *   `.loading-state` skeleton during `store.deviceLoading` (`B-02`), and shared `renderConfirmDialog` (`Q5`).
 */
const SYSTEM_NAV_ITEMS
   = [
  { viewId: "system_overview", labelKey: "view.system_overview" },
  { viewId: "shared_entities", labelKey: "view.shared_entities" },
  { viewId: "remotes", labelKey: "view.remotes" },
  { viewId: "system_sync", labelKey: "view.system_sync" },
  { viewId: "area_tracking", labelKey: "view.area_tracking" },
  { viewId: "system_tools", labelKey: "view.system_tools" },
];
const DEVICE_NAV_ITEMS
   = [
  { viewId: "dashboard", labelKey: "view.dashboard" },
  { viewId: "display", labelKey: "view.display", id: "nav-btn-display" },
  { viewId: "interface", labelKey: "view.interface", id: "nav-btn-interface" },
  { viewId: "audio_voice", labelKey: "view.audio_voice", id: "nav-btn-audio_voice" },
  { viewId: "power", labelKey: "view.power", id: "nav-btn-power" },
  { viewId: "presence", labelKey: "view.presence" },
  { viewId: "tools", labelKey: "view.tools" },
];
class LatterStudio extends LitElement {
  static styles = STUDIO_STYLES;
           store;
          _narrow = false;
          _route = null;
          _panel = null;
          _routeInitialized = false;
          _lastRouteHeadingKey = "";
  constructor() {
    super();
    this.store = new StudioStore(this);
    this.addController(this.store);
  }
           connectedCallback() {
    if (!this._routeInitialized) {
      this._routeInitialized = true;
      this._applyRoute();
    }
    super.connectedCallback();
  }
          _syncShowMenu(h) {
    const show = this._narrow || h?.dockedSidebar === "always_hidden";
    this.toggleAttribute("show-menu", show);
  }
  set hass(h) {
    this.toggleAttribute("dark", Boolean(h?.themes?.darkMode));
    this._syncShowMenu(h);
    this.store.setHass(h);
  }
  get hass() {
    return this.store.hass;
  }
  set narrow(n) {
    const next = Boolean(n);
    if (this._narrow === next) return;
    this._narrow = next;
    this.toggleAttribute("narrow", next);
    this._syncShowMenu(this.store.hass);
  }
  get narrow() {
    return this._narrow;
  }
  set panel(p) {
    this._panel = p;
  }
  get panel() {
    return this._panel;
  }
  set route(r) {
    const prevPath = this._route?.path ?? null;
    this._route = r;
    if (this._routeInitialized && r && r.path !== prevPath) {
      this._applyRoute();
    }
  }
  get route() {
    return this._route;
  }
          _applyRoute() {
    this.store.applyRoute(this._route);
  }
          _onNavLinkClick(ev, navigate) {
    if (
      ev.defaultPrevented ||
      ev.button !== 0 ||
      ev.metaKey ||
      ev.ctrlKey ||
      ev.shiftKey ||
      ev.altKey
    ) {
      return;
    }
    ev.preventDefault();
    navigate();
  }
          _onRootKeyDown(ev) {
    if (ev.ctrlKey || ev.metaKey || ev.altKey || ev.key === "Escape" || ev.key === "Tab") {
      return;
    }
    const path = typeof ev.composedPath === "function" ? ev.composedPath() : [];
    const inner = (path[0] ?? ev.target);
    if (!inner || typeof inner.tagName !== "string") return;
    const tag = inner.tagName.toUpperCase();
    if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") {
      ev.stopPropagation();
    }
  }
          _onMainFocusOut(ev) {
    const path = typeof ev.composedPath === "function" ? ev.composedPath() : [];
    const target = (path[0] ?? ev.target);
    if (!target || typeof target.tagName !== "string") return;
    if (target.getAttribute("role") === "combobox") return;
    const tag = target.tagName.toUpperCase();
    if (tag === "TEXTAREA") {
      void this.store.entity.flushAllPendingSettings();
      return;
    }
    if (tag === "INPUT") {
      const type = String((target).type || "text").toLowerCase();
      if (
        type === "text" ||
        type === "number" ||
        type === "search" ||
        type === "password" ||
        type === "tel" ||
        type === "url" ||
        type === "email"
      ) {
        void this.store.entity.flushAllPendingSettings();
      }
    }
  }
          _onScopeTabKeyDown(ev) {
    if (
      ev.key !== "ArrowLeft" &&
      ev.key !== "ArrowRight" &&
      ev.key !== "Home" &&
      ev.key !== "End"
    ) {
      return;
    }
    ev.preventDefault();
    const currentIsDevice = this.store.currentScope === "device";
    let nextScope;
    if (ev.key === "Home") {
      nextScope = "device";
    } else if (ev.key === "End") {
      nextScope = "system";
    } else {
      nextScope = currentIsDevice ? "system" : "device";
    }
    if (nextScope === "device") {
      this.store.openDevicesLanding();
      const btn = this.renderRoot.querySelector("#tab-scope-device");
      btn?.focus();
    } else {
      this.store.setScope("system");
      const btn = this.renderRoot.querySelector("#tab-scope-system");
      btn?.focus();
    }
  }
                     updated() {
    syncStudioDialogs(this.renderRoot, this.store);
    const confirmDlg = this.renderRoot.getElementById(
      "latter-confirm-modal",
    );
    syncDialogElement(confirmDlg, this.store.confirmModal.open);
    const routeKey = `${this.store.currentScope}|${this.store.currentViewId}|${this.store.activeSubentryId}`;
    if (this._lastRouteHeadingKey && this._lastRouteHeadingKey !== routeKey) {
      const titleText = this.store.pageSubtitle
        ? `${this.store.pageTitle} — ${this.store.pageSubtitle}`
        : this.store.pageTitle;
      this.store.announcePolite(titleText);
      const activeEl = this.renderRoot.activeElement;
      if (activeEl && activeEl.classList?.contains("nav-btn")) {
        const headingEl = this.renderRoot.getElementById(
          "unified-page-title",
        );
        headingEl?.focus?.({ preventScroll: true });
      }
    }
    this._lastRouteHeadingKey = routeKey;
  }
          _renderDeviceNav() {
    const subId = this.store.activeSubentryId;
    const encodedSub = encodeURIComponent(subId);
    const devTitle = this.store.pageSubtitle || this.store.t("common.unknown");
    const items = DEVICE_NAV_ITEMS.filter((item) => this.store.deviceHasView(item.viewId));
    return html`<nav
      id="nav-scope-device"
      aria-label=${this.store.t("nav.device_pages_label")}
      class="nav-list"
    >
      <a
        href="/latter/devices"
        @click=${(ev) =>
          this._onNavLinkClick(ev, () => this.store.openDevicesLanding())}
        class="nav-btn nav-back-btn"
      >
        <span>${this.store.t("nav.back_managed")}</span>
      </a>
      <div id="nav-selected-device-label" class="nav-device-title">
        ${devTitle}
      </div>
      ${items.map((item) => {
        const active = this.store.currentViewId === item.viewId;
        const slug = DEVICE_VIEW_SLUGS[item.viewId];
        return html`<a
          href="/latter/devices/${encodedSub}/${slug}"
          id=${item.id || nothing}
          data-view=${item.viewId}
          aria-current=${active ? "page" : nothing}
          @click=${(ev) =>
            this._onNavLinkClick(ev, () => this.store.switchView(item.viewId))}
          class="nav-btn ${active ? "active" : ""}"
        >
          <span>${this.store.t(item.labelKey)}</span>
        </a>`;
      })}
    </nav>`;
  }
          _renderSidebar() {
    const isDeviceScope = this.store.currentScope === "device";
    const deviceCount = (this.store.state?.system_devices || []).length;
    const discoveredLatterCount = (this.store.state?.discovered_latter_devices || []).length;
    const isDeviceListScope =
      !this.store.deviceSelected ||
      this.store.currentViewId === "select_device_prompt" ||
      this.store.currentViewId === "discovered_devices";
    const managedActive =
      isDeviceScope && isDeviceListScope && this.store.currentViewId !== "discovered_devices";
    const discoveredActive = isDeviceScope && this.store.currentViewId === "discovered_devices";
    return html`<aside class="sidebar">
      <div role="tablist" aria-label=${this.store.t("nav.scope_label")} class="scope-tabs">
        <button
          type="button"
          id="tab-scope-device"
          role="tab"
          aria-selected=${isDeviceScope ? "true" : "false"}
          tabindex=${isDeviceScope ? "0" : "-1"}
          @click=${() => this.store.openDevicesLanding()}
          @keydown=${(ev) => this._onScopeTabKeyDown(ev)}
          class="scope-tab ${isDeviceScope ? "active" : ""}"
        >
          ${this.store.t("nav.devices")}
        </button>
        <button
          type="button"
          id="tab-scope-system"
          role="tab"
          aria-selected=${!isDeviceScope ? "true" : "false"}
          tabindex=${!isDeviceScope ? "0" : "-1"}
          @click=${() => this.store.setScope("system")}
          @keydown=${(ev) => this._onScopeTabKeyDown(ev)}
          class="scope-tab ${!isDeviceScope ? "active" : ""}"
        >
          ${this.store.t("nav.system")}
        </button>
      </div>

      ${!isDeviceScope
        ? html`<nav
            id="nav-scope-system"
            aria-label=${this.store.t("nav.system_pages_label")}
            class="nav-list"
          >
            ${SYSTEM_NAV_ITEMS.map((item) => {
              const active = this.store.currentViewId === item.viewId;
              const slug = SYSTEM_VIEW_SLUGS[item.viewId];
              return html`<a
                href="/latter/system/${slug}"
                data-view=${item.viewId}
                aria-current=${active ? "page" : nothing}
                @click=${(ev) =>
                  this._onNavLinkClick(ev, () => this.store.switchView(item.viewId))}
                class="nav-btn ${active ? "active" : ""}"
              >
                <span>${this.store.t(item.labelKey)}</span>
              </a>`;
            })}
          </nav>`
        : !isDeviceListScope
          ? this._renderDeviceNav()
          : html`<nav
              id="nav-scope-devices-list"
              aria-label=${this.store.t("nav.devices_list_label")}
              class="nav-list"
            >
              <a
                href="/latter/devices"
                data-view="select_device_prompt"
                aria-current=${managedActive ? "page" : nothing}
                @click=${(ev) =>
                  this._onNavLinkClick(ev, () => this.store.openDevicesLanding())}
                class="nav-btn ${managedActive ? "active" : ""}"
              >
                <span>${this.store.t("nav.managed")}</span>
                <span id="nav-system-count" class="nav-badge">
                  ${this.store.state ? String(deviceCount) : this.store.t("common.unknown")}
                </span>
              </a>
              <a
                href="/latter/devices/discovered"
                data-view="discovered_devices"
                aria-current=${discoveredActive ? "page" : nothing}
                @click=${(ev) =>
                  this._onNavLinkClick(ev, () => this.store.openDiscoveredDevices())}
                class="nav-btn ${discoveredActive ? "active" : ""}"
              >
                <span>${this.store.t("nav.discovered")}</span>
                ${discoveredLatterCount > 0
                  ? html`<span id="nav-discovered-count" class="nav-badge">
                      ${String(discoveredLatterCount)}
                    </span>`
                  : nothing}
              </a>
            </nav>`}
    </aside>`;
  }
                     render() {
    const data = this.store.state;
    const isInitialLoading =
      this.store.loading && !data && !this.store.loadError && !this.store.studioRevMismatch;
    const isDevicePendingPayload =
      !isInitialLoading &&
      this.store.currentScope === "device" &&
      this.store.deviceSelected &&
      this.store.deviceLoading;
    const showHeaderUpdate =
      this.store.currentScope === "device" &&
      this.store.deviceSelected &&
      !this.store.deviceLoading &&
      this.store.currentViewId !== "select_device_prompt" &&
      this.store.currentViewId !== "discovered_devices" &&
      Boolean(data?.live?.fw_update_available && data?.live?.fw_update_entity);
    const subtitle = this.store.pageSubtitle;
    const cm = this.store.confirmModal;
    return html`<div
      id="studio-root"
      @keydown=${(ev) => this._onRootKeyDown(ev)}
      class="studio-root ${isInitialLoading ? "is-loading" : ""}"
    >
      <div
        id="studio-live-polite"
        role="status"
        aria-live="polite"
        aria-atomic="true"
        class="sr-only"
      >
        ${this.store.politeAnnouncement}
      </div>
      <div
        id="studio-live-assertive"
        role="alert"
        aria-live="assertive"
        aria-atomic="true"
        class="sr-only"
      >
        ${this.store.assertiveAnnouncement}
      </div>

      ${this.store.studioRevMismatch
        ? html`<div role="status" class="studio-rev-banner">
            <span>${this.store.t("shell.rev_updated_banner")}</span>
            <button
              type="button"
              @click=${() => this.store.reloadPage()}
              class="btn btn-primary btn-compact"
            >
              ${this.store.t("shell.reload_page")}
            </button>
          </div>`
        : nothing}

      <header class="latter-top-titlebar">
        <div class="titlebar-brand">
          <button
            type="button"
            aria-label=${this.store.t("shell.toggle_ha_sidebar")}
            @click=${() => this.store.toggleParentHaSidebar()}
            class="btn-icon ha-menu-btn"
          >
            <svg viewBox="0 0 24 24" aria-hidden="true">
              <path d="M3 6h18v2H3V6m0 5h18v2H3v-2m0 5h18v2H3v-2Z" />
            </svg>
          </button>
          <span class="titlebar-title">${this.store.t("shell.title")}</span>
        </div>
        <div class="titlebar-actions">
          ${showHeaderUpdate
            ? html`<button
                type="button"
                id="hdr-update-pill"
                @click=${() => void this.store.entity.triggerHeaderFirmwareUpdate()}
                class="btn btn-secondary btn-compact"
              >
                ${this.store.t("shell.install_update")}
              </button>`
            : nothing}
        </div>
      </header>

      <div class="app-shell">
        ${this._renderSidebar()}

        <main
          class="main-area"
          @focusin=${(ev) => this.store.onMainFocusIn(ev)}
          @focusout=${(ev) => this._onMainFocusOut(ev)}
        >
          <div class="content-wrap">
            <h1 id="unified-page-title" tabindex="-1" class="page-title">
              <span>${this.store.pageTitle}</span>
              ${subtitle ? html`<span class="page-subtitle">${subtitle}</span>` : nothing}
            </h1>

            ${isInitialLoading
              ? html`<div id="studio-loading" role="status" class="loading-state">
                  ${this.store.t("shell.loading")}
                </div>`
              : nothing}

            ${!data && this.store.loadError
              ? html`<div id="studio-load-error" role="alert" class="alert alert-error">
                  <span id="studio-load-error-text">${this.store.loadError}</span>
                  <button
                    type="button"
                    @click=${() => void this.store.refreshState()}
                    class="btn btn-secondary btn-compact"
                  >
                    ${this.store.t("shell.retry")}
                  </button>
                </div>`
              : nothing}

            ${isDevicePendingPayload
              ? html`<div id="studio-device-loading" role="status" class="loading-state">
                  ${this.store.t("shell.loading_device")}
                </div>`
              : data
                ? renderActiveView(this.store)
                : nothing}
          </div>
        </main>
      </div>

      ${renderStudioDialogs(this.store)}
      ${renderConfirmDialog({
        id: "latter-confirm-modal",
        open: cm.open,
        title: cm.title,
        consequence: cm.consequence,
        blastRadiusCount: cm.blastRadiusCount,
        blastRadiusLabel: cm.blastRadiusLabel || undefined,
        confirmLabel: cm.confirmLabel || this.store.t("action.confirm"),
        cancelLabel: cm.cancelLabel || this.store.t("action.cancel"),
        danger: cm.danger,
        busy: cm.busy,
        confirmButtonId: "btn-confirm-modal-accept",
        onConfirm: () => void this.store.runConfirmedAction(),
        onCancel: () => this.store.closeConfirm(),
        onDownloadBackupFirst: cm.onDownloadBackupFirst
          ? () => void cm.onDownloadBackupFirst?.()
          : null,
        overlay: this.store.localeOverlay,
      })}

      ${this.store.toastMessage
        ? html`<div class="toast ${this.store.toastIsError ? "error" : ""}">
            <span>${this.store.toastMessage}</span>
            ${this.store.toastIsError
              ? html`<button
                  type="button"
                  aria-label=${this.store.t("shell.dismiss_toast")}
                  @click=${() => this.store.dismissToast()}
                  class="btn btn-text btn-compact"
                >
                  ${this.store.t("action.dismiss")}
                </button>`
              : nothing}
          </div>`
        : nothing}
    </div>`;
  }
}
if (!customElements.get("latter-studio")) {
  customElements.define("latter-studio", LatterStudio);
}
__latterExp(__exports, { LatterStudio: () => LatterStudio });
//# sourceURL=latter-studio/src/latter-studio.ts
});
const __latterEntry = __latterReq("src/latter-studio.ts");
export const LatterStudio = __latterEntry.LatterStudio;
